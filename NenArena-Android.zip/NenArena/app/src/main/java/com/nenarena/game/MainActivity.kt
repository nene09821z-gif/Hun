package com.nenarena.game

import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.ApplicationInfo
import android.graphics.Color as AColor
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Spacer
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import kotlinx.coroutines.delay

private const val GAME_URL = "https://appassets.androidplatform.net/assets/index.html"
private const val HOST = "appassets.androidplatform.net"

/** Game đã nạp xong khi màn hình loading của game tắt và three.js tồn tại. */
private const val READY_JS =
    "(function(){var l=document.getElementById('loading');" +
        "return !!l&&!l.classList.contains('on')&&typeof THREE!=='undefined'})()"

/** Nút Back: đang chơi -> tạm dừng, đang tạm dừng -> tiếp tục, chọn nhân vật -> quay lại, còn lại -> thoát. */
private const val BACK_JS =
    "(function(){function on(i){var e=document.getElementById(i);return !!e&&e.classList.contains('on')}" +
        "function c(i){document.getElementById(i).click()}" +
        "if(on('how')){c('btnHowOk');return 'how'}" +
        "if(on('gfx')){c('gfxOk');return 'gfx'}" +
        "if(on('pause')){c('pResume');return 'resume'}" +
        "if(on('hud')){c('btnPause');return 'pause'}" +
        "if(on('over')){c('oSel');return 'over'}" +
        "if(on('select')){c('selBack');return 'back'}" +
        "return 'exit'})()"

/** Tự động tạm dừng khi app ra nền. */
private const val PAUSE_JS =
    "(function(){var h=document.getElementById('hud');" +
        "if(h&&h.classList.contains('on')&&!document.getElementById('pause').classList.contains('on'))" +
        "document.getElementById('btnPause').click()})()"

class MainActivity : ComponentActivity() {

    private var web: WebView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideSystemBars()
        setContent {
            NenArenaApp(onWebView = { web = it }, onExit = { finish() })
        }
    }

    private fun hideSystemBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemBars()
    }

    override fun onPause() {
        web?.evaluateJavascript(PAUSE_JS, null)
        web?.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        web?.onResume()
    }

    override fun onDestroy() {
        web?.let {
            (it.parent as? ViewGroup)?.removeView(it)
            it.destroy()
        }
        web = null
        super.onDestroy()
    }
}

@Composable
fun NenArenaApp(onWebView: (WebView) -> Unit, onExit: () -> Unit) {
    var ready by remember { mutableStateOf(false) }
    var webRef by remember { mutableStateOf<WebView?>(null) }

    BackHandler {
        val w = webRef
        if (w == null) onExit()
        else w.evaluateJavascript(BACK_JS) { r -> if (r?.contains("exit") == true) onExit() }
    }

    // Chờ game báo đã nạp xong (tối đa 25 giây) rồi mới tắt màn hình chờ
    LaunchedEffect(webRef) {
        val w = webRef ?: return@LaunchedEffect
        var waited = 0
        while (!ready && waited < 25_000) {
            delay(250)
            waited += 250
            w.evaluateJavascript(READY_JS) { r -> if (r == "true") ready = true }
        }
        ready = true
    }

    Box(Modifier.fillMaxSize().background(Color(0xFF07040F))) {
        GameWebView(
            onCreated = {
                webRef = it
                onWebView(it)
            }
        )
        AnimatedVisibility(visible = !ready, exit = fadeOut(tween(450))) {
            Splash()
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun GameWebView(onCreated: (WebView) -> Unit) {
    val ctx = LocalContext.current
    val loader = remember {
        WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(ctx))
            .build()
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            if (c.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) {
                WebView.setWebContentsDebuggingEnabled(true)
            }
            WebView(c).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                setBackgroundColor(AColor.parseColor("#07040F"))
                overScrollMode = View.OVER_SCROLL_NEVER
                isVerticalScrollBarEnabled = false
                isHorizontalScrollBarEnabled = false
                isLongClickable = false
                setOnLongClickListener { true }
                setLayerType(View.LAYER_TYPE_HARDWARE, null)

                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    allowFileAccess = false
                    allowContentAccess = false
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                    useWideViewPort = true
                    loadWithOverviewMode = true
                    cacheMode = WebSettings.LOAD_DEFAULT
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                    textZoom = 100
                }

                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView,
                        request: WebResourceRequest
                    ): WebResourceResponse? = loader.shouldInterceptRequest(request.url)

                    // Không cho trang tự điều hướng ra ngoài game
                    override fun shouldOverrideUrlLoading(
                        view: WebView,
                        request: WebResourceRequest
                    ): Boolean = request.url.host != HOST

                    override fun onRenderProcessGone(
                        view: WebView,
                        detail: RenderProcessGoneDetail
                    ): Boolean {
                        (c as? Activity)?.recreate()
                        return true
                    }
                }
                loadUrl(GAME_URL)
                onCreated(this)
            }
        }
    )
}

@Composable
private fun Splash() {
    val t = rememberInfiniteTransition(label = "splash")
    val pulse by t.animateFloat(
        initialValue = .55f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(listOf(Color(0xFF2B0D42), Color(0xFF07040F)))
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Text(
                "HUNTER × HUNTER · FAN GAME",
                color = Color(0xFFFFB0DD),
                style = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 4.sp)
            )
            Spacer(Modifier.height(6.dp))
            Text(
                "NEN ARENA",
                modifier = Modifier.alpha(pulse),
                textAlign = TextAlign.Center,
                style = TextStyle(
                    fontSize = 44.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 3.sp,
                    brush = Brush.verticalGradient(listOf(Color.White, Color(0xFFFF6FB7), Color(0xFF7A2CFF)))
                )
            )
            Spacer(Modifier.height(16.dp))
            LinearProgressIndicator(
                modifier = Modifier.width(200.dp),
                color = Color(0xFFFF3FA0),
                trackColor = Color(0xFF222222)
            )
            Spacer(Modifier.height(10.dp))
            Text(
                "ĐANG TẢI ĐẠI CHIẾN KIẾN CHIMERA",
                color = Color(0xFFFFD27A),
                style = TextStyle(fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            )
        }
    }
}
