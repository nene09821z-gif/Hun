# NEN ARENA – Đại Chiến Kiến Chimera (Android · Kotlin + Jetpack Compose)

Game Hunter × Hunter 3D (three.js) đóng gói thành app Android.
Giao diện app viết bằng **Kotlin + Jetpack Compose** (màn hình chờ, nút Back, vòng đời, toàn màn hình),
phần đồ hoạ 3D chạy bằng **three.js r149 được đóng gói sẵn trong APK** nên chơi được cả khi không có mạng.

## Cấu trúc
- `app/src/main/assets/index.html` – toàn bộ game (đã trỏ sang `three.min.js` cục bộ)
- `app/src/main/assets/three.min.js` – three.js r149
- `app/src/main/java/com/nenarena/game/MainActivity.kt` – Compose + WebView
- `.github/workflows/main.yml` – tự build APK

## Build bằng GitHub
1. Tạo repo mới, đẩy toàn bộ thư mục này lên nhánh `main`.
2. Vào tab **Actions** → workflow **Build NEN ARENA APK** tự chạy (hoặc bấm *Run workflow*).
3. Xong, tải file ở mục **Artifacts → NenArena-APK** (`NenArena-debug.apk`, `NenArena-release.apk`).
4. Muốn đăng bản phát hành: tạo tag `v1.0` – APK tự được đính kèm vào Release.

## Build trên máy
Cần JDK 17 + Android SDK 34 + Gradle 8.9:
```
gradle assembleDebug
```
APK nằm ở `app/build/outputs/apk/debug/`.

## Điều khiển
Cần trái di chuyển · nút lớn bên phải đánh · 2 nút nhỏ + ULT dùng chiêu · vuốt bên phải xoay camera.
Nút Back: tạm dừng / tiếp tục / quay lại menu.
