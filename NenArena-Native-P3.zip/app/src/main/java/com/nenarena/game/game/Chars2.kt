package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)

private fun hairCap(h: Human, c: Material, y: Float = .15f, z: Float = -.01f, rx: Float = -.2f) =
    h.mkk(Geometry.sphere(.215f, 14, 10, 0f, TAU, 0f, PIF * .6f), c, h.head, 0f, y, z, rx = rx)

private fun spikes(h: Human, c: Material, a: Array<FloatArray>, w: Float = .075f) {
    for (s in a) h.mkk(cone(w, if (s.size > 5) s[5] else .32f, 6), c, h.head, s[0], s[1], s[2], rx = s[3], rz = s[4])
}

private const val DP = 0x8a2cff
private const val DR = 0xff2a5a

// ======================= GON =======================
fun buildGon(): Human {
    val h = buildHuman(HumanOpts(s = .74f, skin = 0xe8b48c, top = 0x2f9a4a, bottom = 0x2f9a4a, shoe = 0x5a3a20, legLow = 0xe8b48c))
    val hr = h.mt(0x16241a)
    hairCap(h, hr)
    spikes(h, hr, arrayOf(
        floatArrayOf(0f, .4f, 0f, 0f, 0f), floatArrayOf(.1f, .38f, 0f, 0f, -.5f), floatArrayOf(-.1f, .38f, 0f, 0f, .5f),
        floatArrayOf(.17f, .32f, -.03f, 0f, -.95f), floatArrayOf(-.17f, .32f, -.03f, 0f, .95f), floatArrayOf(0f, .36f, -.1f, -.5f, 0f),
        floatArrayOf(.08f, .34f, .04f, .4f, -.3f), floatArrayOf(-.08f, .34f, .04f, .4f, .3f)))
    humanEyes(h, 0x6a3a10, .042f, .15f, .08f)
    h.mkk(Geometry.torus(.2f, .03f, 6, 14), h.mt(0xf0c030), h.torso, 0f, .66f, 0f, rx = PIF / 2)
    h.mkk(cyl(.285f, .285f, .07f, 12), h.mt(0x5a3a20), h.torso, 0f, .02f, 0f)
    // cần câu
    val rod = Node(); h.elR.add(rod)
    mk(cyl(.02f, .012f, 1.25f, 5), basic(0x8a5a2a), rod, 0f, -1.02f, 0f, outline = false)
    mk(cyl(.03f, .03f, .16f, 6), basic(0x3a2418), rod, 0f, -.48f, 0f, outline = false)
    mk(sph(.05f, 8, 6), basic(0xff7a30), rod, 0f, -1.68f, 0f, outline = false)
    mk(cyl(.004f, .004f, .5f, 3), basic(0xe8f4c8), rod, 0f, -1.9f, 0f, outline = false)
    // mắt đỏ khi hắc hoá
    val dk = ArrayList<Node>()
    for (s in listOf(-1f, 1f)) { val m = mk(sph(.05f, 8, 6), basic(0xff2040), h.head, s * .08f, .15f, .186f, outline = false); m.visible = false; dk.add(m) }
    h.dkEyes = dk
    addAura(h, 0x3ddc5a, 0xc8ffb0)
    return h
}

private fun Game.gonAtk() {
    val d = aim()
    if (P.dk > 0f) {
        act("punch", .2f, P.combo % 2 == 1); P.atkCd = .2f; SFX.swing()
        for (a in floatArrayOf(-.28f, 0f, .28f)) {
            val m = Node(); m.geo = fx.gOrb; m.mat = addMat(DP, .95f); m.scl.set(1.3f, 1.3f, 1.8f)
            shoot(m, hand(1.3f, .9f), rotY(d, a), 34f, 9f, 1f, .28f, 'p', 2, DP, 0f, null, 0f, 1.2f)
        }
        P.combo++; return
    }
    val rt = if (P.combo % 3 == 2) nearest(P.pos, 13f) else null
    if (rt != null) {
        act("throw", .3f); P.atkCd = .4f; SFX.skill()
        val A = { hand(1.5f, .9f) }; val Bp = { Vec3(rt.pos.x, 1.2f + rt.hover, rt.pos.z) }
        fx.beam(A, Bp, 0xe8f4c8, .45f, .05f)
        val m = addMat(0xff7a30, 1f); val lu = Node(); lu.geo = fx.gOrb; lu.mat = m; lu.setScale(.5f)
        fx.add(lu, .45f, m) { k, o, _ -> o.pos.copy(A().lerpTo(Bp(), min(1f, k * 3f))) }
        later(.14f) {
            if (!rt.dead) {
                setPull(rt, Vec3(P.pos.x + d.x * 2.2f, 0f, P.pos.z + d.z * 2.2f), .3f)
                later(.32f) { if (!rt.dead) { hurtE(rt, 20f, Hit(col = 0xff7a30, knock = 1.5f, stun = .7f, big = true, from = P.pos)); fx.ring(rt.pos.x, rt.pos.z, 0xff7a30, .4f, 3f, .3f) } }
            }
        }
        P.combo++; return
    }
    act("punch", .22f, P.combo % 2 == 1); P.atkCd = .26f; SFX.swing()
    val m = Node(); m.geo = fx.gOrb; m.mat = addMat(0x3ddc5a, .9f); m.scl.set(1.1f, 1.1f, 1.4f)
    shoot(m, hand(1.3f, .9f), d, 30f, 9f, .9f, .22f, 'p', 2, 0x3ddc5a, 0f, null, 0f, .8f)
    P.combo++
}

private fun Game.gonS1(): Boolean {
    val d = aim(14f); P.cast = .35f; act("slash", .35f); SFX.skill(); val o = P.pos.clone()
    if (P.dk > 0f) {
        for ((i, a) in floatArrayOf(-.35f, 0f, .35f).withIndex()) {
            val dd = rotY(d, a); val ag = atan2(dd.x, dd.z); val q = Vec3(o.x + dd.x * 6, 1.3f, o.z + dd.z * 6)
            fx.slash(q.x, 1.3f, q.z, ag + .5f, DP, 8f, .35f); fx.slash(q.x, 1.3f, q.z, ag - .5f, DR, 8f, .35f)
            later(.06f + i * .05f) { lineHit(o, dd, 11f, 2f) { e -> hurtE(e, 42f, Hit(knock = 3.5f, stun = .5f, big = true, from = o, col = DP)) } }
        }
        later(.1f) { shake = .5f; SFX.boom() }; return true
    }
    val a = atan2(d.x, d.z); val q = Vec3(o.x + d.x * 5, 1.3f, o.z + d.z * 5)
    fx.slash(q.x, 1.3f, q.z, a + .5f, 0x3ddc5a, 7f, .35f); fx.slash(q.x, 1.3f, q.z, a - .5f, 0xc8ffb0, 7f, .35f)
    later(.08f) { lineHit(o, d, 11f, 2f) { e -> hurtE(e, 40f, Hit(knock = 3f, stun = .4f, big = true, from = o, hs = .05f)) }; shake = .3f; SFX.boom() }
    return true
}

private fun Game.gonS2(): Boolean {
    val t = nearest(P.pos, 16f); val d = aim(16f); val dark = P.dk > 0f
    P.cast = if (dark) .6f else .7f; P.inv = P.cast; act("punch", P.cast); SFX.skill(); P.auraBoost = if (dark) 2f else 1.5f
    if (!dark) fx.ring(P.pos.x, P.pos.z, 0x3ddc5a, 2.5f, .5f, .5f)
    val L = if (t != null) max(1f, dxz(P.pos, t.pos) - 1.6f) else if (dark) 6f else 5f
    later(if (dark) .35f else .45f) {
        val tm = if (dark) .16f else .18f
        P.lunge = Lunge(d.clone(), L / tm, tm, end = {
            val c = P.pos.clone().addScaled(d, 1.6f); SFX.boom()
            if (dark) {
                shake = 1.1f; flash(DP, .5f, 300); crackFx(c.x, c.z, 9f, DP); fx.ring(c.x, c.z, DR, .5f, 9f, .5f); fx.dome(c.x, 1.3f, c.z, DP, .5f, 8f, .45f); popText("HẮC GUU!", DR)
                radiusHit(c, 6.5f) { e -> hurtE(e, 100f, Hit(knock = 6f, stun = 1.4f, big = true, from = c, hs = .12f, col = DP)) }
            } else {
                shake = .8f; flash(0xc8ffb0, .4f, 300); fx.ring(c.x, c.z, 0x3ddc5a, .5f, 7f, .45f); fx.dome(c.x, 1.2f, c.z, 0x3ddc5a, .5f, 6f, .4f); popText("GUU!", 0xc8ffb0)
                radiusHit(c, 5f) { e -> hurtE(e, 75f, Hit(knock = 5f, stun = 1f, big = true, from = c, hs = .1f)) }
            }
        })
    }
    return true
}

private fun Game.gonUlt(): Boolean {
    val o = P.pos.clone()
    if (P.dk > 0f) {
        P.cast = 1.3f; P.inv = 1.5f; act("raise", 1.3f); SFX.ult(); slowmo(.4f, .6f); flash(DP, .4f, 400)
        for (i in 0 until 24) later(i * .03f) { val h = hand(1.2f, .3f); emit(h.x + rnd(-.8f, .8f), h.y, h.z + rnd(-.8f, .8f), 0f, rnd(3f, 7f), 0f, .6f, .5f, .1f, if (i % 2 == 1) DR else DP, 0f, 1f) }
        later(.9f) {
            SFX.boom(); shake = 1.6f; flash(0xffffff, .8f, 500); popText("HẮC PAA!", DR)
            for (k in 0 until 4) fx.ring(o.x, o.z, if (k % 2 == 1) DR else DP, 1f, 16f + k * 3, .6f + k * .1f)
            fx.dome(o.x, 1.5f, o.z, DP, 1f, 17f, .6f)
            radiusHit(o, 14f) { e -> hurtE(e, 160f, Hit(knock = 8f, stun = 1.5f, big = true, from = o, hs = .12f, gain = 0f, col = DP)) }
            P.dk = min(P.dk + 3f, 20f)
        }
        return true
    }
    P.cast = 1.6f; P.inv = 1.8f; act("raise", 1.6f); SFX.ult(); slowmo(.45f, .6f); P.auraBoost = 2.5f; flash(0x3ddc5a, .35f, 400)
    val d = aim(30f)
    for (i in 0 until 30) later(i * .03f) { val h = hand(1.2f, .3f); emit(h.x + rnd(-.6f, .6f), h.y, h.z + rnd(-.6f, .6f), 0f, rnd(3f, 7f), 0f, .6f, .5f, .1f, if (i % 2 == 1) 0xc8ffb0 else 0x3ddc5a, 0f, 1f) }
    later(1f) {
        SFX.boom(); shake = 1.2f; flash(0xffffff, .7f, 500); popText("PAA!", 0xc8ffb0)
        val A = hand(1.4f, .8f); val Bp = Vec3(o.x + d.x * 28, 1.4f, o.z + d.z * 28)
        fx.beam({ A }, { Bp }, 0xc8ffb0, .7f, 2.4f); fx.beam({ A }, { Bp }, 0x3ddc5a, .9f, 4.5f); fx.ring(o.x, o.z, 0x3ddc5a, 1f, 10f, .6f)
        lineHit(o, d, 28f, 4f) { e -> hurtE(e, 130f, Hit(knock = 6f, stun = 1.2f, big = true, from = o, hs = .1f, gain = 0f)) }
        P.dmgBuff = 1.4f; P.dmgBuffT = 8f; P.speedBuf = 8f; P.auraBoost = 3f
    }
    later(1.05f) {
        if (!P.dead && P.cfg.id == "gon") {
            P.dk = 15f; flash(DP, .6f, 500); shake = 1f
            fx.ring(P.pos.x, P.pos.z, DP, 1f, 12f, .7f); fx.dome(P.pos.x, 1.4f, P.pos.z, DR, .5f, 8f, .6f); burst(P.pos.x, 1.2f, P.pos.z, DP, 40, 9f, .7f, .9f)
            popText("HẮC HOÁ!", DP); toast("Gon Hắc Hoá: đổi 3 chiêu thành bản hắc ám, hao máu dần", 3f)
        }
    }
    return true
}

private fun Game.gon(): CharCfg {
    val c = CharCfg(
        "gon", "GON FREECSS", "✊", "Cường Hoá (Enhancement) · Hạng B+", 0x3ddc5a, 0xc8ffb0, 115f, 8f, 1.05f, 1.2f, 1f, 0f,
        "Cậu bé thợ săn bền bỉ, dồn toàn bộ aura vào một đòn duy nhất: Jajanken Đá – Kéo – Giấy.",
        "Nội tại: Bất khuất, nạp Nen nhanh hơn 20%.", intArrayOf(4, 5, 3, 3),
        listOf(
            Skill("Quyền Cương · Cần Câu", "🎣", "ĐẤM", 0f, "Phóng cú đấm aura xanh xuyên 2 kẻ địch. Mỗi đòn thứ 3 quăng cần câu móc địch kéo sát người rồi giáng đòn."),
            Skill("Jajanken: Choki (Kéo)", "✌️", "KÉO", 4f, "Hai lưỡi kéo aura chém chéo thành đường dài, hất văng mọi kẻ trên đường."),
            Skill("Jajanken: Guu (Đá)", "✊", "ĐÁ", 8f, "Dồn aura vào nắm đấm, lao tới và đấm nổ một phát sát thương cực lớn, gây choáng."),
            Skill("Gon Rage: Paa (Giấy)", "🖐️", "ULT", 0f, "Xả luồng aura khổng lồ rồi HẮC HOÁ 15 giây: +30% sát thương, +12% tốc độ, đổi Đấm/Kéo/Đá thành bản hắc ám. Khi đang hắc hoá, ULT thành Hắc Paa quét 360° và kéo dài thêm 3 giây. Cái giá: hao máu khá nhanh (không tự chết).")
        ),
        sigWrap("gon", 0x3ddc5a, ::buildGon), { gonAtk() }, { gonS1() }, { gonS2() }, { gonUlt() })
    c.tick = { dt ->
        val d = P.dk > 0f; P.h.dkOn = d
        if (d) {
            P.spdMul = 1.12f; P.dmgBuff = max(P.dmgBuff, 1.3f); P.dmgBuffT = max(P.dmgBuffT, .2f); P.speedBuf = max(P.speedBuf, .2f)
            P.dk -= dt; P.atkCd -= dt * .2f; P.cd[1] = max(0f, P.cd[1] - dt * .3f); P.cd[2] = max(0f, P.cd[2] - dt * .3f)
            P.auraBoost = max(P.auraBoost, 1.1f); P.hp = max(1f, P.hp - dt * P.maxHp * .025f)
            if (P.dk <= 0f) { P.dk = 0f; popText("Hết Hắc Hoá", DP); burst(P.pos.x, 1.2f, P.pos.z, DP, 26, 7f, .5f, .7f); flash(DP, .3f, 300) }
        }
    }
    return c
}

// ======================= KILLUA =======================
fun buildKillua(): Human {
    val h = buildHuman(HumanOpts(s = .76f, skin = 0xf4e8e2, top = 0x3a3f96, bottom = 0x23263f, shoe = 0x15151f))
    val hr = h.mt(0xe6eef8)
    hairCap(h, hr, .15f, -.01f, -.25f)
    spikes(h, hr, arrayOf(
        floatArrayOf(0f, .4f, 0f, -.2f, 0f), floatArrayOf(.12f, .36f, 0f, 0f, -.7f), floatArrayOf(-.12f, .36f, 0f, 0f, .7f),
        floatArrayOf(.18f, .3f, -.03f, 0f, -1.1f), floatArrayOf(-.18f, .3f, -.03f, 0f, 1.1f), floatArrayOf(0f, .34f, -.12f, -.8f, 0f),
        floatArrayOf(.1f, .3f, -.12f, -.7f, -.5f), floatArrayOf(-.1f, .3f, -.12f, -.7f, .5f), floatArrayOf(.05f, .42f, .06f, .9f, -.2f)))
    humanEyes(h, 0x38b8ff, .044f, .15f, .08f)
    for (s in listOf(-1f, 1f)) mk(box(.1f, .016f, .02f), basic(0x23263f), h.head, s * .08f, .215f, .18f, rz = s * .35f, outline = false)
    h.mkk(Geometry.torus(.2f, .025f, 6, 14), h.mt(0x23263f), h.torso, 0f, .66f, 0f, rx = PIF / 2)
    for (a in listOf(h.elL, h.elR)) {
        mk(cyl(.11f, .11f, .06f, 14), basic(0xcfd6e0), a, 0f, -.5f, .02f, rz = PIF / 2, outline = false)
        mk(cyl(.115f, .115f, .025f, 14), basic(0x38b8ff), a, 0f, -.5f, .02f, rz = PIF / 2, outline = false)
        mk(cyl(.005f, .005f, .5f, 3), basic(0xffffff), a, 0f, -.78f, .02f, outline = false)
    }
    addAura(h, 0x7ae6ff, 0xffffff)
    return h
}

private fun Game.killuaAtk() {
    if (P.assassin > 0f && assassinate(70f)) return
    val d = aim()
    if (P.combo % 3 == 2) {
        act("throw", .3f); P.atkCd = .34f; SFX.swing(); val o = P.pos.clone()
        val m = addMat(0xcfe8ff, .95f); val Y = Node(); Y.geo = Geometry.cylinder(.24f, .24f, .1f, 14); Y.mat = m; Y.rot.z = PIF / 2
        fx.add(Y, .5f, m) { k, n, dt -> n.pos.copy(hand(1.3f, .7f)).addScaled(d, 7f * sin(min(1f, k) * PIF)); n.rot.x += 42f * dt }
        fx.beam({ hand(1.3f, .7f) }, { Y.pos }, 0xffffff, .5f, .04f)
        for (t in floatArrayOf(.12f, .36f)) later(t) {
            lineHit(o, d, 7.5f, 1.5f) { e -> hurtE(e, 13f, Hit(col = 0x7ae6ff, knock = 1.2f, stun = .25f, from = o)) }
            fx.ring(o.x + d.x * 6, o.z + d.z * 6, 0x7ae6ff, .3f, 2f, .2f)
        }
        P.combo++; return
    }
    act("punch", .2f, P.combo % 2 == 1); P.atkCd = .18f; SFX.swing()
    val m = Node(); m.geo = needleGeo; m.mat = addMat(0x7ae6ff, .95f); m.scl.set(2.2f, 2.2f, 1.6f)
    shoot(m, hand(1.3f, .8f), rotY(d, rnd(-.08f, .08f)), 44f, 6f, .7f, .4f, 'p', 1, 0x7ae6ff, 3f, null, 0f, .3f)
    P.combo++
}

private fun Game.killuaS1(): Boolean {
    val t0 = nearest(P.pos, 20f) ?: return false
    P.cast = .4f; act("throw", .35f); SFX.skill()
    val hit = HashSet<Enemy>(); hit.add(t0); val ch = ArrayList<Enemy>(); ch.add(t0); var cur = t0
    for (i in 0 until 4) {
        var b: Enemy? = null; var bd = 9f
        for (e in EN) { if (e.dead || e.team != 'e' || e.spawnT > 0f || hit.contains(e)) continue; val dd = dxz(e.pos, cur.pos); if (dd < bd) { bd = dd; b = e } }
        if (b == null) break
        hit.add(b); ch.add(b); cur = b
    }
    var prev: Vec3? = null
    for ((i, e) in ch.withIndex()) later(.06f + i * .1f) {
        if (!e.dead) {
            val A = prev?.clone() ?: hand(1.4f, .8f); val Bp = Vec3(e.pos.x, 1.3f + e.hover, e.pos.z)
            fx.beam({ A }, { Bp }, 0x7ae6ff, .3f, .22f); fx.beam({ A }, { Bp }, 0xffffff, .15f, .08f)
            fx.ring(e.pos.x, e.pos.z, 0x7ae6ff, .4f, 3f, .3f)
            hurtE(e, 32f, Hit(col = 0x7ae6ff, stun = .8f, big = true, knock = 1f, from = P.pos)); prev = Bp; SFX.hit()
        }
    }
    return true
}

private fun Game.killuaS2(): Boolean {
    val d = aim(22f); P.cast = .35f; P.inv = .6f; act("punch", .3f); SFX.dash(); SFX.skill(); val o = P.pos.clone()
    for (i in 0 until 10) {
        val q = Vec3(o.x + d.x * i * 1.5f, 0f, o.z + d.z * i * 1.5f)
        later(i * .02f) { burst(q.x, 1f, q.z, 0x7ae6ff, 6, 3f, .3f, .5f); fx.ring(q.x, q.z, 0x7ae6ff, .3f, 1.6f, .25f) }
    }
    lineHit(o, d, 15f, 2f) { e -> hurtE(e, 48f, Hit(col = 0x7ae6ff, knock = 3f, stun = .6f, big = true, from = o, hs = .06f)) }
    P.lunge = Lunge(d.clone(), 15f / .2f, .2f, end = { P.speedBuf = 2.5f; P.critN = 2; fx.ring(P.pos.x, P.pos.z, 0xffffff, .5f, 5f, .35f); shake = .3f })
    return true
}

private fun Game.killuaUlt(): Boolean {
    val list = EN.filter { !it.dead && it.team == 'e' && it.spawnT <= 0f && dxz(it.pos, P.pos) < 24f }
    P.gs = 30f; P.gsT = 0f
    P.cast = if (list.isNotEmpty()) 2f else .6f; P.inv = 2.2f; act("raise", .6f); SFX.ult(); slowmo(.4f, .5f); flash(0x7ae6ff, .4f, 300); P.auraBoost = 2.5f; popText("Godspeed!", 0x7ae6ff)
    for (i in 0 until 12) later(.35f + i * .11f) {
        val c = list.filter { !it.dead }; if (c.isEmpty()) return@later
        val e = c[rndi(c.size)]; val a = rnd(0f, TAU); val from = Vec3(P.pos.x, 1.2f, P.pos.z)
        P.pos.set(e.pos.x + cos(a) * 1.8f, 0f, e.pos.z + sin(a) * 1.8f); clampArena(P.pos, 1f); P.face = atan2(e.pos.x - P.pos.x, e.pos.z - P.pos.z); act("punch", .1f, i % 2 == 1)
        val to = Vec3(P.pos.x, 1.2f, P.pos.z)
        fx.beam({ from }, { to }, 0x7ae6ff, .25f, .3f); fx.ring(e.pos.x, e.pos.z, 0x7ae6ff, .4f, 3f, .25f); burst(e.pos.x, 1.3f, e.pos.z, 0xffffff, 10, 6f, .3f, .6f); SFX.hit()
        hurtE(e, 24f, Hit(col = 0x7ae6ff, knock = 1.2f, stun = .4f, big = i % 3 == 0, from = P.pos, gain = .3f))
    }
    later(1.8f) {
        val c = P.pos.clone(); SFX.boom(); shake = 1f; flash(0xffffff, .8f, 500)
        fx.pillar(c.x, c.z, 0x7ae6ff, 2.5f, 30f, .7f); fx.ring(c.x, c.z, 0x7ae6ff, 1f, 13f, .7f); fx.dome(c.x, 1f, c.z, 0x7ae6ff, 1f, 10f, .5f)
        radiusHit(c, 9f) { e -> hurtE(e, 55f, Hit(col = 0x7ae6ff, knock = 4f, stun = 1f, big = true, from = c, hs = .08f, gain = 0f)) }
    }
    return true
}

private fun Game.killua(): CharCfg {
    val c = CharCfg(
        "killua", "KILLUA ZOLDYCK", "⚡", "Biến Hoá (Transmutation) · Hạng B+", 0x7ae6ff, 0xffffff, 100f, 9.2f, 1.05f, 1f, 1f, .1f,
        "Sát thủ nhí nhà Zoldyck, biến aura thành điện. Nhanh đến mức địch chỉ thấy tàn ảnh.",
        "Nội tại: Ám sát Zoldyck. Lướt (Dash) để ẩn mình 2,4 giây, đòn thường kế tiếp dịch chuyển ra sau lưng địch, gây 70 sát thương chí mạng và choáng.",
        intArrayOf(3, 5, 2, 4),
        listOf(
            Skill("Lôi Trảo · Yo-yo", "🪀", "VUỐT", 0f, "Phóng liên tục tia điện sắc như móng. Mỗi đòn thứ 3 quăng yo-yo điện đi và về, trúng 2 lần."),
            Skill("Thunderbolt (Lôi Kích)", "⚡", "SÉT", 5f, "Tia sét nảy qua tối đa 5 kẻ địch gần nhau, mỗi lần trúng gây choáng."),
            Skill("Godspeed (Thần Tốc)", "💨", "TỐC", 8f, "Lao xuyên qua địch với tốc độ ánh sáng, để lại vệt điện. 2 đòn sau đó chí mạng."),
            Skill("Godspeed: Thần Lôi", "🌩️", "ULT", 0f, "Bật Godspeed 30 giây: chạy +75%, đánh và hồi chiêu nhanh hơn, +15% sát thương, tự giáng sét vào địch gần. Mở màn bằng 12 đòn dịch chuyển và một cú sét lớn. Hết 30 giây là tắt.")
        ),
        sigWrap("killua", 0x7ae6ff, ::buildKillua), { killuaAtk() }, { killuaS1() }, { killuaS2() }, { killuaUlt() })
    c.tick = { dt ->
        val g = P.gs > 0f; P.h.gsOn = g
        if (g) {
            P.spdMul = 1.3f; P.speedBuf = max(P.speedBuf, .2f); P.dmgBuff = max(P.dmgBuff, 1.15f); P.dmgBuffT = max(P.dmgBuffT, .2f)
            P.gs -= dt; P.atkCd -= dt * .6f; P.cd[1] = max(0f, P.cd[1] - dt * .7f); P.cd[2] = max(0f, P.cd[2] - dt * .7f); P.auraBoost = max(P.auraBoost, .8f)
            P.gsT -= dt
            if (P.gsT <= 0f) {
                P.gsT = .9f; val e = nearest(P.pos, 9f)
                if (e != null) {
                    val T = Vec3(e.pos.x, 1.2f, e.pos.z); val sky = Vec3(T.x, 12f, T.z)
                    fx.beam({ sky }, { T }, 0x7ae6ff, .25f, .25f); fx.ring(e.pos.x, e.pos.z, 0x7ae6ff, .4f, 2.6f, .25f)
                    hurtE(e, 14f, Hit(col = 0x7ae6ff, stun = .3f, from = P.pos, gain = .3f)); SFX.hit()
                }
            }
            if (P.gs <= 0f) { P.gs = 0f; popText("Hết Godspeed", 0x7ae6ff); burst(P.pos.x, 1.2f, P.pos.z, 0x7ae6ff, 26, 7f, .5f, .7f); fx.ring(P.pos.x, P.pos.z, 0x7ae6ff, .5f, 6f, .5f); flash(0x7ae6ff, .3f, 300) }
        }
    }
    return c
}

// ======================= KURAPIKA =======================
fun buildKurapika(): Human {
    val h = buildHuman(HumanOpts(s = .88f, skin = 0xf2dcc6, top = 0x24408c, bottom = 0xe8e8ee, shoe = 0x5a3a20, sleeveLong = true))
    val hr = h.mt(0xf0d070)
    hairCap(h, hr, .15f, -.015f, -.15f)
    for (s in listOf(-1f, 1f)) {
        h.mkk(box(.07f, .36f, .1f), hr, h.head, s * .19f, 0f, 0f, rz = s * .05f)
        h.mkk(box(.17f, .1f, .09f), hr, h.head, s * .09f, .3f, .16f, rz = s * -.3f)
        mk(sph(.026f, 6, 6), basic(0xff2a2a), h.head, s * .215f, -.14f, 0f, outline = false)
    }
    val em = basic(0x2a1a14); h.em = em
    h.eyeM = listOf(-1f, 1f).map { q -> mk(sph(.034f, 8, 6), em, h.head, q * .08f, .15f, .178f, sy = .8f, sz = .5f, outline = false) }
    h.mkk(box(.2f, .64f, .02f), h.mt(0xf4f4f8), h.torso, 0f, .33f, .27f)
    mk(box(.04f, .64f, .022f), basic(0xffd24a), h.torso, .1f, .33f, .272f, outline = false)
    mk(box(.04f, .64f, .022f), basic(0xffd24a), h.torso, -.1f, .33f, .272f, outline = false)
    for (i in 0 until 2) h.mkk(Geometry.torus(.1f + i * .04f, .014f, 6, 12), h.mt(0xe8c850), h.elR, 0f, -.42f + i * .05f, 0f, rx = PIF / 2 + i * .5f)
    addAura(h, 0xff3d4f, 0xffd9a0)
    return h
}

private fun Game.kurapikaAtk() {
    val d = aim(); act("throw", .26f); P.atkCd = .3f; SFX.swing()
    val m = Node(); m.geo = needleGeo; m.mat = addMat(0xffd24a, .95f); m.scl.set(1.6f, 1.6f, 2.6f)
    shoot(m, hand(1.4f, .8f), d, 40f, 9f, .7f, .5f, 'p', 2, 0xffd24a, 2f, null, 0f, .4f)
    val A = hand(1.4f, .8f); val Bp = A.clone().addScaled(d, 6f); fx.beam({ A }, { Bp }, 0xffd24a, .12f, .1f)
    P.combo++
}

private fun Game.kurapikaS1(): Boolean {
    val t = nearest(P.pos, 20f) ?: return false
    P.cast = .45f; act("throw", .4f); SFX.skill(); aim()
    val tg = { Vec3(t.pos.x, 1.3f + t.hover, t.pos.z) }
    fx.beam({ hand(1.4f, .8f) }, tg, 0xffd24a, 2.4f, .1f); fx.beam({ hand(1.4f, .8f) }, tg, 0xffffff, 2.4f, .04f)
    later(.15f) {
        if (!t.dead) {
            fx.ring(t.pos.x, t.pos.z, 0xffd24a, .4f, 3f, .5f)
            hurtE(t, 30f, Hit(col = 0xffd24a, stun = 2.4f, big = true, from = P.pos, hs = .05f)); P.critN = max(P.critN, 2); popText("Judgment Chain", 0xffd24a)
        }
    }
    return true
}

private fun Game.kurapikaS2(): Boolean {
    val d = fwd(); val c = Vec3(P.pos.x + d.x * 6, 0f, P.pos.z + d.z * 6); val cc = hypot(c.x, c.z); if (cc > ARENA - 3) c.scale((ARENA - 3) / cc)
    P.cast = .5f; act("cast", .5f); SFX.skill(); runeFx(c.x, c.z, 0xffd24a, 6f, 3.2f)
    for (i in 0 until 10) { val a = i / 10f * TAU; later(i * .04f) { fx.pillar(c.x + cos(a) * 5.6f, c.z + sin(a) * 5.6f, 0xffd24a, .25f, 6f, 3f) } }
    for (i in 0 until 6) later(.4f + i * .5f) {
        fx.ring(c.x, c.z, 0xffd24a, 5.5f, 1f, .4f)
        radiusHit(c, 5.6f) { e -> hurtE(e, 11f, Hit(col = 0xffd24a, stun = .6f, noCrit = true, gain = .3f, from = c)) }
    }
    later(3.4f) {
        SFX.boom(); shake = .5f; fx.dome(c.x, 1f, c.z, 0xffd24a, 5.6f, 1f, .4f)
        radiusHit(c, 5.6f) { e -> hurtE(e, 35f, Hit(col = 0xffd24a, knock = 2f, stun = .8f, big = true, from = c)) }
    }
    return true
}

private fun Game.kurapikaUlt(): Boolean {
    val list = EN.filter { !it.dead && it.team == 'e' && it.spawnT <= 0f && dxz(it.pos, P.pos) < 24f }.sortedBy { dxz(it.pos, P.pos) }.take(6)
    P.cast = 1.8f; P.inv = 2f; act("raise", 1.2f); SFX.ult(); slowmo(.45f, .6f); P.auraBoost = 3f; flash(0xff1030, .45f, 500)
    P.h.scarUntil = gtime + 10f; popText("Emperor Time", 0xff3d4f); P.dmgBuff = 1.5f; P.dmgBuffT = 10f; P.speedBuf = 10f
    fx.dome(P.pos.x, 1.2f, P.pos.z, 0xff3d4f, .5f, 7f, .6f); fx.ring(P.pos.x, P.pos.z, 0xff3d4f, 1f, 12f, .7f)
    val cs = intArrayOf(0xff5a3a, 0x3aa0ff, 0xffe04a, 0x4aff7a, 0xb06aff, 0xffffff)
    for ((i, e) in list.withIndex()) {
        val c = cs[i % 6]
        fx.beam({ hand(1.4f, .5f) }, { Vec3(e.pos.x, 1.3f + e.hover, e.pos.z) }, c, .9f, .18f)
        later(.5f + i * .12f) {
            if (!e.dead) { hurtE(e, 60f, Hit(col = c, knock = 3f, stun = 1.4f, big = true, from = P.pos, hs = .06f)); fx.ring(e.pos.x, e.pos.z, c, .5f, 4f, .4f); SFX.hit() }
        }
    }
    return true
}

private fun Game.kurapika() = CharCfg(
    "kurapika", "KURAPIKA", "⛓", "Cụ Thể Hoá (Conjuration) · Hạng A", 0xff3d4f, 0xffd9a0, 110f, 7.6f, 1.06f, 1f, 1f, 0f,
    "Hậu duệ tộc Kurta, dùng xích Nen với điều kiện khắt khe để trói và hạ kẻ thù. Mắt đỏ rực khi cực kỳ phẫn nộ.",
    "Nội tại: Xích Nen trói địch xong sẽ khiến 2 đòn kế tiếp chí mạng.", intArrayOf(4, 4, 3, 5),
    listOf(
        Skill("Holy Chain (Xích Thánh)", "🔗", "XÍCH", 0f, "Phóng mũi xích vàng xuyên thấu, tự dẫn nhẹ."),
        Skill("Judgment Chain (Xích Phán Quyết)", "⛓️", "TRÓI", 6f, "Quấn xích quanh địch gần nhất, khoá cứng 2,4 giây và gây sát thương. Hai đòn sau chí mạng."),
        Skill("Chain Jail (Xích Ngục)", "🏯", "NGỤC", 9f, "Dựng vòng xích khổng lồ: địch bên trong bị giam, chịu sát thương liên tục rồi bị siết nổ cuối cùng."),
        Skill("Emperor Time (Hoàng Đế Thời Gian)", "👁️", "ULT", 0f, "Mặt đỏ bừng, đôi mắt đỏ rực, thông thạo cả sáu hệ Nen: +50% sát thương, chạy nhanh 10 giây, 6 sợi xích nhiều màu trừng phạt 6 kẻ địch.")
    ),
    sigWrap("kurapika", 0xff3d4f, ::buildKurapika), { kurapikaAtk() }, { kurapikaS1() }, { kurapikaS2() }, { kurapikaUlt() })

fun Game.moreChars(): List<CharCfg> = listOf(gon(), killua(), kurapika())
