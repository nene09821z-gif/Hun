# NEN ARENA — tiến độ port HTML → Kotlin Compose (native)

## Giai đoạn 3 (bản này): thêm Gon · Killua · Kurapika + bộ tư thế đặc trưng
- Gon: Quyền Cương/Cần Câu, Kéo, Đá, Paa + chế độ HẮC HOÁ 15s (đổi 3 chiêu, hao máu, aura tím, vignette tím, thanh đếm giờ).
- Killua: Lôi Trảo/Yo-yo, Thunderbolt chuyền 5 địch, Godspeed, ULT Thần Lôi 30s + Ám Sát Zoldyck sau khi lướt.
- Kurapika: Holy Chain, Judgment Chain, Chain Jail, Emperor Time (mắt đỏ rực, da ửng đỏ, 6 xích nhiều màu).
- Bộ chuyển động đặc trưng (SIG) cho 5 nhân vật + keyframe tư thế riêng cho từng chiêu (MV, đủ 13 nhân vật).

Nhân vật đã xong: Hisoka, Illumi, Gon, Killua, Kurapika. Còn lại: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging.

## Giai đoạn 2
Đã xong, KHÔNG cần WebView, toàn bộ tự vẽ bằng OpenGL ES 3.0 + Compose:

**Engine**
- Hệ hạt point-sprite (900 hạt, tự giảm theo mức đồ họa), nổ hạt, nổ trái tim.
- Aura shader (viền sáng + sóng + nhấp nháy) cho mọi nhân vật, lớp aura tối cho Illumi.
- FX lưới: vòng sóng, trụ sáng, vòm, chùm tia (bám mục tiêu), vệt chém, cầu sáng, vòng cảnh báo boss, rune, vết nứt.

**Gameplay**
- Vòng lặp trận: đợt kiến, 3 loại kiến (Lính / Cận Vệ / Cánh bay), boss 3 con (Pitou, Pouf, Youpi) mỗi 5 đợt với chiêu riêng.
- Sát thương, chí mạng, knockback, choáng, hit-stop, slow-mo, rung camera, camera điện ảnh khi tung chiêu / ULT, thanh máu 3D trên đầu kẻ địch, số sát thương bay, combo.
- Con rối Needle (Illumi) – đồng minh tự đánh rồi nổ.

**Giao diện Compose**: màn hình chính, chọn nhân vật (chip + bảng chỉ số + mô tả chiêu), HUD (máu/Nen/boss/đợt/điểm/combo), 5 nút (đánh giữ, chiêu 1, chiêu 2, ULT có hiệu ứng sẵn sàng, lướt) có vòng hồi chiêu, joystick, vuốt xoay camera, tạm dừng, thất bại, hiệu ứng nháy/đỏ viền/tia tốc độ.



## Còn lại (giai đoạn 3 trở đi)
- 8 nhân vật: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging (đủ 4 kỹ năng + mô hình + aura).
- Kẻ địch Nen (Franklin, Feitan, Uvogin, Nobunaga) & AI elite.
- Pose đặc trưng / animation keyframe (SIG, MV) từng nhân vật.
- Âm thanh (SFX đang là hàm rỗng trong Hud.kt → thay bằng bộ tổng hợp AudioTrack).
- Lưu điểm cao, màn Hướng dẫn.
