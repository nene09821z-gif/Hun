package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

/**
 * Aura sấm sét của Killua. Ba loại tia, mỗi tia là một chuỗi đoạn trụ nhỏ (vầng sáng xanh + lõi trắng)
 * gắn vào `parent` (thân nhân vật) nên đi theo mọi chuyển động; dáng tia được tung lại mỗi 0,04–0,1 giây (chớp tắt):
 *  - HUG   : tia ngoằn ngoèo chạy dọc thân/chân/tay, ôm sát cơ thể (đường zích-zắc đứng, không xoắn thành đám mây).
 *  - LEAP  : tia dài bắn ra xa khỏi thân, thuôn nhỏ dần về đầu mút, có một nhánh con và bắn tia lửa ở đầu mút.
 *  - GROUND: tia thấp bò trên mặt đất quanh chân, bắn tia lửa ở cuối.
 * Cường độ tăng theo aura I; khi Godspeed (g=1) có thêm tia LEAP, tia dài/dày hơn và vầng sáng đậm hơn.
 */
class ZapAura(parent: Node, glowHex: Int, coreHex: Int) {
    private class Bolt(val kind: Int, val segs: Int, mg: Material, mc: Material, root: Node) {
        val glow = Array(segs) { Node().also { n -> n.geo = SEG; n.mat = mg; root.add(n) } }
        val core = Array(segs) { Node().also { n -> n.geo = SEG; n.mat = mc; root.add(n) } }
        // mỗi đoạn: điểm đầu (a), điểm cuối (b), hệ số độ dày (w)
        val ax = FloatArray(segs); val ay = FloatArray(segs); val az = FloatArray(segs)
        val bx = FloatArray(segs); val by = FloatArray(segs); val bz = FloatArray(segs)
        val w = FloatArray(segs) { 1f }
        var t = 0f
        var show = false
        fun setVisible(v: Boolean) { for (n in glow) n.visible = v; for (n in core) n.visible = v }
    }

    private val root = Node()
    private val mg = addMat(glowHex, .42f)
    private val mc = addMat(coreHex, .95f)
    private val bolts = ArrayList<Bolt>()
    private val low = Quality.tier.detail < 1f
    private val nHug = if (low) 4 else 5
    private val nLeap = if (low) 2 else 3
    private val nGround = 2
    // bộ đệm điểm dùng chung khi dựng tia (không cấp phát mỗi lần tung lại)
    private val ptx = FloatArray(8); private val pty = FloatArray(8); private val ptz = FloatArray(8)

    init {
        for (i in 0 until nHug) bolts.add(Bolt(HUG, 5, mg, mc, root))
        for (i in 0 until nLeap) bolts.add(Bolt(LEAP, 7, mg, mc, root))
        for (i in 0 until nGround) bolts.add(Bolt(GROUND, 4, mg, mc, root))
        parent.add(root)
        for (b in bolts) b.setVisible(false)
    }

    /** Bán kính thân theo độ cao (hệ toạ độ cục bộ, người cao ~2): chân / thân / đầu. */
    private fun radiusAt(y: Float) = if (y < .9f) .22f else if (y < 1.6f) .36f else .27f

    private fun seg(b: Bolt, i: Int, x0: Float, y0: Float, z0: Float, x1: Float, y1: Float, z1: Float, w: Float) {
        b.ax[i] = x0; b.ay[i] = y0; b.az[i] = z0; b.bx[i] = x1; b.by[i] = y1; b.bz[i] = z1; b.w[i] = w
    }

    /** Tia ôm thân: đi lên hoặc xuống theo chiều đứng, luân phiên sát/xa thân và lệch trái/phải để thành zích-zắc. */
    private fun genHug(b: Bolt, I: Float, g: Float) {
        val n = b.segs
        var a = rnd(0f, TAU)
        val dy = if (rnd01() < .5f) 1f else -1f
        var y = if (dy > 0f) rnd(.05f, 1f) else rnd(.95f, 1.95f)
        var sgn = if (rnd01() < .5f) 1f else -1f
        val reach = .06f + .07f * min(1.6f, I) + .08f * g
        var px = 0f; var py = 0f; var pz = 0f
        for (i in 0..n) {
            val r = radiusAt(y) + (if (i % 2 == 1) rnd(.03f, .03f + reach) else rnd(0f, .03f))
            val cx = cos(a) * r; val cz = sin(a) * r
            if (i > 0) seg(b, i - 1, px, py, pz, cx, y, cz, .8f)
            px = cx; py = y; pz = cz
            a += sgn * rnd(.14f, .34f); sgn = -sgn
            y = clamp(y + dy * rnd(.18f, .32f), .02f, 2f)
        }
    }

    /** Tia bắn ra xa: 5 đoạn chính zích-zắc, thuôn dần, kèm nhánh con 2 đoạn rẽ từ điểm thứ 3. */
    private fun genLeap(b: Bolt, g: Float) {
        val a = rnd(0f, TAU); val y0 = rnd(.35f, 1.7f); val r0 = radiusAt(y0) * .85f
        val sx = cos(a) * r0; val sz = sin(a) * r0
        val a2 = a + rnd(-.5f, .5f)
        var dx = cos(a2); var dy = rnd(-.1f, .5f); var dz = sin(a2)
        val dl = sqrt(dx * dx + dy * dy + dz * dz); dx /= dl; dy /= dl; dz /= dl
        // p: trục ngang vuông góc hướng bắn; q = d × p: trục còn lại (gần như thẳng đứng)
        val ppx = -sin(a2); val ppz = cos(a2)
        val qx = dy * ppz; val qy = dz * ppx - dx * ppz; val qz = -dy * ppx
        val n = 5
        val sl = rnd(.9f, 1.5f) * (1f + .45f * g) / n
        var sg = if (rnd01() < .5f) 1f else -1f
        ptx[0] = sx; pty[0] = y0; ptz[0] = sz
        for (i in 1..n) {
            val off = if (i < n) rnd(.25f, .7f) * sl * sg else 0f
            val off2 = rnd(-.25f, .25f) * sl
            sg = -sg
            ptx[i] = sx + dx * sl * i + ppx * off + qx * off2
            pty[i] = y0 + dy * sl * i + qy * off2
            ptz[i] = sz + dz * sl * i + ppz * off + qz * off2
        }
        for (i in 0 until n) seg(b, i, ptx[i], pty[i], ptz[i], ptx[i + 1], pty[i + 1], ptz[i + 1], LEAP_W[i])
        // nhánh con
        val sd = if (rnd01() < .5f) 1f else -1f
        var fx = dx * .75f + ppx * sd * .55f + qx * rnd(-.3f, .3f)
        var fy = dy * .75f + qy * rnd(-.3f, .3f)
        var fz = dz * .75f + ppz * sd * .55f + qz * rnd(-.3f, .3f)
        var fl = max(.001f, sqrt(fx * fx + fy * fy + fz * fz)); fx /= fl; fy /= fl; fz /= fl
        var cx = ptx[2]; var cy = pty[2]; var cz = ptz[2]
        for (m in 0 until 2) {
            val nx = cx + fx * sl; val ny = cy + fy * sl; val nz = cz + fz * sl
            seg(b, n + m, cx, cy, cz, nx, ny, nz, .5f - .15f * m)
            cx = nx; cy = ny; cz = nz
            fx += ppx * -sd * .5f; fy += rnd(-.15f, .15f); fz += ppz * -sd * .5f
            fl = max(.001f, sqrt(fx * fx + fy * fy + fz * fz)); fx /= fl; fy /= fl; fz /= fl
        }
    }

    /** Tia bò sát đất từ chân ra ngoài, zích-zắc ngang và nhấp nhô nhẹ. */
    private fun genGround(b: Bolt, g: Float) {
        val n = b.segs
        val a = rnd(0f, TAU); val ca = cos(a); val sa = sin(a)
        val len = rnd(.6f, 1f) * (1f + .3f * g)
        var sgn = if (rnd01() < .5f) 1f else -1f
        for (i in 0..n) {
            val r = .2f + len * i / n
            val side = if (i == 0) 0f else sgn * rnd(.08f, .24f)
            sgn = -sgn
            ptx[i] = ca * r - sa * side
            ptz[i] = sa * r + ca * side
            pty[i] = .05f + (if (i == 0 || i == n) 0f else rnd(0f, .14f))
        }
        for (i in 0 until n) seg(b, i, ptx[i], pty[i], ptz[i], ptx[i + 1], pty[i + 1], ptz[i + 1], .9f)
    }

    /** Đặt các đoạn trụ theo dữ liệu tia. Mỗi đoạn kéo dài thêm chút để lấp khe hở ở chỗ gấp khúc. */
    private fun place(b: Bolt, g: Float) {
        val wG = .12f * (1f + .3f * g); val wC = .034f * (1f + .3f * g)
        for (i in 0 until b.segs) {
            val sx = b.bx[i] - b.ax[i]; val sy = b.by[i] - b.ay[i]; val sz = b.bz[i] - b.az[i]
            val l = max(.02f, sqrt(sx * sx + sy * sy + sz * sz))
            val k = b.w[i]
            val gl = b.glow[i]; gl.pos.set(b.ax[i], b.ay[i], b.az[i]); gl.lookDir(sx, sy, sz); gl.scl.set(wG * k, wG * k, l + wG * k * .35f)
            val c = b.core[i]; c.pos.set(b.ax[i], b.ay[i], b.az[i]); c.lookDir(sx, sy, sz); c.scl.set(wC * k, wC * k, l + wC * k * .7f)
        }
    }

    /** Tia lửa bắn ra từ đầu mút tia (toạ độ cục bộ -> thế giới: xoay quanh Y theo hướng nhân vật, nhân tỉ lệ thân). */
    private fun spark(b: Bolt, x: Float, y: Float, z: Float, s: Float, rc: Float, rs: Float) {
        val si = if (b.kind == LEAP) 4 else if (b.kind == GROUND) b.segs - 1 else rndi(b.segs)
        val p = if (b.kind == LEAP) .6f else if (b.kind == GROUND) .4f else .2f
        if (rnd01() >= p) return
        val lx = b.bx[si]; val ly = b.by[si]; val lz = b.bz[si]
        val wx = x + (lx * rc + lz * rs) * s; val wz = z + (-lx * rs + lz * rc) * s; val wy = y + ly * s
        emit(wx, wy, wz, rnd(-1.4f, 1.4f), rnd(.4f, 2.6f), rnd(-1.4f, 1.4f), rnd(.15f, .3f), .26f, .02f, if (rnd01() < .5f) 0xffffff else 0x7ae6ff, 4f, 1.5f)
    }

    fun tick(I: Float, dt: Float, x: Float, y: Float, z: Float, s: Float, g: Float, yaw: Float = 0f) {
        val vis = I > .01f
        root.visible = vis
        if (!vis) return
        mg.opacity = .42f + .12f * g
        val k = clamp(I / 1.4f, .35f, 1f)
        val activeHug = ceil(nHug * k).toInt()
        val activeLeap = min(nLeap, (if (I > .9f) 1 else 0) + (if (g > .3f) 1 else 0) + (if (g > .3f && I > 2f) 1 else 0))
        var hi = 0; var li = 0
        val rc = cos(yaw); val rs = sin(yaw)
        for (b in bolts) {
            b.t -= dt
            if (b.t > 0f) continue
            b.t = rnd(.04f, .1f)
            val on = when (b.kind) {
                HUG -> { val o = hi < activeHug && rnd01() < .85f; hi++; o }
                LEAP -> { val o = li < activeLeap && rnd01() < .7f + .2f * g; li++; o }
                else -> rnd01() < .4f + .25f * g
            }
            b.show = on; b.setVisible(on)
            if (on) {
                when (b.kind) {
                    HUG -> genHug(b, I, g)
                    LEAP -> genLeap(b, g)
                    else -> genGround(b, g)
                }
                place(b, g)
                spark(b, x, y, z, s, rc, rs)
            }
        }
    }

    companion object {
        private const val HUG = 0
        private const val LEAP = 1
        private const val GROUND = 2
        private val LEAP_W = floatArrayOf(1.15f, 1.05f, .9f, .75f, .55f)
        private val SEG: Geometry = Geometry.cylinder(1f, 1f, 1f, 6, true).rotatedX(PIF / 2).translated(0f, 0f, .5f)
    }
}
