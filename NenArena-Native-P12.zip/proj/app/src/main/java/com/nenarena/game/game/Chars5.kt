package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)

private const val KC = 0x35b8ff   // Chrollo
private const val SVC = 0xff4d2e  // Silva
private const val LC = 0x3a8dff   // Leorio

// ---------------------------------------------------------------- hiệu ứng dùng chung
/** Ngôi sao va chạm: quầng sáng + tia hạt toả đều. */
internal fun Game.impactStar(x: Float, y: Float, z: Float, hex: Int) {
    fx.glow(x, y, z, hex, .3f, 2.4f, .25f); fx.glow(x, y, z, 0xffffff, .15f, 1.1f, .18f)
    for (i in 0 until 10) { val a = i / 10f * TAU; emit(x, y, z, cos(a) * 9f, rnd(-1f, 1f), sin(a) * 9f, .3f, .55f, .02f, hex, 0f, 4f) }
}

internal fun Game.fistFx(x: Float, z: Float, hex: Int, sc: Float) {
    val m = addMat(hex, .9f); val o = Node(); o.geo = fx.gOrb; o.mat = m
    fx.add(o, .3f, m) { k, n, _ -> n.pos.set(x, 1.3f + k * .4f, z); val s = sc * (.6f + k); n.scl.set(s, s, s * 1.3f); m.opacity = .9f * (1 - k) }
    impactStar(x, 1.3f, z, hex)
}

/** Cổng không gian: hai vòng sáng đồng tâm tại độ cao y. */
internal fun Game.portal(x: Float, y: Float, z: Float, hex: Int) {
    fx.ring(x, z, hex, .3f, 1.5f, .35f, y); fx.ring(x, z, 0xffffff, .2f, .9f, .3f, y); burst(x, y, z, hex, 6, 3f, .3f, .4f)
}

private val gFish by lazy { Geometry.cone(.16f, .7f, 5).rotatedX(PIF / 2) }
private val gBody by lazy { Geometry.capsule(.32f, .9f, 4, 10) }

/** Bầy cá Nen bơi vòng quanh ctr (Indoor Fish). */
private fun Game.fishFx(ctr: Vec3, R: Float, life: Float, n: Int, hex: Int) {
    val g = Node(); val m = addMat(hex, .85f)
    class F(val f: Node, val a: Float, val r: Float, val h: Float, val s: Float, val w: Float)
    val fs = ArrayList<F>()
    for (i in 0 until n) {
        val f = Node(); f.geo = gFish; f.mat = m; g.add(f)
        fs.add(F(f, rnd(0f, TAU), rnd(.35f, .95f) * R, rnd(.5f, 3f), rnd(1f, 2.2f) * (if (i % 2 == 1) 1f else -1f), rnd(0f, TAU)))
    }
    fx.add(g, life, m) { k, _, _ ->
        val t = k * life
        for (o in fs) {
            val a = o.a + t * o.s; val x = ctr.x + cos(a) * o.r; val z = ctr.z + sin(a) * o.r; val y = o.h + sin(t * 3 + o.w) * .4f
            o.f.pos.set(x, y, z); o.f.lookDir(-sin(a) * o.s, 0f, cos(a) * o.s)
        }
        m.opacity = .85f * (if (k > .9f) (1 - k) / .1f else 1f)
    }
}

/** Đám bản sao lao từ vòng quanh người chơi vào ctr rồi nổ (Gallery Fake). */
private fun Game.crowdFx(hex: Int, n: Int, ringR: Float, ctr: Vec3, t0: Float, dmg: Float, expR: Float) {
    for (i in 0 until n) {
        val a = i / n.toFloat() * TAU + rnd(-.2f, .2f)
        val st = Vec3(P.pos.x + cos(a) * ringR, 0f, P.pos.z + sin(a) * ringR); val cp = hypot(st.x, st.z)
        if (cp > ARENA - 1) { st.x *= (ARENA - 1) / cp; st.z *= (ARENA - 1) / cp }
        val m = addMat(hex, 0f); val o = Node(); o.geo = gBody; o.mat = m
        val to = Vec3(ctr.x + rnd(-1.5f, 1.5f), 0f, ctr.z + rnd(-1.5f, 1.5f)); val T = t0 + .9f
        o.pos.set(st.x, 1f, st.z)
        fx.add(o, T, m) { k, n2, _ ->
            val kk = max(0f, (k * T - t0) / .9f); val e = kk * kk
            n2.pos.set(lerp(st.x, to.x, e), 1f + sin(k * 30) * .04f, lerp(st.z, to.z, e)); m.opacity = min(1f, k * 8) * .55f
        }
        later(T) {
            burst(to.x, 1.2f, to.z, hex, 8, 6f, .4f, .6f); fx.ring(to.x, to.z, hex, .4f, expR * .6f, .35f)
            radiusHit(to, expR) { e -> hurtE(e, dmg, Hit(col = hex, knock = 2f, noCrit = true, from = to, gain = .5f)) }
        }
    }
}

// ======================================================== CHROLLO
fun buildChrollo(): Human {
    val h = buildHuman(HumanOpts(s = .9f, skin = 0xeadccc, top = 0x14161c, bottom = 0x14161c, shoe = 0x0a0a0e, sleeveLong = true))
    val hair = h.mt(0x0a0a10); val fur = h.mt(0xf4f4f6)
    h.mkk(Geometry.sphere(.22f, 14, 10, 0f, TAU, 0f, PIF * .6f), hair, h.head, 0f, .15f, -.015f, rx = -.2f)
    for (p in arrayOf(floatArrayOf(0f, .38f, -.03f, -.1f, 0f), floatArrayOf(.1f, .35f, -.04f, -.15f, -.5f), floatArrayOf(-.1f, .35f, -.04f, -.15f, .5f),
        floatArrayOf(.16f, .3f, -.05f, -.1f, -.9f), floatArrayOf(-.16f, .3f, -.05f, -.1f, .9f)))
        h.mkk(cone(.07f, .28f, 6), hair, h.head, p[0], p[1], p[2], rx = p[3], rz = p[4])
    for (s in listOf(-1f, 1f)) mk(sph(.05f, 8, 8), basic(0x050308), h.head, s * .08f, .15f, .176f, sy = 1.2f, sz = .5f, outline = false)
    mk(box(.02f, .11f, .01f), basic(0x2a1a4a), h.head, 0f, .26f, .19f, outline = false); mk(box(.07f, .02f, .01f), basic(0x2a1a4a), h.head, 0f, .28f, .19f, outline = false)
    h.mkk(Geometry.torus(.2f, .06f, 8, 16), fur, h.torso, 0f, .66f, 0f, rx = PIF / 2)
    h.mkk(cyl(.3f, .5f, 1f, 14), h.mt(0x14161c), h.hips, 0f, -.42f, 0f)
    mk(box(.05f, .34f, .01f), basic(KC), h.torso, 0f, .35f, -.26f, outline = false); mk(box(.2f, .05f, .01f), basic(KC), h.torso, 0f, .4f, -.26f, outline = false)
    // cuốn sách Bandit's Secret: bìa, trang lật, quầng sáng xanh
    val book = Node(); book.pos.set(0f, -.55f, .1f); book.rot.x = .4f; h.elR.add(book)
    mk(box(.24f, .32f, .06f), basic(0x1a3a50), book, 0f, 0f, 0f, outline = false)
    mk(box(.1f, .1f, .01f), basic(0xffd870), book, 0f, 0f, .04f, outline = false)
    val pm = Material(MatType.BASIC, 0xf4ecd8, 0, 1f, doubleSided = true)
    val pages = ArrayList<Node>()
    for (i in 0 until 4) { val p = Node(); p.geo = Geometry.plane(.2f, .28f).translated(.1f, 0f, 0f); p.mat = pm; p.pos.set(-.1f, 0f, .04f + i * .004f); book.add(p); pages.add(p) }
    val gm = addMat(KC, .5f); val gl = Node(); gl.geo = Geometry.sphere(.34f, 10, 8); gl.mat = gm; gl.pos.z = .06f; book.add(gl)
    h.pg = pages; h.glMat = gm; h.bookNode = book
    // dao Ben ở tay trái
    mk(box(.04f, .12f, .03f), basic(0x1a1a22), h.elL, 0f, -.46f, .04f, outline = false); mk(box(.03f, .012f, .34f), basic(0xcfe4ff), h.elL, 0f, -.46f, .24f, outline = false)
    addAura(h, KC, 0xbfe8ff, 0x050a14)
    return h
}

private fun Game.chrolloAtk() {
    act("slash", .26f); val d = aim(); P.atkCd = .28f; SFX.swing(); val heavy = P.combo % 3 == 2
    val t = nearest(P.pos, 9f)
    if (t != null) { val L = min(2.2f, dxz(P.pos, t.pos) - 2.4f); if (L > .3f) P.lunge = Lunge(d.clone(), L / .1f, .1f) }
    later(.08f) {
        val f = fwd(); val o = P.pos.clone()
        coneHit(o, f, 4.2f, if (heavy) 1.3f else 1f) { e -> hurtE(e, if (heavy) 24f else 12f, Hit(knock = if (heavy) 2.4f else 1f, big = heavy, from = o)) }
        fx.slash(o.x + f.x * 2, 1.4f, o.z + f.z * 2, P.face + (if (heavy) 0f else .4f), KC, if (heavy) 4.2f else 3f, .22f)
        burst(o.x + f.x * 2.4f, 1.3f, o.z + f.z * 2.4f, KC, if (heavy) 12 else 6, 5f, .3f, .5f); if (heavy) shake = .25f
    }
    P.combo++
}

private fun Game.chrolloS1(): Boolean {
    val t = nearest(P.pos, 22f); val d = aim()
    val ctr = if (t != null) Vec3(t.pos.x, 0f, t.pos.z) else Vec3(P.pos.x + d.x * 7, 0f, P.pos.z + d.z * 7); val R = 6.5f
    P.cast = .7f; act("cast", .7f); SFX.skill()
    val m = addMat(KC, .16f); val dm = Node(); dm.geo = fx.gDome; dm.mat = m; dm.pos.set(ctr.x, 0f, ctr.z); dm.setScale(R)
    fx.add(dm, 3.4f, m) { k, _, _ -> m.opacity = .18f * min(1f, k * 8) * (if (k > .9f) (1 - k) / .1f else 1f) }
    fx.ring(ctr.x, ctr.z, KC, R * .3f, R, .4f); runeFx(ctr.x, ctr.z, KC, R, 3.4f); fishFx(ctr, R, 3.4f, 16, KC)
    for (i in 0 until 9) later(.4f + i * .33f) {
        radiusHit(ctr, R) { e -> hurtE(e, 8f, Hit(col = KC, stun = .3f, noCrit = true, gain = .5f, from = ctr, knock = 0f)); emit(e.pos.x, 1.2f, e.pos.z, 0f, 1f, 0f, .4f, .5f, .05f, 0xff6070) }
    }
    return true
}

private fun Game.chrolloS2(): Boolean {
    val t = nearest(P.pos, 24f); val d = aim()
    val ctr = if (t != null) Vec3(t.pos.x, 0f, t.pos.z) else Vec3(P.pos.x + d.x * 8, 0f, P.pos.z + d.z * 8)
    P.cast = .5f; P.inv = .4f; act("raise", .5f); SFX.skill()
    popText("Gallery Fake × Order Stamp", KC); crowdFx(KC, 8, 6f, ctr, .25f, 24f, 3.4f)
    return true
}

private fun Game.chrolloUlt(): Boolean {
    P.cast = 2.8f; P.inv = 3f; act("raise", 2.6f); SFX.ult(); slowmo(.5f, .8f); P.auraBoost = 2f; flash(0x0a1830, .5f, 700)
    val d = aim(30f); val ctr = P.pos.clone()
    for (i in 0 until 40) later(i * .03f) { val h = hand(1.4f, .5f); emit(h.x, h.y, h.z, rnd(-3f, 3f), rnd(1f, 4f), rnd(-3f, 3f), .7f, .5f, .1f, if (i % 2 == 1) 0xffffff else KC) }
    later(.6f) {
        popText("Indoor Fish", KC); fx.dome(ctr.x, 0f, ctr.z, KC, 1f, 13f, .5f); fx.ring(ctr.x, ctr.z, KC, 1f, 13f, .6f); runeFx(ctr.x, ctr.z, KC, 12f, 1.6f); fishFx(ctr, 12f, 1.6f, 26, KC)
        for (i in 0 until 5) later(i * .3f) { radiusHit(ctr, 13f) { e -> hurtE(e, 14f, Hit(col = KC, stun = .4f, noCrit = true, gain = 0f, from = ctr)) } }
    }
    later(1.4f) {
        popText("Gallery Fake", KC); val t = nearest(P.pos, 26f)
        val c2 = if (t != null) Vec3(t.pos.x, 0f, t.pos.z) else Vec3(ctr.x + d.x * 8, 0f, ctr.z + d.z * 8)
        crowdFx(KC, 14, 8f, c2, .1f, 26f, 4.2f)
    }
    later(2.4f) {
        popText("Order Stamp: PHÁ HUỶ!", 0xffffff); SFX.boom(); shake = 1f; flash(0xffffff, .85f, 600)
        fx.ring(ctr.x, ctr.z, 0xffffff, 1f, 22f, .7f); fx.ring(ctr.x, ctr.z, KC, 1f, 16f, .9f); fx.pillar(ctr.x, ctr.z, KC, 3f, 36f, .8f)
        radiusHit(ctr, 20f) { e -> hurtE(e, 70f, Hit(knock = 5f, stun = 1f, big = true, hs = .1f, from = ctr, gain = 0f)) }
    }
    return true
}

internal fun Game.chrollo() = CharCfg(
    "chrollo", "CHROLLO LUCILFER", "✠", "Đặc Biệt (Specialization) · Hạng A+", KC, 0xbfe8ff, 120f, 7.6f, 1.12f, 1f, 1f, 0f,
    "Thủ lĩnh Phantom Troupe. Skill Hunter cho phép trộm năng lực qua cuốn sách Bandit's Secret (cầm sách mở ở tay phải, mỗi lúc chỉ dùng một năng lực).",
    "Nội tại: Bandit's Secret, mỗi lần tung chiêu nạp thêm 8 Nen.", intArrayOf(4, 4, 4, 5),
    listOf(
        Skill("Ben's Knife (Dao Ben)", "🗡️", "DAO", 0f, "Chém dao liên hoàn. Đòn thứ 3 là nhát chém rộng, hất văng."),
        Skill("Indoor Fish (Cá Trong Nhà)", "🐟", "CÁ", 7f, "Tạo vùng kín đầy cá Nen bơi lượn, gặm mòn mọi kẻ địch bên trong."),
        Skill("Gallery Fake × Order Stamp", "👥", "BẢN SAO", 10f, "Tạo đám đông bản sao rồi ra lệnh phá huỷ: tất cả lao vào mục tiêu và nổ."),
        Skill("Skill Hunter: Bandit's Secret", "📖", "ULT", 0f, "Lật sách tung liên hoàn ba năng lực đã trộm: Indoor Fish, Gallery Fake, rồi Order Stamp kết thúc.")
    ),
    sigWrap("chrollo", KC, ::buildChrollo), { chrolloAtk() }, { chrolloS1() }, { chrolloS2() }, { chrolloUlt() })

// ======================================================== SILVA
fun buildSilva(): Human {
    val h = buildHuman(HumanOpts(s = 1.14f, w = 1.12f, skin = 0xe9d8c6, top = 0x16161e, bottom = 0x16161e, shoe = 0x0a0a0c, sleeveLong = true))
    val hair = h.mt(0xdfe3ec)
    h.mkk(Geometry.sphere(.22f, 14, 10, 0f, TAU, 0f, PIF * .62f), hair, h.head, 0f, .15f, -.02f, rx = -.15f)
    for (i in 0 until 7) { val a = (i / 6f - .5f) * 2.2f; h.mkk(cone(.06f, .55f, 6), hair, h.head, sin(a) * .2f, .05f, -.15f, rx = .4f, rz = -a * .5f) }
    humanEyes(h, 0x14101a, .04f, .16f, .08f); mk(box(.13f, .015f, .01f), basic(0x14101a), h.head, 0f, .27f, .19f, outline = false)
    h.mkk(cyl(.34f, .46f, .8f, 14), h.mt(0x101018), h.hips, 0f, -.36f, 0f); h.mkk(Geometry.torus(.2f, .05f, 6, 16), h.mt(0xc8ccd6), h.torso, 0f, .66f, 0f, rx = PIF / 2)
    mk(sph(.16f, 10, 8), basic(SVC), h.elR, 0f, -.5f, .05f, outline = false)
    addAura(h, SVC, 0xffe0b0, 0x140606)
    return h
}

private fun Game.silvaAtk() {
    if (P.assassin > 0f && assassinate(105f)) return
    val d = aim(); val o = P.pos.clone(); act("punch", .26f, P.combo % 2 == 1); P.atkCd = .36f; SFX.swing()
    coneHit(o, d, 3.4f, .9f) { e -> hurtE(e, 14f, Hit(knock = 1.3f, from = o, col = SVC)) }
    burst(o.x + d.x * 1.5f, 1.3f, o.z + d.z * 1.5f, SVC, 6, 4f, .3f, .5f)
    if (P.combo % 3 == 2) { val T = tgtPos(d, 14f); fx.orb(hand(1.3f, .8f), T, SVC, .35f, 1f) { boom(T.x, T.z, SVC, 3.2f, 18f, 1.5f) } }
    P.combo++
}

private fun Game.silvaS1(): Boolean {
    val d = aim(22f); val T = tgtPos(d, 20f); P.cast = .55f; act("throw", .5f); SFX.skill()
    fx.orb(hand(1.5f, .8f), T, SVC, .5f, 2.4f) { boom(T.x, T.z, SVC, 5.5f, 58f, 3.2f); popText("Nổ!", 0xffe0b0) }
    return true
}

private fun Game.silvaS2(): Boolean {
    val d = aim(18f); P.cast = .1f; act("slash", .3f); SFX.skill(); val hit = HashSet<Enemy>(); val o = P.pos.clone(); P.inv = .6f
    for (i in 0 until 8) later(i * .03f) { burst(P.pos.x, 1.2f, P.pos.z, 0x111118, 6, 2f, .4f, .9f) }
    P.lunge = Lunge(d.clone(), 44f, .3f, path = { e -> if (hit.add(e)) hurtE(e, 40f, Hit(knock = 2f, stun = .6f, big = true, from = o, col = SVC)) },
        end = { boom(P.pos.x, P.pos.z, SVC, 3.6f, 24f, 2f) })
    return true
}

private fun Game.silvaUlt(): Boolean {
    P.cast = 2.5f; P.inv = 2.7f; act("raise", 2.4f); SFX.ult(); slowmo(.5f, .7f); P.auraBoost = 2f; val d = fwd(); popText("Thiên Cầu Báo Ứng!", 0xffe0b0)
    for (i in 0 until 9) later(.5f + i * .2f) {
        val l = liveEn(30f); val e = if (l.isNotEmpty()) l[i % l.size] else null
        val T = if (e != null) Vec3(e.pos.x, 0f, e.pos.z) else ringPos(Vec3(P.pos.x + d.x * 7, 0f, P.pos.z + d.z * 7), 10f)
        fx.orb(Vec3(T.x, 15f, T.z), T, SVC, .4f, 1.8f) { boom(T.x, T.z, SVC, 4.2f, 34f, 2.5f) }
    }
    later(2.3f) {
        val c = Vec3(P.pos.x + d.x * 7, 0f, P.pos.z + d.z * 7); flash(0xffe0b0, .7f, 500)
        fx.ring(c.x, c.z, SVC, 1f, 16f, .9f); boom(c.x, c.z, SVC, 11f, 95f, 4.5f); shake = 1f
    }
    return true
}

internal fun Game.silva() = CharCfg(
    "silva", "SILVA ZOLDYCK", "✺", "Biến Hoá + Phóng Xuất (Transmutation / Emission) · Hạng A+", SVC, 0xffe0b0, 135f, 7f, 1.14f, 1f, .85f, 0f,
    "Gia chủ nhà Zoldyck, từng đối đầu Chrollo. Nguyên tác chỉ tiết lộ một chiêu: nén aura thành những quả cầu cực lớn, nổ tung khi chạm vào. Lấy sức mạnh tuyệt đối làm nền, không cần tuyệt kỹ rườm rà.",
    "Nội tại: Sát thủ đời thứ 5. Giảm 15% sát thương nhận; Lướt để ẩn mình, đòn thường kế tiếp ám sát từ sau lưng gây 105 sát thương.", intArrayOf(5, 3, 4, 4),
    listOf(
        Skill("Chưởng Aura (Ko)", "👊", "CHƯỞNG", 0f, "Đấm dồn aura vào nắm tay quét thành hình quạt. Mỗi đòn thứ 3 ném một quả cầu nổ nhỏ."),
        Skill("Explosive Orb (Cầu Nổ)", "💥", "CẦU NỔ", 6f, "Ném quả cầu aura khổng lồ, chạm đất là nổ lớn hất văng mọi thứ quanh đó."),
        Skill("Ám Sát Zoldyck", "🌑", "ÁM SÁT", 7f, "Biến mất lao xuyên kẻ địch như bóng đen, chém trúng và nổ aura ở điểm dừng."),
        Skill("Thiên Cầu Báo Ứng", "☄️", "ULT", 0f, "Triệu hồi 9 quả cầu nổ rơi vào từng mục tiêu, rồi dội quả cầu cuối cùng cỡ lớn xuống chiến trường.")
    ),
    sigWrap("silva", SVC, ::buildSilva), { silvaAtk() }, { silvaS1() }, { silvaS2() }, { silvaUlt() })

// ======================================================== LEORIO
fun buildLeorio(): Human {
    val h = buildHuman(HumanOpts(s = 1.1f, skin = 0xe3bd96, top = 0x1b2b48, bottom = 0x1b2b48, shoe = 0x15100c, sleeveLong = true))
    val hair = h.mt(0x0b0b10)
    h.mkk(Geometry.sphere(.22f, 14, 10, 0f, TAU, 0f, PIF * .62f), hair, h.head, 0f, .15f, -.015f, rx = -.1f)
    for (p in arrayOf(floatArrayOf(0f, .36f, 0f), floatArrayOf(.1f, .33f, -.4f), floatArrayOf(-.1f, .33f, .4f))) h.mkk(cone(.06f, .2f, 6), hair, h.head, p[0], p[1], 0f, rz = p[2])
    mk(box(.36f, .07f, .05f), basic(0x06060a), h.head, 0f, .17f, .19f, outline = false); mk(box(.05f, .02f, .04f), basic(0xc8c8d0), h.head, 0f, .17f, .19f, outline = false)
    mk(box(.22f, .42f, .012f), basic(0xf4f4f6), h.torso, 0f, .36f, .262f, outline = false); mk(box(.07f, .4f, .016f), basic(0x0b0b10), h.torso, 0f, .34f, .27f, outline = false)
    val bc = h.mt(0x6b3f1e); h.mkk(box(.46f, .32f, .1f), bc, h.elR, 0f, -.52f, .12f); h.mkk(box(.16f, .04f, .03f), h.mt(0xc8a060), h.elR, 0f, -.34f, .12f)
    addAura(h, LC, 0xcfe2ff, 0x050a18)
    return h
}

private fun Game.leorioAtk() {
    val d = aim(); val o = P.pos.clone(); act("punch", .28f, P.combo % 2 == 1); P.atkCd = .36f; SFX.swing(); var n = 0
    coneHit(o, d, 3.2f, .9f) { e -> n++; hurtE(e, 11f, Hit(knock = 1f, from = o, col = LC)) }
    if (n > 0) P.hp = min(P.maxHp, P.hp + .4f)
    if (P.combo % 3 == 2) {
        val e = nearest(P.pos, 14f)
        if (e != null) {
            val A = hand(1.3f, .8f); portal(A.x, A.y, A.z, LC); portal(e.pos.x, 1.3f, e.pos.z, LC)
            later(.12f) { fistFx(e.pos.x, e.pos.z, LC, 1.2f); hurtE(e, 24f, Hit(knock = 2f, stun = .3f, col = LC, from = P.pos)) }
        }
    }
    P.combo++
}

private fun Game.leorioS1(): Boolean {
    val e = nearest(P.pos, 20f) ?: return false
    aim(20f); P.cast = .5f; act("punch", .45f); SFX.skill()
    val A = hand(1.4f, .8f); val x = e.pos.x; val z = e.pos.z; portal(A.x, A.y, A.z, LC); portal(x, 1.3f, z, LC)
    later(.28f) { fistFx(x, z, LC, 2f); fx.ring(x, z, LC, .5f, 4f, .4f); shake = .4f; SFX.boom(); hurtE(e, 52f, Hit(knock = 3.5f, stun = .7f, big = true, hs = .05f, from = P.pos, col = LC)) }
    return true
}

private fun Game.leorioS2(): Boolean {
    P.cast = .5f; act("raise", .6f); SFX.skill(); P.hp = min(P.maxHp, P.hp + P.maxHp * .22f); P.speedBuf = 6f; P.dmgBuff = 1.2f; P.dmgBuffT = 6f; popText("Hồi phục!", 0x8aff9a)
    fx.ring(P.pos.x, P.pos.z, 0x8aff9a, .5f, 5f, .6f); fx.ring(P.pos.x, P.pos.z, 0xffffff, .3f, 3f, .5f); fx.dome(P.pos.x, 1f, P.pos.z, 0x8aff9a, .5f, 3f, .6f)
    for (i in 0 until 20) emit(P.pos.x + rnd(-1f, 1f), rnd(.2f, 1.6f), P.pos.z + rnd(-1f, 1f), 0f, rnd(1f, 3f), 0f, .8f, .4f, .05f, 0x8aff9a, 0f, 1f)
    return true
}

private fun Game.leorioUlt(): Boolean {
    val L = liveEn(16f, 10); if (L.isEmpty()) return false
    P.cast = 2.2f; P.inv = 2.4f; act("raise", 2.1f); SFX.ult(); slowmo(.5f, .6f); P.auraBoost = 2f; popText("Ngàn Quyền Không Gian!", 0xcfe2ff)
    for ((i, e) in L.withIndex()) for (j in 0 until 3) later(.5f + i * .08f + j * .18f) {
        if (e.dead) return@later
        portal(e.pos.x + rnd(-1.5f, 1.5f), 1.4f + rnd(0f, 1f), e.pos.z + rnd(-1.5f, 1.5f), LC); fistFx(e.pos.x, e.pos.z, LC, 1.4f)
        hurtE(e, 15f, Hit(knock = 1f, stun = .25f, col = LC, from = P.pos, gain = .2f))
    }
    val m = L[0]
    later(1.9f) {
        if (m.dead) return@later
        flash(0xcfe2ff, .7f, 400); shake = 1f; SFX.boom(); fx.ring(m.pos.x, m.pos.z, LC, 1f, 9f, .7f); fx.pillar(m.pos.x, m.pos.z, LC, 1.6f, 24f, .6f)
        hurtE(m, 100f, Hit(knock = 6f, stun = 1f, big = true, hs = .1f, from = P.pos, col = LC))
    }
    return true
}

internal fun Game.leorio() = CharCfg(
    "leorio", "LEORIO PARADINIGHT", "✚", "Phóng Xuất (Emission) · Hạng B", LC, 0xcfe2ff, 115f, 7f, .95f, 1f, 1f, 0f,
    "Sinh viên y khoa, Hunter của Zodiac. Nguyên tác: hệ Phóng Xuất, tung đòn Remote Punch, nắm đấm aura hiện ra từ lỗ không gian ngay trước mặt đối thủ (từng hạ Ging giữa buổi họp báo).",
    "Nội tại: Bác sĩ tương lai, mỗi lần đánh trúng hồi nhẹ sinh lực; kỹ năng hồi máu mạnh hơn.", intArrayOf(3, 3, 3, 4),
    listOf(
        Skill("Cặp Táp Quật", "💼", "CẶP", 0f, "Vung cặp táp quét hình quạt. Mỗi đòn thứ 3 tung nắm đấm từ xa qua cổng không gian."),
        Skill("Remote Punch (Quyền Từ Xa)", "🕳️", "ĐẤM XA", 5f, "Mở cổng không gian ở tay và trước mặt mục tiêu, nắm đấm aura xuyên cổng đấm trúng cực mạnh."),
        Skill("Y Thuật Hunter", "💊", "Y THUẬT", 11f, "Dồn aura chữa lành, hồi 22% sinh lực, tăng tốc và tăng sát thương trong 6 giây."),
        Skill("Ngàn Quyền Không Gian", "🥊", "ULT", 0f, "Mở hàng loạt cổng quanh mọi kẻ địch, ba nắm đấm mỗi mục tiêu, kết thúc bằng cú móc hàm làm Ging bay.")
    ),
    sigWrap("leorio", LC, ::buildLeorio), { leorioAtk() }, { leorioS1() }, { leorioS2() }, { leorioUlt() })
