package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

/**
 * Tóc Godspeed của Killua (theo ảnh tham chiếu): tóc bạc dựng lên thành các LỌN hình lưỡi liềm / ngọn lửa —
 * gốc rộng, cong như chữ C (vài lọn uốn chữ S), thon dần về mũi nhọn, chồng lớp lên nhau, phát sáng trắng-xanh băng.
 * Hai lọn dài rủ hai bên má, vài lọn mái hất lên trán.
 *
 * Mỗi lọn là MỘT mảnh lưới liền (không ghép đốt): dẹt, đường tâm cong sẵn, bề rộng to ở gốc rồi thon về mũi (xem [blade]).
 * Lưới dùng chung giữa các lọn (chỉ khác kích thước/hướng), nên rất nhẹ. Gắn vào XƯƠNG ĐẦU của skin model
 * (SkinModel.boneWorld) nên bám đúng khi cúi/nghiêng/chạy; mọc ra theo gsK, đung đưa nhẹ như bị điện thổi,
 * và ẩn hẳn khi không ở Godspeed.
 *
 * Toạ độ cục bộ theo xương đầu, đơn vị model chuẩn hoá (cao = 1; đầu cao ~0,2; tâm cục tóc ≈ (0, .11, -.02) so với khớp đầu).
 */
class GodHair(private val m: SkinModel, private val h: Human) {
    companion object {
        /** Hệ số thu/phóng toàn bộ chùm tóc Godspeed (1 = cỡ gốc ban đầu). Chỉnh ở đây nếu thấy to/nhỏ. */
        const val SIZE = .72f
        const val SIZE_LOCK = .85f
    }

    private class Lock(val node: Node, val dx: Float, val dy: Float, val dz: Float, val len: Float,
                       val seed: Float, val hang: Boolean)

    private val iHead = m.bi("head")
    private val group = Node()
    private val locks = ArrayList<Lock>()
    private val matA = h.mt(0xf4f8ff)   // trắng ngả xanh nhạt
    private val matB = h.mt(0xc4e0ff)   // xanh băng, dùng cho lớp sau để có chiều sâu
    private val hairMat: Material? = if (m.mats.size > 2) m.mats[2] else null   // mesh thứ 3 trong killua.json = tóc (708 đỉnh)
    private val geoCache = HashMap<String, Geometry>()

    /**
     * Lọn tóc dài 1 đơn vị dọc +Z, rộng nửa-bề-ngang W (so với chiều dài) ở gốc, đường tâm cong theo +X:
     * x(s) = curl·s² + wave·sin(2πs)·.06 (curl>0 cong sang +X như lưỡi liềm, wave≠0 thêm nét chữ S).
     * Bề rộng w(s) = W·(1-s)^.8·(1+.35·sin πs): phình nhẹ ở khoảng 1/3 rồi thon dần về mũi nhọn.
     * Tiết diện hình elip dẹt (dày = .38 bề rộng), 6 đỉnh/vòng, pháp tuyến mượt để tô màu và viền đẹp.
     */
    private fun blade(W: Float, curl: Float, wave: Float): Geometry = geoCache.getOrPut("$W/$curl/$wave") {
        val rings = 8; val K = 6
        val v = ArrayList<Float>(); val idx = ArrayList<Short>()
        fun cx(s: Float) = curl * s * s + wave * sin(TAU * s) * .06f
        fun width(s: Float) = W * (1f - s).pow(.8f) * (1f + .35f * sin(PIF * s))
        val e = .001f
        for (i in 0 until rings) {
            val s = i / rings.toFloat()
            val x = cx(s); val d = (cx(s + e) - cx(s - e)) / (2f * e)
            val tl = sqrt(d * d + 1f); val tx = d / tl; val tz = 1f / tl
            val nwx = tz; val nwz = -tx   // hướng bề ngang: vuông góc tiếp tuyến trong mặt XZ
            val w = max(width(s), .002f); val t = w * .38f
            for (k in 0 until K) {
                val a = TAU * k / K; val c = cos(a); val sn = sin(a)
                var nx = nwx * c * t; var ny = sn * w; var nz = nwz * c * t
                val nl = sqrt(nx * nx + ny * ny + nz * nz); nx /= nl; ny /= nl; nz /= nl
                v.add(x + nwx * c * w); v.add(sn * t); v.add(s + nwz * c * w); v.add(nx); v.add(ny); v.add(nz)
            }
        }
        val dt = (cx(1f) - cx(1f - e)) / e; val tlt = sqrt(dt * dt + 1f)
        v.add(cx(1f)); v.add(0f); v.add(1f); v.add(dt / tlt); v.add(0f); v.add(1f / tlt)
        val tip = rings * K
        // thêm tam giác, tự đảo chiều nếu mặt quay vào trong (so với pháp tuyến đỉnh)
        fun tri(a: Int, b: Int, c: Int) {
            val ax = v[a * 6]; val ay = v[a * 6 + 1]; val az = v[a * 6 + 2]
            val ux = v[b * 6] - ax; val uy = v[b * 6 + 1] - ay; val uz = v[b * 6 + 2] - az
            val wx = v[c * 6] - ax; val wy = v[c * 6 + 1] - ay; val wz = v[c * 6 + 2] - az
            val cxn = uy * wz - uz * wy; val cyn = uz * wx - ux * wz; val czn = ux * wy - uy * wx
            val dot = cxn * v[a * 6 + 3] + cyn * v[a * 6 + 4] + czn * v[a * 6 + 5]
            if (dot >= 0f) { idx.add(a.toShort()); idx.add(b.toShort()); idx.add(c.toShort()) }
            else { idx.add(a.toShort()); idx.add(c.toShort()); idx.add(b.toShort()) }
        }
        for (i in 0 until rings - 1) for (k in 0 until K) {
            val a = i * K + k; val b = i * K + (k + 1) % K; val c = (i + 1) * K + k; val dd = (i + 1) * K + (k + 1) % K
            tri(a, b, c); tri(b, dd, c)
        }
        for (k in 0 until K) tri((rings - 1) * K + k, (rings - 1) * K + (k + 1) % K, tip)
        Geometry(v.toFloatArray(), idx.toShortArray())
    }

    init {
        val cx = 0f; val cy = .11f; val cz = -.02f
        /** Thêm một lọn: gốc (bx,by,bz) theo khớp đầu, hướng (dx,dy,dz), dài len; curl là độ cong HƯỚNG RA NGOÀI (theo dấu của dx). */
        fun put(bx: Float, by: Float, bz: Float, dx: Float, dy: Float, dz: Float, len0: Float, W: Float, curl: Float, wave: Float, mat: Material, hang: Boolean) {
            val len = len0 * (if (hang) SIZE_LOCK else SIZE)   // thu nhỏ chung (kích thước lọn tỉ lệ theo chiều dài)
            val side = if (abs(dx) < .2f) 0f else if (dx > 0f) 1f else -1f
            val nd = mk(blade(W * .9f, curl * side * 1.15f, wave), mat, group, bx, by, bz, outline = true)
            nd.olw = .0065f / len
            m.outNodes.add(nd)
            locks.add(Lock(nd, dx, dy, dz, len, rnd(0f, TAU), hang))
        }
        // lọn mọc ra từ cục tóc: gốc nằm bên trong cục tóc (base) để không hở
        fun add(dx: Float, dy: Float, dz: Float, len: Float, W: Float = .27f, curl: Float = .32f, wave: Float = 0f, mat: Material = matA, base: Float = .055f) {
            val l = sqrt(dx * dx + dy * dy + dz * dz)
            put(cx + dx / l * base, cy + dy / l * base, cz + dz / l * base, dx, dy, dz, len, W, curl, wave, mat, false)
        }
        // lọn dài rủ sát má: gốc ở thái dương, chỉ tới quanh cằm
        fun lock(side: Float, bz: Float, dz: Float, len: Float, mat: Material) =
            put(side * .085f, .07f, bz, side * .14f, -1f, dz, len, .22f, .22f, 0f, mat, true)

        // --- chùm lọn dựng lên trên đỉnh đầu, xoè quạt như ảnh, mũi cong ra ngoài ---
        add(0f, 1f, -.18f, .25f, W = .3f, curl = 0f, wave = 1f)
        add(.38f, 1f, -.12f, .23f, curl = .3f); add(-.38f, 1f, -.12f, .23f, curl = .3f)
        add(.8f, 1f, -.1f, .21f, curl = .36f); add(-.8f, 1f, -.1f, .21f, curl = .36f)
        add(1.35f, .9f, -.05f, .185f, curl = .4f); add(-1.35f, .9f, -.05f, .185f, curl = .4f)
        add(2f, .5f, 0f, .15f, W = .25f, curl = .34f); add(-2f, .5f, 0f, .15f, W = .25f, curl = .34f)
        // --- lớp sau, màu xanh băng (camera game nhìn từ sau lưng nên đây là phần lộ nhiều nhất) ---
        add(0f, .85f, -1f, .2f, curl = 0f, wave = -1f, mat = matB)
        add(.75f, .85f, -.95f, .185f, curl = .32f, mat = matB); add(-.75f, .85f, -.95f, .185f, curl = .32f, mat = matB)
        add(1.25f, .6f, -.8f, .155f, curl = .34f, mat = matB); add(-1.25f, .6f, -.8f, .155f, curl = .34f, mat = matB)
        add(0f, .3f, -1f, .14f, W = .24f, curl = 0f, wave = 1f, mat = matB)
        // --- lọn ngắn quanh chân tóc: làm tóc bồng, hất ra hai bên ---
        add(1.1f, .25f, .35f, .12f, W = .24f, curl = .3f, mat = matB); add(-1.1f, .25f, .35f, .12f, W = .24f, curl = .3f, mat = matB)
        add(1.05f, .15f, -.5f, .12f, W = .24f, curl = .3f); add(-1.05f, .15f, -.5f, .12f, W = .24f, curl = .3f)
        // --- mái trước: vài lọn hất lên trán ---
        add(.45f, 1f, .7f, .135f, W = .24f, curl = .3f); add(-.45f, 1f, .7f, .135f, W = .24f, curl = .3f)
        add(0f, 1f, .9f, .115f, W = .22f, curl = 0f, wave = .8f)
        add(.9f, .7f, .9f, .1f, W = .22f, curl = .3f, mat = matB); add(-.9f, .7f, .9f, .1f, W = .22f, curl = .3f, mat = matB)
        // --- hai lọn dài rủ hai bên má (như ảnh) + hai lọn phụ phía sau tai ---
        lock(1f, .04f, .18f, .1f, matA); lock(-1f, .04f, .18f, .1f, matA)
        lock(1f, -.03f, -.1f, .08f, matB); lock(-1f, -.03f, -.1f, .08f, matB)

        group.visible = false
        m.root.add(group)
        // sau mỗi lần model cập nhật xương, đặt nhóm lọn theo xương đầu
        val old = h.sync
        h.sync = { dt, t, mv -> old?.invoke(dt, t, mv); if (group.visible) m.boneWorld(iHead, group) }
    }

    /** Gọi mỗi khung hình từ bộ chuyển động (SIG) của Killua. g = h.gsK (0..1), t = thời gian trận. */
    fun tick(g: Float, t: Float) {
        // tóc thường của model phát sáng trắng-xanh theo g (để không lộ cục xám dưới các lọn)
        hairMat?.let { it.setEmissiveF(.34f * g, .5f * g, .66f * g) }
        val on = g > .02f
        if (group.visible != on) { group.visible = on; if (on) m.boneWorld(iHead, group) }
        if (!on) return
        val grow = ease(clamp((g - .05f) / .8f, 0f, 1f))
        // lúc mới bật Godspeed tóc bật dựng vượt chút rồi lún lại (như bị điện giật)
        val pop = 1f + .2f * sin(clamp(g * 1.15f, 0f, 1f) * PIF) * (1f - g) * 2.2f
        val em = .22f + .1f * sin(t * 18f)
        matA.setEmissiveF(.2f * g + em * .08f * g, .3f * g + em * .1f * g, .5f * g + em * .1f * g)
        matB.setEmissiveF(.05f * g, .18f * g, .42f * g)
        for (s in locks) {
            val w = s.seed
            // đung đưa mượt (chậm, biên độ nhỏ), mỗi lọn một pha riêng
            val sw = sin(t * (2.6f + (w % 1.5f)) + w * 2f) * .09f * g
            val sw2 = sin(t * 3.7f + w * 3.1f) * .1f * g
            val gr = if (s.hang) (.8f + .2f * grow) else grow
            val len = s.len * gr * pop * (1f + .03f * sin(t * 15f + w * 3f))
            s.node.lookDir(s.dx + sw, s.dy + sw2 * .5f, s.dz + sw2 * .6f)
            s.node.setScale(max(.001f, len))
            s.node.visible = len > .004f
        }
    }
}
