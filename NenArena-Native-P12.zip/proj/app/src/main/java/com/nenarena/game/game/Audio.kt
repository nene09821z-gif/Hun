package com.nenarena.game.game

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import kotlin.random.Random

/**
 * Hiệu ứng âm thanh. File ogg nằm trong assets/sfx (sinh bằng tools/gen_sfx.py).
 * Tên file: <loại>[_<id nhân vật>][_<số biến thể>].ogg — hậu tố số là biến thể ngẫu nhiên,
 * tên có id nhân vật là âm riêng của nhân vật đó (không có thì dùng âm chung).
 */
object SFX {
    @Volatile var on = true; private set
    /** id nhân vật đang chơi: chọn bộ âm đánh/chiêu/ULT/lướt riêng. */
    @Volatile var char = ""

    private var pool: SoundPool? = null
    private val bank = HashMap<String, IntArray>()
    private val lastAt = HashMap<String, Long>()
    private val lastIdx = HashMap<String, Int>()
    private val gaps = mapOf(
        "hit" to 40L, "hit_crit" to 70L, "hit_boss" to 60L, "swing" to 55L, "die_ant" to 45L, "boom" to 90L, "spawn" to 140L,
        "ant_attack" to 90L, "heartbeat" to 900L, "combo" to 120L, "hurt" to 150L, "dash" to 120L, "ui_click" to 60L
    )
    private val sizeRx = Regex("^(.*)_(\\d+)$")

    fun init(ctx: Context) {
        if (pool != null) return
        val sp = SoundPool.Builder()
            .setMaxStreams(16)
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .build()
        val groups = HashMap<String, MutableList<Int>>()
        try {
            val files = ctx.assets.list("sfx") ?: emptyArray()
            for (f in files) {
                if (!f.endsWith(".ogg")) continue
                val name = f.removeSuffix(".ogg")
                val key = sizeRx.matchEntire(name)?.groupValues?.get(1) ?: name
                ctx.assets.openFd("sfx/$f").use { afd -> groups.getOrPut(key) { ArrayList() }.add(sp.load(afd, 1)) }
            }
        } catch (e: Throwable) { android.util.Log.e("NenArena", "sfx load", e) }
        for ((k, v) in groups) bank[k] = v.toIntArray()
        pool = sp
        val pr = ctx.getSharedPreferences("nenarena_audio", Context.MODE_PRIVATE)
        on = pr.getBoolean("sfx", true)
        prefs = pr
    }

    private var prefs: android.content.SharedPreferences? = null
    fun setOn(v: Boolean) { on = v; prefs?.edit()?.putBoolean("sfx", v)?.apply() }

    private fun has(name: String) = bank.containsKey(name)
    /** Tên âm riêng của nhân vật nếu có, không thì âm chung. */
    private fun c(base: String): String { val n = "${base}_$char"; return if (has(n)) n else base }

    @Synchronized
    fun play(name: String, vol: Float = 1f, rate: Float = 1f, jitter: Float = .04f) {
        if (!on) return
        val p = pool ?: return
        val ids = bank[name] ?: return
        val now = SystemClock.uptimeMillis()
        val gap = gaps[name] ?: gaps[name.substringBefore('_')] ?: 25L
        val l = lastAt[name]
        if (l != null && now - l < gap) return
        lastAt[name] = now
        var i = Random.nextInt(ids.size)
        if (ids.size > 1 && i == lastIdx[name]) i = (i + 1) % ids.size   // không lặp cùng biến thể hai lần liền
        lastIdx[name] = i
        val r = (rate * (1f + (Random.nextFloat() * 2f - 1f) * jitter)).coerceIn(.5f, 2f)
        val v = vol.coerceIn(0f, 1f)
        p.play(ids[i], v, v, 1, 0, r)
    }

    // ---- giữ nguyên tên hàm cũ (code chiêu thức đang gọi) ----
    fun swing() = play(c("swing"), .85f, 1f, .06f)
    fun skill() = play(c("skill"), 1f)
    fun ult() { play(c("ult"), 1f, 1f, 0f); Music.duck(2200) }
    fun boom() = play("boom", .95f)
    fun bigBoom() { play("boom_big", 1f, 1f, .02f); Music.duck(1500) }
    fun hit(big: Boolean = false, boss: Boolean = false) {
        if (big) play("hit_crit", .9f) else if (boss) play("hit_boss", .85f) else play(c("hit"), .8f, 1f, .08f)
    }
    fun die(boss: Boolean = false) { if (boss) { play("die_boss", 1f, 1f, 0f); Music.duck(2500) } else play("die_ant", .8f, 1f, .1f) }
    fun hurt() = play("hurt", .9f)
    fun dash() = play(c("dash"), .8f)
    fun ui() = play("ui_click", .8f)

    // ---- mới ----
    fun select() = play("ui_select", .85f)
    fun back() = play("ui_back", .8f)
    fun start() = play("ui_start", .95f, 1f, 0f)
    /** Nghe thử chiêu đặc trưng của nhân vật khi chọn ở màn hình chọn. */
    fun preview(id: String) { val n = "skill_$id"; play(if (has(n)) n else "skill", .75f, 1f, 0f) }
    fun waveStart() = play("wave_start", .9f, 1f, 0f)
    fun waveClear() = play("wave_clear", .9f, 1f, 0f)
    fun ultReady() = play("ult_ready", .9f, 1f, 0f)
    fun gameOver() { play("gameover", 1f, 1f, 0f) }
    fun combo(step: Int) = play("combo", .7f, (1f + .09f * (step - 1)).coerceAtMost(1.9f), 0f)
    fun heartbeat() = play("heartbeat", .9f, 1f, 0f)
    fun spawn() = play("spawn", .55f, 1f, .15f)
    fun enemyAtk() = play("ant_attack", .7f, 1f, .1f)
    fun bossSpawn() { play("boss_roar", 1f, 1f, 0f); Music.duck(2600) }
    fun bossWarn(rate: Float = 1f) = play("boss_warn", .9f, rate, 0f)
    fun bossVolley() = play("boss_volley", .85f)
    fun katana(draw: Boolean) = play(if (draw) "katana_draw" else "katana_sheath", .8f, 1f, .03f)
}

/** Nhạc nền: hai bài lặp, chuyển mượt theo trạng thái (menu / giao tranh / boss / tạm dừng / thua). */
object Music {
    const val MENU = 0; const val BATTLE = 1; const val BOSS = 2; const val PAUSE = 3; const val OVER = 4

    @Volatile var on = true; private set
    @Volatile private var mode = MENU
    @Volatile private var track = 1           // bài đang được chọn phát
    @Volatile private var duckUntil = 0L
    @Volatile private var appPaused = false

    private class Trk(val file: String) {
        var mp: MediaPlayer? = null; var ready = false; var vol = 0f
    }
    private val trk = arrayOf(Trk("music/just_awake.mp3"), Trk("music/hunting_for_your_dreams.mp3"))
    private val h = Handler(Looper.getMainLooper())
    private var app: Context? = null
    private var prefs: android.content.SharedPreferences? = null
    private var running = false

    // Bài theo chế độ: sảnh = Hunting For Your Dreams, giao tranh = Just Awake, boss = Hunting For Your Dreams
    private fun trackFor(m: Int) = when (m) { MENU -> 1; BATTLE -> 0; BOSS -> 1; else -> track }
    private fun volFor(m: Int) = when (m) { MENU -> .62f; BATTLE -> .42f; BOSS -> .5f; PAUSE -> .16f; else -> .2f }

    fun init(ctx: Context) {
        if (app != null) return
        app = ctx.applicationContext
        prefs = app!!.getSharedPreferences("nenarena_audio", Context.MODE_PRIVATE)
        on = prefs!!.getBoolean("music", true)
        h.post {
            for (t in trk) prepare(t)
            if (!running) { running = true; h.postDelayed(tick, 60) }
        }
    }

    private fun prepare(t: Trk) {
        try {
            val a = app ?: return
            val mp = MediaPlayer()
            a.assets.openFd(t.file).use { afd -> mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length) }
            mp.isLooping = true
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
            mp.setVolume(0f, 0f)
            mp.setOnPreparedListener { t.ready = true }
            mp.setOnErrorListener { _, _, _ -> t.ready = false; true }
            mp.prepareAsync()
            t.mp = mp
        } catch (e: Throwable) { android.util.Log.e("NenArena", "music ${t.file}", e) }
    }

    fun setOn(v: Boolean) { on = v; prefs?.edit()?.putBoolean("music", v)?.apply() }

    /** Gọi mỗi khung hình từ luồng game: chỉ đổi cờ, việc nặng làm ở luồng chính. */
    fun mode(m: Int) {
        if (m == mode) return
        mode = m
        if (m != PAUSE && m != OVER) track = trackFor(m)
    }

    fun duck(ms: Long) { duckUntil = SystemClock.uptimeMillis() + ms }

    fun onPause() { appPaused = true; h.post { for (t in trk) try { if (t.mp?.isPlaying == true) t.mp?.pause() } catch (_: Throwable) {} } }
    fun onResume() { appPaused = false }

    fun release() {
        running = false; h.removeCallbacksAndMessages(null)
        for (t in trk) { try { t.mp?.release() } catch (_: Throwable) {}; t.mp = null; t.ready = false }
        app = null
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { step(.06f) } catch (e: Throwable) { android.util.Log.e("NenArena", "music tick", e) }
            h.postDelayed(this, 60)
        }
    }

    private fun step(dt: Float) {
        val now = SystemClock.uptimeMillis()
        val ducking = now < duckUntil
        val cur = track
        for (i in trk.indices) {
            val t = trk[i]; val mp = t.mp ?: continue
            if (!t.ready) continue
            var target = 0f
            if (on && !appPaused && i == cur) target = volFor(mode) * (if (ducking) .38f else 1f)
            // lên chậm, xuống nhanh hơn một chút; bài khác dần nhỏ để hoà vào bài mới
            val rate = if (target > t.vol) dt / 1.1f else dt / .7f
            t.vol = if (target > t.vol) minOf(target, t.vol + rate) else maxOf(target, t.vol - rate)
            try {
                mp.setVolume(t.vol, t.vol)
                if (target > 0f && !mp.isPlaying && !appPaused) mp.start()
                else if (target == 0f && t.vol <= .002f && mp.isPlaying) mp.pause()
            } catch (_: Throwable) {}
        }
    }
}
