package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

// Bảng màu Sukuna: huyết chú lực · xương trắng · hoả · vàng đồng · đêm
internal const val SK_RED = 0xff2b3a
internal const val SK_DRK = 0x4a0012
internal const val SK_BONE = 0xf4ead8
internal const val SK_FIRE = 0xff8a20
internal const val SK_GLD = 0xffd070
internal const val SK_BLK = 0x16020a

private class SQ(val x: Float, val y: Float, val z: Float, val w: Float) {
    operator fun times(o: SQ) = SQ(
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w,
        w * o.w - x * o.x - y * o.y - z * o.z)
    fun inv() = SQ(-x, -y, -z, w)
}
private fun sqAxis(ax: Float, ay: Float, az: Float, a: Float): SQ { val s = sin(a / 2f); return SQ(ax * s, ay * s, az * s, cos(a / 2f)) }
private fun sqEuler(x: Float, y: Float, z: Float, k: Float = 1f) = sqAxis(1f, 0f, 0f, x * k) * sqAxis(0f, 1f, 0f, y * k) * sqAxis(0f, 0f, 1f, z * k)
private fun sqEuler(v: Vec3, k: Float = 1f) = sqEuler(v.x, v.y, v.z, k)

private fun hideAll(n: Node) { if (n.geo != null) n.visible = false; for (c in n.children) hideAll(c) }

/**
 * Gắn model Sukuna (assets/sukuna.*, 32 xương do tools/export_sukuna.py tự thiết kế) lên khung người vô hình.
 * Khung người vẫn chạy mọi chuyển động; mỗi khung hình các góc khớp được chép sang bộ xương:
 *  - cột sống 3 đoạn (hông → lưng dưới → ngực), cổ + đầu, xương tóc đung đưa
 *  - xương đòn nhún theo tay, vai/khuỷu/cổ tay, cụm ngón nắm lại theo h.fistK, bàn chân (toe) gập theo bước chân
 *  - ĐÔI TAY THỨ HAI (Ryomen): mesh riêng, chỉ hiện khi h.fourK > 0, điều khiển bằng h.arm2L/R + h.el2L/R
 */
fun attachSukunaRig(h: Human): SkinModel {
    hideAll(h.body)
    h.mats.clear(); h.outs.clear()
    val md = ModelCache.get("sukuna")
    val m = SkinModel(md)
    val hipsRest = md.rest[md.index["hips"]!! * 3 + 1]
    val height = .95f / hipsRest          // hông của model trùng độ cao hông của khung người
    m.root.setScale(height)
    h.body.add(m.root)
    h.mats.addAll(m.mats)
    for (nd in m.outNodes) nd.olw = .03f / height
    h.fadeHook = { o -> for (nd in m.outNodes) nd.outline = o >= 1f }

    val iHips = m.bi("hips"); val iSp0 = m.bi("spine0"); val iSp1 = m.bi("spine1"); val iNeck = m.bi("neck"); val iHead = m.bi("head"); val iHair = m.bi("hair")
    fun pair(n: String) = intArrayOf(m.bi(n + "L"), m.bi(n + "R"))
    val clav = pair("clav"); val arm = pair("arm"); val el = pair("el"); val wr = pair("wr"); val fing = pair("fing")
    val th = pair("thigh"); val kn = pair("knee"); val an = pair("ankle"); val toe = pair("toe")
    val arm2 = pair("arm2"); val el2 = pair("el2"); val wr2 = pair("wr2"); val fing2 = pair("fing2")
    val extra = if (m.root.children.size > 1) m.root.children[1] else null
    val armDown = 1.0f
    fun put(i: Int, q: SQ) = m.setQ(i, q.x, q.y, q.z, q.w)

    h.sync = { _, time, _ ->
        // đôi tay phụ: mở dần / gấp vào thân
        h.fourK += ((if (h.four) 1f else 0f) - h.fourK) * .14f
        if (!h.four && h.fourK < .02f) h.fourK = 0f
        extra?.visible = h.fourK > .02f
        val unfold = 1f - ease(h.fourK)

        m.resetQ()
        put(iHips, sqEuler(h.hips.rot))
        val t = h.torso.rot; val hd = h.head.rot
        put(iSp0, sqEuler(t.x, t.y, t.z, .4f)); put(iSp1, sqEuler(t.x, t.y, t.z, .6f))
        put(iNeck, sqEuler(hd.x, hd.y, hd.z, .4f)); put(iHead, sqEuler(hd.x, hd.y, hd.z, .6f))
        put(iHair, sqEuler(sin(time * 2.1f) * .07f - t.x * .3f, 0f, sin(time * 1.6f) * .06f))
        val fist = h.fistK
        for (s in 0..1) {
            val a = if (s == 0) h.armL else h.armR; val e = if (s == 0) h.elL else h.elR
            val lg = if (s == 0) h.legL else h.legR; val k = if (s == 0) h.knL else h.knR
            val sg = if (s == 0) 1f else -1f
            val b = sqAxis(0f, 0f, 1f, sg * armDown)
            val lift = clamp(-a.rot.x, 0f, 3f) * .1f
            put(clav[s], sqAxis(0f, 0f, 1f, -sg * lift))
            put(arm[s], sqEuler(a.rot) * b)
            put(el[s], b.inv() * sqEuler(e.rot) * b)
            put(wr[s], b.inv() * sqAxis(1f, 0f, 0f, e.rot.x * .18f) * b)
            put(fing[s], b.inv() * sqAxis(1f, 0f, 0f, -fist * 1.15f) * b)
            put(th[s], sqEuler(lg.rot)); put(kn[s], sqEuler(k.rot))
            put(an[s], sqAxis(1f, 0f, 0f, -k.rot.x * .25f))
            put(toe[s], sqAxis(1f, 0f, 0f, clamp(-lg.rot.x * .35f, -.25f, .45f)))
            // tay thứ hai
            val a2 = if (s == 0) h.arm2L else h.arm2R; val e2 = if (s == 0) h.el2L else h.el2R
            put(arm2[s], sqEuler(a2.rot.x - unfold * 1.1f, a2.rot.y, a2.rot.z + sg * unfold * .9f) * b)
            put(el2[s], b.inv() * sqEuler(e2.rot) * b)
            put(wr2[s], b.inv() * sqAxis(1f, 0f, 0f, e2.rot.x * .18f) * b)
            put(fing2[s], b.inv() * sqAxis(1f, 0f, 0f, -fist * .9f) * b)
        }
        m.update()
        m.root.pos.y = h.hips.pos.y - hipsRest * height
    }
    h.sync?.invoke(0f, 0f, 0f)
    return m
}

/**
 * Aura chú lực của Sukuna: lõi đỏ + ngọn lửa đen-đỏ, vòng ấn dưới chân (hai vòng + tam giác quay), tàn lửa bay lên,
 * tia sét đen đỏ (Hắc Thiểm) lách tách; Lãnh Địa (h.domainOn) và dạng Ryomen (h.four) làm mọi lớp mạnh và đỏ rực hơn.
 */
internal class SukuAura(private val h: Human) {
    private val core = Material(MatType.AURA, 0xff6a50, additive = true, depthWrite = false)
    private val flame = Material(MatType.AURA, SK_RED, additive = true, depthWrite = false)
    private val coreN = Node(); private val flameN = Node()
    private val gm = addMat(SK_RED, 0f); private val gm2 = addMat(SK_FIRE, 0f)
    private val ground = Node(); private val gSpin = Node(); private val gTri = Node()
    private var dK = 0f; private var fK = 0f

    init {
        core.aa = .9f; flame.aa = .55f
        coreN.geo = Geometry.capsule(.5f, 1.2f, 6, 14); coreN.mat = core; coreN.pos.y = 1.1f; h.body.add(coreN)
        flameN.geo = Geometry.capsule(.82f, 1.35f, 6, 16); flameN.mat = flame; flameN.pos.y = 1.15f; h.body.add(flameN)
        ground.pos.y = .06f; h.root.add(ground); ground.add(gSpin); ground.add(gTri)
        val r1 = Node(); r1.geo = Geometry.ring(.95f, 1f, 64).rotatedX(-PIF / 2); r1.mat = gm; r1.setScale(1.7f); ground.add(r1)
        val r2 = Node(); r2.geo = Geometry.ring(.93f, 1f, 48).rotatedX(-PIF / 2); r2.mat = gm; r2.setScale(1.2f); gSpin.add(r2)
        for (k in 0..1) {
            val t = Node(); t.geo = Geometry.ring(.95f, 1f, 3).rotatedX(-PIF / 2); t.mat = gm2; t.setScale(1.45f); t.rot.y = k * PIF / 3f; gTri.add(t)
        }
    }

    fun update(dt0: Float, t: Float) {
        val dt = min(dt0, .05f)
        val main = h.auraMat
        val I = max(.2f, main?.inten ?: 1f)
        val on = h.aura?.visible ?: true
        val q = Quality.tier.detail
        dK += ((if (h.domainOn) 1f else 0f) - dK) * min(1f, dt * 4f)
        fK += ((if (h.four) 1f else 0f) - fK) * min(1f, dt * 4f)
        val pulse = .5f + .5f * sin(t * 3f)
        val boost = dK + fK * .6f

        main?.let { setMatHex(it, mixC(SK_RED, SK_FIRE, boost * .5f)) }
        core.t = (main?.t ?: t) * 1.3f + 2f; core.inten = I * .8f + .3f + boost * .9f
        flame.t = (main?.t ?: t) * .8f + 4f; flame.inten = I * .9f + boost * 1.2f
        setMatHex(core, mixC(0xff6a50, SK_BONE, boost * .5f))
        coreN.visible = on; flameN.visible = on
        h.aCol[0] = SK_RED; h.aCol[1] = if (boost > .5f) SK_FIRE else SK_DRK

        // ánh đỏ trên da
        val er = .06f + .08f * pulse + boost * .22f; val eg = .0f + boost * .03f; val eb = .01f + boost * .02f
        for (mt in h.mats) mt.setEmissiveF(er, eg, eb)

        gSpin.rot.y += dt * (.8f + boost * 2f); gTri.rot.y -= dt * (.5f + boost * 1.2f)
        val gOp = if (on) clamp(.28f + .2f * pulse + I * .1f + boost * .3f, 0f, 1f) else 0f
        gm.opacity = gOp; gm2.opacity = gOp * .9f; ground.visible = on
        gm.setColor(mixC(SK_RED, SK_BONE, dK * .3f)); gm2.setColor(mixC(SK_FIRE, SK_GLD, dK))

        if (!on) return
        val p = h.root.pos
        val cnt = (I * .8f + boost * 1.5f) * q
        var n = cnt.toInt(); if (rnd01() < cnt % 1f) n++
        for (i in 0 until n) {   // tàn lửa chú lực bay lên
            val a = rnd(0f, TAU); val r = rnd(.2f, .75f)
            emit(p.x + cos(a) * r, p.y + rnd(.1f, 1.2f), p.z + sin(a) * r, rnd(-.3f, .3f), rnd(1.6f, 3.4f), rnd(-.3f, .3f), rnd(.7f, 1.2f), .32f, .03f,
                if (rnd01() < .6f) SK_RED else SK_FIRE, 0f, .6f)
        }
        if (rnd01() < (.12f + .25f * boost) * q) {   // tia sét đen đỏ lách tách quanh thân
            val a = rnd(0f, TAU); val r = rnd(.5f, 1f); val y = rnd(.3f, 2f)
            for (j in 0 until 4) emit(p.x + cos(a) * r + rnd(-.2f, .2f), p.y + y + rnd(-.25f, .25f), p.z + sin(a) * r + rnd(-.2f, .2f),
                rnd(-2f, 2f), rnd(-2f, 2f), rnd(-2f, 2f), .18f, .22f, .02f, if (j % 2 == 0) SK_BLK else SK_RED, 0f, 2f)
        }
    }
}

private fun mixC(a: Int, b: Int, k: Float): Int {
    val t = clamp(k, 0f, 1f)
    val r = lerp(((a shr 16) and 255).toFloat(), ((b shr 16) and 255).toFloat(), t).toInt()
    val g = lerp(((a shr 8) and 255).toFloat(), ((b shr 8) and 255).toFloat(), t).toInt()
    val bl = lerp((a and 255).toFloat(), (b and 255).toFloat(), t).toInt()
    return (r shl 16) or (g shl 8) or bl
}
