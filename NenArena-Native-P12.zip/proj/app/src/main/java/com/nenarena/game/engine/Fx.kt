package com.nenarena.game.engine

import kotlin.math.*

/** Hệ hạt dạng điểm sáng (point sprite), mỗi hạt 8 float: x y z size r g b alpha. Số hạt giữ lại theo mức đồ họa. */
object Particles {
    const val NP = 900
    @JvmField val data = FloatArray(NP * 8)
    private val vel = FloatArray(NP * 3)
    private val life = FloatArray(NP); private val max = FloatArray(NP)
    private val s0 = FloatArray(NP); private val s1 = FloatArray(NP)
    private val gr = FloatArray(NP); private val dr = FloatArray(NP)
    private var idx = 0
    @JvmField var keep = 1f

    fun emit(x: Float, y: Float, z: Float, vx: Float, vy: Float, vz: Float, lf: Float, a: Float, b: Float, hex: Int, grav: Float = 0f, drag: Float = 0f) {
        if (keep < 1f && rnd01() > keep) return
        val i = idx; idx = (idx + 1) % NP
        val k = i * 3; val d = i * 8
        data[d] = x; data[d + 1] = y; data[d + 2] = z; data[d + 3] = a
        data[d + 4] = ((hex shr 16) and 255) / 255f; data[d + 5] = ((hex shr 8) and 255) / 255f; data[d + 6] = (hex and 255) / 255f; data[d + 7] = 1f
        vel[k] = vx; vel[k + 1] = vy; vel[k + 2] = vz
        life[i] = lf; max[i] = lf; s0[i] = a; s1[i] = b; gr[i] = grav; dr[i] = drag
    }

    fun update(dt: Float) {
        for (i in 0 until NP) {
            if (life[i] <= 0f) continue
            life[i] -= dt
            val d = i * 8
            if (life[i] <= 0f) { data[d + 3] = 0f; data[d + 7] = 0f; continue }
            val k = i * 3; val u = 1f - life[i] / max[i]; val dd = max(0f, 1f - dr[i] * dt)
            vel[k + 1] -= gr[i] * dt
            vel[k] *= dd; vel[k + 1] *= dd; vel[k + 2] *= dd
            data[d] += vel[k] * dt; data[d + 1] += vel[k + 1] * dt; data[d + 2] += vel[k + 2] * dt
            data[d + 3] = lerp(s0[i], s1[i], u)
            data[d + 7] = min(1f, (1f - u) * 1.8f)
        }
    }

    fun clear() { for (i in 0 until NP) { life[i] = 0f; data[i * 8 + 3] = 0f; data[i * 8 + 7] = 0f } }
}

fun emit(x: Float, y: Float, z: Float, vx: Float, vy: Float, vz: Float, life: Float, s0: Float, s1: Float, hex: Int, grav: Float = 0f, drag: Float = 0f) =
    Particles.emit(x, y, z, vx, vy, vz, life, s0, s1, hex, grav, drag)

fun burst(x: Float, y: Float, z: Float, hex: Int, n: Int, spd: Float, life: Float, size: Float) {
    for (i in 0 until n) {
        val a = rnd(0f, TAU); val b = rnd(-.6f, 1f); val s = rnd(.3f, 1f) * spd
        emit(x, y, z, cos(a) * s, b * s, sin(a) * s, rnd(.5f, 1f) * life, size, size * .2f, hex, 6f, 2.5f)
    }
}

fun heartBurst(x: Float, y: Float, z: Float, hex: Int, n: Int, sc: Float) {
    for (i in 0 until n) {
        val t = i.toFloat() / n * TAU
        val hx = 16f * sin(t).pow(3); val hy = 13f * cos(t) - 5f * cos(2 * t) - 2f * cos(3 * t) - cos(4 * t)
        emit(x, y, z, hx * sc, hy * sc, rnd(-.5f, .5f), 1.1f, .9f, .3f, hex, 0f, 1.6f)
    }
}

/** Mục FX dạng lưới: tồn tại `life` giây, upd(k,node,dt) cập nhật theo k=0..1. */
class FxItem(val node: Node, val life: Float, val upd: ((Float, Node, Float) -> Unit)?, val mat: Material?) { var t = 0f }

/** Quản lý FX lưới + dựng sẵn vòng/chùm/trụ/vòm/vệt chém (ringFx0, beamFx0... của bản HTML). */
class Fx(val root: Node) {
    val list = ArrayList<FxItem>()
    val gRing = Geometry.ring(.84f, 1f, 44).rotatedX(-PIF / 2)
    val gBeam = Geometry.cylinder(1f, 1f, 1f, 8, true).rotatedX(PIF / 2).translated(0f, 0f, .5f)
    val gPil = Geometry.cylinder(1f, 1f, 1f, 18, true).translated(0f, .5f, 0f)
    val gDome = Geometry.sphere(1f, 24, 14)
    val gSlash = Geometry.crescent()
    val gOrb = Geometry.sphere(.32f, 8, 6)
    val gDisc = Geometry.circle(1f, 28).rotatedX(-PIF / 2)

    fun add(n: Node, life: Float, mat: Material?, upd: ((Float, Node, Float) -> Unit)?) { root.add(n); list.add(FxItem(n, life, upd, mat)) }

    fun update(dt: Float) {
        var i = list.size - 1
        while (i >= 0) {
            val f = list[i]; f.t += dt
            val k = min(1f, f.t / f.life)
            f.upd?.invoke(k, f.node, dt)
            if (k >= 1f) { root.remove(f.node); list.removeAt(i) }
            i--
        }
    }

    fun clear() { for (f in list) root.remove(f.node); list.clear() }

    private val gSeg = Geometry.cylinder(1f, 1f, 1f, 6, true).rotatedX(PIF / 2).translated(0f, 0f, .5f)
    private val gGhost = Geometry.capsule(.3f, 1f, 5, 10)

    /**
     * Tia sét nối a -> b, tồn tại `life` giây và đổi dáng (nhấp nháy) mỗi ~0,045 giây.
     * Thân tia gấp khúc luân phiên trái/phải (giống sét thật), có 2 nhánh con ở tia dài, loé sáng ở hai đầu.
     * w = độ dày lõi trắng (vầng sáng ~2,2 lần), jag = biên độ ngoằn ngoèo tối đa, n = số đoạn tối thiểu.
     */
    fun bolt(a: Vec3, b: Vec3, hex: Int, life: Float, w: Float, jag: Float = .8f, n: Int = 8) {
        val A = a.clone(); val B = b.clone()
        val dx = B.x - A.x; val dy = B.y - A.y; val dz = B.z - A.z
        val len = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(.001f)
        val nm = max(max(n, 4), min(18, (len / 1.1f).toInt() + 1))
        val nb = if (len > 4f) 2 else 0; val bn = 3
        val total = nm + nb * bn
        val mg = addMat(hex, .5f); val mc = addMat(0xffffff, 1f)
        val grp = Node()
        val glow = Array(total) { mesh(gSeg, mg).also { s -> grp.add(s) } }
        val core = Array(total) { mesh(gSeg, mc).also { s -> grp.add(s) } }
        val s0 = Array(total) { Vec3() }; val s1 = Array(total) { Vec3() }; val ws = FloatArray(total)
        val pts = Array(nm + 1) { Vec3() }
        val tipA = mesh(gDome, mg); val tipB = mesh(gDome, mg); grp.add(tipA); grp.add(tipB)
        tipA.pos.copy(A); tipB.pos.copy(B)
        val ux = dx / len; val uy = dy / len; val uz = dz / len
        // hai trục vuông góc với hướng tia
        var px = uy; var py = -ux; var pz = 0f
        if (px * px + py * py < .01f) { px = 0f; py = uz; pz = -uy }
        val pl = sqrt(px * px + py * py + pz * pz); px /= pl; py /= pl; pz /= pl
        val qx = uy * pz - uz * py; val qy = uz * px - ux * pz; val qz = ux * py - uy * px
        val segL = len / nm
        val maxOff = min(jag, segL * .6f)
        var fade = 1f
        fun rebuild() {
            pts[0].copy(A); pts[nm].copy(B)
            var sgn = if (rnd01() < .5f) 1f else -1f
            for (i in 1 until nm) {
                val t = i.toFloat() / nm
                val off = maxOff * sqrt(sin(t * PIF))
                val r1 = sgn * rnd(.35f, 1f) * off; val r2 = rnd(-.4f, .4f) * off
                sgn = -sgn
                pts[i].set(A.x + dx * t + px * r1 + qx * r2, A.y + dy * t + py * r1 + qy * r2, A.z + dz * t + pz * r1 + qz * r2)
            }
            for (i in 0 until nm) { s0[i].copy(pts[i]); s1[i].copy(pts[i + 1]); ws[i] = 1f }
            var k = nm
            for (j in 0 until nb) {
                val bi = 1 + rndi(nm - 2)
                val sd = if (j == 0) 1f else -1f
                var bx = ux * .55f + (px * rnd(.4f, 1f) * sd + qx * rnd(-.6f, .6f)) * .9f
                var by = uy * .55f + (py * rnd(.4f, 1f) * sd + qy * rnd(-.6f, .6f)) * .9f
                var bz = uz * .55f + (pz * rnd(.4f, 1f) * sd + qz * rnd(-.6f, .6f)) * .9f
                var cx = pts[bi].x; var cy = pts[bi].y; var cz = pts[bi].z
                for (m in 0 until bn) {
                    val st = segL * .85f
                    s0[k].set(cx, cy, cz)
                    cx += bx * st; cy += by * st; cz += bz * st
                    s1[k].set(cx, cy, cz); ws[k] = .55f * (1f - m * .25f)
                    bx += rnd(-.5f, .5f); by += rnd(-.5f, .5f); bz += rnd(-.5f, .5f)
                    k++
                }
            }
            for (i in 0 until total) {
                val p0 = s0[i]; val p1 = s1[i]
                val sx = p1.x - p0.x; val sy = p1.y - p0.y; val sz = p1.z - p0.z
                val l = max(.01f, sqrt(sx * sx + sy * sy + sz * sz)) * 1.04f
                val wg = w * 2.2f * ws[i] * fade; val wc = w * ws[i] * fade
                val g = glow[i]; g.pos.copy(p0); g.lookDir(sx, sy, sz); g.scl.set(wg, wg, l)
                val c = core[i]; c.pos.copy(p0); c.lookDir(sx, sy, sz); c.scl.set(wc, wc, l)
            }
            tipA.setScale(w * 3f * fade * (.8f + .4f * rnd01())); tipB.setScale(w * 5f * fade * (.8f + .4f * rnd01()))
        }
        rebuild()
        var acc = 0f
        add(grp, life, mg) { k, _, dt ->
            fade = 1f - k * .45f
            acc += dt
            if (acc > .045f) { acc = 0f; rebuild() }
            mg.opacity = .5f * (1 - k); mc.opacity = min(1f, (1 - k) * 1.6f)
        }
    }

    /** Tàn ảnh sáng của nhân vật (Godspeed): hình viên nhộng cộng sáng mờ dần. */
    fun ghost(x: Float, z: Float, face: Float, hex: Int, life: Float) {
        val m = addMat(hex, .5f); val o = mesh(gGhost, m); o.pos.set(x, .95f, z); o.rot.y = face
        add(o, life, m) { k, n, _ -> m.opacity = .5f * (1 - k); n.scl.set(1f - k * .2f, 1f + k * .1f, 1f - k * .2f) }
    }

    private fun mesh(g: Geometry, m: Material): Node { val n = Node(); n.geo = g; n.mat = m; return n }

    fun ring(x: Float, z: Float, hex: Int, r0: Float, r1: Float, life: Float, y: Float = .1f) {
        val m = addMat(hex); val o = mesh(gRing, m); o.pos.set(x, y, z)
        add(o, life, m) { k, n, _ -> val r = lerp(r0, r1, 1 - (1 - k) * (1 - k)); n.scl.set(r, 1f, r); m.opacity = 1 - k }
    }

    fun pillar(x: Float, z: Float, hex: Int, r: Float, h: Float, life: Float) {
        val m = addMat(hex, .8f); val o = mesh(gPil, m); o.pos.set(x, 0f, z)
        add(o, life, m) { k, n, _ -> val s = r * (1 - k * .6f); n.scl.set(s, h * min(1f, k * 6 + .2f), s); m.opacity = .8f * (1 - k) }
    }

    fun dome(x: Float, y: Float, z: Float, hex: Int, r0: Float, r1: Float, life: Float) {
        val m = addMat(hex, .5f); val o = mesh(gDome, m); o.pos.set(x, y, z)
        add(o, life, m) { k, n, _ -> n.setScale(lerp(r0, r1, 1 - (1 - k) * (1 - k))); m.opacity = .5f * (1 - k) }
    }

    /** Chùm sáng nối hai điểm (có thể bám mục tiêu động qua lambda). */
    fun beam(a: () -> Vec3, b: () -> Vec3, hex: Int, life: Float, w: Float) {
        val m = addMat(hex); val o = mesh(gBeam, m)
        add(o, life, m) { k, n, _ ->
            val p = a(); val q = b(); val len = p.distanceTo(q)
            n.pos.copy(p); n.lookDir(q.x - p.x, q.y - p.y, q.z - p.z)
            val ww = w * (1 + sin(k * 50) * .18f) * (1 - k * .5f)
            n.scl.set(ww, ww, max(.01f, len)); m.opacity = min(1f, (1 - k) * 2.2f)
        }
    }

    fun slash(x: Float, y: Float, z: Float, ang: Float, hex: Int, size: Float, life: Float) {
        val m = addMat(hex); val o = mesh(gSlash, m); o.pos.set(x, y, z); o.rot.y = ang
        add(o, life, m) { k, n, _ -> val s = size * (.7f + k * .5f); n.scl.set(s, 1f, s); m.opacity = 1 - k }
    }

    /** Quả cầu sáng bay từ A tới T (orbFx). */
    fun orb(a: Vec3, t: Vec3, hex: Int, life: Float, sc: Float, cb: (() -> Unit)? = null) {
        val m = addMat(hex, .95f); val o = mesh(gOrb, m); val A = a.clone(); val T = t.clone()
        var done = false
        add(o, life, m) { k, n, _ ->
            n.pos.set(lerp(A.x, T.x, k), lerp(A.y, T.y, k) + sin(k * PIF) * 1.2f, lerp(A.z, T.z, k))
            n.setScale(sc * (1f + .2f * sin(k * 30)))
            if (k >= 1f && !done) { done = true; cb?.invoke() }
        }
    }

    /** Quả cầu phát sáng phình/co tại điểm (glowFx). */
    fun glow(x: Float, y: Float, z: Float, hex: Int, s0: Float, s1: Float, life: Float) {
        val m = addMat(hex, .9f); val o = mesh(gDome, m); o.pos.set(x, y, z)
        add(o, life, m) { k, n, _ -> n.setScale(lerp(s0, s1, k)); m.opacity = .9f * (1 - k) }
    }

    /** Vòng cảnh báo đỏ + đĩa đầy dần (teleCircle). */
    fun teleCircle(x: Float, z: Float, r: Float, dur: Float) {
        val m = addMat(0xff2040, .5f); val o = mesh(gRing, m); o.pos.set(x, .12f, z)
        add(o, dur, m) { k, n, _ -> n.scl.set(r, 1f, r); m.opacity = .4f + .5f * sin(k * 30) }
        val m2 = addMat(0xff2040, .3f); val d = mesh(gDisc, m2); d.pos.set(x, .1f, z)
        add(d, dur, m2) { k, n, _ -> n.scl.set(r * k, 1f, r * k); m2.opacity = .35f * k }
    }

    /** Dải cảnh báo hướng lao (teleLine). */
    fun teleLine(px: Float, pz: Float, dx: Float, dz: Float, len: Float, w: Float, dur: Float) {
        val m = addMat(0xff2040, .4f)
        val o = mesh(Geometry.plane(1f, 1f).rotatedX(-PIF / 2).translated(0f, 0f, .5f), m)
        o.pos.set(px, .12f, pz); o.rot.y = atan2(dx, dz)
        add(o, dur, m) { k, n, _ -> n.scl.set(w * 2, 1f, len); m.opacity = .15f + .35f * k }
    }
}
