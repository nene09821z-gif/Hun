# NEN ARENA — tiến độ port HTML → Kotlin Compose (native)

## Giai đoạn P12: ghép Chrollo, Silva, Leorio (từ P7) vào P11
- `game/Chars5.kt` (mới): **Chrollo** (sách Bandit's Secret có trang lật + quầng sáng, Dao Ben, Indoor Fish, Gallery Fake × Order Stamp, ULT ba năng lực liên hoàn), **Silva** (Chưởng Aura, Cầu Nổ, Ám Sát Zoldyck, Thiên Cầu Báo Ứng), **Leorio** (cặp táp, Remote Punch qua cổng không gian, Y Thuật, Ngàn Quyền Không Gian) + hiệu ứng dùng chung (fishFx, crowdFx, portal, fistFx, impactStar).
- `Sig.kt`: thêm dáng đứng/chạy riêng và nhịp chiêu cho 3 nhân vật; `Human.kt`: thêm `pg`, `glMat`, `bookNode` (trang sách Chrollo); `Chars2.moreChars()` đăng ký thêm 3 nhân vật (tổng 10).
- Killua: bỏ hẳn yo-yo (không còn vật cầm tay), đòn thường thứ 3 thành hai nhát Lôi Trảo bắt chéo hình quạt có tia sét.
- Màn chọn nhân vật làm lại (`GameUi.SelectScreen`): cột trái mô hình + tên + danh sách tròn cuộn ngang tự cuộn tới người đang chọn + mũi tên trước/sau + số thứ tự; cột phải thông tin; nút CHỌN & CHIẾN ĐẤU cố định. `Game.menuUpdate` đặt nhân vật giữa cột trái.
- Âm thanh: 3 nhân vật mới dùng âm chung (Audio tự dự phòng khi chưa có file riêng như swing_chrollo...); muốn có âm riêng thì thêm vào `tools/gen_sfx.py`.
- Đã biên dịch và chạy mô phỏng không GL cả 10 nhân vật (đòn, chiêu, ULT, lướt, menu). Chưa build/chạy trên thiết bị.

## Giai đoạn P11: buff Hisoka và Illumi
- **Hisoka**: máu 115→140, tốc độ 7.6→8.3, sát thương ×1.08→×1.2, nạp Nen ×1.25→×1.4, giáp .93, chí mạng 10%. Thẻ bài 9→12 sát thương, nhanh hơn (.3→.26 giây), đòn thứ 3 quạt 5 lá (trước 3). Bungee Gum 40/38→62/58 sát thương, choáng lâu hơn, lan 28 sát thương quanh mục tiêu, hồi 5→4 giây. Texture Surprise: tàng hình và tăng tốc 3 giây, nổ 55→90, bán kính 7→8.5, hồi 9→8 giây. ULT: 95→150 sát thương, bán kính 9→11, choáng 2→3.5 giây, rồi +25% sát thương và tăng tốc 8 giây.
- **Illumi**: máu 105→135, tốc độ 7.4→8.1, sát thương ×1.05→×1.18, nạp Nen ×1.15, giáp .93, chí mạng 15%→22%. Kim Nen 2→3 cây, 7→10 sát thương, xuyên 2 mục tiêu, nhanh hơn (.2→.17 giây). Hari Ningen: rối chiến đấu 7→9 giây, hồi 8→6 giây. Zetsu: 3→4 nhát, mỗi nhát 22→34, 4 đòn chí mạng kế tiếp, hồi 7→6 giây. ULT: 46→70 kim, rối 6→8 giây, sát thương 35→60. Rối nổ (`Game.explodePuppet`): 40→65 sát thương, bán kính 5→6.5.
- Đã biên dịch và chạy thử không GL (dùng đủ đòn thường, chiêu 1, chiêu 2, ULT của cả hai). Chưa cân bằng bằng cách chơi thật.

## Giai đoạn P10: Ryomen Sukuna (nhân vật thứ 7) + bộ xương tự thiết kế
- `sukuna.glb` là **mesh tĩnh, không có xương** (Z-lên, mặt quay +Y, tư thế chữ A). `tools/export_sukuna.py` chuẩn hoá (cao 1, chân y=0, mặt +Z) và **tự thiết kế bộ xương 32 xương** (giới hạn shader):
  hips · spine0 · spine1 · neck · head · hair · clav L/R · arm · el · wr · fing (cụm ngón) · thigh · knee · ankle · toe · **arm2 · el2 · wr2 · fing2 (đôi tay thứ hai của Ryomen)**.
- Trọng số tự gán: mềm theo khoảng cách tới đoạn xương (chuẩn hoá theo bán kính), ràng buộc trái/phải, riêng vùng tóc cho xương `hair`. Đôi tay phụ là mesh riêng (bản sao cánh tay dịch xuống sườn + khớp vai tròn), chỉ hiện ở dạng Ryomen. Chạy lại: `python3 tools/export_sukuna.py <sukuna.glb> app/src/main/assets`.
- `game/SukunaRig.kt`: `attachSukunaRig()` chép khớp khung người sang xương (cột sống 3 đoạn, cổ/đầu, đòn nhún theo tay, nắm tay, gập bàn chân, tóc đung đưa, tay phụ mở/gấp); `SukuAura` aura đỏ + vòng ấn + tàn lửa + sét đen.
- `game/Chars4.kt`: nhân vật Sukuna.
  - Đòn thường 4 nhịp: Giải · Giải · **Hắc Thiểm** (40% bùng sét đen đỏ) · **Bát** (Cleave, sát thương theo máu mục tiêu).
  - Dash: chém Giải 5 nhát dọc đường lướt.
  - Chiêu 1 **Vạn Trảm**: 20 nhát Giải lên tối đa 8 địch, kết bằng Bát đồng loạt.
  - Chiêu 2 **Phủ · Hoả Tiễn (Fuga)**: cung lửa, mũi tên xuyên suốt, nổ thành hoả hải cháy lan 4 giây.
  - ULT **Lãnh Địa Phục Ma Ngự Trù Tử** (8.6 giây): vòm trời đen đỏ, biển máu, đền đầu bò, vòng cột xương; mọi địch bị giam và trúng Giải/Bát liên tục; cuối cùng **Thế Giới Đoạn Trảm**; hồi 25% máu rồi vào **dạng Ryomen 4 tay** 14 giây.
  - Nội tại: Đảo Ngược Chú Thuật (hồi 0.4%/giây).
- Âm thanh riêng (`tools/gen_sfx.py`): `swing_sukuna_1/2`, `hit_sukuna`, `skill_sukuna` (cũng là âm nghe thử ở màn chọn), `ult_sukuna` (dài ~10 giây, khớp nhịp Lãnh Địa: gong, bão chém, nhát Đoạn Trảm lúc ~8 giây), `dash_sukuna`.
- Nối vào: `Sig.kt` (sukuSig), `Chars2.moreChars`, `Game.doDash` (sukuDash), `Game.clearWorld` (sukuReset trả sương mù), HUD gauge "RYOMEN", `Human` (arm2L/R, el2L/R, four, fourK, fistK, domainOn).
- Đã kiểm: biên dịch sạch engine + game bằng kotlinc (khung Android giả, Audio thay bằng khung rỗng) và chạy thử không GL: đủ 7 nhân vật khởi tạo, Sukuna dùng đòn thường / dash / chiêu 1 / chiêu 2 / ULT hết 8.6 giây, sương mù và dạng Ryomen được trả đúng.
- Chưa kiểm trên máy thật: hình dáng Lãnh Địa, độ mượt khung hình, âm thanh (chưa nghe thử).
- Bản quyền model: "Sukuna" của Aliza tiktok (Sketchfab), giấy phép CC-BY-4.0. Phải ghi công khi phát hành.

## Giai đoạn P9: tóc Godspeed của Killua (theo ảnh tham chiếu)
- `game/GodHair.kt` (mới): khi bật Godspeed, tóc Killua dựng thành 28 LỌN hình lưỡi liềm / ngọn lửa: gốc rộng, cong như chữ C (vài lọn chữ S), thon dần về mũi nhọn, chồng lớp (lớp trên trắng, lớp sau xanh băng để có chiều sâu), toả quạt như ảnh: 9 lọn trên đỉnh, 6 lọn lớp sau (camera nhìn từ sau lưng), 4 lọn bồng quanh chân tóc, 5 lọn mái hất lên trán, 4 lọn rủ hai bên má.
- Mỗi lọn là MỘT mảnh lưới liền do `blade(W, curl, wave)` sinh ra (đường tâm cong sẵn, tiết diện elip dẹt, bề rộng thon theo (1-s)^.8), dùng chung giữa các lọn cùng kiểu. Gắn vào XƯƠNG ĐẦU của skin model (bám đúng khi cúi/nghiêng/chạy), mọc ra theo `gsK`, bật dựng có "giật" lúc mới vào Godspeed, đung đưa nhẹ, ẩn hẳn khi không Godspeed.
- Tóc thường của model (mesh thứ 3 trong killua.json) cũng phát sáng xanh-trắng theo `gsK`.
- `engine/Model.kt`: `SkinModel.boneWorld(i, node)` chép vị trí + góc Euler của xương sang một Node (gọi sau `update()`).
- Nối vào: `Chars2.buildKillua` (tạo `h.godHair`), `Sig.kt` nhánh killua (gọi `h.godHair?.tick(g, t)`), `Human.godHair`.
- Chưa build/chạy thử trên thiết bị. Chỉnh dáng tóc: `len`, `W` (bề rộng), `curl` (độ cong), `wave` (chữ S) trong các lời gọi `add(...)`; hệ số `.9f` và `1.15f` trong `put()` là co bề rộng / tăng cong chung; `GodHair.SIZE` (.72) / `SIZE_LOCK` (.85) thu phóng cả chùm tóc.

## Giai đoạn P8: aura sấm sét Killua, chiêu Killua đúng nguyên tác, aura vàng của Gon
- `game/Zap.kt` (ZapAura): aura Killua gồm 3 loại tia sét — HUG (zích-zắc đứng ôm sát thân), LEAP (tia dài bắn ra, thuôn dần, có nhánh con + tia lửa ở đầu mút), GROUND (bò sát đất quanh chân); chớp tắt 0,04–0,1 giây, tăng theo cường độ aura, Godspeed thêm tia LEAP và dày/dài hơn. Vỏ aura cũ chỉ còn rất mờ, hạt aura bay lên giảm (auraRise).
- `engine/Fx.kt`: thêm `bolt()` (tia sét ngoằn ngoèo đổi dáng liên tục) và `ghost()` (tàn ảnh).
- Chiêu Killua: Vuốt Điện (ba vết cào điện) + Yo-yo; Lôi Chưởng Narukami (tia điện từ lòng bàn tay + sét giáng từ trời xuống 5 kẻ gần nhất); Điện Quang Hoả Thạch (lao đi để lại tàn ảnh và vệt sét); ULT Godspeed (12 lần dịch chuyển có vệt sét, bão sét Narukami, rồi Godspeed 30 giây).
- Gon: toàn bộ aura và hiệu ứng chiêu đổi từ xanh lá sang vàng (0xffc82e / 0xfff3a6); trang phục vẫn xanh.
- Chưa build/chạy thử trên thiết bị: cần xem lại độ dày tia sét và hiệu năng trên máy yếu (có giảm số tia ở mức đồ hoạ thấp).


## Giai đoạn 3.8: nhạc nền + âm thanh trận (bản này)
- `game/Audio.kt` thay cho `SFX` rỗng cũ:
  - **Music**: 2 bài trong `assets/music` (Just Awake, Hunting For Your Dreams), phát qua MediaPlayer, chuyển mượt (fade) theo trạng thái:
    sảnh/chọn nhân vật = Hunting For Your Dreams · giao tranh = Just Awake · đánh boss = Hunting For Your Dreams (bài kia dừng, quay lại thì chạy tiếp đúng chỗ cũ) ·
    tạm dừng/thua = nhỏ dần. Nhạc tự hạ nhỏ khi ULT, nổ lớn, boss xuất hiện/chết. Tự dừng khi thoát ra màn hình chính, chạy tiếp khi quay lại.
  - **SFX**: SoundPool, 73 file ogg trong `assets/sfx` (không phải thu âm: sinh bằng tổng hợp, xem `tools/gen_sfx.py`, chạy lại để đổi âm).
    Âm chung: đánh trúng (3 biến thể) / chí mạng / đánh boss, kiến chết (3), bị đau, nổ (2) + nổ lớn cho ULT, lướt, vung, chiêu, ULT, kiến xuất hiện/tấn công,
    boss: gầm / báo hiệu chiêu / đạn, mở đợt, hoàn thành đợt, ULT sẵn sàng, combo (cao dần mỗi 5 combo), tim đập khi dưới 30% máu, thua, giao diện (bấm/chọn/bắt đầu/quay lại).
    **Âm riêng từng nhân vật** (vung đòn 2 biến thể, chiêu, ULT, lướt): Hisoka (lá bài, kẹo cao su Bungee Gum), Illumi (kim, chuông trầm), Gon (cú đấm nặng, tích Nen), Killua (điện xẹt, sấm), Kurapika (xích loảng xoảng),
    Kurotsuki (kiếm "shing", chuông trăng) + tiếng rút kiếm / tra kiếm "tách". Âm đánh trúng riêng cho Gon, Killua, Kurotsuki, Hisoka, Illumi, Kurapika.
  - Chọn nhân vật ở màn hình chọn sẽ nghe thử chiêu đặc trưng.
- Nút bật/tắt Nhạc và Âm thanh: màn hình chính (góc phải dưới) và màn hình tạm dừng. Lưu lại giữa các lần mở.
- `build.gradle.kts`: `noCompress` cho ogg/mp3 (bắt buộc để mở âm thanh từ assets).
- Chưa làm: tiếng bước chân, âm thanh định vị trái/phải theo vị trí địch.

## Giai đoạn 3.5: model 3D thật cho Killua và Neferpitou
- Engine mới: mesh có **texture + alpha-cut**, **skinning bằng xương** (tối đa 32 xương, shader tự nội suy 4 trọng số), viền đen cũng chạy qua skin.
- `engine/Model.kt` nạp `assets/<tên>.json + .bin + .png` (ModelData dùng chung, SkinModel là bản sao riêng có vật liệu/xương riêng).
- `game/ModelRig.kt`: `attachSkinModel()` ẩn khung người bằng hình khối nhưng vẫn để nó chạy mọi chuyển động (đi, đánh, SIG, keyframe chiêu);
  cuối `poseHuman` các góc khớp (hông, thân, đầu, vai, khuỷu, đùi, gối) được chép sang xương của model. Mọi code chiêu thức/aura/hand() giữ nguyên.
- **Killua**: model từ `killua-zoldyck.zip`, đã bỏ ván trượt, tự gán trọng số xương, hạ tay từ tư thế chữ T.
- **Neferpitou (boss)**: model `neferpitou.glb`, rút 69 xương xuống 29, đuôi 7 đốt tự vẫy.
- `tools/export_models.mjs`: script Node (gltf-transform) chuyển .glb sang định dạng assets. Chạy lại khi đổi model.
- Chưa làm: tóc Pitou chưa có vật lý, ngón tay không cử động (gộp vào cổ tay).

## Giai đoạn 3 (bản này): thêm Gon · Killua · Kurapika + bộ tư thế đặc trưng
- Gon: Quyền Cương/Cần Câu, Kéo, Đá, Paa + chế độ HẮC HOÁ 15s (đổi 3 chiêu, hao máu, aura tím, vignette tím, thanh đếm giờ).
- Killua: Lôi Trảo/Yo-yo, Thunderbolt chuyền 5 địch, Godspeed, ULT Thần Lôi 30s + Ám Sát Zoldyck sau khi lướt.
- Kurapika: Holy Chain, Judgment Chain, Chain Jail, Emperor Time (mắt đỏ rực, da ửng đỏ, 6 xích nhiều màu).
- Bộ chuyển động đặc trưng (SIG) cho 5 nhân vật + keyframe tư thế riêng cho từng chiêu (MV, đủ 13 nhân vật).

Nhân vật đã xong: Hisoka, Illumi, Gon, Killua, Kurapika. Còn lại: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging.

## Giai đoạn 2
Đã xong, KHÔNG cần WebView, toàn bộ tự vẽ bằng OpenGL ES 3.0 + Compose:

**Engine**
- Hệ hạt point-sprite (900 hạt, tự giảm theo mức đồ họa), nổ hạt, nổ trái tim.
- Aura shader (viền sáng + sóng + nhấp nháy) cho mọi nhân vật, lớp aura tối cho Illumi.
- FX lưới: vòng sóng, trụ sáng, vòm, chùm tia (bám mục tiêu), vệt chém, cầu sáng, vòng cảnh báo boss, rune, vết nứt.

**Gameplay**
- Vòng lặp trận: đợt kiến, 3 loại kiến (Lính / Cận Vệ / Cánh bay), boss 3 con (Pitou, Pouf, Youpi) mỗi 5 đợt với chiêu riêng.
- Sát thương, chí mạng, knockback, choáng, hit-stop, slow-mo, rung camera, camera điện ảnh khi tung chiêu / ULT, thanh máu 3D trên đầu kẻ địch, số sát thương bay, combo.
- Con rối Needle (Illumi) – đồng minh tự đánh rồi nổ.

**Giao diện Compose**: màn hình chính, chọn nhân vật (chip + bảng chỉ số + mô tả chiêu), HUD (máu/Nen/boss/đợt/điểm/combo), 5 nút (đánh giữ, chiêu 1, chiêu 2, ULT có hiệu ứng sẵn sàng, lướt) có vòng hồi chiêu, joystick, vuốt xoay camera, tạm dừng, thất bại, hiệu ứng nháy/đỏ viền/tia tốc độ.



## Còn lại (giai đoạn 3 trở đi)
- 8 nhân vật: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging (đủ 4 kỹ năng + mô hình + aura).
- Kẻ địch Nen (Franklin, Feitan, Uvogin, Nobunaga) & AI elite.
- Pose đặc trưng / animation keyframe (SIG, MV) từng nhân vật.
- Âm thanh (SFX đang là hàm rỗng trong Hud.kt → thay bằng bộ tổng hợp AudioTrack).
- Lưu điểm cao, màn Hướng dẫn.

## Giai đoạn 3.6: Kurotsuki (nhân vật thứ 6) + katana asset
- `tools/export_katana.mjs`: chuyển `katana.glb` -> `assets/katana.json/.bin/.jpg` (dài 1 đơn vị, gốc = giữa cán, mũi +Z, lưỡi sắc -X; mesh 0..2 là lưỡi để phát sáng).
- `game/Chars3.kt`: Kurotsuki với aura xanh nhiều lớp (lõi trắng, ngọn lửa ngoài, hạt xoắn ốc, vòng rune dưới chân, 4 trăng khuyết bay quanh, ánh kiếm; đỏ khi Nhuốm Máu, trắng lạnh khi Nguyệt Thực).
- Tư thế/đòn vung kiếm riêng trong `kuroSig` (Sig.kt gọi), hook `kuroDash` trong `Game.doDash`.
- Thu/rút kiếm: model katana thứ hai gắn ở hông (chỉ hiện chuôi+tsuba), `Human.sheathed`; tự rút khi tấn công, tự thu sau 3 giây ngoài giao tranh (act "knoto").
- Chiêu 2 mới "Cư Hợp: Nguyệt Quang Loạn Trảm" thay Huyết Trảm: cúi thấp tra kiếm -> 6 nhát xuyên qua địch (dịch chuyển, vệt chém trăng khuyết cong `slashDisc`) -> tra kiếm "tách" nổ mọi vết chém.

## Giai đoạn 3.7
- Killua Godspeed: tự động né mọi đòn (hurtP -> godDodge: chớp sang bên, không mất máu/không bị hất, hồi 0.1s); bỏ rung thân (torso.rot.z); ult mượt hơn.
- Hisoka: làm lại mặt theo ảnh (tóc vuốt ngược dài có lọn tím, mắt hẹp vàng mi dày, chân mày sắc, mũi, sao xanh má phải nhân vật, giọt lệ vàng-lục, cười nhếch).

## P9 — R8 + engine mượt (chưa biên dịch/chạy thử trên máy thật)
- R8: bỏ `-keepclassmembers com.nenarena.game.** {*}`; thêm allowaccessmodification, repackageclasses, 5 passes, xoá Log/Intrinsics checks; appCategory/isGame trong manifest.
- GeoCache: mọi lưới tạo lúc dùng chiêu (yo-yo, rune, nứt đất, kim con rối) tạo 1 lần + upload sẵn lúc khởi động (hết rò buffer GPU & khựng lần đầu).
- Renderer: cache trạng thái GL (mode/skin/texture/cull/depthMask), comparator tĩnh cho sort blend (không cấp phát), không unbind VAO thừa, luồng GL ưu tiên URGENT_DISPLAY.
- Nhịp khung: Surface.setFrameRate (API 30+) thay Thread.sleep; dt lọc jitter (EMA 0.35, bỏ lọc khi spike); sustained performance mode.
- HUD: đồng hồ Compose ~30Hz thay vì mỗi khung.
