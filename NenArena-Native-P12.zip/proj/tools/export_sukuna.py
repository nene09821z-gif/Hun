#!/usr/bin/env python3
"""
Chuyển sukuna.glb (mesh tĩnh, KHÔNG có xương, tư thế chữ A, Z-lên, mặt quay +Y) sang định dạng asset của NEN ARENA:
  assets/sukuna.json + sukuna.bin + sukuna_<hash>.png

Tự thiết kế bộ xương cao cấp 32 xương (shader tối đa 32):
  lõi   : hips, spine0, spine1, neck, head, hair
  vai   : clavL/R
  tay   : armL/R, elL/R, wrL/R (cổ tay + bàn tay), fingL/R (cụm ngón)
  chân  : thighL/R, kneeL/R, ankleL/R, toeL/R
  4 TAY : arm2L/R, el2L/R, wr2L/R, fing2L/R  (đôi tay thứ hai của Ryomen Sukuna — mesh riêng, bật/tắt được)
Trọng số: mỗi đỉnh nhận trọng số mềm theo khoảng cách tới đoạn xương (chuẩn hoá theo bán kính), có ràng buộc trái/phải,
gắn riêng vùng tóc cho xương hair; đôi tay thứ hai là bản sao của cánh tay, dịch xuống sườn, thêm "khớp vai" tròn.

Hệ toạ độ model xuất: cao 1.0, chân chạm y=0, nhìn về +Z, L ở -X (giống Killua/Pitou).
Chạy:  python3 tools/export_sukuna.py <sukuna.glb> <thư mục assets>
"""
import json, struct, sys, hashlib, os
import numpy as np

SRC = sys.argv[1] if len(sys.argv) > 1 else 'sukuna.glb'
OUT = sys.argv[2] if len(sys.argv) > 2 else 'app/src/main/assets'

# ---------------------------------------------------------------- đọc glb
d = open(SRC, 'rb').read()
jl = struct.unpack('<I', d[12:16])[0]
J = json.loads(d[20:20 + jl]); BIN = d[20 + jl + 8:]
def acc(i):
    a = J['accessors'][i]; bv = J['bufferViews'][a['bufferView']]
    ct = {5126: 'f4', 5123: 'u2', 5125: 'u4'}[a['componentType']]; n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3}[a['type']]
    off = bv.get('byteOffset', 0) + a.get('byteOffset', 0)
    r = np.frombuffer(BIN, dtype=ct, count=a['count'] * n, offset=off)
    return r.reshape(-1, n) if n > 1 else r
pr = J['meshes'][0]['primitives'][0]
P0 = acc(pr['attributes']['POSITION']).astype(np.float64)
N0 = acc(pr['attributes']['NORMAL']).astype(np.float64)
UV = acc(pr['attributes']['TEXCOORD_0']).astype(np.float32)
IDX = acc(pr['indices']).astype(np.uint32).reshape(-1, 3)
im = J['images'][0]; bv = J['bufferViews'][im['bufferView']]
TEX = BIN[bv.get('byteOffset', 0):bv.get('byteOffset', 0) + bv['byteLength']]

# ---------------------------------------------------------------- toạ độ cục bộ (z lên, mặt +y)
ZMAX = P0[:, 2].max(); S = 1.0 / ZMAX; YC = -0.03

def to_model(p):               # (x,y,z)_local -> (-x, z, y-YC) * S   (phép quay đúng, mặt về +Z)
    return np.stack([-p[:, 0] * S, p[:, 2] * S, (p[:, 1] - YC) * S], 1)
def nrm_model(n):
    return np.stack([-n[:, 0], n[:, 2], n[:, 1]], 1)

# ---------------------------------------------------------------- bộ xương (cục bộ, phía x>0 = "L" của model)
def V(x, y, z): return np.array([x, y, z], dtype=np.float64)
JT = {  # khớp
 'hips': V(0, -.03, 1.62), 'spine0': V(0, -.03, 1.80), 'spine1': V(0, -.03, 2.08), 'neck': V(0, -.07, 2.50),
 'head': V(0, -.07, 2.64), 'headTop': V(0, -.07, 3.0), 'hair': V(0, -.08, 2.80), 'hairTip': V(0, -.08, 3.0),
 'clav': V(.10, -.04, 2.38), 'arm': V(.42, -.06, 2.28), 'el': V(.72, -.065, 2.07), 'wr': V(.93, -.05, 1.88),
 'fing': V(1.02, -.05, 1.84), 'tip': V(1.19, -.05, 1.79),
 'thigh': V(.17, -.02, 1.60), 'knee': V(.17, -.02, .92), 'ankle': V(.17, -.03, .22), 'toe': V(.18, .10, .06), 'toeTip': V(.19, .27, .03),
}
ARM2_DX, ARM2_DZ = .20, .30     # đôi tay thứ hai: dịch vào trong / xuống thấp

def mir(p, s): return V(p[0] * s, p[1], p[2])   # s=+1 -> L (x cục bộ dương), s=-1 -> R

# danh sách xương: (tên, cha, khớp (cục bộ))
bones = []
def add(name, parent, pos): bones.append((name, parent, pos)); return len(bones) - 1
names = []
def B(name, parent, pos):
    i = add(name, parent, pos); names.append(name); return i
b_hips = B('hips', -1, JT['hips']); b_sp0 = B('spine0', b_hips, JT['spine0']); b_sp1 = B('spine1', b_sp0, JT['spine1'])
b_neck = B('neck', b_sp1, JT['neck']); b_head = B('head', b_neck, JT['head']); b_hair = B('hair', b_head, JT['hair'])
side = {}
for sfx, s in (('L', 1), ('R', -1)):
    side[sfx] = dict(
        clav=B('clav' + sfx, b_sp1, mir(JT['clav'], s)))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]
    c['arm'] = B('arm' + sfx, c['clav'], mir(JT['arm'], s)); 
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['el'] = B('el' + sfx, c['arm'], mir(JT['el'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['wr'] = B('wr' + sfx, c['el'], mir(JT['wr'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['fing'] = B('fing' + sfx, c['wr'], mir(JT['fing'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['thigh'] = B('thigh' + sfx, b_hips, mir(JT['thigh'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['knee'] = B('knee' + sfx, c['thigh'], mir(JT['knee'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['ankle'] = B('ankle' + sfx, c['knee'], mir(JT['ankle'], s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['toe'] = B('toe' + sfx, c['ankle'], mir(JT['toe'], s))
def shift2s(p, s): return V(p[0] - s * ARM2_DX, p[1], p[2] - ARM2_DZ)   # dịch VÀO TRONG theo phía của tay
for sfx, s in (('L', 1), ('R', -1)):
    side[sfx]['arm2'] = B('arm2' + sfx, b_sp1, shift2s(mir(JT['arm'], s), s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['el2'] = B('el2' + sfx, c['arm2'], shift2s(mir(JT['el'], s), s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['wr2'] = B('wr2' + sfx, c['el2'], shift2s(mir(JT['wr'], s), s))
for sfx, s in (('L', 1), ('R', -1)):
    c = side[sfx]; c['fing2'] = B('fing2' + sfx, c['wr2'], shift2s(mir(JT['fing'], s), s))
assert len(bones) == 32, len(bones)
idx = {n: i for i, n in enumerate(names)}
# cha phải đứng trước con
for i, (n, p, _) in enumerate(bones): assert p < i, (n, p)

# vị trí nghỉ trong không gian model
rest_local = np.array([b[2] for b in bones])
rest = to_model(rest_local)
lt = np.zeros_like(rest)
for i, (n, p, _) in enumerate(bones): lt[i] = rest[i] - (rest[p] if p >= 0 else 0)

# ---------------------------------------------------------------- đoạn xương để gán trọng số
# (xương, điểm đầu, điểm cuối, bán kính, bên (0 = cả hai / lõi, +1 = L, -1 = R), nhóm)
segs = []
def seg(name, a, b, r, s=0, grp='core'): segs.append((idx[name], a, b, r, s, grp))
seg('hips', JT['hips'], JT['spine0'], .30); seg('spine0', JT['spine0'], JT['spine1'], .27); seg('spine1', JT['spine1'], JT['neck'], .30)
seg('neck', JT['neck'], JT['head'], .10); seg('head', JT['head'], JT['headTop'], .23)
for sfx, s in (('L', 1), ('R', -1)):
    seg('clav' + sfx, mir(JT['clav'], s), mir(JT['arm'], s), .13, s, 'arm')
    seg('arm' + sfx, mir(JT['arm'], s), mir(JT['el'], s), .105, s, 'arm')
    seg('el' + sfx, mir(JT['el'], s), mir(JT['wr'], s), .09, s, 'arm')
    seg('wr' + sfx, mir(JT['wr'], s), mir(JT['fing'], s), .075, s, 'arm')
    seg('fing' + sfx, mir(JT['fing'], s), mir(JT['tip'], s), .07, s, 'arm')
    seg('thigh' + sfx, mir(JT['thigh'], s), mir(JT['knee'], s), .17, s, 'leg')
    seg('knee' + sfx, mir(JT['knee'], s), mir(JT['ankle'], s), .13, s, 'leg')
    seg('ankle' + sfx, mir(JT['ankle'], s), mir(JT['toe'], s), .12, s, 'leg')
    seg('toe' + sfx, mir(JT['toe'], s), mir(JT['toeTip'], s), .09, s, 'leg')

def seg_dist(p, a, b):
    ab = b - a; l2 = float(ab @ ab); t = np.clip(((p - a) @ ab) / l2, 0, 1)
    q = a + np.outer(t, ab); return np.linalg.norm(p - q, axis=1)

def smooth(e0, e1, x): t = np.clip((x - e0) / (e1 - e0), 0, 1); return t * t * (3 - 2 * t)

def skin_weights(P, segs_, tau=.42, gate=True, extra_core=None):
    n = len(P); W = np.zeros((n, 32)); D = []; ids = []
    for (bi, a, b, r, s, grp) in segs_:
        dd = seg_dist(P, a, b) / r
        if gate and s != 0:
            side_ok = (P[:, 0] * s > -.015)
            dd = np.where(side_ok, dd, 1e3)
            if grp == 'arm': dd = np.where(np.abs(P[:, 0]) > .17, dd, 1e3)      # cánh tay không kéo ngực giữa
            if grp == 'leg': dd = np.where(P[:, 2] < 1.80, dd, 1e3)
        D.append(dd); ids.append(bi)
    D = np.array(D); dmin = D.min(0)
    E = np.exp(-(D - dmin) / tau)
    for k, bi in enumerate(ids): W[:, bi] += E[k]
    return W

def finalize(W):
    # giữ 4 trọng số lớn nhất, chuẩn hoá
    ji = np.zeros((len(W), 4), np.uint8); jw = np.zeros((len(W), 4), np.float32)
    top = np.argsort(-W, 1)[:, :4]
    for k in range(4):
        ji[:, k] = top[:, k]; jw[:, k] = W[np.arange(len(W)), top[:, k]]
    s = jw.sum(1, keepdims=True); s[s == 0] = 1; jw /= s
    return ji, jw

# ---------------------------------------------------------------- mesh thân
P = P0.copy(); NN = N0.copy()
W = skin_weights(P, segs)
W /= W.sum(1, keepdims=True)
# vùng tóc: nửa trọng số chuyển sang xương hair (tóc đung đưa nhẹ); mặt phía trước không bị ảnh hưởng
m_hair = smooth(2.80, 2.92, P[:, 2]) * (1 - smooth(.04, .09, P[:, 1])) * (P[:, 2] > 2.7)
W = W * (1 - .6 * m_hair)[:, None]; W[:, idx['hair']] += .6 * m_hair
ji0, jw0 = finalize(W)

# ---------------------------------------------------------------- đôi tay thứ hai: bản sao cánh tay, dịch xuống sườn
armb = [idx['arm' + s] for s in 'LR'] + [idx['el' + s] for s in 'LR'] + [idx['wr' + s] for s in 'LR'] + [idx['fing' + s] for s in 'LR']
armw = W[:, armb].sum(1)
sel = (armw > .55) & (np.abs(P[:, 0]) > .40)
tri_ok = sel[IDX].all(1)
T2 = IDX[tri_ok]
used = np.unique(T2); remap = -np.ones(len(P), np.int64); remap[used] = np.arange(len(used))
P2 = P[used].copy(); N2 = NN[used].copy(); U2 = UV[used].copy(); sg = np.sign(P2[:, 0]); sg[sg == 0] = 1
P2[:, 0] -= sg * ARM2_DX; P2[:, 2] -= ARM2_DZ
T2 = remap[T2]
# khớp vai tròn nối tay phụ với sườn: cầu nhỏ, UV lấy từ một điểm da (trung bình các đỉnh cánh tay gốc)
def sphere(c, r, nu=10, nv=7, uv=(0, 0)):
    vs = []; ns = []; us = []; ts = []
    for j in range(nv + 1):
        th = np.pi * j / nv
        for i in range(nu + 1):
            ph = 2 * np.pi * i / nu
            n = np.array([np.sin(th) * np.cos(ph), np.sin(th) * np.sin(ph), np.cos(th)])
            vs.append(c + n * r); ns.append(n); us.append(uv)
    ts = []
    for j in range(nv):
        for i in range(nu):
            a = j * (nu + 1) + i; b = a + nu + 1
            ts += [[a, b, a + 1], [a + 1, b, b + 1]]
    return np.array(vs), np.array(ns), np.array(us, np.float32), np.array(ts)
root_sel = sel & (np.abs(P[:, 0]) < .50) & (P[:, 2] > 2.1)
uvskin = UV[root_sel].mean(0) if root_sel.any() else UV[sel].mean(0)
parts = [(P2, N2, U2, T2)]
for s in (1, -1):
    c = V(s * (.42 - ARM2_DX), -.06, 2.28 - ARM2_DZ)
    vs, ns, us, ts = sphere(c, .105, uv=uvskin)
    parts.append((vs, ns, us, ts))
PP = []; NNp = []; UU = []; TT = []; off = 0
for (vs, ns, us, ts) in parts:
    PP.append(vs); NNp.append(ns); UU.append(us); TT.append(ts + off); off += len(vs)
P2 = np.concatenate(PP); N2 = np.concatenate(NNp); U2 = np.concatenate(UU); T2 = np.concatenate(TT)

segs2 = []
def seg2(name, a, b, r, s, grp='arm2'): segs2.append((idx[name], a, b, r, s, grp))
for sfx, s in (('L', 1), ('R', -1)):
    seg2('arm2' + sfx, shift2s(mir(JT['arm'], s), s), shift2s(mir(JT['el'], s), s), .105, s)
    seg2('el2' + sfx, shift2s(mir(JT['el'], s), s), shift2s(mir(JT['wr'], s), s), .09, s)
    seg2('wr2' + sfx, shift2s(mir(JT['wr'], s), s), shift2s(mir(JT['fing'], s), s), .075, s)
    seg2('fing2' + sfx, shift2s(mir(JT['fing'], s), s), shift2s(mir(JT['tip'], s), s), .07, s)
    # gốc vai tay phụ neo vào xương ngực
    seg2('spine1', V(0, -.03, 2.08 - .25), V(0, -.03, 2.08 + .05), .22, 0)
W2 = skin_weights(P2, segs2, tau=.35)
# phần gần gốc (|x| nhỏ) bám hẳn vào ngực để không hở
root = 1 - smooth(.30, .50, np.abs(P2[:, 0]))
W2 = W2 / W2.sum(1, keepdims=True)
W2 = W2 * (1 - root)[:, None]; W2[:, idx['spine1']] += root
ji2, jw2 = finalize(W2)

# ---------------------------------------------------------------- xuất
chunks = []; off = [0]
def push(a):
    b = np.ascontiguousarray(a).tobytes(); o = off[0]; chunks.append(b); off[0] += len(b)
    pad = (4 - off[0] % 4) % 4
    if pad: chunks.append(b'\0' * pad); off[0] += pad
    return o
meta = {'bones': [{'n': names[i], 'p': bones[i][1], 't': [round(float(x), 5) for x in lt[i]]} for i in range(32)], 'meshes': []}
tex_name = 'sukuna_' + hashlib.md5(TEX).hexdigest()[:6] + '.png'
os.makedirs(OUT, exist_ok=True); open(os.path.join(OUT, tex_name), 'wb').write(TEX)
for (Pm, Nm, Um, Tm, ji, jw, ol) in ((P, NN, UV, IDX, ji0, jw0, True), (P2, N2, U2, T2, ji2, jw2, True)):
    pos = to_model(Pm).astype(np.float32); nor = nrm_model(Nm).astype(np.float32)
    e = {'v': len(pos), 'i': int(Tm.size)}
    assert len(pos) < 65535
    e['pos'] = push(pos); e['nor'] = push(nor); e['uv'] = push(Um.astype(np.float32)); e['ji'] = push(ji); e['jw'] = push(jw)
    e['idx'] = push(Tm.astype(np.uint16).reshape(-1)); e['tex'] = tex_name; e['cut'] = 0.0; e['ds'] = True; e['ol'] = ol
    meta['meshes'].append(e)
open(os.path.join(OUT, 'sukuna.bin'), 'wb').write(b''.join(chunks))
json.dump(meta, open(os.path.join(OUT, 'sukuna.json'), 'w'))
print('sukuna: bones', len(bones), 'verts', [m['v'] for m in meta['meshes']], 'bin', off[0], 'tex', tex_name)
print('rest hips y', rest[0][1], 'head', rest[idx['head']][1])
np.save('/tmp/suk_dbg.npy', dict(P=to_model(P), W=W, ji=ji0, jw=jw0, P2=to_model(P2), ji2=ji2, jw2=jw2, T=IDX, T2=T2, rest=rest, par=np.array([b[1] for b in bones])), allow_pickle=True)
