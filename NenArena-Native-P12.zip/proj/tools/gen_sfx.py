#!/usr/bin/env python3
"""
Sinh toàn bộ hiệu ứng âm thanh NenArena bằng tổng hợp (không cần file ngoài).
Chạy:  python3 tools/gen_sfx.py   ->  app/src/main/assets/sfx/*.wav  (mono, 32 kHz, 16-bit)

Quy ước tên: <loại>[_<nhân vật>][_<số biến thể>].wav
  - hậu tố _1, _2... là biến thể ngẫu nhiên của cùng một âm
  - tên có _<id nhân vật> (hisoka, illumi, gon, killua, kurapika, kurotsuki, sukuna) là âm riêng của nhân vật đó
"""
import os, sys, wave, subprocess, shutil
import numpy as np
from scipy.signal import butter, sosfilt, lfilter

SR = 32000
rng = np.random.default_rng(20261127)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "app", "src", "main", "assets", "sfx")


# ------------------------------------------------------------------ cơ bản
def T(d): return np.arange(int(d * SR)) / SR
def N(d): return rng.standard_normal(int(d * SR))

def sweep(f0, f1, d):
    t = T(d); k = t / max(d, 1e-6)
    return f0 * (f1 / f0) ** k

def osc(f, kind="sin"):
    f = np.asarray(f, float)
    ph = 2 * np.pi * np.cumsum(f) / SR
    if kind == "sin": return np.sin(ph)
    if kind == "saw": return 2 * ((ph / (2 * np.pi)) % 1.0) - 1
    if kind == "sq":  return np.sign(np.sin(ph))
    if kind == "tri": return 2 * np.abs(2 * ((ph / (2 * np.pi)) % 1.0) - 1) - 1
    raise ValueError(kind)

def tone(f, d, kind="sin"):
    """Dao động tần số cố định f trong d giây."""
    return osc(np.full(int(d * SR), float(f)), kind)

def env(d, a=.002, dec=.1):
    t = T(d)
    return np.minimum(t / max(a, 1e-4), 1.0) * np.exp(-t / dec)

def bump(d, peak=.4, pw=2.0):
    """Hình chuông: tăng tới peak (tỉ lệ 0..1) rồi giảm."""
    t = T(d) / d
    up = np.clip(t / peak, 0, 1) ** pw
    dn = np.clip((1 - t) / (1 - peak), 0, 1) ** pw
    return np.where(t < peak, up, dn)

def lp(x, fc, order=2):  return sosfilt(butter(order, min(fc, SR / 2 - 100), "low", fs=SR, output="sos"), x)
def hp(x, fc, order=2):  return sosfilt(butter(order, max(fc, 20), "high", fs=SR, output="sos"), x)
def bp(x, lo, hi, order=2): return sosfilt(butter(order, [max(lo, 20), min(hi, SR / 2 - 100)], "band", fs=SR, output="sos"), x)

def svf(x, fc, q=4.0, mode="bp"):
    """Bộ lọc biến thiên theo thời gian (Chamberlin SVF). fc: mảng tần số cắt cho mỗi mẫu."""
    fc = np.broadcast_to(np.asarray(fc, float), x.shape)
    f = 2 * np.sin(np.pi * np.minimum(fc, SR / 5.5) / SR)
    qi = 1.0 / q
    low = band = 0.0
    out = np.empty_like(x)
    for i in range(len(x)):
        low += f[i] * band
        high = x[i] - low - qi * band
        band += f[i] * high
        out[i] = band if mode == "bp" else (low if mode == "lp" else high)
    return out

def drive(x, g): return np.tanh(x * g) / np.tanh(g)

def pad(x, n):
    if len(x) >= n: return x[:n]
    return np.concatenate([x, np.zeros(n - len(x))])

def mix(*parts):
    """parts: (tín hiệu, thời điểm bắt đầu giây, hệ số) hoặc tín hiệu trần."""
    items = []
    for p in parts:
        if isinstance(p, tuple):
            sig, st, g = (p + (1.0,))[:3] if len(p) == 2 else p
            items.append((sig, int(st * SR), g))
        else:
            items.append((p, 0, 1.0))
    n = max(s + len(x) for x, s, _ in items)
    out = np.zeros(n)
    for x, s, g in items:
        out[s:s + len(x)] += x * g
    return out

def reverb(x, mix_=.25, tail=.6):
    x = np.concatenate([x, np.zeros(int(tail * SR))])
    wet = np.zeros_like(x)
    for dly, g in [(.0297, .74), (.0371, .72), (.0411, .70), (.0437, .68)]:
        n = int(dly * SR); a = np.zeros(n + 1); a[0] = 1; a[-1] = -g
        wet += lfilter([1.0], a, x)
    wet = lp(wet, 5200)
    return x * (1 - mix_ * .5) + wet * mix_ * .35

def bell(f, d, amp=1.0, ratios=(1, 2.76, 5.4, 8.9), amps=(1, .5, .25, .12), brightness=1.0):
    out = np.zeros(int(d * SR))
    t = T(d)
    for i, (r, a) in enumerate(zip(ratios, amps)):
        fr = f * r
        if fr > SR / 2.2: continue
        dec = d * (.33 / (1 + i * .8)) * brightness
        out += a * np.sin(2 * np.pi * fr * t) * np.exp(-t / dec)
    return out * amp * np.minimum(t / .002, 1.0)

def clink(f=2400, d=.09, amp=1.0):
    return bell(f, d, amp, ratios=(1, 1.52, 2.3, 3.4), amps=(1, .8, .6, .4), brightness=.6)

def thump(f0=120, f1=45, d=.2, dec=.07, amp=1.0):
    return osc(sweep(f0, f1, d)) * env(d, .001, dec) * amp

def noise_burst(d, dec, lo=0, hi=0, amp=1.0):
    x = N(d)
    if lo and hi: x = bp(x, lo, hi)
    elif hi: x = lp(x, hi)
    elif lo: x = hp(x, lo)
    return x * env(d, .0006, dec) * amp

def whoosh(d, f0, f1, q=3.0, peak=.45, amp=1.0, pw=2.0):
    x = svf(N(d), sweep(f0, f1, d), q)
    return x * bump(d, peak, pw) * amp

def crackle(d, rate=70, amp=1.0, lo=2000, dec=None):
    """Tiếng điện xẹt: nhiễu cao cổng ngẫu nhiên."""
    n = int(d * SR)
    gate = (rng.random(int(d * rate) + 2) > .45).astype(float)
    gate = np.repeat(gate, int(SR / rate))[:n]
    gate = lp(gate, 900, 1)
    x = hp(N(d), lo) * gate
    if dec: x *= np.exp(-T(d) / dec)
    return x * amp

def finish(x, peak=.92):
    x = np.nan_to_num(x)
    x = x - np.mean(x)
    m = np.max(np.abs(x)) or 1.0
    x = x / m * peak
    fi = int(.002 * SR); fo = int(.012 * SR)
    x[:fi] *= np.linspace(0, 1, fi)
    x[-fo:] *= np.linspace(1, 0, fo)
    return x


# ------------------------------------------------------------------ giao diện
def ui_click():
    return mix(osc(sweep(1700, 950, .06)) * env(.06, .0008, .018) * .7, noise_burst(.015, .004, 3000, 9000, .5))

def ui_select():
    return reverb(mix(bell(784, .35, .8), (bell(1175, .4, .8), .075)), .2, .3)

def ui_back():
    return mix(osc(sweep(820, 480, .1), "tri") * env(.1, .001, .03) * .8, noise_burst(.012, .003, 2000, 8000, .4))

def ui_start():
    d = 1.2
    boom = thump(95, 30, d, .35, 1.0)
    rise = whoosh(.7, 250, 7000, 3, .85, .55, 1.6)
    chord = mix(bell(392, 1.0, .6), bell(587, 1.0, .5), bell(784, 1.0, .5), bell(1175, 1.0, .25))
    return reverb(mix((boom, .5, 1.0), rise, (chord, .5, .8), (noise_burst(.15, .05, 200, 2500, .7), .5)), .3, .6)


# ------------------------------------------------------------------ đánh trúng
def hit_n(f0, c0, c1):
    d = .17
    return mix(thump(f0, f0 * .3, d, .05, .95), noise_burst(d, .028, c0, c1, .9), osc(sweep(900, 300, d)) * env(d, .001, .015) * .3)

def hit_crit():
    d = .45
    ring = sum(bell(f, d, a, ratios=(1,), amps=(1,), brightness=.7) for f, a in [(1900, .45), (2610, .4), (3330, .3), (4410, .2)])
    return reverb(mix(thump(130, 38, d, .08, 1.1), noise_burst(d, .04, 800, 9000, 1.0), ring), .18, .25)

def hit_boss():
    d = .4
    return drive(mix(thump(95, 28, d, .13, 1.2), noise_burst(d, .09, 0, 900, 1.0), noise_burst(d, .02, 1500, 5000, .6)), 1.6)

def hit_gon():
    d = .3
    return drive(mix(thump(150, 38, d, .09, 1.3), noise_burst(d, .05, 0, 1800, .9), noise_burst(d, .015, 2000, 6000, .6), osc(sweep(60, 30, d)) * env(d, .002, .12) * .8), 1.8)

def hit_killua():
    d = .26
    zap = osc(sweep(5200, 700, d)) * env(d, .0008, .035) * .5
    return mix(crackle(d, 110, 1.0, 2500, .09), zap, thump(170, 60, d, .04, .55))

def hit_kurotsuki():
    d = .26
    return reverb(mix(noise_burst(d, .028, 3000, 12000, 1.0), bell(3100, d, .55, ratios=(1, 1.5), amps=(1, .4)), thump(190, 70, d, .035, .5)), .15, .2)

def hit_hisoka():
    d = .2
    return mix(noise_burst(d, .02, 4000, 11000, .9), thump(210, 80, d, .04, .7), bell(2600, d, .25, ratios=(1, 2), amps=(1, .3)))

def hit_illumi():
    d = .2
    return mix(bell(3600, d, .65, ratios=(1, 1.4), amps=(1, .35)), thump(150, 55, d, .05, .6), noise_burst(d, .02, 5000, 12000, .5))

def hit_kurapika():
    d = .26
    return mix(thump(160, 50, d, .05, .85), clink(2100, .22, .8), clink(3300, .16, .5), noise_burst(d, .02, 1500, 7000, .6))


# ------------------------------------------------------------------ chết / bị đau / nổ
def die_ant(f0=520, wob=30):
    d = .42
    t = T(d)
    f = sweep(f0, 80, d) + 70 * np.sin(2 * np.pi * wob * t) * np.exp(-t / .15)
    body = osc(f, "saw") * env(d, .002, .12)
    body = lp(body, 2400)
    sq = svf(N(d), sweep(1400, 300, d), 3) * env(d, .002, .1) * .8
    pop = noise_burst(.05, .015, 300, 4000, .8)
    return mix(body * .9, sq, pop)

def die_boss():
    d = 2.4
    t = T(d)
    f = sweep(95, 22, d) + 14 * np.sin(2 * np.pi * 7 * t)
    growl = lp(osc(f, "saw"), 600) * env(d, .01, .9) * 1.1
    rum = svf(N(d), sweep(900, 50, d), 1.2, "lp") * env(d, .004, .7) * 2.0
    boom = thump(85, 24, d, .5, 1.3)
    shards = sum(bell(f_, .9, .13) for f_ in (1480, 1960, 2640))
    return reverb(drive(mix(growl, rum, boom, (shards, .02)), 1.5), .3, 1.0)

def hurt():
    d = .38
    t = T(d)
    buz = (osc(sweep(230, 150, d), "saw") + osc(sweep(244, 158, d), "saw")) * env(d, .002, .09) * .4
    return drive(mix(thump(125, 48, d, .09, 1.1), lp(buz, 1800), noise_burst(d, .03, 200, 2500, .6)), 1.4)

def boom_n(base, d, dec):
    n = N(d)
    low = svf(n, sweep(4200, 110, d), 1.1, "lp") * env(d, .002, dec) * 2.2
    sub = osc(sweep(base, base * .4, d)) * env(d, .003, dec * 1.4) * 1.3
    crack = noise_burst(d, .02, 1500, 9000, .9)
    return reverb(drive(mix(low, sub, crack), 1.6), .22, .6)

def boom_big():
    d = 1.9
    return reverb(drive(mix(boom_n(62, d, .55), (noise_burst(d, .35, 100, 1200, .8), .04), (thump(48, 20, d, .6, 1.2), 0), bell(220, 1.4, .08, ratios=(1, 2.1), amps=(1, .5))), 1.4), .3, .9)


# ------------------------------------------------------------------ di chuyển / chiêu chung
def swing_n(f0, f1, peak):
    d = .21
    return mix(whoosh(d, f0, f1, 3.2, peak, 1.0), whoosh(d, f0 * .5, f1 * .6, 1.5, peak, .35))

def dash_n(f0, f1, f2):
    d = .32
    t = T(d)
    fc = np.where(t < d * .4, f0 + (f1 - f0) * (t / (d * .4)), f1 + (f2 - f1) * ((t - d * .4) / (d * .6)))
    return mix(svf(N(d), fc, 2.4) * bump(d, .35, 1.6), noise_burst(d, .05, 150, 700, .4))

def skill_gen():
    d = .6
    t = T(d)
    tone = osc(sweep(300, 1250, d), "tri") * bump(d, .8, 1.5) * .5
    sw = whoosh(d, 400, 3200, 3, .7, .7)
    return reverb(mix(tone, sw, (bell(1568, .35, .45), .26), (noise_burst(.08, .03, 800, 6000, .5), .25)), .2, .4)

def ult_gen():
    d = 1.7
    t = T(d)
    pitch = sweep(70, 900, d)
    saw = lp(osc(pitch, "saw"), 1500) * (t / d) ** 1.6 * .8
    swell = whoosh(d, 200, 7000, 2.4, .92, .9, 2.0)
    return reverb(mix(saw, swell, (bell(660, 1.1, .6), 1.15), (bell(990, 1.1, .45), 1.15), (thump(90, 40, .6, .25, .9), 1.15)), .3, .7)

def spawn_ant():
    d = .36
    t = T(d)
    f = sweep(1250, 380, d) + 120 * np.sin(2 * np.pi * 22 * t)
    return lp(osc(f, "saw"), 3000) * env(d, .004, .12) * .8

def ant_attack():
    d = .2
    return mix(svf(N(d), sweep(3600, 1400, d), 5) * env(d, .002, .05), thump(180, 80, d, .03, .4))

def boss_warn():
    d = .75
    t = T(d)
    f = sweep(130, 260, d)
    horn = lp(osc(f, "saw") + osc(f * 1.5, "saw") * .6, 1400) * bump(d, .55, 1.3)
    return reverb(mix(horn * .8, thump(70, 45, .4, .18, .8), noise_burst(.4, .15, 300, 2500, .3)), .2, .5)

def boss_roar():
    d = 1.8
    t = T(d)
    f = sweep(105, 52, d) + 10 * np.sin(2 * np.pi * 6 * t)
    gr = osc(f, "saw") + .6 * osc(f * 2.01, "saw")
    voice = svf(gr, 450 + 600 * np.sin(2 * np.pi * .9 * t) ** 2, 2.2, "bp") * 3.0
    trem = .65 + .35 * np.sin(2 * np.pi * 22 * t)
    amp = bump(d, .18, 1.1) * trem
    return reverb(drive(mix(voice * amp, noise_burst(d, .6, 100, 1400, .5), thump(70, 28, d, .35, 1.0)), 1.8), .25, .9)

def boss_volley():
    d = .6
    t = T(d)
    parts = [(osc(sweep(1100 - 120 * i, 260, .2), "tri") * env(.2, .002, .05) * .6, .07 * i) for i in range(5)]
    return mix(whoosh(d, 500, 2600, 2.4, .35, .6), *parts)

def wave_start():
    d = 1.4
    def horn(f, dd, a=1.0):
        s = lp(tone(f, dd, "saw") + tone(f * 1.003, dd, "saw") * .8, 1100) * bump(dd, .4, 1.2) * a
        return s
    return reverb(mix(horn(146.8, .8), horn(220, .8, .8), (horn(196, .9), .45), (horn(293.7, .9, .8), .45),
                      thump(90, 50, .5, .2, 1.0), (thump(95, 52, .5, .2, 1.0), .45)), .25, .6)

def wave_clear():
    notes = [523.3, 659.3, 784.0, 1046.5]
    return reverb(mix(*[(bell(n, .6, .7), i * .11) for i, n in enumerate(notes)], (bell(1568, .8, .4), .48)), .3, .6)

def ult_ready():
    d = .7
    t = T(d)
    shim = osc(sweep(800, 2600, d), "sin") * bump(d, .6, 1.2) * .35 * (1 + .6 * np.sin(2 * np.pi * 18 * t))
    return reverb(mix(shim, (bell(1319, .5, .7), .12), (bell(1760, .5, .6), .22)), .3, .4)

def gameover():
    d = 2.6
    notes = [392.0, 370.0, 329.6, 293.7]
    pad_ = lp(osc(sweep(196, 110, d), "saw") + osc(sweep(197, 110.5, d), "saw"), 520) * bump(d, .15, 1.1) * .9
    return reverb(mix(pad_, *[(bell(n, 1.2, .7), i * .4) for i, n in enumerate(notes)], (thump(70, 30, 1.2, .5, .9), 1.5)), .35, 1.0)

def combo_n():
    return reverb(mix(bell(1047, .3, .8), (bell(1568, .3, .5), .045)), .15, .2)

def heartbeat():
    d = .6
    return lp(mix(thump(75, 38, .3, .09, 1.0), (thump(65, 34, .3, .09, .75), .23)), 220, 2)


# ------------------------------------------------------------------ HISOKA
def swing_hisoka(f0, f1):
    d = .16
    return mix(whoosh(d, f0, f1, 5, .35, .8), (bell(5300, .05, .25, ratios=(1,), amps=(1,)), .02))

def skill_hisoka():
    d = .85
    t = T(d)
    f = 520 + 430 * np.exp(-t * 5) * np.sin(2 * np.pi * 13 * t) + 200 * np.exp(-t * 2)
    gum = osc(f, "tri") * env(d, .004, .32) * .8
    sticky = svf(N(d), 300 + 500 * np.abs(np.sin(2 * np.pi * 9 * t)), 3, "lp") * env(d, .004, .15) * .5
    return reverb(mix(gum, sticky, (bell(1760, .4, .35), .02), (bell(2349, .35, .25), .12)), .2, .4)

def ult_hisoka():
    d = 2.0
    t = T(d)
    chord = sum(tone(f * (1 + .004 * i), d, "saw") for f in (220.0, 261.6, 311.1, 370.0) for i in (0, 1))
    fc = 350 + 2200 * (t / d) ** 1.5
    pad_ = svf(chord, fc, 1.4, "lp") * (.6 + .4 * np.sin(2 * np.pi * 5 * t)) * bump(d, .85, 1.1) * .22
    sw = whoosh(d, 400, 8000, 3, .88, .5, 1.8)
    spark = mix(*[(bell(1318 * (1 + .13 * i), .5, .35), 1.45 + .09 * i) for i in range(5)])
    return reverb(mix(pad_ * 2.4, sw, (spark, 0), (thump(80, 35, .5, .2, .7), 1.5)), .3, .8)

def dash_hisoka():
    d = .34
    return mix(whoosh(d, 900, 4200, 3, .4, .8), *[(bell(f, .12, .3, ratios=(1, 2.5), amps=(1, .3)), .025 * i) for i, f in enumerate((2093, 2637, 3136, 3951))])


# ------------------------------------------------------------------ ILLUMI
def swing_illumi(f):
    d = .13
    return mix(bell(f, .1, .8, ratios=(1, 1.5), amps=(1, .3)), whoosh(d, 3000, 7000, 4, .3, .5))

def skill_illumi():
    d = .8
    t = T(d)
    pulse = osc(sweep(65, 105, d)) * bump(d, .4, 1.3) * (.7 + .3 * np.sin(2 * np.pi * 9 * t))
    zings = [(bell(f, .25, .5, ratios=(1, 1.4), amps=(1, .35)), .12 * i + .1) for i, f in enumerate((4200, 3800, 3400, 3000))]
    return reverb(mix(pulse * 1.1, whoosh(d, 500, 2000, 2, .5, .4), *zings), .35, .6)

def ult_illumi():
    d = 3.0
    t = T(d)
    gong = bell(98, d, 1.0, ratios=(1, 1.59, 2.14, 2.3, 2.65, 3.5), amps=(1, .7, .5, .45, .35, .25), brightness=2.2)
    drone = osc(49 + 3 * np.sin(2 * np.pi * .7 * t)) * bump(d, .3, 1.2) * .6
    swell = hp(N(d), 1500) * (t / d) ** 2 * np.exp(-t / 2.2) * .35
    return reverb(drive(mix(gong * 1.1, drone, swell, whoosh(1.2, 300, 6000, 2, .9, .4)), 1.3), .35, 1.2)

def dash_illumi():
    d = .4
    return reverb(mix(whoosh(d, 1300, 280, 2.2, .35, .9), osc(sweep(300, 170, d)) * bump(d, .3) * .25), .45, .5)


# ------------------------------------------------------------------ GON
def swing_gon(f0, f1):
    d = .22
    return mix(whoosh(d, f0, f1, 2.0, .45, 1.0), thump(110, 55, d, .05, .35))

def skill_gon():
    d = .6
    t = T(d)
    charge = osc(sweep(110, 560, d), "tri") * bump(d, .85, 1.4) * .8 + osc(sweep(55, 280, d)) * bump(d, .85) * .6
    return reverb(drive(mix(charge, whoosh(d, 300, 2500, 1.6, .8, .6), (thump(160, 45, .3, .1, 1.1), .42), (noise_burst(.2, .06, 500, 6000, .6), .42)), 1.4), .2, .4)

def ult_gon():
    d = 1.9
    t = T(d)
    rise = osc(sweep(38, 420, d)) * (t / d) ** 1.8 * 1.0 + lp(osc(sweep(76, 840, d), "saw"), 1200) * (t / d) ** 2 * .45
    shake = (.7 + .3 * np.sin(2 * np.pi * (6 + 18 * t / d) * t))
    rum = svf(N(d), 120 + 900 * (t / d) ** 2, 1.5, "lp") * (t / d) * .9
    return drive(mix(rise * shake, rum, (noise_burst(.12, .04, 400, 5000, .7), 1.78)), 1.5)

def dash_gon():
    d = .3
    return mix(whoosh(d, 220, 900, 1.6, .3, 1.0), thump(100, 40, d, .09, .7))


# ------------------------------------------------------------------ KILLUA
def swing_killua(f0, f1):
    d = .15
    return mix(whoosh(d, f0, f1, 3, .35, .8), crackle(d, 140, .5, 3500, .06))

def skill_killua():
    d = .75
    t = T(d)
    zap = osc(sweep(5200, 260, d), "saw") * env(d, .001, .09) * .5
    thunder = svf(N(d), sweep(1200, 70, d), 1.2, "lp") * env(d, .006, .3) * 2.2
    return reverb(drive(mix(crackle(d, 90, 1.1, 2200, .22), zap, thunder, thump(100, 35, d, .2, .8)), 1.4), .2, .5)

def ult_killua():
    d = 2.0
    t = T(d)
    whine = lp(osc(sweep(260, 5200, d) * (1 + .02 * np.sin(2 * np.pi * 40 * t)), "saw"), 7000) * (t / d) ** 1.4 * .5
    cr = crackle(d, 110, 1.0, 2000) * (.2 + .8 * t / d)
    sw = whoosh(d, 400, 9000, 2.4, .9, .5, 1.8)
    tail = mix(*[(crackle(.1, 150, .9, 2500, .04), 1.55 + .08 * i) for i in range(5)])
    return reverb(drive(mix(whine, cr * .8, sw, tail, (thump(95, 38, .5, .2, .9), 1.7)), 1.3), .2, .5)

def dash_killua():
    d = .24
    return mix(svf(N(d), sweep(700, 7000, d), 3) * bump(d, .5, 1.5), crackle(d, 160, .6, 3000, .1))


# ------------------------------------------------------------------ KURAPIKA
def rattle(n, span, f=2300, amp=1.0, spread=.35):
    parts = []
    for i in range(n):
        ff = f * (1 + spread * (rng.random() - .5))
        parts.append((clink(ff, .1, amp * (.5 + .5 * rng.random())), span * (i / max(n - 1, 1)) + .004 * rng.random()))
    return mix(*parts)

def swing_kurapika(f0, f1):
    d = .32
    return mix(whoosh(d, f0, f1, 2.6, .35, .9), (rattle(5, .16, 2300, .7), .02))

def skill_kurapika():
    d = .8
    return reverb(mix(whoosh(.5, 400, 3000, 2.2, .6, .8), (rattle(10, .38, 2500, .7), .03), (bell(700, .35, .7, ratios=(1, 1.5, 2.2), amps=(1, .6, .4)), .45), (thump(120, 50, .25, .08, .9), .45)), .2, .4)

def ult_kurapika():
    d = 2.6
    t = T(d)
    padv = sum(tone(f * (1 + .003 * k), d, "saw") for f in (164.8, 246.9, 329.6) for k in (0, 1))
    pad_ = svf(padv, 300 + 900 * (t / d), 1.3, "lp") * bump(d, .75, 1.1) * .22
    ch = mix(*[(clink(2000 + 300 * rng.random(), .12, .5), 1.4 * (i / 18) ** .6 * 1.0) for i in range(18)])
    hb = mix((thump(70, 36, .3, .09, 1.0), .15), (thump(62, 34, .3, .09, .8), .38), (thump(70, 36, .3, .09, 1.0), 1.0), (thump(62, 34, .3, .09, .8), 1.23))
    shimmer = (bell(1760, 1.0, .55), 1.7)
    return reverb(mix(pad_ * 2.6, ch, hb * 1.0, shimmer, whoosh(d, 300, 6000, 2.5, .8, .35, 1.8)), .35, 1.0)

def dash_kurapika():
    d = .32
    return mix(whoosh(d, 500, 1700, 2.2, .4, .6), (rattle(6, .2, 2300, .55), .02))


# ------------------------------------------------------------------ KUROTSUKI
def swing_kuro(f0, f1, ring=3300):
    d = .26
    sh = svf(N(d), sweep(f0, f1, d), 6) * bump(d, .22, 1.6) * 1.2
    return reverb(mix(sh, bell(ring, .22, .45, ratios=(1, 2.01), amps=(1, .35)), whoosh(d, 400, 1800, 2, .4, .4), noise_burst(.012, .004, 3000, 10000, .4)), .12, .2)

def skill_kuro():
    d = .62
    return reverb(mix(whoosh(.24, 350, 2800, 2.5, .6, .9), (swing_kuro(2500, 9500, 3600), .17), (thump(120, 45, .3, .1, .7), .18), (bell(2093, .4, .3), .22)), .2, .4)

def ult_kuro():
    d = 3.2
    t = T(d)
    deep = bell(73.4, d, 1.0, ratios=(1, 2.0, 2.76, 4.07, 5.43), amps=(1, .55, .45, .3, .22), brightness=2.4)
    moon = mix(*[(bell(1568 * (1 + .12 * (i % 4)), .8, .28), .5 + .22 * i) for i in range(8)])
    sw = whoosh(1.6, 200, 7000, 2.2, .9, .6, 1.8)
    return reverb(drive(mix(deep * 1.1, moon, sw, (swing_kuro(2500, 11000, 3800), 1.55), (thump(75, 30, .8, .3, .9), 1.6)), 1.2), .35, 1.2)

def dash_kuro():
    d = .24
    return mix(svf(N(d), sweep(1400, 6500, d), 3.5) * bump(d, .4, 1.5), (bell(3500, .12, .25, ratios=(1, 2.01), amps=(1, .3)), .1), thump(100, 50, d, .05, .3))

def katana_draw():
    d = .5
    t = T(d)
    scrape = svf(N(d), sweep(700, 5200, d) * (1 + .06 * np.sin(2 * np.pi * 31 * t)), 9) * bump(d, .8, 1.2) * 1.8
    return reverb(mix(scrape, (bell(3600, .3, .5, ratios=(1, 1.51, 2.4), amps=(1, .4, .2)), .38), (noise_burst(.02, .006, 2500, 9000, .5), .4)), .2, .3)

def katana_sheath():
    d = .42
    return reverb(mix(noise_burst(.03, .008, 1800, 9000, 1.0), (noise_burst(.04, .01, 1500, 8000, .9), .1), (bell(2450, .3, .5, ratios=(1, 1.5, 2.2), amps=(1, .5, .3)), .1), thump(160, 70, .12, .03, .6)), .18, .25)

# ------------------------------------------------------------------ SUKUNA
def swing_suku(f0, f1):
    """Nhát Giải: đường cắt mảnh, khô, không dội — nghe như không khí bị cắt đôi."""
    d = .2
    sl = svf(N(d), sweep(f0, f1, d), 9) * bump(d, .3, 1.4) * 1.3
    return mix(sl, (noise_burst(.014, .004, 5000, 14000, .7), .04), thump(150, 55, d, .04, .3))

def hit_sukuna():
    d = .3
    return mix(noise_burst(d, .04, 2500, 11000, 1.0), crackle(d, 90, .6, 3000, .08), thump(140, 45, d, .06, .7))

def skill_suku():
    """Vạn Trảm: loạt nhát cắt dồn dập rồi một nhát Bát nặng."""
    parts = [(swing_suku(5200 + 300 * i, 12000 - 200 * i), .035 * i, .8) for i in range(9)]
    return reverb(mix(*parts, (thump(95, 38, .45, .16, 1.0), .34), (noise_burst(.18, .06, 400, 5000, .7), .34)), .2, .4)

def dash_suku():
    d = .24
    return mix(svf(N(d), sweep(2500, 9000, d), 5) * bump(d, .35, 1.5) * .9, (swing_suku(6000, 12000), .06, .7), thump(90, 45, d, .05, .4))

def ult_suku():
    """Lãnh Địa: chuông trầm dội, gầm sâu, bão chém, rồi một nhát Đoạn Trảm xé toạc."""
    d = 8.6
    t = T(d)
    gong = bell(55, d, 1.0, ratios=(1, 1.5, 2.01, 2.76, 4.2), amps=(1, .6, .5, .35, .2), brightness=3.0)
    rumble = lp(N(d), 160) * (.3 + .7 * np.minimum(t / 2, 1)) * .7
    parts = [gong * .9, rumble]
    for i in range(70):   # bão chém trải đều
        st = 1.3 + i * .09 + rng.random() * .05
        parts.append((swing_suku(4000 + rng.random() * 3000, 9000 + rng.random() * 4000), st, .22 + .18 * rng.random()))
    parts.append((whoosh(1.3, 150, 8000, 2.2, .95, .9, 2.2), 6.5, 1.0))
    parts.append((thump(70, 28, 1.2, .5, 1.0), 8.0, 1.6)); parts.append((noise_burst(.5, .15, 300, 9000, 1.0), 8.0, 1.0))
    return reverb(drive(mix(*parts), 1.2), .35, 1.2)


# ------------------------------------------------------------------ danh sách
SOUNDS = {}
def add(name, fn, gain=1.0):
    SOUNDS[name] = (fn, gain)

add("ui_click", ui_click, .55); add("ui_select", ui_select, .7); add("ui_back", ui_back, .5); add("ui_start", ui_start, 1.0)

add("hit_1", lambda: hit_n(190, 1800, 5000), .75); add("hit_2", lambda: hit_n(160, 2400, 6500), .75); add("hit_3", lambda: hit_n(225, 1500, 4200), .75)
add("hit_crit", hit_crit, .95); add("hit_boss", hit_boss, .62)
add("hit_gon", hit_gon, .62); add("hit_killua", hit_killua, .85); add("hit_kurotsuki", hit_kurotsuki, .85)
add("hit_hisoka", hit_hisoka, .75); add("hit_illumi", hit_illumi, .75); add("hit_kurapika", hit_kurapika, .8)

add("die_ant_1", lambda: die_ant(520, 30), .8); add("die_ant_2", lambda: die_ant(430, 24), .8); add("die_ant_3", lambda: die_ant(640, 38), .8)
add("die_boss", die_boss, 1.0); add("hurt", hurt, .7)
add("boom_1", lambda: boom_n(70, 1.0, .26), 1.0); add("boom_2", lambda: boom_n(82, .9, .22), 1.0); add("boom_big", boom_big, 1.0)

add("swing_1", lambda: swing_n(700, 3200, .4), .55); add("swing_2", lambda: swing_n(1100, 4200, .35), .55); add("swing_3", lambda: swing_n(550, 2600, .5), .55)
add("dash_1", lambda: dash_n(500, 2600, 900), .7); add("dash_2", lambda: dash_n(400, 2000, 700), .7)
add("skill", skill_gen, .85); add("ult", ult_gen, 1.0)

add("spawn", spawn_ant, .5); add("ant_attack", ant_attack, .55)
add("boss_warn", boss_warn, .9); add("boss_roar", boss_roar, 1.0); add("boss_volley", boss_volley, .8)
add("wave_start", wave_start, .9); add("wave_clear", wave_clear, .85); add("ult_ready", ult_ready, .8)
add("gameover", gameover, .95); add("combo", combo_n, .6); add("heartbeat", heartbeat, .9)

add("swing_hisoka_1", lambda: swing_hisoka(3800, 7800), .55); add("swing_hisoka_2", lambda: swing_hisoka(4600, 9000), .55)
add("skill_hisoka", skill_hisoka, .85); add("ult_hisoka", ult_hisoka, 1.0); add("dash_hisoka", dash_hisoka, .7)

add("swing_illumi_1", lambda: swing_illumi(3400), .6); add("swing_illumi_2", lambda: swing_illumi(4100), .6)
add("skill_illumi", skill_illumi, .85); add("ult_illumi", ult_illumi, 1.0); add("dash_illumi", dash_illumi, .65)

add("swing_gon_1", lambda: swing_gon(500, 1600), .75); add("swing_gon_2", lambda: swing_gon(420, 1300), .75)
add("skill_gon", skill_gon, .95); add("ult_gon", ult_gon, 1.0); add("dash_gon", dash_gon, .8)

add("swing_killua_1", lambda: swing_killua(1800, 6500), .6); add("swing_killua_2", lambda: swing_killua(2400, 7500), .6)
add("skill_killua", skill_killua, .95); add("ult_killua", ult_killua, 1.0); add("dash_killua", dash_killua, .75)

add("swing_kurapika_1", lambda: swing_kurapika(600, 2400), .65); add("swing_kurapika_2", lambda: swing_kurapika(800, 2900), .65)
add("skill_kurapika", skill_kurapika, .85); add("ult_kurapika", ult_kurapika, 1.0); add("dash_kurapika", dash_kurapika, .65)

add("swing_kurotsuki_1", lambda: swing_kuro(2500, 9500, 3300), .7); add("swing_kurotsuki_2", lambda: swing_kuro(9500, 3000, 2900), .7)
add("skill_kurotsuki", skill_kuro, .9); add("ult_kurotsuki", ult_kuro, 1.0); add("dash_kurotsuki", dash_kuro, .7)
add("swing_sukuna_1", lambda: swing_suku(5200, 11000), .65); add("swing_sukuna_2", lambda: swing_suku(11000, 5000), .65)
add("hit_sukuna", hit_sukuna, .85); add("skill_sukuna", skill_suku, .95); add("ult_sukuna", ult_suku, 1.0); add("dash_sukuna", dash_suku, .7)
add("katana_draw", katana_draw, .7); add("katana_sheath", katana_sheath, .75)


def write_wav(path, x):
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def main():
    os.makedirs(OUT, exist_ok=True)
    only = set(sys.argv[1:])
    total = 0
    for name, (fn, gain) in SOUNDS.items():
        if only and name not in only: continue
        x = finish(fn(), .95 * gain)
        write_wav(os.path.join(OUT, name + ".wav"), x)
        total += len(x) * 2
        print(f"{name:22s} {len(x) / SR:5.2f}s  peak {np.max(np.abs(x)):.2f}  rms {np.sqrt(np.mean(x ** 2)):.3f}")
    print(f"{len(SOUNDS)} âm, tổng {total / 1024:.0f} KB (wav)")
    # Nén sang ogg để APK nhẹ (SoundPool đọc ogg được); xoá wav nếu có ffmpeg
    if shutil.which("ffmpeg"):
        for name in SOUNDS:
            if only and name not in only: continue
            w = os.path.join(OUT, name + ".wav"); o = os.path.join(OUT, name + ".ogg")
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", w, "-c:a", "libvorbis", "-q:a", "5", o], check=True)
            os.remove(w)
        print("đã nén ogg")


if __name__ == "__main__":
    main()
