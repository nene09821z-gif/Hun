# NEN ARENA — tiến độ port HTML → Kotlin Compose (native)

## Giai đoạn 3.5: model 3D thật cho Killua và Neferpitou
- Engine mới: mesh có **texture + alpha-cut**, **skinning bằng xương** (tối đa 32 xương, shader tự nội suy 4 trọng số), viền đen cũng chạy qua skin.
- `engine/Model.kt` nạp `assets/<tên>.json + .bin + .png` (ModelData dùng chung, SkinModel là bản sao riêng có vật liệu/xương riêng).
- `game/ModelRig.kt`: `attachSkinModel()` ẩn khung người bằng hình khối nhưng vẫn để nó chạy mọi chuyển động (đi, đánh, SIG, keyframe chiêu);
  cuối `poseHuman` các góc khớp (hông, thân, đầu, vai, khuỷu, đùi, gối) được chép sang xương của model. Mọi code chiêu thức/aura/hand() giữ nguyên.
- **Killua**: model từ `killua-zoldyck.zip`, đã bỏ ván trượt, tự gán trọng số xương, hạ tay từ tư thế chữ T.
- **Neferpitou (boss)**: model `neferpitou.glb`, rút 69 xương xuống 29, đuôi 7 đốt tự vẫy.
- `tools/export_models.mjs`: script Node (gltf-transform) chuyển .glb sang định dạng assets. Chạy lại khi đổi model.
- Chưa làm: tóc Pitou chưa có vật lý, ngón tay không cử động (gộp vào cổ tay).

## Giai đoạn 3 (bản này): thêm Gon · Killua · Kurapika + bộ tư thế đặc trưng
- Gon: Quyền Cương/Cần Câu, Kéo, Đá, Paa + chế độ HẮC HOÁ 15s (đổi 3 chiêu, hao máu, aura tím, vignette tím, thanh đếm giờ).
- Killua: Lôi Trảo/Yo-yo, Thunderbolt chuyền 5 địch, Godspeed, ULT Thần Lôi 30s + Ám Sát Zoldyck sau khi lướt.
- Kurapika: Holy Chain, Judgment Chain, Chain Jail, Emperor Time (mắt đỏ rực, da ửng đỏ, 6 xích nhiều màu).
- Bộ chuyển động đặc trưng (SIG) cho 5 nhân vật + keyframe tư thế riêng cho từng chiêu (MV, đủ 13 nhân vật).

Nhân vật đã xong: Hisoka, Illumi, Gon, Killua, Kurapika. Còn lại: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging.

## Giai đoạn 2
Đã xong, KHÔNG cần WebView, toàn bộ tự vẽ bằng OpenGL ES 3.0 + Compose:

**Engine**
- Hệ hạt point-sprite (900 hạt, tự giảm theo mức đồ họa), nổ hạt, nổ trái tim.
- Aura shader (viền sáng + sóng + nhấp nháy) cho mọi nhân vật, lớp aura tối cho Illumi.
- FX lưới: vòng sóng, trụ sáng, vòm, chùm tia (bám mục tiêu), vệt chém, cầu sáng, vòng cảnh báo boss, rune, vết nứt.

**Gameplay**
- Vòng lặp trận: đợt kiến, 3 loại kiến (Lính / Cận Vệ / Cánh bay), boss 3 con (Pitou, Pouf, Youpi) mỗi 5 đợt với chiêu riêng.
- Sát thương, chí mạng, knockback, choáng, hit-stop, slow-mo, rung camera, camera điện ảnh khi tung chiêu / ULT, thanh máu 3D trên đầu kẻ địch, số sát thương bay, combo.
- Con rối Needle (Illumi) – đồng minh tự đánh rồi nổ.

**Giao diện Compose**: màn hình chính, chọn nhân vật (chip + bảng chỉ số + mô tả chiêu), HUD (máu/Nen/boss/đợt/điểm/combo), 5 nút (đánh giữ, chiêu 1, chiêu 2, ULT có hiệu ứng sẵn sàng, lướt) có vòng hồi chiêu, joystick, vuốt xoay camera, tạm dừng, thất bại, hiệu ứng nháy/đỏ viền/tia tốc độ.



## Còn lại (giai đoạn 3 trở đi)
- 8 nhân vật: Netero, Meruem, Zeno, Chrollo, Silva, Leorio, Morel, Ging (đủ 4 kỹ năng + mô hình + aura).
- Kẻ địch Nen (Franklin, Feitan, Uvogin, Nobunaga) & AI elite.
- Pose đặc trưng / animation keyframe (SIG, MV) từng nhân vật.
- Âm thanh (SFX đang là hàm rỗng trong Hud.kt → thay bằng bộ tổng hợp AudioTrack).
- Lưu điểm cao, màn Hướng dẫn.

## Giai đoạn 3.6: Kurotsuki (nhân vật thứ 6) + katana asset
- `tools/export_katana.mjs`: chuyển `katana.glb` -> `assets/katana.json/.bin/.jpg` (dài 1 đơn vị, gốc = giữa cán, mũi +Z, lưỡi sắc -X; mesh 0..2 là lưỡi để phát sáng).
- `game/Chars3.kt`: Kurotsuki với aura xanh nhiều lớp (lõi trắng, ngọn lửa ngoài, hạt xoắn ốc, vòng rune dưới chân, 4 trăng khuyết bay quanh, ánh kiếm; đỏ khi Nhuốm Máu, trắng lạnh khi Nguyệt Thực).
- Tư thế/đòn vung kiếm riêng trong `kuroSig` (Sig.kt gọi), hook `kuroDash` trong `Game.doDash`.
- Thu/rút kiếm: model katana thứ hai gắn ở hông (chỉ hiện chuôi+tsuba), `Human.sheathed`; tự rút khi tấn công, tự thu sau 3 giây ngoài giao tranh (act "knoto").
- Chiêu 2 mới "Cư Hợp: Nguyệt Quang Loạn Trảm" thay Huyết Trảm: cúi thấp tra kiếm -> 6 nhát xuyên qua địch (dịch chuyển, vệt chém trăng khuyết cong `slashDisc`) -> tra kiếm "tách" nổ mọi vết chém.

## Giai đoạn 3.7
- Killua Godspeed: tự động né mọi đòn (hurtP -> godDodge: chớp sang bên, không mất máu/không bị hất, hồi 0.1s); bỏ rung thân (torso.rot.z); ult mượt hơn.
- Hisoka: làm lại mặt theo ảnh (tóc vuốt ngược dài có lọn tím, mắt hẹp vàng mi dày, chân mày sắc, mũi, sao xanh má phải nhân vật, giọt lệ vàng-lục, cười nhếch).
