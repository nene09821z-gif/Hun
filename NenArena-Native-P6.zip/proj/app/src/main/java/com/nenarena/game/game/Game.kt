package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

class Game : GameLoop {
    override val scene = Scene()
    val world: World
    val fx: Fx
    val models = HashMap<String, Human>()
    val chars: List<CharCfg>

    // ---------- trạng thái ----------
    var state = "title"
    lateinit var P: Player
    var hasP = false
    val EN = ArrayList<Enemy>(); val projs = ArrayList<Proj>(); val zones = ArrayList<Zone>(); val timers = ArrayList<Timer>()
    var wave = 1; var kills = 0; var score = 0; var gtime = 0f
    val queue = ArrayList<String>(); var spawnT = 0f; var waveClear = 0f
    var slowS = 1f; var slowT = 0f; var slowT0 = 0f; var hs = 0f; var shake = 0f
    var boss: Enemy? = null; var comboN = 0; var comboT = 0f
    var tAll = 0f; var selIdx = 0; var menuId = ""
    private var portrait = true; private var aspect = 1f
    private val dns = ArrayList<Dn>(); private var dnId = 0
    private var toastTxt = ""; private var toastT = 0f; private var toastId = 0
    private var bnT = ""; private var bnS = ""; private var bnId = 0
    private var flC = 0; private var flA = 0f; private var flMs = 0; private var flId = 0
    private var hurtId = 0; private var speedId = 0; private var speedMs = 0
    private var overStats: List<Pair<String, String>> = emptyList()
    private var hudN = 0

    // ---------- camera ----------
    private var camYaw = PIF; private var camPOff = 0f; private var camPn = 0f; private var idle = 1f
    private var snapTo = 0f; private var snapT = 0f
    private var shotT = 0f; private var shotD = 0f; private var shotOn = false
    private var shDist = 0f; private var shFov = 0f; private var shYaw = 0f; private var shH = 0f
    private val camPos = Vec3(0f, 6f, 20f); private val camLook = Vec3(0f, 1f, 0f)
    private var camFirst = true; private var curFov = 50f
    private val tp = Vec3(); private val tl = Vec3()
    private val projM = FloatArray(16); private val viewM = FloatArray(16); private val vpM = FloatArray(16)

    private val barBg = Geometry.plane(1.4f, .16f); private val barFgG = Geometry.plane(1f, .1f).translated(.5f, 0f, 0f)
    private val barBgMat = basic(0x1a0810); private val barFgMat = basic(0xff5a5a); private val barAllyMat = basic(0x9a7aff)
    private val pmC = HashMap<Int, Material>()
    fun pm(h: Int) = pmC.getOrPut(h) { basic(h) }

    init {
        scene.fogHex = 0x3b1230; scene.fogDensity = 0.0125f
        Particles.keep = if (Quality.tier.detail < 1f) max(.35f, Quality.tier.detail) else 1f
        world = World(scene)
        fx = Fx(scene.root)
        chars = allChars()
        for (c in chars) {
            val h = c.build(); models[c.id] = h; scene.root.add(h.root); h.root.visible = false
        }
        ModelCache.get("pitou")   // nạp trước model boss để lúc boss xuất hiện không bị khựng
        Hud.chars = chars; Hud.gameRef = this
        gotoTitle()
    }

    override fun onSurface(w: Int, h: Int) { portrait = h > w; aspect = w.toFloat() / h }

    // ================= tiện ích chiến đấu =================
    fun later(t: Float, fn: () -> Unit) { timers.add(Timer(t, fn)) }
    private fun runTimers(dt: Float) {
        var i = timers.size - 1
        while (i >= 0) { val x = timers[i]; x.t -= dt; if (x.t <= 0f) { timers.removeAt(i); try { x.fn() } catch (e: Throwable) { android.util.Log.e("NenArena", "timer", e) } }; i-- }
    }
    fun slowmo(s: Float, t: Float) { slowS = s; slowT = t; slowT0 = t }
    fun toast(t: String, sec: Float = 2.2f) { toastTxt = t; toastT = sec; toastId++ }
    fun banner(t: String, s: String = "") { bnT = t; bnS = s; bnId++ }
    fun flash(c: Int, a: Float, ms: Int) { flC = c; flA = a; flMs = ms; flId++ }
    fun speedLines(ms: Int) { speedMs = ms; speedId++ }
    fun popText(t: String, hex: Int? = null) = dmgNum(P.pos, 0f, hex ?: P.cfg.col, true, t)

    fun fwd() = Vec3(sin(P.face), 0f, cos(P.face))
    fun nearest(pos: Vec3, range: Float): Enemy? {
        var b: Enemy? = null; var bd = range
        for (e in EN) { if (e.dead || e.team != 'e' || e.spawnT > 0f) continue; val d = dxz(pos, e.pos); if (d < bd) { bd = d; b = e } }
        return b
    }
    fun aim(range: Float = 24f): Vec3 {
        val t = nearest(P.pos, range)
        if (t != null) {
            val d = Vec3(t.pos.x - P.pos.x, 0f, t.pos.z - P.pos.z); val l = d.length()
            if (l > .01f) { d.scale(1f / l); P.face = atan2(d.x, d.z); return d }
        }
        return fwd()
    }
    fun hand(hh: Float = 1.4f, f: Float = .7f) = Vec3(P.pos.x + sin(P.face) * f, P.y + hh, P.pos.z + cos(P.face) * f)
    var curSk = -1; private var tipShown = false
    /** Tạo tư thế ra đòn; nếu nhân vật có keyframe riêng (MV) cho chiêu đang dùng thì dùng keyframe đó. */
    fun act(n: String, d: Float, flip: Boolean = false) {
        if (curSk >= 0) {
            val key = P.cfg.id + ":" + curSk
            if (MV.containsKey(key)) { val a = Act(key, d, flip); a.m = curSk == 0 && P.combo % 2 == 1; P.h.act = a; return }
        }
        P.h.act = Act(n, d, flip)
    }

    /** Ám sát Zoldyck: dịch chuyển ra sau lưng địch gần nhất, đòn chí mạng. */
    fun assassinate(dmg: Float): Boolean {
        val e = nearest(P.pos, 18f) ?: return false
        val d = Vec3(e.pos.x - P.pos.x, 0f, e.pos.z - P.pos.z).normalize()
        burst(P.pos.x, 1.2f, P.pos.z, 0x101018, 16, 4f, .45f, .9f)
        P.pos.set(e.pos.x + d.x * 1.3f, 0f, e.pos.z + d.z * 1.3f); P.face = atan2(-d.x, -d.z)
        P.assassin = 0f; P.stealth = .001f; P.atkCd = .5f; P.inv = max(P.inv, .5f); act("slash", .3f); SFX.swing()
        burst(P.pos.x, 1.2f, P.pos.z, 0x101018, 16, 5f, .4f, .9f); fx.ring(e.pos.x, e.pos.z, P.cfg.col, .4f, 3f, .3f)
        hurtE(e, dmg, Hit(big = true, noCrit = true, knock = 1.5f, stun = .8f, from = P.pos, col = P.cfg.col, hs = .08f, gain = 6f)); popText("Ám Sát!", 0xffffff)
        return true
    }
    fun liveEn(r: Float, c: Int = 99): List<Enemy> =
        EN.filter { !it.dead && it.team == 'e' && it.spawnT <= 0f && dxz(P.pos, it.pos) <= r }.sortedBy { dxz(P.pos, it.pos) }.take(c)
    fun rotY(d: Vec3, a: Float): Vec3 { val c = cos(a); val s = sin(a); return Vec3(d.x * c + d.z * s, 0f, -d.x * s + d.z * c) }
    fun tgtPos(d: Vec3, rg: Float): Vec3 {
        val t = nearest(P.pos, rg); val x: Float; val z: Float
        if (t != null) { x = t.pos.x; z = t.pos.z } else { x = P.pos.x + d.x * rg * .55f; z = P.pos.z + d.z * rg * .55f }
        val v = Vec3(x, 0f, z); val c = hypot(x, z); if (c > ARENA - 2) v.scale((ARENA - 2) / c); return v
    }
    fun ringPos(c: Vec3, r: Float): Vec3 {
        val a = rnd(0f, TAU); val q = sqrt(rnd01()) * r
        var x = c.x + cos(a) * q; var z = c.z + sin(a) * q; val h = hypot(x, z)
        if (h > ARENA - 1) { x *= (ARENA - 1) / h; z *= (ARENA - 1) / h }
        return Vec3(x, 0f, z)
    }

    fun radiusHit(c: Vec3, r: Float, fn: (Enemy) -> Unit): Int {
        var n = 0
        for (e in EN.toList()) { if (e.dead || e.team != 'e' || e.spawnT > 0f) continue; if (dxz(c, e.pos) <= r + e.r) { fn(e); n++ } }
        return n
    }
    fun coneHit(o: Vec3, dir: Vec3, range: Float, half: Float, fn: (Enemy) -> Unit): Int {
        val a0 = atan2(dir.x, dir.z); var n = 0
        for (e in EN.toList()) {
            if (e.dead || e.team != 'e' || e.spawnT > 0f) continue
            val dx = e.pos.x - o.x; val dz = e.pos.z - o.z; val d = hypot(dx, dz)
            if (d > range + e.r) continue
            var da = abs(atan2(dx, dz) - a0); if (da > PIF) da = TAU - da
            if (da <= half || d < e.r + 1) { fn(e); n++ }
        }
        return n
    }
    fun lineHit(o: Vec3, dir: Vec3, len: Float, w: Float, fn: (Enemy) -> Unit): Int {
        var n = 0
        for (e in EN.toList()) {
            if (e.dead || e.team != 'e' || e.spawnT > 0f) continue
            val dx = e.pos.x - o.x; val dz = e.pos.z - o.z; val t = dx * dir.x + dz * dir.z
            if (t < -1 || t > len) continue
            val px = dx - dir.x * t; val pz = dz - dir.z * t
            if (hypot(px, pz) < w + e.r) { fn(e); n++ }
        }
        return n
    }

    fun setPull(e: Enemy, to: Vec3, dur: Float) { e.pull = Pull(e.pos.clone(), to.clone(), 0f, dur); e.stun = max(e.stun, dur + .1f) }

    fun shoot(node: Node, pos: Vec3, dir: Vec3, speed: Float, dmg: Float, r: Float = .6f, life: Float = 1f, team: Char = 'p', pierce: Int = 0,
              col: Int = 0xffffff, homing: Float = 0f, onHit: ((Enemy) -> Unit)? = null, spin: Float = 0f, knock: Float = 0f, stun: Float = 0f, trail: Boolean = true): Proj {
        val p = Proj(node, pos.clone(), dir.clone().scale(speed), dmg, r, life, team, pierce, col, homing, onHit, spin, knock, stun, trail)
        node.pos.copy(p.pos); scene.root.add(node); projs.add(p); return p
    }
    private fun removeProj(i: Int) { scene.root.remove(projs[i].node); projs.removeAt(i) }

    // ---------- số sát thương / chiếu 3D -> màn hình ----------
    private fun project(x: Float, y: Float, z: Float): FloatArray? {
        val m = vpM
        val w = m[3] * x + m[7] * y + m[11] * z + m[15]; if (w <= .05f) return null
        val cx = (m[0] * x + m[4] * y + m[8] * z + m[12]) / w; val cy = (m[1] * x + m[5] * y + m[9] * z + m[13]) / w
        return floatArrayOf(cx * .5f + .5f, -cy * .5f + .5f)
    }
    fun dmgNum(pos: Vec3, v: Float, hex: Int, big: Boolean, txt: String? = null) {
        if (dns.size > 22) return
        val s = project(pos.x, pos.y + 2.3f, pos.z) ?: return
        dns.add(Dn(dnId++, s[0], s[1], txt ?: v.roundToInt().toString(), hex, big, System.currentTimeMillis()))
    }

    // ---------- sát thương ----------
    fun hurtE(e: Enemy, dmg0: Float, o: Hit = Hit()) {
        if (e.dead) return
        var dmg = dmg0
        if (o.src != "ally") {
            dmg *= P.cfg.dmg * (if (P.dmgBuff > 0f) P.dmgBuff else 1f)
            if (P.critN > 0 && !o.noCrit) { P.critN--; dmg *= 1.6f; o.big = true }
            else if (P.cfg.crit > 0f && rnd01() < P.cfg.crit && !o.noCrit) { dmg *= 1.6f; o.big = true }
        }
        e.hp -= dmg; e.flash = 1f; e.barT = 3f
        val c = o.col ?: P.cfg.col
        burst(e.pos.x, 1.2f + e.hover, e.pos.z, c, if (o.big) 12 else 7, 5f, .35f, .55f)
        dmgNum(e.pos, dmg.roundToInt().toFloat(), if (o.big) 0xffffff else c, o.big)
        if (o.knock > 0f && !e.cfg.boss) {
            val f = o.from ?: P.pos
            val d = Vec3(e.pos.x - f.x, 0f, e.pos.z - f.z); if (d.lengthSq() < .001f) d.set(0f, 0f, 1f)
            d.normalize(); e.kb.addScaled(d, o.knock * e.cfg.kbMul * 5f)
        }
        if (o.stun > 0f) e.stun = max(e.stun, o.stun * (if (e.cfg.boss) .3f else 1f))
        if (o.src != "ally") {
            P.nen = min(100f, P.nen + (o.gain ?: 2.5f) * P.cfg.nenGain); comboN++; comboT = 3f
            if (o.hs > 0f) hs = max(hs, o.hs)
        }
        if (o.big && o.src != "ally") fx.glow(e.pos.x, 1.3f + e.hover, e.pos.z, o.col ?: P.cfg.col, .3f, 2.2f, .25f)
        SFX.hit()
        if (e.hp <= 0f) killE(e, o)
    }

    private fun killE(e: Enemy, o: Hit) {
        e.dead = true; e.deadT = 0f; kills++; score += e.cfg.score; SFX.die()
        burst(e.pos.x, 1.2f, e.pos.z, if (e.cfg.boss) 0xffd27a else 0x80ff60, if (e.cfg.boss) 40 else 14, if (e.cfg.boss) 10f else 6f, .7f, if (e.cfg.boss) 1.2f else .7f)
        if (e.cfg.boss) {
            fx.ring(e.pos.x, e.pos.z, 0xffd27a, 1f, 14f, .9f); fx.pillar(e.pos.x, e.pos.z, 0xffd27a, 2f, 30f, .9f)
            shake = .8f; flash(0xffffff, .5f, 500); P.hp = min(P.maxHp, P.hp + P.maxHp * .3f)
            toast("Hạ Hộ Vệ Hoàng Gia! Hồi 30% sinh lực", 2.5f)
        }
        e.bg?.visible = false; e.fg?.visible = false
        P.nen = min(100f, P.nen + (if (o.src == "ally") 0f else 3f))
    }

    /** Godspeed: tự động né mọi đòn — chớp tắt sang bên, không mất máu, không bị hất. */
    private fun godDodge(from: Vec3?) {
        val a = if (from != null) Vec3(P.pos.x - from.x, 0f, P.pos.z - from.z) else Vec3(rnd(-1f, 1f), 0f, rnd(-1f, 1f))
        if (a.length() < .01f) a.set(1f, 0f, 0f)
        a.normalize()
        val side = if (rnd01() < .5f) 1f else -1f
        val d = Vec3(-a.z * side + a.x * .6f, 0f, a.x * side + a.z * .6f).normalize()
        P.inv = .1f
        P.lunge = Lunge(d, 46f, .1f, dash = true)
        for (i in 0 until 10) emit(P.pos.x + rnd(-.2f, .2f), rnd(.3f, 1.7f), P.pos.z + rnd(-.2f, .2f), -d.x * 4, rnd(-.3f, .3f), -d.z * 4, .3f, .35f, .02f, if (i % 2 == 0) 0xffffff else 0x7ae6ff)
        fx.ring(P.pos.x, P.pos.z, 0x7ae6ff, .4f, 2.2f, .25f)
    }

    fun hurtP(d0: Float, from: Vec3?) {
        if (!hasP || P.dead || P.inv > 0f) return
        if (P.cfg.id == "killua" && P.gs > 0f) { godDodge(from); return }
        val d = d0 * P.cfg.def
        P.hp -= d; P.inv = .4f; shake = max(shake, .3f); SFX.hurt(); hurtId++
        burst(P.pos.x, 1.2f, P.pos.z, 0xff3050, 10, 5f, .4f, .6f); dmgNum(P.pos, d.roundToInt().toFloat(), 0xff4060, false)
        if (from != null) { val k = Vec3(P.pos.x - from.x, 0f, P.pos.z - from.z).normalize(); P.kb.addScaled(k, 6f) }
        comboN = 0
        if (P.hp <= 0f) { P.hp = 0f; P.dead = true; gameOver() }
    }

    // ================= kẻ địch =================
    fun spawnEnemy(type: String, x: Float, z: Float, hpMul: Float = 0f): Enemy {
        val cfg = ET[type]!!; val b = cfg.build(); b.g.pos.set(x, 0f, z); scene.root.add(b.g)
        val hm = if (hpMul > 0f) hpMul else (1 + (wave - 1) * .13f) * (if (cfg.boss) 1 + (wave / 5f - 1) * .3f else 1f)
        val e = Enemy(type, cfg, b, cfg.hp * hm, cfg.dmg * (1 + (wave - 1) * .06f))
        if (!cfg.boss) {
            val bg = Node(); bg.geo = barBg; bg.mat = barBgMat; bg.visible = false; scene.root.add(bg)
            val fg = Node(); fg.geo = barFgG; fg.mat = barFgMat; fg.visible = false; scene.root.add(fg); e.bg = bg; e.fg = fg
        } else { boss = e; banner(cfg.name, cfg.sub) }
        EN.add(e); burst(x, .3f, z, 0x3a1a20, 12, 5f, .7f, .7f); fx.ring(x, z, 0xc02030, .5f, 2.6f, .6f)
        return e
    }

    fun removeEnemy(e: Enemy) {
        scene.root.remove(e.g); e.bg?.let { scene.root.remove(it) }; e.fg?.let { scene.root.remove(it) }
        EN.remove(e); if (boss === e) boss = null
    }

    private fun animSimple(e: Enemy, dt: Float, mv: Float, wind: Boolean) {
        val p = e.parts ?: return; e.phase += dt * (6 + mv * 6); val s = sin(e.phase) * mv
        if (p.legL != null) {
            p.legL.rot.x = s * .8f; p.legR!!.rot.x = -s * .8f
            p.armL!!.rot.x = if (wind) -2f + sin(e.phase * 3) * .2f else -s * .6f; p.armR!!.rot.x = if (wind) -2f else s * .6f
            p.body!!.pos.y = abs(cos(e.phase)) * .06f * mv; p.body.rot.x = if (wind) -.3f else .1f * mv
        }
        p.wings?.let { for (w in it) w.w.rot.z = w.s * sin(gtime * 45f) * .5f }
    }

    private fun updEnemy(e: Enemy, dt: Float) {
        if (e.dead) {
            e.deadT += dt; val k = min(1f, e.deadT / .45f)
            e.g.setScale(e.sc * max(.001f, 1 - k)); e.g.pos.y = -k * .6f; e.g.rot.z = k * .8f
            if (k >= 1f) removeEnemy(e); return
        }
        if (e.spawnT > 0f) { e.spawnT -= dt; val k = 1 - max(0f, e.spawnT / .7f); e.g.setScale(max(.001f, k * e.sc)); return }
        e.flash = max(0f, e.flash - dt * 6f); val f = e.flash
        for (m in e.mats) m.setEmissiveF(f, f * .3f, f * .3f)
        if (e.team == 'a') {
            if (f < .01f) for (m in e.mats) m.setEmissive(0x2a1070)
            e.puppetT -= dt
            if (e.puppetT <= 0f) { e.needle?.let { e.g.remove(it) }; e.needle = null; explodePuppet(e); return }
        }
        if (e.barT > 0f) e.barT -= dt
        e.pos.addScaled(e.kb, dt); e.kb.scale(max(0f, 1 - 8 * dt))
        var mvAmt = 0f; var wind = false
        val pl = e.pull
        if (pl != null) {
            pl.t += dt; val k = ease(min(1f, pl.t / pl.d))
            e.pos.x = lerp(pl.from.x, pl.to.x, k); e.pos.z = lerp(pl.from.z, pl.to.z, k); if (pl.t >= pl.d) e.pull = null
        } else if (e.stun > 0f) e.stun -= dt
        else if (e.team == 'a') {
            var tg: Enemy? = null; var bd = 1e9f
            for (o in EN) { if (o === e || o.dead || o.team != 'e' || o.spawnT > 0f) continue; val d = dxz(o.pos, e.pos); if (d < bd) { bd = d; tg = o } }
            if (tg != null) {
                val dx = tg.pos.x - e.pos.x; val dz = tg.pos.z - e.pos.z; val d = hypot(dx, dz); e.face = atan2(dx, dz)
                if (d > e.r + tg.r + .8f) { val s = e.cfg.spd * 1.1f * dt; e.pos.x += dx / d * s; e.pos.z += dz / d * s; mvAmt = 1f }
                else { e.cdT -= dt; wind = e.cdT < .3f; if (e.cdT <= 0f) { e.cdT = e.cfg.cd * .7f; hurtE(tg, e.cfg.dmg * 2.3f, Hit(src = "ally", knock = 1.5f, from = e.pos, col = 0xb89cff)) } }
            } else {
                val dx = P.pos.x - e.pos.x; val dz = P.pos.z - e.pos.z; val d = hypot(dx, dz)
                if (d > 4f) { e.pos.x += dx / d * e.cfg.spd * dt; e.pos.z += dz / d * e.cfg.spd * dt; mvAmt = 1f; e.face = atan2(dx, dz) }
            }
        } else if (e.cfg.boss) { bossThink(e, dt); mvAmt = e.mv }
        else {
            val dec = P.decoy
            val hide = P.stealth > 0f && (P.cfg.id == "illumi" || P.assassin > 0f)
            val tgPos: Vec3? = if (dec != null && dec.life != 0f) dec.pos else if (hide) null else P.pos
            if (tgPos == null) { e.stT += dt; e.pos.x += cos(e.phase) * e.cfg.spd * .3f * dt; e.pos.z += sin(e.phase) * e.cfg.spd * .3f * dt }
            else {
                val dx = tgPos.x - e.pos.x; val dz = tgPos.z - e.pos.z; val d = max(.001f, hypot(dx, dz)); val sp = e.cfg.spd * e.slow
                e.face = atan2(dx, dz)
                if (e.cfg.fly) {
                    if (e.st == "chase") {
                        val want = if (d > 12f) 1f else if (d < 8f) -1f else 0f
                        e.pos.x += dx / d * sp * want * dt + (-dz / d) * sp * .5f * dt; e.pos.z += dz / d * sp * want * dt + (dx / d) * sp * .5f * dt
                        mvAmt = 1f; e.cdT -= dt; if (e.cdT <= 0f && d < 17f) { e.st = "wind"; e.stT = .55f }
                    } else if (e.st == "wind") {
                        wind = true; e.stT -= dt
                        if (e.stT <= 0f) {
                            val dir = Vec3(dx, 0f, dz).normalize(); val m = Node(); m.geo = fx.gOrb; m.mat = pm(0x80ff50)
                            shoot(m, Vec3(e.pos.x, 1.6f + e.hover * .3f, e.pos.z), dir, 15f, e.dmg, .55f, 2.5f, 'e', col = 0x80ff50)
                            e.st = "chase"; e.cdT = e.cfg.cd + rnd(0f, .8f); SFX.swing()
                        }
                    }
                } else {
                    if (e.st == "chase") {
                        if (d > e.cfg.range + e.r * .3f) { e.pos.x += dx / d * sp * dt; e.pos.z += dz / d * sp * dt; mvAmt = 1f }
                        e.cdT -= dt; if (d < e.cfg.range + e.r * .5f && e.cdT <= 0f) { e.st = "wind"; e.stT = .4f }
                    } else if (e.st == "wind") {
                        wind = true; e.stT -= dt
                        if (e.stT <= 0f) {
                            e.st = "chase"; e.cdT = e.cfg.cd + rnd(0f, .4f)
                            if (dxz(e.pos, tgPos) < e.cfg.range + e.r * .5f + .9f) {
                                if (tgPos === P.pos) hurtP(e.dmg, e.pos)
                                burst(e.pos.x + sin(e.face) * 1.2f, 1.2f, e.pos.z + cos(e.face) * 1.2f, 0xff4040, 6, 4f, .25f, .5f)
                            }
                        }
                    }
                }
            }
        }
        if (!e.cfg.boss) {
            for (o in EN) {
                if (o === e || o.dead || o.spawnT > 0f) continue
                val dx = e.pos.x - o.pos.x; val dz = e.pos.z - o.pos.z; val d = hypot(dx, dz); val m = e.r + o.r
                if (d < m && d > .01f) { val k = (m - d) * .5f * min(1f, dt * 8f); e.pos.x += dx / d * k; e.pos.z += dz / d * k }
            }
        }
        clampArena(e.pos, 1f)
        e.g.rot.y = e.face
        e.g.pos.y = if (e.cfg.fly && !e.cfg.boss) 3f + sin(gtime * 3 + e.phase) * .3f else if (e.hover > 0f) e.hover + sin(gtime * 2) * .15f else 0f
        val h = e.h
        if (h != null) { if (wind && h.act == null) h.act = Act("raise", .4f); poseHuman(h, dt, mvAmt, gtime) } else animSimple(e, dt, mvAmt, wind)
        val bg = e.bg; val fg = e.fg
        if (bg != null && fg != null) {
            val show = e.barT > 0f && !e.dead; bg.visible = show; fg.visible = show
            if (show) {
                val y = e.cfg.barY + (if (e.cfg.fly) 3f else 0f)
                val yaw = atan2(camPos.x - e.pos.x, camPos.z - e.pos.z); val cx = cos(yaw); val sx = sin(yaw)
                bg.rot.y = yaw; fg.rot.y = yaw
                bg.pos.set(e.pos.x, y, e.pos.z)
                fg.pos.set(e.pos.x - .68f * cx + sx * .03f, y, e.pos.z + .68f * sx + cx * .03f)
                fg.scl.x = 1.36f * max(0f, e.hp / e.maxHp) + .001f
                fg.mat = if (e.team == 'a') barAllyMat else barFgMat
            }
        }
        if (e.team == 'a' && rnd01() < .3f) emit(e.pos.x, 1.5f, e.pos.z, 0f, 1f, 0f, .5f, .5f, .1f, 0x8a6aff)
    }

    private fun bossThink(e: Enemy, dt: Float) {
        e.mv = 0f
        val dx = P.pos.x - e.pos.x; val dz = P.pos.z - e.pos.z; val d = max(.01f, hypot(dx, dz))
        val rage = if (e.hp / e.maxHp < .5f) 1.25f else 1f
        var a = e.act
        if (a == null) {
            e.face = atan2(dx, dz)
            val want = if (e.type == "pouf") 9f else e.r + 1.5f
            if (d > want) { e.pos.x += dx / d * e.cfg.spd * rage * dt; e.pos.z += dz / d * e.cfg.spd * rage * dt; e.mv = 1f }
            else if (e.type == "pouf" && d < 7f) { e.pos.x -= dx / d * e.cfg.spd * dt; e.pos.z -= dz / d * e.cfg.spd * dt; e.mv = 1f }
            e.ct -= dt * rage
            if (e.ct <= 0f) {
                val mv = e.cfg.moves[e.mi++ % e.cfg.moves.size]; val na = BossAct(mv, .8f); e.act = na
                when (mv) {
                    "dash" -> { na.dir = Vec3(dx / d, 0f, dz / d); na.tele = .7f; fx.teleLine(e.pos.x, e.pos.z, dx / d, dz / d, 18f, e.r * .9f, .7f) }
                    "slam" -> { na.c = P.pos.clone(); na.tele = .9f; fx.teleCircle(P.pos.x, P.pos.z, 6f, .9f) }
                    "spin" -> { na.tele = .8f; fx.teleCircle(e.pos.x, e.pos.z, 5.5f, .8f) }
                    "volley" -> na.tele = .6f
                    "summon" -> { na.tele = .9f; fx.ring(e.pos.x, e.pos.z, 0xc02030, .5f, 3f, .9f) }
                }
                e.h?.act = Act("raise", na.tele + .2f)
            }
            return
        }
        a.t += dt
        if (a.t < a.tele) { if (a.m != "dash") e.face = atan2(dx, dz); return }
        if (!a.fired) {
            a.fired = true
            when (a.m) {
                "spin" -> { fx.ring(e.pos.x, e.pos.z, 0xff4060, .5f, 6f, .4f); burst(e.pos.x, 1f, e.pos.z, 0xff4060, 24, 8f, .5f, .8f); shake = .3f; if (dxz(e.pos, P.pos) < 6f) hurtP(e.dmg, e.pos); e.h?.act = Act("spread", .4f) }
                "slam" -> { val c = a.c!!; fx.ring(c.x, c.z, 0xff4060, .5f, 7f, .4f); fx.dome(c.x, .5f, c.z, 0xff2040, .5f, 6f, .4f); burst(c.x, .5f, c.z, 0xffa060, 30, 9f, .6f, .9f); shake = .6f; SFX.boom(); if (dxz(c, P.pos) < 6.6f) hurtP(e.dmg, c) }
                "volley" -> {
                    val n = if (e.type == "pouf") 9 else 5; val base = atan2(dx, dz); val col = if (e.type == "pouf") 0x9a7aff else 0xff6a30
                    for (i in 0 until n) {
                        val an = base + (i - (n - 1) / 2f) * .2f; val m = Node(); m.geo = fx.gOrb; m.mat = pm(col)
                        shoot(m, Vec3(e.pos.x, 1.8f + e.hover * .5f, e.pos.z), Vec3(sin(an), 0f, cos(an)), 15f, e.dmg * .6f, .6f, 3f, 'e', col = 0xff6a30)
                    }
                    SFX.skill()
                }
                "summon" -> {
                    for (i in 0 until 2) { val an = rnd(0f, TAU); spawnEnemy("soldier", clamp(e.pos.x + cos(an) * 4, -22f, 22f), clamp(e.pos.z + sin(an) * 4, -22f, 22f), 1f) }
                    burst(e.pos.x, 1f, e.pos.z, 0x9a7aff, 20, 6f, .6f, .7f); e.h?.act = Act("spread", .4f)
                }
                "dash" -> a.dt = .35f
            }
        }
        if (a.m == "dash" && a.dt > 0f) {
            a.dt -= dt; e.pos.addScaled(a.dir!!, 46f * dt); e.mv = 1f
            emit(e.pos.x, 1.2f, e.pos.z, 0f, 0f, 0f, .4f, 1.2f, .1f, 0xff4060)
            if (!a.hit && dxz(e.pos, P.pos) < e.r + .9f) { a.hit = true; hurtP(e.dmg * 1.2f, e.pos) }
            return
        }
        if (a.t > a.tele + (if (a.m == "dash") .35f else 0f) + .55f) { e.act = null; e.ct = e.cfg.cd }
    }

    // ---------- con rối (Illumi) ----------
    fun puppetize(e: Enemy, dur: Float, dmg: Float) {
        if (e.cfg.boss) { hurtE(e, dmg * 2, Hit(col = 0xb89cff, stun = 2.5f)); return }
        e.team = 'a'; e.puppetT = dur; e.stun = 0f; e.st = "chase"
        val nd = Node(); nd.geo = Geometry.cone(.04f, .7f, 5); nd.mat = pm(0xc8b0ff); nd.pos.set(0f, 2.4f * (if (e.cfg.r > 1f) 1.5f else 1f), 0f); nd.rot.x = PIF
        e.g.add(nd); e.needle = nd
        for (m in e.mats) m.setEmissive(0x2a1070)
        fx.beam({ hand(1.4f) }, { Vec3(e.pos.x, 1.4f + e.hover, e.pos.z) }, 0x8a6aff, dur, .05f)
    }
    fun explodePuppet(e: Enemy) {
        burst(e.pos.x, 1.2f, e.pos.z, 0x8a6aff, 24, 8f, .6f, .8f); fx.ring(e.pos.x, e.pos.z, 0x8a6aff, .5f, 5f, .45f); fx.dome(e.pos.x, 1f, e.pos.z, 0x6b4bff, .5f, 5f, .4f)
        radiusHit(e.pos, 5f) { t -> if (t !== e) hurtE(t, 40f, Hit(col = 0xb89cff, knock = 2f, src = "ally")) }
        SFX.boom(); hurtE(e, 99999f, Hit(src = "ally", noCrit = true))
    }

    // ---------- đạn ----------
    private fun updProjs(dt: Float) {
        var i = projs.size - 1
        while (i >= 0) {
            val p = projs[i]; p.life -= dt
            if (p.homing > 0f && p.team == 'p') {
                val t = nearest(p.pos, 12f)
                if (t != null) {
                    val dx = t.pos.x - p.pos.x; val dz = t.pos.z - p.pos.z; val l = max(.001f, hypot(dx, dz)); val sp = p.vel.length()
                    p.vel.x += dx / l * sp * p.homing * dt; p.vel.z += dz / l * sp * p.homing * dt; p.vel.setLength(sp)
                }
            }
            p.pos.addScaled(p.vel, dt); p.node.pos.copy(p.pos)
            if (p.spin != 0f) p.node.rot.y += p.spin * dt else p.node.lookDir(p.vel.x, p.vel.y, p.vel.z)
            if (p.trail) emit(p.pos.x, p.pos.y, p.pos.z, 0f, 0f, 0f, .25f, .5f, .05f, p.col)
            var dead = p.life <= 0f || hypot(p.pos.x, p.pos.z) > ARENA + 6
            if (!dead) {
                if (p.team == 'p') {
                    for (e in EN.toList()) {
                        if (e.dead || e.team != 'e' || e.spawnT > 0f || p.hit.contains(e)) continue
                        if (dxz(p.pos, e.pos) < p.r + e.r) {
                            p.hit.add(e); p.onHit?.invoke(e)
                            if (p.dmg > 0f) hurtE(e, p.dmg, Hit(col = p.col, knock = p.knock, stun = p.stun, from = p.pos))
                            if (p.pierce-- <= 0) { dead = true; break }
                        }
                    }
                } else {
                    val dec = P.decoy
                    if (dec != null && dxz(p.pos, dec.pos) < p.r + 1.2f) { dead = true; burst(p.pos.x, p.pos.y, p.pos.z, p.col, 8, 4f, .3f, .5f) }
                    else if (!P.dead && dxz(p.pos, P.pos) < p.r + .55f && p.pos.y < 3f) { hurtP(p.dmg, p.pos); dead = true; burst(p.pos.x, p.pos.y, p.pos.z, p.col, 8, 4f, .3f, .5f) }
                }
            }
            if (dead) removeProj(i)
            i--
        }
    }

    private fun updZones(dt: Float) {
        var i = zones.size - 1
        while (i >= 0) {
            val z = zones[i]; z.t -= dt; z.tick -= dt
            for (k in 0 until 4) { val a = rnd(0f, TAU); val r = sqrt(rnd01()) * z.r; emit(z.x + cos(a) * r, rnd(.2f, 1.8f), z.z + sin(a) * r, rnd(-.3f, .3f), rnd(.3f, 1.2f), rnd(-.3f, .3f), 1f, 1.6f, .6f, if (rnd01() < .5f) 0xb040ff else 0x60ff90, 0f, .3f) }
            if (z.tick <= 0f) {
                z.tick = .5f
                radiusHit(Vec3(z.x, 0f, z.z), z.r) { e -> hurtE(e, 10f, Hit(col = 0xb040ff, gain = 0f, src = "zone", noCrit = true)); e.slow = .5f; later(.7f) { e.slow = 1f } }
            }
            if (z.t <= 0f) zones.removeAt(i)
            i--
        }
    }

    // ================= người chơi =================
    fun clampArena(p: Vec3, m: Float = 1f) { val r = hypot(p.x, p.z); val lim = ARENA - m; if (r > lim) { p.x *= lim / r; p.z *= lim / r } }
    fun camRel(mx: Float, my: Float): Vec3 { val sn = sin(camYaw); val c = cos(camYaw); return Vec3(-c * mx - sn * my, 0f, sn * mx - c * my) }

    fun useSkill(i: Int) {
        if (state != "play" || !hasP || P.dead) return
        curSk = i
        try { useSkill0(i) } finally { curSk = -1 }
    }

    private fun useSkill0(i: Int) {
        if (i == 3) {
            if (P.nen < 100f || P.cast > 0f) return
            if (P.cfg.ult()) { P.nen = 0f; cineSkill(3) } else toast("Không có mục tiêu!", 1f)
        } else {
            if (P.cd[i] > 0f || P.cast > 0f) return
            val ok = if (i == 1) P.cfg.s1() else P.cfg.s2()
            if (ok) { P.cd[i] = P.cdMax[i]; cineSkill(i) } else toast("Không có mục tiêu trong tầm!", 1f)
        }
    }

    fun doDash() {
        if (state != "play" || !hasP || P.dead || P.dashCd > 0f || (P.cast > 0f && P.cast > .6f)) return
        var d = camRel(Input.mx, Input.my); if (d.length() < .2f) d = fwd(); d.normalize()
        P.lunge = Lunge(d, 30f, .2f, dash = true); P.inv = max(P.inv, .3f); P.dashCd = 2f; P.cast = 0f; SFX.dash()
        if (P.cfg.id == "kurotsuki") kuroDash(P.pos.clone(), d)
        for (i in 0 until 12) emit(P.pos.x + rnd(-.4f, .4f), rnd(.3f, 1.6f), P.pos.z + rnd(-.4f, .4f), -d.x * 3, rnd(-.5f, .5f), -d.z * 3, .4f, .8f, .1f, P.cfg.col)
        if (P.cfg.id == "killua" || P.cfg.id == "silva") {
            P.stealth = 2.4f; P.assassin = 2.4f; P.h.fade(.22f)
            if (!tipShown) { tipShown = true; toast("Ám sát: lướt xong chạm đòn thường để hiện sau lưng địch và hạ đòn chí mạng", 3.2f) }
        }
    }

    private fun updPlayer(dt: Float) {
        val h = P.h
        P.spdMul = 1f; P.cfg.tick?.invoke(dt)
        P.inv -= dt; P.atkCd -= dt; P.dashCd -= dt; P.cast -= dt
        for (i in 1 until 3) P.cd[i] = max(0f, P.cd[i] - dt)
        if (P.dmgBuffT > 0f) { P.dmgBuffT -= dt; if (P.dmgBuffT <= 0f) P.dmgBuff = 0f }
        if (P.stealth > 0f) { P.stealth -= dt; if (P.stealth <= 0f) { h.fade(1f); h.root.visible = true } }
        if (P.speedBuf > 0f) P.speedBuf -= dt
        if (P.assassin > 0f) P.assassin -= dt
        if (P.cfg.id == "meruem") P.hp = min(P.maxHp, P.hp + P.maxHp * .01f * dt)
        var mx = Input.mx; var my = Input.my
        val ml = hypot(mx, my); if (ml > 1f) { mx /= ml; my /= ml }
        run { val w = camRel(mx, my); mx = w.x; my = w.z }
        var mv = 0f
        val L = P.lunge
        if (L != null) {
            P.pos.x += L.dir.x * L.speed * dt; P.pos.z += L.dir.z * L.speed * dt; L.t -= dt
            if (L.path != null) for (e in EN.toList()) if (!e.dead && e.team == 'e' && dxz(e.pos, P.pos) < e.r + 2.2f) L.path.invoke(e)
            if (L.fly) P.y = sin(min(1f, (.34f - L.t) / .34f) * PIF) * 1.6f
            if (L.dash && rnd01() < .8f) emit(P.pos.x, 1f, P.pos.z, 0f, 0f, 0f, .35f, 1f, .1f, P.cfg.col)
            if (L.t <= 0f) { P.lunge = null; P.y = 0f; L.end?.invoke() }
            mv = .7f
        } else {
            val sp = P.cfg.spd * P.spdMul * (if (P.cast > 0f) .3f else 1f) * (if (P.speedBuf > 0f) 1.35f else 1f)
            P.pos.x += mx * sp * dt; P.pos.z += my * sp * dt
            mv = min(1f, ml) * (if (P.cast > 0f) .4f else 1f)
            val tgt = if (Input.atk || P.cast > 0f) nearest(P.pos, 24f) else null
            if (tgt != null) {
                val a = atan2(tgt.pos.x - P.pos.x, tgt.pos.z - P.pos.z); var da = a - P.face
                while (da > PIF) da -= TAU; while (da < -PIF) da += TAU; P.face += da * min(1f, dt * 18f)
            } else if (ml > .1f) {
                val a = atan2(mx, my); var da = a - P.face
                while (da > PIF) da -= TAU; while (da < -PIF) da += TAU; P.face += da * min(1f, dt * 14f)
            }
        }
        P.pos.addScaled(P.kb, dt); P.kb.scale(max(0f, 1 - 9 * dt))
        clampArena(P.pos, 1f)
        if (P.atkCd <= 0f && P.cast <= 0f && Input.atk && P.lunge == null) P.cfg.atk()
        for (e in EN) {
            if (e.dead || e.spawnT > 0f || e.team != 'e') continue
            val d = dxz(e.pos, P.pos); val m = e.r + .5f
            if (d < m && d > .01f && P.lunge == null) { P.pos.x += (P.pos.x - e.pos.x) / d * (m - d) * .4f; P.pos.z += (P.pos.z - e.pos.z) / d * (m - d) * .4f }
        }
        val dec = P.decoy
        if (dec != null) {
            dec.node.pos.y = 2f + sin(gtime * 5) * .15f; dec.node.rot.y = sin(gtime * 3) * .15f
            if (rnd01() < .4f) emit(dec.pos.x + rnd(-1f, 1f), rnd(0f, 3.5f), dec.pos.z + rnd(-1f, 1f), 0f, 1.5f, 0f, .6f, .5f, .1f, 0xff3fa0)
        }
        h.root.pos.set(P.pos.x, P.y, P.pos.z); h.root.rot.y = P.face
        poseHuman(h, dt, mv, gtime)
        var I = .7f + (P.nen / 100f) * .8f + (if (P.cast > 0f) .4f else 0f) + P.auraBoost
        P.auraBoost = max(0f, P.auraBoost - dt * .6f)
        if (P.stealth > 0f && (P.cfg.id == "illumi" || P.assassin > 0f)) I = 0f
        h.aura?.visible = I > .01f; h.auraDark?.visible = I > .01f
        auraTick(h, P.pos.x, P.y, P.pos.z, I, dt)
    }

    // ---------- hiệu ứng điện ảnh khi tung chiêu ----------
    fun chargeFx(hex: Int, dur: Float, sc: Float) {
        val n = (30 * sc).toInt()
        for (i in 0 until n) later(i.toFloat() / n * dur) {
            val a = rnd(0f, TAU); val r = rnd(2.2f, 4.2f) * sc; val y = rnd(.2f, 2.6f)
            val x = P.pos.x + cos(a) * r; val z = P.pos.z + sin(a) * r
            emit(x, y, z, -cos(a) * r * 2.2f + sin(a) * 3, (1.4f - y) * 1.5f, -sin(a) * r * 2.2f - cos(a) * 3, .5f, .55f, .08f, hex)
        }
        fx.ring(P.pos.x, P.pos.z, hex, 4.2f * sc, .6f, dur + .1f)
        val m = addMat(hex, 0f); val g = Node(); g.geo = fx.gDome; g.mat = m
        fx.add(g, dur + .15f, m) { k, nd, _ ->
            val hp = hand(1.4f, .6f); nd.pos.copy(hp)
            nd.setScale((.15f + .5f * sin(min(1f, k) * PIF * .5f)) * sc); m.opacity = .9f * (if (k < .85f) k else (1 - k) / .15f)
        }
    }

    fun runeFx(x: Float, z: Float, hex: Int, r: Float, life: Float) {
        val g = Node(); g.pos.set(x, .06f, z)
        val m = addMat(hex, 0f)
        for (rr in floatArrayOf(.96f, .92f, .64f, .62f, .35f)) { val n = Node(); n.geo = fx.gRing.let { Geometry.ring(rr - .012f, rr + .012f, 56).rotatedX(-PIF / 2) }; n.mat = m; g.add(n) }
        for (k in 0..1) { val n = Node(); n.geo = Geometry.ring(.62f - .008f, .62f + .008f, 3).rotatedX(-PIF / 2); n.mat = m; n.rot.y = k * PIF / 3; g.add(n) }
        fx.add(g, life, m) { k, nd, _ -> nd.setScale(r); nd.rot.y = k * 2.4f; m.opacity = .85f * sin(k * PIF).coerceAtLeast(0f) }
    }

    fun crackFx(x: Float, z: Float, r: Float, hex: Int) {
        val g = Node(); g.pos.set(x, .07f, z); val m = addMat(hex, .9f)
        val geo = Geometry.plane(.12f, 1f).rotatedX(-PIF / 2).translated(0f, 0f, .5f)
        for (i in 0 until 9) { val n = Node(); n.geo = geo; n.mat = m; n.rot.y = i / 9f * TAU + rnd(-.2f, .2f); n.scl.set(1f, 1f, r * rnd(.55f, 1f)); g.add(n) }
        fx.add(g, .9f, m) { k, _, _ -> m.opacity = .9f * (1 - k) }
    }

    fun boom(x: Float, z: Float, hex: Int, r: Float, dmg: Float, kn: Float) {
        fx.ring(x, z, hex, .5f, r, .4f); fx.dome(x, 1f, z, hex, .5f, r * .8f, .4f); burst(x, 1f, z, hex, 18, 8f, .5f, .8f); crackFx(x, z, r * .7f, hex); SFX.boom()
        shake = max(shake, .45f)
        radiusHit(Vec3(x, 0f, z), r) { e -> hurtE(e, dmg, Hit(col = hex, knock = kn, big = true, from = Vec3(x, 0f, z))) }
    }

    private fun cineSkill(i: Int) {
        snapTo = P.face; snapT = .45f
        if (P.cfg.id == "chrollo" && i < 3) P.nen = min(100f, P.nen + 8f)
        when (i) {
            1 -> startShot(.7f, -1.4f, -5f, 0f, -.2f)
            2 -> startShot(.8f, -.6f, 6f, .18f, 0f)
            else -> startShot(max(2.2f, (if (P.cast > 0f) P.cast else 1f) + .6f), -2.8f, -10f, .25f, -.5f)
        }
        val ult = i == 3
        chargeFx(P.cfg.col, if (ult) min(1.4f, (if (P.cast > 0f) P.cast else 1f) * .6f) else .35f, if (ult) 1.4f else .8f)
        if (ult) speedLines(((if (P.cast > 0f) P.cast else 1f) * 900).toInt())
        runeFx(P.pos.x, P.pos.z, P.cfg.col, if (ult) 9f else 4.5f, (if (ult) (if (P.cast > 0f) P.cast else 2f) else .9f) + .4f)
        if (ult) chargeFx(P.cfg.col2, min(1.2f, (if (P.cast > 0f) P.cast else 1f) * .5f), 1f)
        later(if (ult) 1.0f else .3f) { hs = max(hs, if (ult) .09f else .04f); camPn = if (ult) 1.6f else .8f; shake = max(shake, if (ult) .7f else .25f) }
    }
    private fun startShot(d: Float, dist: Float, fov: Float, yaw: Float, h: Float) { shotOn = true; shotT = 0f; shotD = d; shDist = dist; shFov = fov; shYaw = yaw; shH = h }

    // ================= luồng game =================
    fun gotoTitle() {
        state = "title"; clearWorld(); hasP = false
        showMenuModel(chars[selIdx].id)
    }
    fun gotoSelect() { state = "select"; hasP = false; clearWorld(); showMenuModel(chars[selIdx].id) }
    fun pickChar(i: Int) { selIdx = (i % chars.size + chars.size) % chars.size; showMenuModel(chars[selIdx].id); SFX.ui() }
    private fun showMenuModel(id: String) {
        menuId = id
        for ((_, m) in models) m.root.visible = false
        val h = models[id] ?: return
        h.root.visible = true; h.fade(1f); h.root.pos.set(0f, 0f, 0f); h.root.rot.set(0f, 0f, 0f); h.act = null; h.root.setScale(1f)
        h.bloodOn = false; h.eclOn = false; h.swingK = 0f; h.sheathed = false
        camFirst = true
    }

    private fun clearWorld() {
        for (e in EN.toList()) removeEnemy(e)
        for (i in projs.indices.reversed()) removeProj(i)
        zones.clear(); timers.clear(); fx.clear(); Particles.clear(); dns.clear(); boss = null
        if (hasP) { P.decoy?.let { scene.root.remove(it.node) }; P.decoy = null; P.h.fade(1f) }
    }

    fun startGame(id: String) {
        clearWorld()
        val c = chars.first { it.id == id }
        for ((_, m) in models) m.root.visible = false
        val h = models[id]!!; h.root.visible = true; h.fade(1f); h.root.rot.set(0f, 0f, 0f); h.act = null
        h.root.setScale(1f); h.dkOn = false; h.dkK = 0f; h.gsOn = false; h.gsK = 0f; h.scar = 0f; h.scarUntil = 0f
        h.bloodOn = false; h.eclOn = false; h.swingK = 0f; h.sheathed = false
        P = Player(c, h); hasP = true; h.root.pos.copy(P.pos)
        wave = 1; kills = 0; score = 0; gtime = 0f; slowT = 0f; hs = 0f; shake = 0f; boss = null; comboN = 0; comboT = 0f; waveClear = 0f
        startWave(1)
        state = "play"; camYaw = P.face; camPOff = 0f; snapT = 0f; shotOn = false; camFirst = true
        toast("Cần trái: di chuyển · Vuốt phải: xoay camera · Nút phải: tung chiêu", 3.2f)
        if (portrait) later(3.5f) { toast("Xoay ngang màn hình để chơi tốt hơn", 3f) }
    }

    private fun startWave(n: Int) {
        wave = n; queue.clear()
        if (n % 5 == 0) {
            queue.add(listOf("pitou", "pouf", "youpi")[(n / 5 - 1) % 3]); for (i in 0 until 2 + n / 5) queue.add("soldier")
        } else {
            val s = 3 + floor(n * 1.3f).toInt(); val b = if (n >= 3) floor((n - 1) / 2.4f).toInt() else 0; val f = if (n >= 2) n / 2 else 0
            repeat(s) { queue.add("soldier") }; repeat(b) { queue.add("brute") }; repeat(f) { queue.add("flier") }
            queue.shuffle(Rnd.r)
        }
        spawnT = 1.2f
        if (n % 5 != 0) banner("ĐỢT $n", "KIẾN CHIMERA TẤN CÔNG")
    }

    private fun spawnFromQueue() {
        val type = queue.removeAt(0); var x: Float; var z: Float; var t = 0
        do { val a = rnd(0f, TAU); x = cos(a) * (ARENA - 2); z = sin(a) * (ARENA - 2); t++ } while (t < 8 && hypot(x - P.pos.x, z - P.pos.z) < 12f)
        spawnEnemy(type, x, z)
    }

    fun pauseGame() { if (state == "play") state = "pause" }
    fun resumeGame() { if (state == "pause") state = "play" }
    fun quitToSelect() { gotoSelect() }
    fun retry() { startGame(P.cfg.id) }

    private fun gameOver() {
        state = "over"; slowmo(.3f, 1f)
        overStats = listOf("Đợt đạt được" to "$wave", "Hạ gục" to "$kills", "Điểm" to "$score", "Thời gian" to "${(gtime / 60).toInt()}:${((gtime % 60).toInt()).toString().padStart(2, '0')}")
        burst(P.pos.x, 1.2f, P.pos.z, P.cfg.col, 40, 8f, .8f, 1f)
    }

    // ================= vòng lặp =================
    override fun update(rdt: Float) {
        Input.drain()
        tAll += rdt
        val dt0 = when (state) {
            "play" -> stepPlay(rdt)
            "over" -> { val s = rdt * .4f; runTimers(s); for (i in EN.indices.reversed()) updEnemy(EN[i], s); if (hasP) poseHuman(P.h, s, 0f, gtime); camPlay(s); s }
            "pause" -> 0f
            else -> { menuUpdate(rdt); rdt }
        }
        if (state != "pause") { val s = if (state == "over") rdt * .4f else rdt; Particles.update(s); fx.update(s); world.update(tAll) }
        computeVP()
        if (++hudN % 3 == 0) publish()
    }

    private fun stepPlay(rdt: Float): Float {
        // phím bấm từ giao diện
        if (Input.pS1) { Input.pS1 = false; useSkill(1) }
        if (Input.pS2) { Input.pS2 = false; useSkill(2) }
        if (Input.pUlt) { Input.pUlt = false; useSkill(3) }
        if (Input.pDash) { Input.pDash = false; doDash() }
        var dt = rdt
        if (hs > 0f) { hs -= rdt; dt = rdt * .03f }
        if (slowT > 0f) {
            slowT -= rdt
            dt *= 1 - (1 - slowS) * ease(clamp(min((slowT0 - slowT) / .1f, slowT / .35f), 0f, 1f))
        }
        gtime += dt; if (comboT > 0f) comboT -= dt
        runTimers(dt)
        if (!P.dead) { curSk = 0; updPlayer(dt); curSk = -1 } else poseHuman(P.h, dt, 0f, gtime)
        for (i in EN.indices.reversed()) if (i < EN.size) updEnemy(EN[i], dt)
        updProjs(dt); updZones(dt)
        if (!P.dead) {
            if (queue.isNotEmpty()) {
                spawnT -= dt
                val alive = EN.count { !it.dead && it.team == 'e' && !it.cfg.boss }
                if (spawnT <= 0f && (alive < 9 || ET[queue[0]]!!.boss)) { spawnFromQueue(); spawnT = .75f }
            } else if (EN.none { !it.dead } && waveClear <= 0f) {
                waveClear = 2.6f; P.hp = min(P.maxHp, P.hp + P.maxHp * .15f); P.nen = min(100f, P.nen + 20f)
                toast("Đợt $wave hoàn thành! +15% sinh lực", 2.2f)
            }
            if (waveClear > 0f) { waveClear -= dt; if (waveClear <= 0f) startWave(wave + 1) }
        }
        camPlay(dt)
        return dt
    }

    // ---------- camera ----------
    private fun menuUpdate(dt: Float) {
        val h = models[menuId]
        if (h != null) {
            h.root.rot.y += dt * .6f; poseHuman(h, dt, 0f, tAll)
            h.aura?.visible = true; auraTick(h, 0f, 0f, 0f, 1f, dt)
        }
        val a = tAll * .12f
        val sel = state == "select"
        tp.set(sin(a) * 13f * .5f, 2.4f, cos(a) * 13f * .5f + 1f); tl.set(0f, 1.3f, 0f)
        if (sel) { tp.set(0f, 2.2f, 7.2f); tl.set(if (portrait) 0f else 1.9f, if (portrait) 1.9f else 1.2f, 0f) }
        if (camFirst) { camPos.copy(tp); camLook.copy(tl); camFirst = false }
        val k = min(1f, dt * 2.5f); camPos.lerpTo(tp, k); camLook.lerpTo(tl, k)
        scene.camPos.copy(camPos); scene.camTarget.copy(camLook); scene.fov = if (portrait) 52f else 42f; curFov = scene.fov
    }

    private fun camPlay(dt: Float) {
        val dx = Input.camDX; val dy = Input.camDY; Input.camDX = 0f; Input.camDY = 0f
        if (dx != 0f || dy != 0f) { idle = 0f; snapT = 0f; camYaw -= dx * .006f; camPOff = clamp(camPOff - dy * .004f, -.13f, .5f) } else idle += dt
        var dist = if (portrait) 8.6f else 6.6f; var fov = if (portrait) 62f else 50f; var yawO = 0f; var hO = 0f
        if (idle > .3f) camPOff = lerp(camPOff, 0f, min(1f, dt * 3f))
        camPn = max(0f, camPn - dt * 4f); dist -= camPn * .6f
        if (shotOn) {
            shotT += dt; val k = min(1f, shotT / shotD); val b = sin(PIF * k); val e = b * b * (3 - 2 * b)
            dist += shDist * e; fov += shFov * e; yawO = shYaw * e; hO = shH * e; if (k >= 1f) shotOn = false
        }
        if (snapT > 0f) {
            snapT -= dt; var da = snapTo - camYaw; while (da > PIF) da -= TAU; while (da < -PIF) da += TAU; camYaw += da * min(1f, dt * 6f)
        }
        val pitch = clamp(.2f + camPOff + hO * .12f, .07f, .7f); val yaw = camYaw + yawO
        val sn = sin(yaw); val c = cos(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val sd = if (portrait) .55f else .85f
        val bx = P.pos.x - c * sd; val by = P.y + 1.55f; val bz = P.pos.z + sn * sd
        tp.set(bx - sn * cp * dist, max(.7f, by + sp * dist), bz - c * cp * dist); tl.set(bx + sn * 4f, by - .1f, bz + c * 4f)
        val lim = ARENA + 14f; val rr = hypot(tp.x, tp.z); if (rr > lim) { tp.x *= lim / rr; tp.z *= lim / rr }
        if (camFirst) { camPos.copy(tp); camLook.copy(tl); camFirst = false }
        val k = 1f - exp(-dt * (if (shotOn || snapT > 0f) 12f else 9f))
        camPos.lerpTo(tp, k); camLook.lerpTo(tl, k)
        shake = max(0f, shake - dt * 2.2f); val sk = shake * shake * .5f
        scene.camPos.set(camPos.x + sin(tAll * 47f) * sk, camPos.y + sin(tAll * 53f + 1f) * sk, camPos.z + sin(tAll * 41f + 2f) * sk)
        scene.camTarget.copy(camLook)
        curFov = lerp(curFov, fov - camPn * 4f, min(1f, dt * 8f)); scene.fov = curFov
    }

    private fun computeVP() {
        M4.perspective(projM, scene.fov, aspect, .2f, 600f)
        M4.lookAt(viewM, scene.camPos.x, scene.camPos.y, scene.camPos.z, scene.camTarget.x, scene.camTarget.y, scene.camTarget.z)
        M4.mul(vpM, projM, viewM)
    }

    // ---------- đẩy trạng thái cho giao diện ----------
    private fun publish() {
        val now = System.currentTimeMillis()
        dns.removeAll { now - it.born > 850 }
        if (toastT > 0f) toastT -= .05f
        val hudOn = hasP && (state == "play" || state == "pause" || state == "over")
        val p = if (hudOn) P else null
        fun cdTxt(c: Float) = if (c > 0f) ceil(c).toInt().toString() else ""
        val skills = if (p != null) p.cfg.skills else if (state == "select" || state == "title") chars[selIdx].skills else emptyList()
        val cfg = p?.cfg ?: chars[selIdx]
        var gaugeV = -1f; var gaugeL = ""; var gaugeC = 0
        if (p != null && !p.dead) {
            if (p.cfg.id == "gon" && p.dk > 0f) { gaugeV = p.dk / 20f; gaugeL = "HẮC HOÁ ${ceil(p.dk).toInt()}s"; gaugeC = 0x8a2cff }
            else if (p.cfg.id == "killua" && p.gs > 0f) { gaugeV = p.gs / 30f; gaugeL = "GODSPEED ${ceil(p.gs).toInt()}s"; gaugeC = 0x7ae6ff }
        }
        Hud.snap = HudSnap(
            screen = state,
            hp = if (p != null) p.hp / p.maxHp else 1f, hpTxt = if (p != null) "${p.hp.toInt()}/${p.maxHp.toInt()}" else "",
            nen = if (p != null) p.nen / 100f else 0f,
            cd1 = if (p != null && p.cdMax[1] > 0f) p.cd[1] / p.cdMax[1] else 0f, cd2 = if (p != null && p.cdMax[2] > 0f) p.cd[2] / p.cdMax[2] else 0f,
            cdDash = if (p != null) max(0f, p.dashCd) / 2f else 0f,
            cdN1 = if (p != null) cdTxt(p.cd[1]) else "", cdN2 = if (p != null) cdTxt(p.cd[2]) else "", cdND = if (p != null) cdTxt(p.dashCd) else "",
            ultFrac = if (p != null) 1f - p.nen / 100f else 1f, ultTxt = if (p != null && p.nen < 100f) "${p.nen.toInt()}%" else "", ultReady = p != null && p.nen >= 100f,
            wave = wave, kills = kills, score = score,
            bossName = boss?.cfg?.name ?: "", bossFrac = boss?.let { max(0f, it.hp / it.maxHp) } ?: -1f,
            combo = if (comboT > 0f && comboN >= 3) comboN else 0,
            toast = if (toastT > 0f) toastTxt else "", toastId = toastId,
            banner = bnT, bannerSub = bnS, bannerId = bnId,
            dns = ArrayList(dns),
            flashC = flC, flashA = flA, flashMs = flMs, flashId = flId, hurtId = hurtId, speedId = speedId, speedMs = speedMs,
            gauge = gaugeV, gaugeLabel = gaugeL, gaugeCol = gaugeC, vig = if (p != null && p.cfg.id == "gon" && p.dk > 0f) 1f else 0f,
            skills = skills, avatar = cfg.short, col = cfg.col, col2 = cfg.col2, selIdx = selIdx, overStats = overStats, portrait = portrait
        )
    }
}
