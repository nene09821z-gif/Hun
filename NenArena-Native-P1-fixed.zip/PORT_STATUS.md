# Tiến độ port NEN ARENA HTML -> Kotlin native

## Giai đoạn 1 (bản này) – ENGINE + DI CHUYỂN
- [x] Engine: toán, mesh, scene graph, shader toon, viền, sương mù, trời, additive
- [x] Đấu trường (nền, bục, vòng rune, kết giới, trụ, trứng, gai núi, tinh thể)
- [x] Mô hình người + animation đi + 7 động tác (throw/punch/cast/pray/raise/spread/slash)
- [x] Hisoka (thiếu: lá bài texture, hình trái tim texture, hào quang aura)
- [x] Cần analog + camera bám + vuốt xoay camera

## Còn lại (theo thứ tự)
- [ ] Hệ texture (canvas -> bitmap), sprite, hạt (particles), aura shader, FX (ring/beam/dome/slash)
- [ ] HUD: thanh máu, thanh Nen, nút đánh/chiêu 1/chiêu 2/ULT/lướt, chiến cảnh, banner, combo
- [ ] Chiến đấu: đạn, va chạm, sát thương, knockback, hit-stop, slow-mo, camera điện ảnh
- [ ] Kẻ địch: Kiến Lính, Cận Vệ, Cánh; 3 boss Hộ Vệ; 4 quái Nen (Franklin, Feitan, Uvogin, Nobunaga); AI + đợt sóng
- [ ] 13 nhân vật: Hisoka, Illumi, Netero, Meruem, Zeno, Chrollo, Gon, Killua, Kurapika, Silva, Leorio, Morel, Ging (mô hình + 4 kỹ năng mỗi người)
- [ ] Màn chọn nhân vật, menu, tạm dừng, thất bại, khu vực (areas), âm thanh, đồ hoạ thấp/trung/cao

## Tối ưu máy yếu/trung (đã có)
- [x] 3 mức đồ họa THẤP/TRUNG/CAO, tự nhận diện theo RAM/nhân CPU/đời Android; bấm nút trên cùng màn hình để đổi (lưu lại)
- [x] Render ở độ phân giải thấp hơn màn hình (0.55 / 0.8 / 1.0) + tự hạ/nâng theo FPS thực tế
- [x] THẤP: khoá 30fps, tắt viền đen, tắt kết giới, giảm một nửa số vật trang trí, cắt vật ở xa
- [x] Bỏ cấp phát bộ nhớ mỗi frame (hết giật do GC), cache uniform, tắt dither
- Quy ước cho giai đoạn sau: hạt/FX/aura phải đọc Quality.tier.detail để giảm số lượng; shader chung 2 stage phải cùng precision
