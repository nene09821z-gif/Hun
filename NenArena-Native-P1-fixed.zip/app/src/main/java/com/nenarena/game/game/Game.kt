package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

/** Trạng thái điều khiển do giao diện Compose ghi, luồng GL đọc. */
object Input {
    @Volatile var mx = 0f
    @Volatile var my = 0f
    @Volatile var camDX = 0f      // vuốt xoay camera (px tích luỹ)
    @Volatile var camDY = 0f
    @Volatile var atk = false
}

class Game : GameLoop {
    override val scene = Scene()
    private val world: World
    private val hero: Human
    private val heroPos = Vec3(0f, 0f, 8f)
    private var face = PIF
    private var time = 0f
    private var portrait = true

    // camera (port CAM trong bản HTML)
    private var yaw = PIF
    private var pOff = 0f
    private val camPos = Vec3(); private val camLook = Vec3(0f, 1f, 0f)
    private var camFirst = true
    private val tp = Vec3(); private val tl = Vec3()

    init {
        scene.fogHex = 0x3b1230
        scene.fogDensity = 0.0125f
        world = World(scene)
        hero = buildHisoka()
        scene.root.add(hero.root)
        hero.root.pos.copy(heroPos)
    }

    override fun onSurface(w: Int, h: Int) { portrait = h > w }

    override fun update(dt: Float) {
        time += dt
        world.update(time)

        // --- vuốt xoay camera ---
        val dx = Input.camDX; val dy = Input.camDY
        Input.camDX = 0f; Input.camDY = 0f
        yaw -= dx * .006f
        pOff = clamp(pOff - dy * .004f, -.13f, .5f)

        // --- di chuyển theo hướng camera ---
        var mx = Input.mx; var my = Input.my
        val ml = hypot(mx, my)
        if (ml > 1f) { mx /= ml; my /= ml }
        val sn = sin(yaw); val c = cos(yaw)
        val wx = -c * mx - sn * my
        val wz = sn * mx - c * my
        val spd = 7.6f // Hisoka
        heroPos.x += wx * spd * dt
        heroPos.z += wz * spd * dt
        val r = hypot(heroPos.x, heroPos.z); val lim = ARENA - 1f
        if (r > lim) { heroPos.x *= lim / r; heroPos.z *= lim / r }
        if (ml > .1f) {
            val a = atan2(wx, wz)
            var da = a - face
            while (da > PIF) da -= TAU
            while (da < -PIF) da += TAU
            face += da * min(1f, dt * 14f)
        }
        hero.root.pos.copy(heroPos)
        hero.root.rot.y = face
        poseHuman(hero, dt, min(1f, ml), time)

        updateCamera(dt)
    }

    private fun updateCamera(dt: Float) {
        val dist = if (portrait) 8.6f else 6.6f
        val fov = if (portrait) 62f else 50f
        val pitch = clamp(.2f + pOff, .07f, .7f)
        val sn = sin(yaw); val c = cos(yaw); val cp = cos(pitch); val sp = sin(pitch)
        val sd = if (portrait) .55f else .85f
        val bx = heroPos.x - c * sd; val by = 1.55f; val bz = heroPos.z + sn * sd
        tp.set(bx - sn * cp * dist, max(.7f, by + sp * dist), bz - c * cp * dist)
        tl.set(bx + sn * 4f, by - .1f, bz + c * 4f)
        val lim = ARENA + 14f; val rr = hypot(tp.x, tp.z)
        if (rr > lim) { tp.x *= lim / rr; tp.z *= lim / rr }
        if (camFirst) { camPos.copy(tp); camLook.copy(tl); camFirst = false }
        val k = 1f - exp(-dt * 9f)
        camPos.set(lerp(camPos.x, tp.x, k), lerp(camPos.y, tp.y, k), lerp(camPos.z, tp.z, k))
        camLook.set(lerp(camLook.x, tl.x, k), lerp(camLook.y, tl.y, k), lerp(camLook.z, tl.z, k))
        scene.camPos.copy(camPos); scene.camTarget.copy(camLook); scene.fov = fov
    }
}
