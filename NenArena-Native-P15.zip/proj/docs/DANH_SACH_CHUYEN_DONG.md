# Killua — danh sách 312 chuyển động

Sinh từ `assets/killua_anim.json` (30 fps). Cột *vòng* = clip lặp. Xem trực tiếp trong game: màn chọn nhân vật → chọn Killua → thanh ⏮ ◀ ▶ ⏭.


## Đòn đánh (64)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `jab_L` | 0.40 |  |
| `jab_R` | 0.40 |  |
| `cross_L` | 0.50 |  |
| `cross_R` | 0.50 |  |
| `hook_L` | 0.52 |  |
| `hook_R` | 0.52 |  |
| `uppercut_L` | 0.50 |  |
| `uppercut_R` | 0.50 |  |
| `overhand_L` | 0.58 |  |
| `overhand_R` | 0.58 |  |
| `hammerfist_L` | 0.50 |  |
| `hammerfist_R` | 0.50 |  |
| `backfist_L` | 0.46 |  |
| `backfist_R` | 0.46 |  |
| `palm_L` | 0.48 |  |
| `palm_R` | 0.48 |  |
| `palm_double_L` | 0.55 |  |
| `palm_double_R` | 0.55 |  |
| `elbow_fwd_L` | 0.48 |  |
| `elbow_fwd_R` | 0.48 |  |
| `elbow_up_L` | 0.48 |  |
| `elbow_up_R` | 0.48 |  |
| `claw_slash_h_L` | 0.46 |  |
| `claw_slash_h_R` | 0.46 |  |
| `claw_slash_dn_L` | 0.48 |  |
| `claw_slash_dn_R` | 0.48 |  |
| `claw_slash_up_L` | 0.50 |  |
| `claw_slash_up_R` | 0.50 |  |
| `claw_thrust_L` | 0.44 |  |
| `claw_thrust_R` | 0.44 |  |
| `claw_rake_x_L` | 0.50 |  |
| `claw_rake_x_R` | 0.50 |  |
| `claw_rake_wide_L` | 0.46 |  |
| `claw_rake_wide_R` | 0.46 |  |
| `shoulder_charge_L` | 0.50 |  |
| `shoulder_charge_R` | 0.50 |  |
| `kick_front_L` | 0.62 |  |
| `kick_front_R` | 0.62 |  |
| `kick_snap_L` | 0.45 |  |
| `kick_snap_R` | 0.45 |  |
| `kick_round_low_L` | 0.60 |  |
| `kick_round_low_R` | 0.60 |  |
| `kick_round_mid_L` | 0.66 |  |
| `kick_round_mid_R` | 0.66 |  |
| `kick_round_high_L` | 0.72 |  |
| `kick_round_high_R` | 0.72 |  |
| `kick_side_L` | 0.70 |  |
| `kick_side_R` | 0.70 |  |
| `kick_back_L` | 0.70 |  |
| `kick_back_R` | 0.70 |  |
| `kick_hook_L` | 0.68 |  |
| `kick_hook_R` | 0.68 |  |
| `kick_axe_L` | 0.80 |  |
| `kick_axe_R` | 0.80 |  |
| `kick_crescent_L` | 0.62 |  |
| `kick_crescent_R` | 0.62 |  |
| `knee_strike_L` | 0.50 |  |
| `knee_strike_R` | 0.50 |  |
| `knee_round_L` | 0.54 |  |
| `knee_round_R` | 0.54 |  |
| `stomp_L` | 0.50 |  |
| `stomp_R` | 0.50 |  |
| `sweep_low_L` | 0.64 |  |
| `sweep_low_R` | 0.64 |  |

## Di chuyển (31)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `walk` | 1.00 | có |
| `jog` | 1.00 | có |
| `run` | 1.00 | có |
| `sprint` | 1.00 | có |
| `walk_relaxed` | 1.00 | có |
| `walk_strut` | 1.00 | có |
| `walk_combat` | 1.00 | có |
| `walk_sneak` | 1.00 | có |
| `walk_tired` | 1.00 | có |
| `walk_limp` | 1.00 | có |
| `walk_hands_head` | 1.00 | có |
| `run_godspeed` | 1.00 | có |
| `run_anime` | 1.00 | có |
| `run_guard` | 1.00 | có |
| `run_tired` | 1.00 | có |
| `run_sneak` | 1.00 | có |
| `run_scared` | 1.00 | có |
| `run_cheer` | 1.00 | có |
| `back_walk` | 1.00 | có |
| `back_run` | 1.00 | có |
| `back_walk_guard` | 1.00 | có |
| `strafe_walk_L` | 1.00 | có |
| `strafe_walk_R` | 1.00 | có |
| `strafe_run_L` | 1.00 | có |
| `strafe_run_R` | 1.00 | có |
| `strafe_sprint_L` | 1.00 | có |
| `strafe_sprint_R` | 1.00 | có |
| `turn_L90` | 0.50 |  |
| `turn_R90` | 0.50 |  |
| `turn_L180` | 0.65 |  |
| `turn_R180` | 0.65 |  |

## Đứng chờ (17)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `idle_relaxed` | 4.80 | có |
| `idle_relaxed_shift_L` | 5.20 | có |
| `idle_relaxed_shift_R` | 5.20 | có |
| `idle_ready_L` | 1.20 | có |
| `idle_ready_R` | 1.20 | có |
| `idle_alert` | 5.00 | có |
| `idle_hands_head` | 5.00 | có |
| `idle_arms_crossed` | 5.50 | có |
| `idle_bored` | 6.00 | có |
| `idle_tired` | 1.60 | có |
| `idle_stalk_L` | 3.60 | có |
| `idle_stalk_R` | 3.60 | có |
| `idle_crouch` | 4.00 | có |
| `idle_charged` | 0.90 | có |
| `idle_hum` | 2.40 | có |
| `idle_think` | 5.00 | có |
| `idle_pockets` | 5.00 | có |

## Cử chỉ khi rảnh (15)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `fidget_neck_crack` | 2.20 |  |
| `fidget_shrug` | 1.40 |  |
| `fidget_stretch_arms` | 3.00 |  |
| `fidget_yawn` | 3.20 |  |
| `fidget_look_around` | 3.40 |  |
| `fidget_scratch_head` | 2.40 |  |
| `fidget_knuckles` | 2.40 |  |
| `fidget_bounce` | 1.40 |  |
| `fidget_shake_arms` | 2.00 |  |
| `fidget_sigh` | 3.00 |  |
| `fidget_stretch_legs` | 3.60 |  |
| `fidget_snap_fingers` | 1.80 |  |
| `fidget_nod` | 1.20 |  |
| `fidget_tie_shoe` | 3.00 |  |
| `fidget_yoyo_flick` | 1.60 |  |

## Nhào lộn (28)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `jump_up` | 1.05 |  |
| `jump_forward` | 1.00 |  |
| `jump_back` | 0.95 |  |
| `jump_double` | 0.50 |  |
| `fall_loop` | 1.00 | có |
| `land_soft` | 0.45 |  |
| `land_hard` | 0.75 |  |
| `land_hero` | 0.95 |  |
| `land_roll` | 0.85 |  |
| `flip_front` | 1.00 |  |
| `flip_back` | 1.00 |  |
| `flip_side_L` | 0.95 |  |
| `flip_side_R` | 0.95 |  |
| `flip_front_long` | 1.25 |  |
| `flip_back_high` | 1.20 |  |
| `flip_twist_L` | 0.90 |  |
| `flip_twist_R` | 0.90 |  |
| `flip_double_back` | 1.45 |  |
| `spin_air_360` | 1.05 |  |
| `cartwheel_L` | 1.05 |  |
| `cartwheel_R` | 1.05 |  |
| `handspring` | 1.05 |  |
| `roll_forward` | 0.90 |  |
| `roll_back` | 0.95 |  |
| `roll_side_L` | 0.88 |  |
| `roll_side_R` | 0.88 |  |
| `kipup` | 1.00 |  |
| `slide_fwd` | 0.95 |  |

## Lướt (12)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `dash_fwd` | 0.30 |  |
| `dash_back` | 0.30 |  |
| `dash_L` | 0.28 |  |
| `dash_R` | 0.28 |  |
| `dash_fwd_long` | 0.45 |  |
| `dash_diag_FL` | 0.30 |  |
| `dash_diag_FR` | 0.30 |  |
| `godspeed_launch` | 0.34 |  |
| `flash_step_L` | 0.40 |  |
| `flash_step_R` | 0.40 |  |
| `flash_step_F` | 0.40 |  |
| `flash_step_B` | 0.40 |  |

## Né tránh (10)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `dodge_duck` | 0.50 |  |
| `dodge_limbo` | 0.60 |  |
| `dodge_slip_L` | 0.40 |  |
| `dodge_side_L` | 0.45 |  |
| `dodge_sidehop_L` | 0.65 |  |
| `dodge_slip_R` | 0.40 |  |
| `dodge_side_R` | 0.45 |  |
| `dodge_sidehop_R` | 0.65 |  |
| `dodge_backstep` | 0.45 |  |
| `dodge_hop_back` | 0.70 |  |

## Phòng thủ (6)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `block_high` | 0.50 |  |
| `block_mid` | 0.50 |  |
| `block_low` | 0.50 |  |
| `block_cross` | 0.50 |  |
| `parry_L` | 0.32 |  |
| `parry_R` | 0.32 |  |

## Trúng đòn (17)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `hit_front_light` | 0.40 |  |
| `hit_front_heavy` | 0.60 |  |
| `hit_back` | 0.50 |  |
| `hit_side_L` | 0.45 |  |
| `hit_head_L` | 0.40 |  |
| `hit_side_R` | 0.45 |  |
| `hit_head_R` | 0.40 |  |
| `hit_gut` | 0.75 |  |
| `hit_uppercut` | 0.80 |  |
| `hit_electric` | 0.45 |  |
| `stagger_back` | 0.90 |  |
| `stagger_L` | 0.90 |  |
| `stagger_R` | 0.90 |  |
| `knockback_fly` | 0.50 |  |
| `dizzy_loop` | 1.60 | có |
| `kneel_hurt_loop` | 2.40 | có |
| `stun_loop` | 1.40 | có |

## Ngã / dậy (8)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `knockdown_back` | 0.70 |  |
| `knockdown_front` | 0.70 |  |
| `lie_back_loop` | 3.20 | có |
| `lie_front_loop` | 3.20 | có |
| `getup_back` | 1.00 |  |
| `getup_front` | 0.95 |  |
| `getup_kipup` | 0.95 |  |
| `getup_roll` | 1.00 |  |

## Biểu cảm / ăn mừng (34)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `kneel_down` | 0.50 |  |
| `win_fist_pump` | 2.20 |  |
| `win_both_arms` | 2.60 |  |
| `win_peace` | 2.40 |  |
| `win_jump` | 1.30 |  |
| `win_thumbs_down` | 2.00 |  |
| `win_pose_cool` | 3.00 |  |
| `win_arms_crossed_smirk` | 2.60 |  |
| `win_cheer_jump_spin` | 1.50 |  |
| `taunt_beckon` | 1.80 |  |
| `taunt_come_on` | 2.00 |  |
| `taunt_laugh` | 2.40 |  |
| `taunt_smirk_shrug` | 1.80 |  |
| `taunt_point` | 1.60 |  |
| `taunt_tongue_pull` | 1.80 |  |
| `taunt_bored_yawn` | 2.60 |  |
| `taunt_wave` | 2.00 |  |
| `emote_bow` | 2.00 |  |
| `emote_salute` | 1.40 |  |
| `emote_think_hard` | 3.00 |  |
| `emote_facepalm` | 2.20 |  |
| `emote_clap` | 2.00 |  |
| `emote_shake_head` | 1.60 |  |
| `emote_thumbs_up` | 1.80 |  |
| `emote_scared_shiver` | 1.80 |  |
| `emote_angry_stomp` | 2.00 |  |
| `emote_dance_bounce` | 2.40 | có |
| `emote_dance_swing` | 2.00 | có |
| `emote_sit_down` | 1.00 |  |
| `emote_sit_loop` | 4.40 | có |
| `emote_sleep_stand` | 3.60 | có |
| `emote_look_up` | 2.60 |  |
| `emote_surprised` | 1.60 |  |
| `emote_victory_pose_yoyo` | 2.60 |  |

## Gục ngã (7)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `death_back` | 1.00 |  |
| `death_front` | 1.20 |  |
| `death_kneel_fall` | 1.50 |  |
| `death_collapse` | 1.30 |  |
| `death_spin` | 1.40 |  |
| `death_flung` | 1.40 |  |
| `death_shock` | 1.30 |  |

## Nen (15)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `nen_charge_start` | 0.80 |  |
| `nen_charge_loop` | 0.80 | có |
| `nen_release_burst` | 1.20 |  |
| `nen_power_up_scream` | 2.00 |  |
| `nen_ten_calm` | 2.00 |  |
| `nen_ren_stance` | 1.00 | có |
| `nen_zetsu_hush` | 1.00 |  |
| `nen_hands_crackle` | 2.00 |  |
| `nen_sky_call` | 1.60 |  |
| `nen_both_sky` | 2.00 |  |
| `nen_kneel_charge` | 1.60 |  |
| `nen_overload_shudder` | 0.40 | có |
| `nen_transmute_pose` | 1.80 |  |
| `nen_godspeed_activate` | 1.30 |  |
| `nen_ultimate_start` | 2.40 |  |

## Chiêu thức (30)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `yoyo_throw_L` | 0.60 |  |
| `yoyo_sidearm_L` | 0.60 |  |
| `yoyo_overhead_L` | 0.62 |  |
| `yoyo_recall_L` | 0.50 |  |
| `yoyo_throw_R` | 0.60 |  |
| `yoyo_sidearm_R` | 0.60 |  |
| `yoyo_overhead_R` | 0.62 |  |
| `yoyo_recall_R` | 0.50 |  |
| `yoyo_whirl` | 0.60 | có |
| `narukami_palm_L` | 0.85 |  |
| `narukami_palm_R` | 0.85 |  |
| `narukami_cast` | 1.30 |  |
| `narukami_double_palm_ground` | 1.00 |  |
| `lightning_palm_beam` | 1.20 |  |
| `godspeed_slash_L` | 0.45 |  |
| `godspeed_slash_R` | 0.45 |  |
| `godspeed_spin_slash` | 0.65 |  |
| `whirlwind_claw` | 0.70 |  |
| `assassin_stab_L` | 0.70 |  |
| `assassin_strike_down_L` | 0.60 |  |
| `assassin_stab_R` | 0.70 |  |
| `assassin_strike_down_R` | 0.60 |  |
| `snake_dance` | 1.00 | có |
| `rhythm_echo_L` | 0.50 | có |
| `thunder_clap` | 0.60 |  |
| `lightning_dive_claw` | 1.00 |  |
| `meteor_kick` | 1.10 |  |
| `rising_claw_flip` | 1.10 |  |
| `lightning_drop_kick` | 1.10 |  |
| `finisher_pose` | 1.50 |  |

## Combo (18)

| clip | thời lượng (s) | vòng |
|---|---|---|
| `combo_jab_cross_hook` | 1.14 |  |
| `combo_1_2_round` | 1.57 |  |
| `combo_claw_triple` | 1.08 |  |
| `combo_boxer_high` | 1.79 |  |
| `combo_front_knee` | 1.30 |  |
| `combo_thrust_rake` | 1.06 |  |
| `combo_spin_chain` | 1.52 |  |
| `combo_hook_elbow` | 1.60 |  |
| `combo_palm_storm` | 1.26 |  |
| `combo_claw_side_hook` | 1.53 |  |
| `combo_hammer_sweep_axe` | 1.69 |  |
| `combo_finisher_claw` | 1.69 |  |
| `combo_blitz_6` | 1.90 |  |
| `combo_claw_blitz` | 1.80 |  |
| `combo_kick_storm` | 2.14 |  |
| `combo_assassin` | 1.55 |  |
| `combo_yoyo_claw` | 1.77 |  |
| `combo_elbow_knee` | 1.67 |  |
