package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

// ======================= SUKUNA · VUA NGUYỀN RỦA =======================
// Nội tại: Đảo Ngược Chú Thuật (hồi máu chậm) · Dash chém Giải (Dismantle) · dạng Ryomen 4 tay (sau Lãnh Địa).
// Đòn thường 4 nhịp: Giải · Giải · Hắc Thiểm (Black Flash) · Bát (Cleave).  Chiêu 1: Vạn Trảm.  Chiêu 2: Phủ (Fuga) Hoả Tiễn.
// ULT: Lãnh Địa Triển Khai · Phục Ma Ngự Trù Tử (Malevolent Shrine) → kết thúc bằng Thế Giới Đoạn Trảm.

private const val SUKU_FORM = 14f          // thời gian dạng Ryomen sau Lãnh Địa (giây)
private const val SUKU_FOG = 0x3b1230

// ---------- tiện ích hình ảnh ----------
/** Một nhát "Giải": đường chém mảnh trắng-đỏ, tâm (x,y,z), hướng ngang ang, nghiêng tilt, dài len. */
private fun Game.dismantle(x: Float, y: Float, z: Float, ang: Float, tilt: Float, len: Float, big: Boolean = false) {
    val ct = cos(tilt); val dx = cos(ang) * ct * len / 2f; val dy = sin(tilt) * len / 2f; val dz = sin(ang) * ct * len / 2f
    val a = Vec3(x - dx, y - dy, z - dz); val b = Vec3(x + dx, y + dy, z + dz)
    fx.beam({ a }, { b }, SK_BONE, .16f, if (big) .08f else .035f)
    fx.beam({ a }, { b }, SK_RED, .26f, if (big) .22f else .1f)
    for (i in 0 until (if (big) 8 else 3)) {
        val u = rnd(-1f, 1f)
        emit(x + dx * u, y + dy * u, z + dz * u, rnd(-1.5f, 1.5f), rnd(0f, 2f), rnd(-1.5f, 1.5f), rnd(.25f, .5f), .33f, .02f, if (rnd01() < .5f) SK_BONE else SK_RED, 3f, 1f)
    }
}

/** Nhát "Bát" (Cleave): chém chữ X lớn, vết chém bán nguyệt đỏ, trụ máu bắn lên. */
private fun Game.cleaveFx(x: Float, y: Float, z: Float, yaw: Float, size: Float) {
    val side = yaw + PIF / 2f
    dismantle(x, y, z, side, .85f, size * 2.2f, true); dismantle(x, y, z, side, -.85f, size * 2.2f, true)
    fx.slash(x, y, z, yaw, SK_RED, size * 1.6f, .35f); fx.slash(x, y, z, yaw + .5f, SK_BONE, size, .3f)
    fx.ring(x, z, SK_RED, .5f, size * 1.6f, .35f); fx.pillar(x, z, SK_RED, .45f, 8f, .3f)
    burst(x, y, z, SK_RED, 14, 6f, .5f, .6f)
}

private fun cleaveDmg(e: Enemy, base: Float) = base + e.maxHp * (if (e.cfg.boss) .012f else .06f)   // Bát tự điều chỉnh theo độ cứng của mục tiêu

/** Hắc Thiểm: va chạm chú lực lệch 0.000001 giây — sét đen đỏ, sát thương lớn. */
private fun Game.blackFlash(e: Enemy, dmg: Float, from: Vec3) {
    val y = 1.3f + e.hover; val c = Vec3(e.pos.x, y, e.pos.z)
    fx.glow(c.x, y, c.z, SK_BLK, .3f, 3.4f, .3f); fx.glow(c.x, y, c.z, SK_RED, .2f, 2.3f, .25f)
    for (i in 0 until 7) {
        val a = rnd(0f, TAU); val ex = c.x + cos(a) * 2.8f; val ey = y + rnd(-1f, 1.3f); val ez = c.z + sin(a) * 2.8f
        val tip = Vec3(ex, ey, ez)
        fx.beam({ c }, { tip }, if (i % 2 == 0) SK_BLK else SK_RED, .24f, .09f)
    }
    fx.ring(c.x, c.z, SK_RED, .4f, 4.5f, .35f); shake = max(shake, .35f)
    hurtE(e, dmg, Hit(col = SK_RED, knock = 3.5f, stun = .6f, big = true, hs = .08f, from = from, noCrit = true, gain = 5f))
    dmgNum(e.pos, 0f, SK_RED, true, "HẮC THIỂM!")
}

// ======================= MÔ HÌNH =======================
fun buildSukuna(): Human {
    val h = buildHuman(HumanOpts(s = 1.1f, skin = 0xe8b48c, top = 0x2a1418, bottom = 0x15101a, shoe = 0x2a0a0a))
    attachSukunaRig(h)
    addAura(h, SK_RED, SK_FIRE, SK_BLK)
    val sa = SukuAura(h)
    h.extra = { dt, t, _ -> sa.update(dt, t) }
    return h
}

// ======================= TƯ THẾ (gọi từ SIG trong Sig.kt) =======================
internal fun sukuSig(h: Human, t: Float, A: String?, k: Float, w: Float, r: Float, sa: Float) {
    val br = sin(t * 1.6f)
    // --- đứng: ngạo nghễ, ngửa đầu, tay buông lỏng ---
    B(h.armR, -.12f, 0f, .14f, w); B(h.elR, -.45f + br * .02f, 0f, 0f, w)
    B(h.armL, -.05f, 0f, -.12f, w); B(h.elL, -.35f, 0f, 0f, w)
    h.head.rot.x += -.12f * w; h.head.rot.z += (.08f + sin(t * .7f) * .03f) * w; h.torso.rot.x += (-.04f + br * .01f) * w
    h.hips.pos.y -= .02f * w
    // --- chạy: người chúi nhẹ, bước dài ---
    h.torso.rot.x += .16f * r; h.head.rot.x -= .1f * r

    val q = min(1f, sa * 1.5f)
    fun legs(a: Float, b: Float, kn: Float) {
        B(h.legL, -a, 0f, 0f, q); B(h.legR, b, 0f, 0f, q)
        h.knL.rot.x = lerp(h.knL.rot.x, kn, q); h.knR.rot.x = lerp(h.knR.rot.x, kn * .8f, q)
    }
    var fist = .25f
    var seal = false
    when (A) {
        "sdis0", "sdis1" -> {   // Giải: vung tay chém ngang, tay kia phản lực
            val a = A == "sdis0"; val e = ease(clamp((k - .1f) / .4f, 0f, 1f))
            val A1 = if (a) h.armR else h.armL; val E1 = if (a) h.elR else h.elL; val A2 = if (a) h.armL else h.armR
            B(A1, lerp(-1.9f, -1.4f, e), 0f, if (a) lerp(.8f, -.5f, e) else lerp(-.8f, .5f, e), q); B(E1, -.1f, 0f, 0f, q)
            B(A2, .3f, 0f, if (a) -.5f else .5f, q)
            B(h.torso, .1f, (if (a) 1f else -1f) * lerp(.8f, -.8f, e), 0f, q); B(h.head, 0f, (if (a) 1f else -1f) * lerp(.3f, -.3f, e), 0f, q)
            h.hips.pos.y -= .06f * sin(e * PIF) * q; legs(.4f, .3f, .35f); fist = .1f
        }
        "sflash" -> {   // Hắc Thiểm: đấm thẳng, dồn trọng tâm
            val e = ease(clamp(k / .45f, 0f, 1f))
            B(h.armR, lerp(-.4f, -1.55f, e), 0f, .1f, q); B(h.elR, lerp(-1.6f, -.08f, e), 0f, 0f, q)
            B(h.armL, -.7f, 0f, .6f, q); B(h.elL, -1.5f, 0f, 0f, q)
            B(h.torso, .35f, lerp(.7f, -.5f, e), 0f, q); B(h.head, -.2f, 0f, 0f, q)
            h.hips.pos.y -= .1f * q; legs(.7f, .6f, .5f); fist = 1f
        }
        "scleave" -> {  // Bát: hai tay giơ cao rồi bổ xuống
            val e = ease(clamp((k - .15f) / .4f, 0f, 1f))
            B(h.armR, lerp(-2.8f, -1.15f, e), 0f, .12f, q); B(h.armL, lerp(-2.8f, -1.15f, e), 0f, -.12f, q)
            B(h.elR, -.1f, 0f, 0f, q); B(h.elL, -.1f, 0f, 0f, q)
            B(h.torso, lerp(-.3f, .55f, e), 0f, 0f, q); B(h.head, lerp(-.3f, .15f, e), 0f, 0f, q)
            h.hips.pos.y -= .14f * e * q; legs(.4f * e, .3f * e, .5f * e); fist = 1f
        }
        "sdash" -> {    // bước chớp: người chúi, tay phía sau
            B(h.armR, .7f, 0f, .3f, q); B(h.armL, .7f, 0f, -.3f, q); B(h.elR, -.3f, 0f, 0f, q); B(h.elL, -.3f, 0f, 0f, q)
            B(h.torso, .8f, 0f, 0f, q); B(h.head, -.5f, 0f, 0f, q); h.hips.pos.y -= .2f * q; legs(.9f, .7f, .8f)
        }
        "sbarrage" -> { // Vạn Trảm: hai tay vung loạn xạ liên tục
            val ph = sin(t * 30f)
            B(h.armR, -1.3f + ph * .5f, 0f, .5f * ph + .1f, q); B(h.armL, -1.3f - ph * .5f, 0f, -.5f * ph - .1f, q)
            B(h.elR, -.2f, 0f, 0f, q); B(h.elL, -.2f, 0f, 0f, q)
            B(h.torso, .2f, sin(t * 15f) * .6f, 0f, q); B(h.head, -.1f, sin(t * 15f) * .25f, 0f, q); legs(.3f, .3f, .3f); fist = .6f
        }
        "sbow" -> {     // Phủ: giương cung lửa — tay trái dẫn hướng, tay phải kéo dây
            val e = ease(clamp(k / .55f, 0f, 1f)); val rel = ease(clamp((k - .6f) / .1f, 0f, 1f))
            B(h.armL, -1.55f, 0f, -.05f, q); B(h.elL, -.05f, 0f, 0f, q)
            B(h.armR, -1.25f, 0f, lerp(.1f, .85f, e) * (1f - rel * .8f), q); B(h.elR, lerp(-.3f, -2.1f, e) * (1f - rel * .7f), 0f, 0f, q)
            B(h.torso, .05f, lerp(0f, .55f, e), 0f, q); B(h.head, -.05f, -.25f, 0f, q)
            legs(.45f, .35f, .4f); fist = 1f
        }
        "sseal", "sdom" -> {   // Lãnh Địa: kết ấn trước ngực, đầu ngẩng cao
            val g = ease(clamp(k * (if (A == "sseal") 2.2f else 8f), 0f, 1f)); val tr = if (A == "sdom") sin(t * 38f) * .012f else 0f
            B(h.armL, -.95f * g + tr, 0f, .5f * g, q); B(h.armR, -.95f * g - tr, 0f, -.5f * g, q)
            B(h.elL, -1.55f * g, 0f, 0f, q); B(h.elR, -1.55f * g, 0f, 0f, q)
            B(h.torso, -.1f, 0f, 0f, q); B(h.head, -.28f * g, 0f, 0f, q); legs(.25f, .25f, .2f)
            fist = .5f; seal = true
        }
        "sworld" -> {   // Thế Giới Đoạn Trảm: giơ tay chém xuống một đường
            val rise = ease(clamp(k / .5f, 0f, 1f)); val drop = ease(clamp((k - .62f) / .12f, 0f, 1f))
            B(h.armR, lerp(lerp(-1f, -3f, rise), -1.0f, drop), 0f, .1f, q); B(h.elR, -.05f, 0f, 0f, q)
            B(h.armL, lerp(lerp(-.4f, -2.6f, rise), .2f, drop), 0f, -.5f, q); B(h.elL, -.2f, 0f, 0f, q)
            B(h.torso, lerp(lerp(0f, -.3f, rise), .6f, drop), 0f, 0f, q); B(h.head, lerp(lerp(0f, -.5f, rise), .15f, drop), 0f, 0f, q)
            h.hips.pos.y -= .15f * drop * q; legs(.2f + .4f * drop, .2f + .3f * drop, .3f + .3f * drop); fist = 1f
        }
        "sroar" -> {    // bung dạng Ryomen: dang rộng cả bốn tay
            val g = ease(clamp(k * 3f, 0f, 1f))
            B(h.armL, -.3f * g, 0f, -1.3f * g, q); B(h.armR, -.3f * g, 0f, 1.3f * g, q)
            B(h.torso, -.2f, 0f, 0f, q); B(h.head, -.4f * g, 0f, 0f, q)
        }
    }
    h.fistK = lerp(h.fistK, fist, .3f)

    // --- đôi tay thứ hai (Ryomen) ---
    val e2 = sa
    if (seal) {   // dang ra hai bên, lòng bàn tay mở
        h.arm2L.rot.set(-.35f, 0f, -.85f); h.arm2R.rot.set(-.35f, 0f, .85f); h.el2L.rot.set(-.9f, 0f, 0f); h.el2R.rot.set(-.9f, 0f, 0f)
    } else if (A == "sroar") {
        h.arm2L.rot.set(-.2f, 0f, -1.1f); h.arm2R.rot.set(-.2f, 0f, 1.1f); h.el2L.rot.set(-.2f, 0f, 0f); h.el2R.rot.set(-.2f, 0f, 0f)
    } else {      // đứng: khoanh trước bụng; ra đòn: bắt chước tay chính trễ nhịp
        h.arm2L.rot.set(lerp(-.5f, h.armL.rot.x * .6f - .25f, e2), 0f, lerp(.3f, h.armL.rot.z * .5f + .2f, e2))
        h.arm2R.rot.set(lerp(-.5f, h.armR.rot.x * .6f - .25f, e2), 0f, lerp(-.3f, h.armR.rot.z * .5f - .2f, e2))
        h.el2L.rot.set(lerp(-1.6f, h.elL.rot.x * .8f - .4f, e2) + br * .03f, 0f, 0f)
        h.el2R.rot.set(lerp(-1.6f, h.elR.rot.x * .8f - .4f, e2) - br * .03f, 0f, 0f)
    }
}

// ======================= ĐÁNH THƯỜNG: GIẢI · GIẢI · HẮC THIỂM · BÁT =======================
private fun Game.sukuAtk() {
    val d = aim(); val n = P.combo % 4; val rage = P.h.four
    if (n <= 1) {
        act(if (n == 0) "sdis0" else "sdis1", .22f); P.atkCd = .19f; SFX.swing()
        val tilt = if (n == 0) .55f else -.55f
        later(.06f) {
            val ox = P.pos.x + d.x * 2.2f; val oz = P.pos.z + d.z * 2.2f
            dismantle(ox, 1.3f, oz, atan2(d.z, d.x) + PIF / 2f, tilt, 4f)
            val slashes = if (rage) intArrayOf(-1, 0, 1) else intArrayOf(0)
            for (s in slashes) {
                val m = Node(); m.add(crescentNode(SK_BONE, .95f, 2.2f, tilt)); m.add(crescentNode(SK_RED, .6f, 2.9f, tilt))
                shoot(m, hand(1.3f, 1f), rotY(d, s * .28f), 46f, 11f, 1.1f, .5f, 'p', 2, SK_RED, 0f,
                    { e -> fx.slash(e.pos.x, 1.3f + e.hover, e.pos.z, rnd(0f, TAU), SK_RED, 2.2f, .2f) }, 0f, .8f)
            }
        }
    } else if (n == 2) {
        act("sflash", .3f); P.atkCd = .36f; SFX.swing(); val o = P.pos.clone()
        P.lunge = Lunge(d.clone(), 20f, .12f)
        later(.14f) {
            fx.ring(o.x + d.x * 2f, o.z + d.z * 2f, SK_RED, .5f, 3f, .25f)
            coneHit(P.pos, d, 3.6f, .9f) { e ->
                if (rnd01() < .4f || rage) blackFlash(e, 42f, o)
                else hurtE(e, 17f, Hit(col = SK_RED, knock = 2.5f, stun = .3f, big = true, hs = .05f, from = o))
            }
        }
    } else {
        act("scleave", .34f); P.atkCd = .42f; SFX.swing()
        later(.16f) {
            val tg = nearest(P.pos, 8f)
            val cx = tg?.pos?.x ?: (P.pos.x + d.x * 3.5f); val cz = tg?.pos?.z ?: (P.pos.z + d.z * 3.5f)
            cleaveFx(cx, 1.4f, cz, P.face, 3.4f); shake = max(shake, .3f); SFX.boom()
            radiusHit(Vec3(cx, 0f, cz), 3.4f) { e -> hurtE(e, cleaveDmg(e, 22f), Hit(col = SK_RED, knock = 2f, stun = .45f, big = true, hs = .06f, from = P.pos)) }
        }
    }
    P.combo++
}

// ======================= DASH: BƯỚC CHỚP CHÉM GIẢI (gọi từ Game.doDash) =======================
internal fun Game.sukuDash(o: Vec3, d: Vec3) {
    act("sdash", .25f)
    val yaw = atan2(d.z, d.x)
    for (i in 0 until 5) {
        val u = 1.2f + i * 1.3f
        dismantle(o.x + d.x * u, 1.2f, o.z + d.z * u, yaw + PIF / 2f + rnd(-.3f, .3f), rnd(-.7f, .7f), 3.6f)
    }
    fx.ring(o.x, o.z, SK_RED, .4f, 3f, .3f); burst(o.x, 1.1f, o.z, SK_RED, 10, 4f, .4f, .6f)
    lineHit(o, d, 6.5f, 1.6f) { e -> hurtE(e, 15f, Hit(col = SK_RED, knock = 1f, stun = .2f, from = o, gain = 1f)) }
}

// ======================= CHIÊU 1: GIẢI · VẠN TRẢM =======================
private fun Game.sukuS1(): Boolean {
    val list = liveEn(24f); if (list.isEmpty()) return false
    val tg = list.take(8); val rage = P.h.four
    P.cast = 1.25f; P.inv = 1.35f; act("sbarrage", 1.2f); SFX.skill(); aim(24f)
    popText("Giải!", SK_RED); P.auraBoost = 1.6f
    val N = if (rage) 30 else 20
    for (i in 0 until N) later(.1f + i * .04f) {
        val e = tg[i % tg.size]
        if (e.dead) return@later
        dismantle(e.pos.x + rnd(-1f, 1f), 1.3f + e.hover + rnd(-.5f, .8f), e.pos.z + rnd(-1f, 1f), rnd(0f, TAU), rnd(-.9f, .9f), rnd(3f, 6f))
        if (i % 3 == 0) burst(e.pos.x, 1.3f + e.hover, e.pos.z, SK_RED, 4, 4f, .3f, .5f)
        hurtE(e, 6.5f, Hit(col = SK_RED, knock = .1f, stun = .15f, from = P.pos, gain = .8f))
    }
    later(1.0f) {   // nhát kết: Bát đồng loạt lên mọi mục tiêu
        shake = max(shake, .7f); SFX.boom(); flash(SK_RED, .3f, 220)
        for (e in tg) {
            if (e.dead) continue
            cleaveFx(e.pos.x, 1.4f + e.hover, e.pos.z, P.face, 3.8f)
            hurtE(e, cleaveDmg(e, 24f), Hit(col = SK_RED, knock = 2.5f, stun = .8f, big = true, hs = .06f, from = P.pos))
        }
        popText("Bát!", SK_BONE); P.critN = max(P.critN, 2)
    }
    return true
}

// ======================= CHIÊU 2: PHỦ · HOẢ TIỄN (FUGA) =======================
private fun fugaArrow(): Node {
    val r = Node()
    r.add(mk(Geometry.cylinder(.1f, .1f, 2.6f, 6).rotatedX(PIF / 2), addMat(SK_GLD, .95f), null, outline = false))
    r.add(mk(Geometry.cone(.42f, 1.3f, 8).rotatedX(PIF / 2).translated(0f, 0f, 1.9f), addMat(SK_BONE, .95f), null, outline = false))
    r.add(mk(Geometry.sphere(.75f, 10, 8), addMat(SK_FIRE, .55f), null, sz = 2.6f, outline = false))
    r.add(mk(Geometry.sphere(1.1f, 10, 8), addMat(SK_RED, .3f), null, sz = 3.2f, outline = false))
    return r
}

private fun Game.sukuS2(): Boolean {
    val t0 = nearest(P.pos, 32f) ?: return false
    val d = aim(32f); val o = P.pos.clone(); val rage = P.h.four
    val dist = clamp(dxz(P.pos, t0.pos), 8f, 30f)
    P.cast = 1.5f; P.inv = 1.0f; act("sbow", 1.4f); SFX.skill()
    popText("Phủ! · Hoả Tiễn", SK_FIRE)
    chargeFx(SK_FIRE, .85f, 1.3f); chargeFx(SK_GLD, .6f, .9f)
    // ấn cung lửa trước người: vòng lửa + chùm sáng căng dây
    val bowM = addMat(SK_FIRE, 0f); val ringN = Node(); ringN.geo = Geometry.torus(1f, .06f, 6, 28); ringN.mat = bowM
    fx.add(ringN, .95f, bowM) { k, nd, _ ->
        nd.pos.copy(hand(1.45f, 1.5f)); nd.rot.y = P.face; nd.setScale(.4f + 1.1f * ease(min(1f, k * 1.4f))); bowM.opacity = .85f * (if (k < .8f) 1f else (1f - k) / .2f)
    }
    later(.85f) {
        shake = max(shake, .5f); SFX.boom(); flash(SK_FIRE, .25f, 180)
        val offs = if (rage) floatArrayOf(-.22f, 0f, .22f) else floatArrayOf(0f)
        for (a in offs) {
            val dir = rotY(d, a)
            shoot(fugaArrow(), hand(1.5f, 1.4f), dir, 60f, 38f, 1.4f, dist / 60f, 'p', 99, SK_FIRE, 0f, null, 0f, 1f, .3f)
            val ex = o.x + dir.x * dist; val ez = o.z + dir.z * dist
            later(dist / 60f) { sukuFugaBlast(ex, ez, if (a == 0f) 1f else .6f) }
        }
    }
    return true
}

private fun Game.sukuFugaBlast(x: Float, z: Float, sc: Float) {
    boom(x, z, SK_FIRE, 7f * sc, 80f * sc, 5f)
    fx.pillar(x, z, SK_GLD, 2.2f * sc, 26f, .8f); fx.pillar(x, z, SK_RED, 3.4f * sc, 18f, .9f)
    fx.dome(x, 1.2f, z, SK_FIRE, 1f, 9f * sc, .6f); fx.ring(x, z, SK_GLD, 1f, 12f * sc, .7f)
    burst(x, 1.5f, z, SK_FIRE, 30, 9f, .8f, .9f); burst(x, 1.5f, z, SK_GLD, 14, 6f, .6f, .6f)
    // hoả hải: lửa cháy lan 4 giây
    val c = Vec3(x, 0f, z)
    for (i in 1..8) later(i * .5f) {
        radiusHit(c, 6f * sc) { e -> hurtE(e, 9f, Hit(col = SK_FIRE, gain = 0f, noCrit = true, src = "zone")) }
        for (j in 0 until 10) { val a = rnd(0f, TAU); val r = sqrt(rnd01()) * 6f * sc; emit(x + cos(a) * r, rnd(.1f, 1f), z + sin(a) * r, rnd(-.3f, .3f), rnd(1.5f, 3.5f), rnd(-.3f, .3f), rnd(.6f, 1f), .8f, .1f, if (j % 2 == 0) SK_FIRE else SK_RED, 0f, .5f) }
    }
}

// ======================= ULT: LÃNH ĐỊA · PHỤC MA NGỰ TRÙ TỬ =======================
private fun grow(tt: Float, t0: Float, t1: Float) = ease((tt - t0) / (t1 - t0))

/** Dựng toàn bộ lãnh địa: vòm trời đen đỏ, biển máu, đền thờ đầu bò khổng lồ, vòng cột xương. Trả về nút gốc + vài tham chiếu để hoạt hoạ. */
private class Domain(val root: Node, val dome: Node, val floor: Node, val shrine: Node, val pillars: Node)

private fun Game.buildDomain(cx: Float, cz: Float): Domain {
    val root = Node()
    val dome = Node(); dome.geo = fx.gDome; dome.mat = Material(MatType.BASIC, 0x16030a, doubleSided = true, fog = false); dome.noCull = true; dome.setScale(.001f); root.add(dome)
    val floor = Node(); floor.geo = Geometry.circle(32f, 48).rotatedX(-PIF / 2); floor.mat = Material(MatType.BASIC, 0x6a0612, doubleSided = true, fog = false)
    floor.pos.y = .045f; floor.noCull = true; floor.setScale(.001f); root.add(floor)

    val red = toon(0x9a1018); val dark = toon(0x1c0a10); val bone = toon(0xe6dcc6); val wood = toon(0x3a1418)
    val gold = basic(SK_GLD); val glow = addMat(SK_RED, .8f); val eye = basic(0x0a0004)
    // --- đền thờ ---
    val sh = Node(); sh.pos.set(cx, 0f, cz); sh.rot.y = atan2(-cx, -cz); sh.noCull = true; root.add(sh)
    mk(Geometry.box(15f, .9f, 11f), dark, sh, 0f, .45f, 0f)
    mk(Geometry.box(12f, .9f, 8.6f), wood, sh, 0f, 1.35f, 0f)
    for (sx in floatArrayOf(-1f, 1f)) for (sz in floatArrayOf(-1f, 1f)) mk(Geometry.cylinder(.5f, .55f, 6.2f, 10), red, sh, sx * 5f, 4.9f, sz * 3.4f)
    mk(Geometry.box(12.4f, .5f, 9f), dark, sh, 0f, 8.1f, 0f)
    mk(Geometry.cone(9.4f, 3.4f, 4), dark, sh, 0f, 10f, 0f, ry = PIF / 4f)
    mk(Geometry.torus(5.9f, .12f, 4, 4), gold, sh, 0f, 8.45f, 0f, rx = PIF / 2f, ry = 0f, rz = PIF / 4f, outline = false)
    mk(Geometry.box(7.4f, .45f, 5.6f), wood, sh, 0f, 12.1f, 0f)
    mk(Geometry.cone(6.2f, 2.8f, 4), dark, sh, 0f, 13.7f, 0f, ry = PIF / 4f)
    // --- đầu lâu bò khổng lồ trên mái ---
    mk(Geometry.sphere(1.5f, 14, 10), bone, sh, 0f, 15.6f, .2f, sy = .85f, sz = 1.25f)
    mk(Geometry.cone(.65f, 1.6f, 8), bone, sh, 0f, 15.2f, 2.2f, rx = PIF / 2f - .2f)
    for (sx in floatArrayOf(-1f, 1f)) {
        mk(Geometry.sphere(.36f, 8, 6), eye, sh, sx * .6f, 15.9f, 1.4f, outline = false)
        mk(Geometry.cone(.35f, 3.4f, 7), bone, sh, sx * 2.1f, 16.5f, -.1f, rz = -sx * 1.15f)
        mk(Geometry.cone(.3f, 2.2f, 7), bone, sh, sx * 3.7f, 17.9f, -.1f, rz = -sx * .35f)
    }
    mk(Geometry.sphere(2.4f, 10, 8), glow, sh, 0f, 15.6f, 0f, outline = false)
    // đèn lồng đỏ dọc bậc thềm
    for (i in -3..3) mk(Geometry.sphere(.4f, 8, 6), addMat(SK_RED, .95f), sh, i * 1.8f, 1.9f, 5.6f, sy = 1.3f, outline = false)

    // --- vòng cột xương + đầu lâu quanh đấu trường ---
    val pil = Node(); root.add(pil)
    val np = max(8, (14 * Quality.tier.detail).toInt())
    for (i in 0 until np) {
        val a = i.toFloat() / np * TAU; val px = cos(a) * 29f; val pz = sin(a) * 29f
        mk(Geometry.cylinder(.55f, .75f, 9f, 8), bone, pil, px, 4.5f, pz)
        mk(Geometry.sphere(.95f, 10, 8), bone, pil, px, 9.6f, pz, sy = .9f)
        for (sx in floatArrayOf(-1f, 1f)) mk(Geometry.sphere(.2f, 6, 5), eye, pil, px + cos(a + PIF / 2f) * sx * .35f - cos(a) * .7f, 9.8f, pz + sin(a + PIF / 2f) * sx * .35f - sin(a) * .7f, outline = false)
        mk(Geometry.sphere(.45f, 8, 6), addMat(SK_RED, .9f), pil, px, 10.9f, pz, outline = false)
    }
    fun nc(n: Node) { n.noCull = true; for (c in n.children) nc(c) }   // renderer chỉ xét cull theo từng mesh, không kế thừa từ cha
    nc(root)
    return Domain(root, dome, floor, sh, pil)
}

/** Khôi phục môi trường khi lãnh địa kết thúc / ván mới (được Game.clearWorld gọi). */
internal fun Game.sukuReset() {
    scene.fogHex = SUKU_FOG; scene.fogDensity = .0125f
    if (hasP) { P.h.domainOn = false; P.h.four = false }
}

private fun Game.sukuUlt(): Boolean {
    if (EN.none { !it.dead && it.team == 'e' }) return false
    val T = 8.6f; val h = P.h; val f = fwd()
    P.cast = T + .5f; P.inv = T + .7f; P.bl = T + SUKU_FORM; h.four = true
    SFX.ult(); P.auraBoost = 3f
    banner("LÃNH ĐỊA TRIỂN KHAI", "PHỤC MA NGỰ TRÙ TỬ · Malevolent Shrine")
    act("sseal", 1.4f); later(1.4f) { act("sdom", T - 1.4f - 1.2f) }; later(T - 1.2f) { act("sworld", 1.2f) }
    flash(SK_BLK, .6f, 900)
    val cx = clamp(P.pos.x + f.x * 15f, -22f, 22f); val cz = clamp(P.pos.z + f.z * 15f, -22f, 22f)
    val dm = buildDomain(cx, cz); val life = T + .7f
    var acc = 0f
    fx.add(dm.root, life, null) { k, _, dt ->
        val tt = k * life
        val gr = grow(tt, .15f, 1.0f); val out = 1f - grow(tt, T - .05f, T + .65f)
        dm.dome.setScale(max(.001f, 74f * gr * out)); dm.floor.setScale(max(.001f, gr * out))
        val s = grow(tt, .5f, 1.9f) * out; dm.shrine.scl.set(max(.001f, s), max(.001f, s), max(.001f, s)); dm.shrine.pos.y = (1f - s) * -3f
        dm.pillars.scl.set(1f, max(.001f, grow(tt, .8f, 1.8f) * out), 1f)
        acc += dt
        if (acc > .22f && gr > .5f) { acc = 0f; val a = rnd(0f, TAU); val r = sqrt(rnd01()) * 24f; fx.ring(cos(a) * r, sin(a) * r, SK_RED, .5f, rnd(3f, 6f), .9f, .1f) }
    }
    // 1) bóng tối lan ra · hai nhịp sóng chấn động
    for (j in 0 until 3) later(.15f + j * .25f) { fx.ring(P.pos.x, P.pos.z, if (j == 1) SK_BONE else SK_RED, 1f, 30f + j * 8f, .7f); fx.dome(P.pos.x, 1.2f, P.pos.z, SK_DRK, 1f, 34f, .6f) }
    later(.4f) { shake = max(shake, 1.1f); popText("Ryomen!", SK_RED) }
    later(.7f) { scene.fogHex = 0x34000a; scene.fogDensity = .017f; h.domainOn = true }
    // 2) mọi kẻ địch bị giam trong lãnh địa
    later(1.2f) {
        for (e in EN) if (!e.dead && e.team == 'e') e.stun = max(e.stun, T - 1.6f)
        toast("Lãnh Địa: mọi kẻ địch trúng đòn tất sát — Giải / Bát liên tục", 2.6f)
    }
    // 3) bão chém: nhát Giải bủa khắp đấu trường, mỗi 0.4 giây mọi kẻ địch chịu một đợt sát thương (bắt buộc trúng)
    val n = ((T - 3.2f) / .1f).toInt()
    for (i in 0 until n) later(1.3f + i * .1f) {
        if (P.dead) return@later
        for (j in 0 until 3) {
            val a = rnd(0f, TAU); val r = sqrt(rnd01()) * ARENA * .9f
            dismantle(cos(a) * r, rnd(.5f, 3.5f), sin(a) * r, rnd(0f, TAU), rnd(-.9f, .9f), rnd(4f, 10f), j == 0)
        }
        if (i % 4 == 0) {
            val big = (i / 4) % 3 == 2
            for (e in EN.toList()) {
                if (e.dead || e.team != 'e') continue
                if (big || e.cfg.boss) cleaveFx(e.pos.x, 1.4f + e.hover, e.pos.z, rnd(0f, TAU), 3.2f)
                else dismantle(e.pos.x, 1.3f + e.hover, e.pos.z, rnd(0f, TAU), rnd(-.8f, .8f), 4.5f)
                hurtE(e, if (big) cleaveDmg(e, 16f) else 8f + e.maxHp * (if (e.cfg.boss) .004f else .02f),
                    Hit(col = SK_RED, knock = if (big) 1.2f else .2f, stun = .3f, big = big, hs = if (big) .04f else 0f, from = P.pos, noCrit = true, gain = 0f, src = "domain"))
            }
            if (big) { shake = max(shake, .5f); SFX.boom() }
        }
    }
    // 4) Thế Giới Đoạn Trảm: khe nứt xé ngang + dọc, rồi cắt đôi cả đấu trường
    later(T - 1.3f) {
        flash(0xffffff, .35f, 300); shake = max(shake, .6f)
        val yaw = P.face
        riftFx(P.pos.x + f.x * 12f, 4f, P.pos.z + f.z * 12f, yaw + PIF / 2f, 34f, 1.3f, SK_RED, 1.4f, 0f)
        riftFx(P.pos.x + f.x * 12f, 8f, P.pos.z + f.z * 12f, yaw + PIF / 2f, 30f, 1.8f, SK_BONE, 1.2f, PIF / 2f)
        toast("Thế Giới Đoạn Trảm…", 1.2f)
    }
    later(T - .55f) {
        SFX.boom(); flash(0xffffff, .9f, 500); shake = max(shake, 2f); hs = max(hs, .12f)
        val c = P.pos.clone()
        fx.pillar(c.x + f.x * 12f, c.z + f.z * 12f, SK_BONE, 3f, 70f, .9f); fx.pillar(c.x + f.x * 12f, c.z + f.z * 12f, SK_RED, 6f, 60f, 1.0f)
        for (k in 0 until 3) fx.ring(c.x, c.z, if (k == 1) SK_BONE else SK_RED, 1f, 20f + k * 6f, .7f + k * .1f)
        for (i in 0 until 40) { val a = rnd(0f, TAU); val s = rnd(5f, 14f); emit(c.x, 1.5f, c.z, cos(a) * s, rnd(1f, 7f), sin(a) * s, rnd(.8f, 1.4f), .6f, .05f, if (i % 3 == 0) SK_BONE else SK_RED, 3f, 1.2f) }
        popText("Đoạn Trảm!", SK_BONE)
        radiusHit(c, 60f) { e -> hurtE(e, 120f + e.maxHp * (if (e.cfg.boss) .06f else .25f), Hit(col = SK_RED, knock = 6f, stun = 1.5f, big = true, hs = .1f, from = c, noCrit = true, gain = 0f)) }
    }
    // 5) lãnh địa sụp đổ · Đảo Ngược Chú Thuật hồi máu · dạng Ryomen kéo dài
    later(T) {
        scene.fogHex = SUKU_FOG; scene.fogDensity = .0125f; h.domainOn = false
        val heal = P.maxHp * .25f; P.hp = min(P.maxHp, P.hp + heal); dmgNum(P.pos, heal, 0x7dff9a, false, "+" + heal.roundToInt())
        flash(SK_RED, .3f, 400); P.dmgBuff = 1.3f; P.dmgBuffT = 6f; P.auraBoost = 2.5f
        for (k in 0 until 2) fx.ring(P.pos.x, P.pos.z, SK_RED, 1f, 16f + k * 4f, .6f)
        toast("Dạng Ryomen 4 tay: +25% sát thương, hồi máu, 14 giây", 2.6f)
    }
    return true
}

// ======================= CẤU HÌNH NHÂN VẬT =======================
internal fun Game.sukuna(): CharCfg {
    val c = CharCfg(
        "sukuna", "RYOMEN SUKUNA", "👹", "Chú Linh (Cursed Spirit) · Hạng Đặc Cấp", SK_RED, SK_GOLD_UI, 130f, 8.6f, 1.15f, 1.1f, .95f, .15f,
        "Vua Nguyền Rủa. Sinh vật ngạo nghễ chỉ cần vẫy tay là cắt vụn mọi thứ trong tầm mắt. Hai tay đã đủ giết người, tay thứ ba và thứ tư chỉ lộ ra khi hắn nghiêm túc.",
        "Nội tại: Đảo Ngược Chú Thuật, tự hồi 0.4% máu mỗi giây. Dash chém Giải 5 nhát dọc đường. Sau Lãnh Địa vào dạng Ryomen 4 tay trong 14 giây: đòn thường bắn 3 nhát, +25% sát thương, hồi nhanh hơn.",
        intArrayOf(5, 4, 3, 5),
        listOf(
            Skill("Giải · Giải · Hắc Thiểm · Bát", "👹", "CHÉM", 0f, "Vòng 4 nhịp: hai nhát Giải bắn trăng chém mảnh xuyên địch, đấm Hắc Thiểm có cơ hội 40% bùng sét đen đỏ gây sát thương cực lớn, rồi nhát Bát chém chữ X, sát thương tăng theo máu tối đa của mục tiêu."),
            Skill("Giải: Vạn Trảm", "🩸", "GIẢI", 5f, "Hai tay vung liên tục, hàng chục nhát Giải bủa lên tối đa 8 kẻ địch gần nhất, kết thúc bằng Bát đồng loạt: sát thương lớn, choáng. Hai đòn kế tiếp chí mạng."),
            Skill("Phủ: Hoả Tiễn (Fuga)", "🔥", "PHỦ", 9f, "Giương cung lửa, dồn chú lực rồi bắn mũi tên hoả xuyên mọi thứ trên đường bay, nổ tung thành hoả hải cháy lan 4 giây. Ở dạng Ryomen bắn ba mũi cùng lúc."),
            Skill("Lãnh Địa: Phục Ma Ngự Trù Tử", "⛩️", "ULT", 0f, "Triển khai lãnh địa: bầu trời đen đỏ, biển máu, ngôi đền đầu bò khổng lồ. Mọi kẻ địch bị giam và trúng Giải / Bát liên tục không thể né. Cuối cùng Thế Giới Đoạn Trảm xé đôi đấu trường. Hồi 25% máu và vào dạng Ryomen 4 tay 14 giây.")
        ),
        sigWrap("sukuna", SK_RED, ::buildSukuna), { sukuAtk() }, { sukuS1() }, { sukuS2() }, { sukuUlt() })
    c.tick = { dt ->
        val h = P.h
        P.hp = min(P.maxHp, P.hp + P.maxHp * .004f * dt)   // Đảo Ngược Chú Thuật
        if (P.bl > 0f) {
            P.bl -= dt; h.four = true
            P.dmgBuff = max(P.dmgBuff, 1.25f); P.dmgBuffT = max(P.dmgBuffT, .2f); P.spdMul = 1.08f
            P.hp = min(P.maxHp, P.hp + P.maxHp * .01f * dt); P.auraBoost = max(P.auraBoost, .7f)
            if (P.bl <= 0f) {
                P.bl = 0f; h.four = false; popText("Hết Ryomen", SK_RED); burst(P.pos.x, 1.2f, P.pos.z, SK_RED, 22, 6f, .5f, .7f)
            }
        }
    }
    return c
}

private const val SK_GOLD_UI = 0xffc86a
