package com.nenarena.game.engine

import kotlin.math.*

/** Dữ liệu lưới: vị trí + pháp tuyến (xen kẽ 6 float/đỉnh) + chỉ số. Mỗi geometry được GPU cache theo id. */
class Geometry(val verts: FloatArray, val indices: ShortArray) {
    val id = nextId++
    val indexCount get() = indices.size
    @JvmField var vbo = 0
    @JvmField var ibo = 0
    @JvmField var vao = 0
    @JvmField var vbo2 = 0
    @JvmField var gen = 0
    /** Dữ liệu phụ cho mô hình có skin/texture: 10 float/đỉnh = u,v, j0..j3 (chỉ số xương), w0..w3 (trọng số). */
    @JvmField var ext: FloatArray? = null

    /** Dịch toàn bộ đỉnh (giống geometry.translate). */
    fun translated(x: Float, y: Float, z: Float): Geometry {
        val v = verts.copyOf()
        var i = 0
        while (i < v.size) { v[i] += x; v[i + 1] += y; v[i + 2] += z; i += 6 }
        return Geometry(v, indices)
    }

    /** Xoay quanh trục X (giống geometry.rotateX). */
    fun rotatedX(a: Float): Geometry {
        val v = verts.copyOf(); val c = cos(a); val s = sin(a)
        var i = 0
        while (i < v.size) {
            val y = v[i + 1]; val z = v[i + 2]
            v[i + 1] = y * c - z * s; v[i + 2] = y * s + z * c
            val ny = v[i + 4]; val nz = v[i + 5]
            v[i + 4] = ny * c - nz * s; v[i + 5] = ny * s + nz * c
            i += 6
        }
        return Geometry(v, indices)
    }

    companion object {
        private var nextId = 1

        private class B {
            val v = ArrayList<Float>(); val idx = ArrayList<Short>()
            fun vert(x: Float, y: Float, z: Float, nx: Float, ny: Float, nz: Float): Int {
                v.add(x); v.add(y); v.add(z); v.add(nx); v.add(ny); v.add(nz); return v.size / 6 - 1
            }
            fun tri(a: Int, b: Int, c: Int) { idx.add(a.toShort()); idx.add(b.toShort()); idx.add(c.toShort()) }
            fun build() = Geometry(v.toFloatArray(), idx.toShortArray())
        }

        fun box(w: Float, h: Float, d: Float): Geometry {
            val b = B(); val hw = w / 2; val hh = h / 2; val hd = d / 2
            fun face(nx: Float, ny: Float, nz: Float, ax: FloatArray, bx: FloatArray) {
                // ax,bx: vectores cạnh (đã nhân nửa kích thước)
                val ox = nx * hw
                val oy = ny * hh
                val oz = nz * hd
                val i0 = b.vert(ox - ax[0] - bx[0], oy - ax[1] - bx[1], oz - ax[2] - bx[2], nx, ny, nz)
                val i1 = b.vert(ox + ax[0] - bx[0], oy + ax[1] - bx[1], oz + ax[2] - bx[2], nx, ny, nz)
                val i2 = b.vert(ox + ax[0] + bx[0], oy + ax[1] + bx[1], oz + ax[2] + bx[2], nx, ny, nz)
                val i3 = b.vert(ox - ax[0] + bx[0], oy - ax[1] + bx[1], oz - ax[2] + bx[2], nx, ny, nz)
                b.tri(i0, i1, i2); b.tri(i0, i2, i3)
            }
            // +X, -X, +Y, -Y, +Z, -Z  (thứ tự đỉnh đảm bảo CCW nhìn từ ngoài)
            face(1f, 0f, 0f, floatArrayOf(0f, 0f, -hd), floatArrayOf(0f, hh, 0f))
            face(-1f, 0f, 0f, floatArrayOf(0f, 0f, hd), floatArrayOf(0f, hh, 0f))
            face(0f, 1f, 0f, floatArrayOf(hw, 0f, 0f), floatArrayOf(0f, 0f, -hd))
            face(0f, -1f, 0f, floatArrayOf(hw, 0f, 0f), floatArrayOf(0f, 0f, hd))
            face(0f, 0f, 1f, floatArrayOf(hw, 0f, 0f), floatArrayOf(0f, hh, 0f))
            face(0f, 0f, -1f, floatArrayOf(-hw, 0f, 0f), floatArrayOf(0f, hh, 0f))
            return b.build()
        }

        /** SphereGeometry(r, wSeg, hSeg, phiStart, phiLen, thetaStart, thetaLen) của three.js. */
        fun sphere(r: Float, ws: Int = 14, hs: Int = 10, phiStart: Float = 0f, phiLen: Float = TAU, thetaStart: Float = 0f, thetaLen: Float = PIF): Geometry {
            val b = B(); val grid = ArrayList<IntArray>()
            for (iy in 0..hs) {
                val row = IntArray(ws + 1); val v = iy.toFloat() / hs
                for (ix in 0..ws) {
                    val u = ix.toFloat() / ws
                    val x = -r * cos(phiStart + u * phiLen) * sin(thetaStart + v * thetaLen)
                    val y = r * cos(thetaStart + v * thetaLen)
                    val z = r * sin(phiStart + u * phiLen) * sin(thetaStart + v * thetaLen)
                    val l = sqrt(x * x + y * y + z * z).let { if (it == 0f) 1f else it }
                    row[ix] = b.vert(x, y, z, x / l, y / l, z / l)
                }
                grid.add(row)
            }
            for (iy in 0 until hs) for (ix in 0 until ws) {
                val a = grid[iy][ix + 1]; val bb = grid[iy][ix]; val c = grid[iy + 1][ix]; val d = grid[iy + 1][ix + 1]
                if (iy != 0 || thetaStart > 0f) b.tri(a, bb, d)
                if (iy != hs - 1 || thetaStart + thetaLen < PIF) b.tri(bb, c, d)
            }
            return b.build()
        }

        /** CylinderGeometry(rTop, rBottom, h, seg, 1, openEnded). Cone = rTop 0. */
        fun cylinder(rt: Float, rb: Float, h: Float, seg: Int = 10, open: Boolean = false): Geometry {
            val b = B(); val hh = h / 2
            val slope = (rb - rt) / h
            val top = IntArray(seg + 1); val bot = IntArray(seg + 1)
            for (i in 0..seg) {
                val u = i.toFloat() / seg; val th = u * TAU
                val s = sin(th); val c = cos(th)
                var nx = s; var ny = slope; var nz = c
                val nl = sqrt(nx * nx + ny * ny + nz * nz); nx /= nl; ny /= nl; nz /= nl
                top[i] = b.vert(rt * s, hh, rt * c, nx, ny, nz)
                bot[i] = b.vert(rb * s, -hh, rb * c, nx, ny, nz)
            }
            for (i in 0 until seg) {
                if (rt > 0f) b.tri(top[i], bot[i], top[i + 1])
                if (rb > 0f) b.tri(bot[i], bot[i + 1], top[i + 1])
            }
            fun cap(up: Boolean, rad: Float) {
                if (rad <= 0f) return
                val y = if (up) hh else -hh; val ny = if (up) 1f else -1f
                val c = b.vert(0f, y, 0f, 0f, ny, 0f)
                val ring = IntArray(seg + 1)
                for (i in 0..seg) { val th = i.toFloat() / seg * TAU; ring[i] = b.vert(rad * sin(th), y, rad * cos(th), 0f, ny, 0f) }
                for (i in 0 until seg) if (up) b.tri(ring[i], ring[i + 1], c) else b.tri(ring[i + 1], ring[i], c)
            }
            if (!open) { cap(true, rt); cap(false, rb) }
            return b.build()
        }

        fun cone(r: Float, h: Float, seg: Int = 8) = cylinder(0f, r, h, seg)

        /** Mặt phẳng nằm trong XY, hướng +Z (như PlaneGeometry). */
        fun plane(w: Float, h: Float): Geometry {
            val b = B(); val x = w / 2; val y = h / 2
            val a = b.vert(-x, y, 0f, 0f, 0f, 1f); val bb = b.vert(-x, -y, 0f, 0f, 0f, 1f)
            val c = b.vert(x, -y, 0f, 0f, 0f, 1f); val d = b.vert(x, y, 0f, 0f, 0f, 1f)
            b.tri(a, bb, d); b.tri(bb, c, d)
            return b.build()
        }

        /** Vệt chém hình trăng khuyết nằm trong mặt XZ (thay texSlash): tâm (-.34,0), bán kính .49, dày nhất ở giữa. */
        fun crescent(arc: Float = 1.1f, seg: Int = 16): Geometry {
            val b = B(); val cx = -.34f; val ro = .49f
            val o = IntArray(seg + 1); val n = IntArray(seg + 1)
            for (i in 0..seg) {
                val u = i.toFloat() / seg; val a = -arc + 2f * arc * u
                val w = .02f + .13f * Math.pow(cos((u - .5f) * PIF).toDouble().coerceAtLeast(0.0), .8).toFloat()
                o[i] = b.vert(cx + ro * cos(a), 0f, ro * sin(a), 0f, 1f, 0f)
                n[i] = b.vert(cx + (ro - w) * cos(a), 0f, (ro - w) * sin(a), 0f, 1f, 0f)
            }
            for (i in 0 until seg) { b.tri(o[i], n[i], n[i + 1]); b.tri(o[i], n[i + 1], o[i + 1]) }
            return b.build()
        }

        /** Hình trái tim phẳng trong XY (đường cong tham số như heartBurst), cao ~size. */
        fun heart(size: Float): Geometry {
            val b = B(); val c = b.vert(0f, 0f, 0f, 0f, 0f, 1f); val n = 40; val k = size / 34f
            val ids = IntArray(n + 1)
            for (i in 0..n) {
                val t = i.toFloat() / n * TAU
                val x = 16f * sin(t).pow(3); val y = 13f * cos(t) - 5f * cos(2 * t) - 2f * cos(3 * t) - cos(4 * t)
                ids[i] = b.vert(x * k, (y + 3f) * k, 0f, 0f, 0f, 1f)
            }
            for (i in 0 until n) b.tri(c, ids[i], ids[i + 1])
            return b.build()
        }

        /** CircleGeometry nằm trong XY. */
        fun circle(r: Float, seg: Int = 32): Geometry {
            val b = B(); val c = b.vert(0f, 0f, 0f, 0f, 0f, 1f)
            val ring = IntArray(seg + 1)
            for (i in 0..seg) { val t = i.toFloat() / seg * TAU; ring[i] = b.vert(r * cos(t), r * sin(t), 0f, 0f, 0f, 1f) }
            for (i in 0 until seg) b.tri(ring[i], ring[i + 1], c)
            return b.build()
        }

        /** RingGeometry(inner, outer, seg) nằm trong XY. */
        fun ring(ri: Float, ro: Float, seg: Int = 32): Geometry {
            val b = B(); val inn = IntArray(seg + 1); val out = IntArray(seg + 1)
            for (i in 0..seg) {
                val t = i.toFloat() / seg * TAU
                inn[i] = b.vert(ri * cos(t), ri * sin(t), 0f, 0f, 0f, 1f)
                out[i] = b.vert(ro * cos(t), ro * sin(t), 0f, 0f, 0f, 1f)
            }
            for (i in 0 until seg) { b.tri(inn[i], out[i], out[i + 1]); b.tri(inn[i], out[i + 1], inn[i + 1]) }
            return b.build()
        }

        fun torus(r: Float, tube: Float, rs: Int = 6, ts: Int = 14): Geometry {
            val b = B(); val g = Array(rs + 1) { IntArray(ts + 1) }
            for (j in 0..rs) for (i in 0..ts) {
                val u = i.toFloat() / ts * TAU; val v = j.toFloat() / rs * TAU
                val x = (r + tube * cos(v)) * cos(u); val y = (r + tube * cos(v)) * sin(u); val z = tube * sin(v)
                val cx = r * cos(u); val cy = r * sin(u)
                var nx = x - cx; var ny = y - cy; var nz = z
                val l = sqrt(nx * nx + ny * ny + nz * nz); nx /= l; ny /= l; nz /= l
                g[j][i] = b.vert(x, y, z, nx, ny, nz)
            }
            for (j in 1..rs) for (i in 1..ts) {
                val a = g[j][i - 1]; val bb = g[j - 1][i - 1]; val c = g[j - 1][i]; val d = g[j][i]
                b.tri(a, bb, d); b.tri(bb, c, d)
            }
            return b.build()
        }

        fun octahedron(r: Float): Geometry {
            val b = B()
            val p = arrayOf(floatArrayOf(r, 0f, 0f), floatArrayOf(-r, 0f, 0f), floatArrayOf(0f, r, 0f),
                floatArrayOf(0f, -r, 0f), floatArrayOf(0f, 0f, r), floatArrayOf(0f, 0f, -r))
            val f = arrayOf(intArrayOf(0, 2, 4), intArrayOf(4, 2, 1), intArrayOf(1, 2, 5), intArrayOf(5, 2, 0),
                intArrayOf(0, 4, 3), intArrayOf(4, 1, 3), intArrayOf(1, 5, 3), intArrayOf(5, 0, 3))
            for (t in f) {
                val a = p[t[0]]; val bb = p[t[1]]; val c = p[t[2]]
                val ux = bb[0] - a[0]; val uy = bb[1] - a[1]; val uz = bb[2] - a[2]
                val vx = c[0] - a[0]; val vy = c[1] - a[1]; val vz = c[2] - a[2]
                var nx = uy * vz - uz * vy; var ny = uz * vx - ux * vz; var nz = ux * vy - uy * vx
                val l = sqrt(nx * nx + ny * ny + nz * nz); nx /= l; ny /= l; nz /= l
                val i0 = b.vert(a[0], a[1], a[2], nx, ny, nz); val i1 = b.vert(bb[0], bb[1], bb[2], nx, ny, nz); val i2 = b.vert(c[0], c[1], c[2], nx, ny, nz)
                b.tri(i0, i1, i2)
            }
            return b.build()
        }

        /** CapsuleGeometry(radius, length, capSeg, radialSeg): trụ + 2 bán cầu theo trục Y. */
        fun capsule(r: Float, len: Float, capSeg: Int = 4, rad: Int = 10): Geometry {
            val b = B(); val hl = len / 2
            val rows = ArrayList<IntArray>()
            // nửa trên: theta 0..90°, nửa dưới: 90..180°
            val rings = ArrayList<FloatArray>() // [y, radius, ny, nr]
            for (i in 0..capSeg) { val t = i.toFloat() / capSeg * (PIF / 2); rings.add(floatArrayOf(hl + r * cos(t), r * sin(t), cos(t), sin(t))) }
            for (i in 0..capSeg) { val t = PIF / 2 + i.toFloat() / capSeg * (PIF / 2); rings.add(floatArrayOf(-hl + r * cos(t), r * sin(t), cos(t), sin(t))) }
            for (rg in rings) {
                val row = IntArray(rad + 1)
                for (i in 0..rad) {
                    val th = i.toFloat() / rad * TAU
                    row[i] = b.vert(rg[1] * sin(th), rg[0], rg[1] * cos(th), rg[3] * sin(th), rg[2], rg[3] * cos(th))
                }
                rows.add(row)
            }
            for (j in 0 until rows.size - 1) for (i in 0 until rad) {
                val a = rows[j][i]; val bb = rows[j + 1][i]; val c = rows[j + 1][i + 1]; val d = rows[j][i + 1]
                b.tri(a, bb, d); b.tri(bb, c, d)
            }
            return b.build()
        }
    }
}
