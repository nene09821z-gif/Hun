package com.nenarena.game.game

import com.nenarena.game.engine.*
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.*

/*
 * ============================ KILLUA · THƯ VIỆN CHUYỂN ĐỘNG ============================
 * assets/killua_anim.json + killua_anim.bin: 312 clip 30fps (sinh bởi tools/killua_anim/export.py).
 * Mỗi khung = 21 quaternion xương (int16 /32767) + 3 số dịch chuyển gốc (int16 /2000, đơn vị model, cao 1).
 * 8 xương tóc không nằm trong clip: chạy lò xo theo vận tốc/quán tính của đầu.
 */

private const val NB = 21
private const val FL = NB * 4 + 3          // số float / khung sau khi giải mã
private const val FS = NB * 4 + 3          // số short / khung trong file

class KClip(val name: String, val cat: String, val base: Int, val frames: Int, val dur: Float, val loop: Boolean, val stride: Float, val hits: FloatArray)

class KAnimLib(val clips: List<KClip>, val byName: HashMap<String, KClip>, val data: ShortArray, val bones: Array<String>) {
    val cats: List<String> = clips.map { it.cat }.distinct()
    operator fun get(n: String): KClip? = byName[n]

    /** Lấy mẫu clip tại thời điểm t (giây) -> o[0..83] quaternion (x,y,z,w) x21, o[84..86] gốc (đơn vị model). */
    fun sample(c: KClip, t0: Float, o: FloatArray) {
        val n = if (c.loop) c.frames else c.frames - 1
        var t = t0
        if (c.loop) { t %= c.dur; if (t < 0f) t += c.dur } else t = t.coerceIn(0f, c.dur)
        val fp = if (c.dur > 0f && n > 0) t * n / c.dur else 0f
        var i0 = fp.toInt(); var fr = fp - i0
        if (c.loop) i0 %= c.frames
        else if (i0 >= c.frames - 1) { i0 = c.frames - 1; fr = 0f }
        val i1 = if (c.loop) (i0 + 1) % c.frames else min(i0 + 1, c.frames - 1)
        val a = c.base + i0 * FS; val b = c.base + i1 * FS
        val k = 1f / 32767f
        for (j in 0 until NB) {
            val p = j * 4
            val ax = data[a + p] * k; val ay = data[a + p + 1] * k; val az = data[a + p + 2] * k; val aw = data[a + p + 3] * k
            var bx = data[b + p] * k; var by = data[b + p + 1] * k; var bz = data[b + p + 2] * k; var bw = data[b + p + 3] * k
            if (ax * bx + ay * by + az * bz + aw * bw < 0f) { bx = -bx; by = -by; bz = -bz; bw = -bw }
            var x = ax + (bx - ax) * fr; var y = ay + (by - ay) * fr; var z = az + (bz - az) * fr; var w = aw + (bw - aw) * fr
            val l = 1f / sqrt(x * x + y * y + z * z + w * w + 1e-12f)
            o[p] = x * l; o[p + 1] = y * l; o[p + 2] = z * l; o[p + 3] = w * l
        }
        val r = 1f / 2000f
        for (q in 0 until 3) {
            val u = data[a + NB * 4 + q] * r; val v = data[b + NB * 4 + q] * r
            o[NB * 4 + q] = u + (v - u) * fr
        }
    }
}

object KAnim {
    private var lib: KAnimLib? = null
    private var failed = false

    @Synchronized fun get(): KAnimLib? {
        if (lib != null || failed) return lib
        try {
            val ctx = Assets.ctx ?: return null
            val js = JSONObject(String(ctx.assets.open("killua_anim.json").use { it.readBytes() }, Charsets.UTF_8))
            val bytes = ctx.assets.open("killua_anim.bin").use { it.readBytes() }
            val sb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val data = ShortArray(sb.remaining()); sb.get(data)
            val bj = js.getJSONArray("bones"); val bones = Array(bj.length()) { bj.getString(it) }
            val cj = js.getJSONArray("clips"); val list = ArrayList<KClip>(); val map = HashMap<String, KClip>()
            for (i in 0 until cj.length()) {
                val o = cj.getJSONObject(i)
                val hj = o.optJSONArray("h")
                val hits = FloatArray(hj?.length() ?: 0) { hj!!.getDouble(it).toFloat() }
                val c = KClip(o.getString("n"), o.getString("c"), o.getInt("o") / 2, o.getInt("f"), o.getDouble("d").toFloat(),
                    o.getInt("l") == 1, o.optDouble("s", 0.0).toFloat(), hits)
                list.add(c); map[c.name] = c
            }
            lib = KAnimLib(list, map, data, bones)
        } catch (e: Throwable) { failed = true; lib = null }
        return lib
    }
}

/** Bộ lấy mẫu một clip, có cross-fade mượt khi đổi clip (chụp lại tư thế cuối rồi nội suy sang clip mới). */
private class Sampler(val lib: KAnimLib) {
    var clip: KClip? = null; var t = 0f; var rate = 1f; var done = false; private var el = 0f
    private val snap = FloatArray(FL); private val tmp = FloatArray(FL)
    val out = FloatArray(FL)
    private var bt = 1f; private var bd = .15f
    val phase get() = clip?.let { if (it.dur > 0f) (t % it.dur) / it.dur else 0f } ?: 0f

    fun play(c: KClip, rate: Float, start: Float = 0f, blend: Float = .15f) {
        val had = clip != null && blend > 0f
        if (had) { System.arraycopy(out, 0, snap, 0, FL); bt = 0f; bd = blend } else bt = 1f
        clip = c; this.rate = rate; t = start; done = false; el = 0f
        if (!had) lib.sample(c, t, out)      // có cross-fade thì tại thời điểm này đầu ra vẫn là tư thế cũ (snap)
    }

    fun step(dt: Float) {
        val c = clip ?: return
        t += dt * rate
        if (c.loop) { el += dt * rate; if (t >= c.dur) t %= c.dur; if (el >= c.dur * 2f) done = true }
        else if (t >= c.dur) { t = c.dur; done = true }
        lib.sample(c, t, if (bt < 1f) tmp else out)
        if (bt < 1f) {
            bt += dt / bd
            if (bt >= 1f) { bt = 1f; System.arraycopy(tmp, 0, out, 0, FL) }
            else { val k = bt * bt * (3f - 2f * bt); Blend.mix(snap, tmp, k, null, out) }
        }
    }
}

private object Blend {
    /** out = nlerp(a, b, w * mask[j]) cho từng xương; gốc theo mask[NB] nếu có (mask=null -> đều w). */
    fun mix(a: FloatArray, b: FloatArray, w: Float, mask: FloatArray?, o: FloatArray) {
        for (j in 0 until NB) {
            val k = w * (mask?.get(j) ?: 1f); val p = j * 4
            if (k <= 0f) { o[p] = a[p]; o[p + 1] = a[p + 1]; o[p + 2] = a[p + 2]; o[p + 3] = a[p + 3]; continue }
            var bx = b[p]; var by = b[p + 1]; var bz = b[p + 2]; var bw = b[p + 3]
            if (a[p] * bx + a[p + 1] * by + a[p + 2] * bz + a[p + 3] * bw < 0f) { bx = -bx; by = -by; bz = -bz; bw = -bw }
            val x = a[p] + (bx - a[p]) * k; val y = a[p + 1] + (by - a[p + 1]) * k; val z = a[p + 2] + (bz - a[p + 2]) * k; val ww = a[p + 3] + (bw - a[p + 3]) * k
            val l = 1f / sqrt(x * x + y * y + z * z + ww * ww + 1e-12f)
            o[p] = x * l; o[p + 1] = y * l; o[p + 2] = z * l; o[p + 3] = ww * l
        }
        val kr = w * (mask?.get(NB) ?: 1f)
        for (q in 0 until 3) o[NB * 4 + q] = a[NB * 4 + q] + (b[NB * 4 + q] - a[NB * 4 + q]) * kr
    }
}

/**
 * Bộ điều khiển animation của Killua: đọc trạng thái từ game (vị trí/hướng/cờ), chọn clip nền (đi/chạy/chờ),
 * chồng clip hành động (đòn đánh, chiêu, né, trúng đòn, chết) lên trên, rồi ghi quaternion vào xương của SkinModel.
 */
class KilluaAnimator(private val h: Human, private val m: SkinModel, private val lib: KAnimLib, private val scale: Float) {
    private val iB = IntArray(NB) { m.bi(lib.bones[it]) }
    private val hairNames = arrayOf("hairTop", "hairFr", "hairBk0", "hairBk1", "hairL0", "hairL1", "hairR0", "hairR1")
    private val iH = IntArray(8) { m.bi(hairNames[it]) }
    private val hGain = floatArrayOf(.35f, .6f, .9f, 1.2f, .7f, 1.0f, .7f, 1.0f)

    private val base = Sampler(lib); private val act = Sampler(lib)
    private val mask = FloatArray(NB + 1); private val pose = FloatArray(FL)
    private var baseName = ""
    private var fam = 0                       // họ clip nền: 0 chờ, 1 đi tới, 2 đi ngang, 3 lùi
    private var moving = false; private var tier = 0; private var dir = 0

    // ----- động học đo từ vị trí/hướng gốc -----
    private var havePrev = false; private var lpx = 0f; private var lpz = 0f; private var lry = 0f
    private var svx = 0f; private var svz = 0f; private var spd = 0f
    private var lvx = 0f; private var lvz = 0f; private var plvx = 0f; private var plvz = 0f; private var yawRate = 0f

    // ----- lớp hành động -----
    private var actOn = false; private var actW = 0f; private var actPrio = 0; private var actIn = .08f; private var actOut = .15f
    private var actHold = false; private var actFull = false; private var actFading = false; private var actName = ""
    private var combatT = 0f; private var atkN = 0; private var atkIdle = 0f
    private var idleT = 0f; private var fidgetAt = 8f; private var idleVarT = 0f; private var idleVar = "idle_relaxed"
    var dead = false; private set
    private var lastHitA = 0f

    // ----- thư viện / showcase -----
    var showOn = false; private set
    var showAuto = true; private set
    private var showIdx = 0; private var showT = 0f; private var showWait = 0f
    val clipCount get() = lib.clips.size
    val showName get() = lib.clips[showIdx].name
    val showCatName get() = lib.clips[showIdx].cat
    val showPos get() = showIdx + 1

    // ----- tóc -----
    private val hx = FloatArray(8); private val hvx = FloatArray(8); private val hz = FloatArray(8); private val hvz = FloatArray(8)

    fun reset() {
        actOn = false; actW = 0f; actHold = false; actFading = false; dead = false; combatT = 0f; atkN = 0; idleT = 0f
        havePrev = false; svx = 0f; svz = 0f; spd = 0f; moving = false; baseName = ""; showOn = false
        for (i in 0 until 8) { hx[i] = 0f; hvx[i] = 0f; hz[i] = 0f; hvz[i] = 0f }
    }

    // =========================== API cho Game ===========================
    /** Game.act(): nhận tên động tác cũ + chiêu đang dùng (curSk: 0 đánh thường, 1, 2, 3 = ULT, -1 khác). */
    fun onAct(n: String, sk: Int, d: Float, flip: Boolean) {
        if (dead) return
        when {
            // Ám sát (lướt tàng hình rồi chạm đòn thường): đâm / chém xuống từ sau lưng
            sk == 0 && n == "slash" && h.stealthOn -> {
                atkIdle = 0f; combat(); fit(if (rnd01() < .5f) "assassin_stab_R" else "assassin_strike_down_R", .55f, .8f, 1.5f, 2)
            }
            // Đòn thường thứ 3: hai nhát Lôi Trảo bắt chéo hình quạt -> vồ chéo hình chữ X
            sk == 0 && n == "slash" -> {
                atkIdle = 0f; combat(); fit("claw_rake_x" + (if (flip) "_L" else "_R"), d * 1.6f + .1f, 1f, 2.4f, 1)
            }
            sk == 0 -> {
                if (atkIdle > 1.1f) atkN = 0
                val sd = if (flip) "_L" else "_R"
                val c = arrayOf("claw_slash_h", "claw_slash_dn", "claw_slash_h", "claw_slash_up", "claw_rake_x", "claw_thrust")[atkN++ % 6] + sd
                atkIdle = 0f; combat(); fit(c, d * 1.6f + .05f, 1f, 2.4f, 1)
            }
            sk == 1 -> { combat(); fit("lightning_palm_beam", d + .45f, .8f, 1.6f, 2) }
            sk == 2 -> { combat(); fit(if (atkN++ % 2 == 0) "godspeed_slash_R" else "godspeed_slash_L", .5f, .8f, 1.5f, 2) }
            sk == 3 -> { combat(); fit("nen_ultimate_start", 2.3f, .9f, 1.2f, 2) }
            n == "slash" -> { combat(); fit(if (rnd01() < .5f) "assassin_stab_R" else "assassin_strike_down_R", .55f, .8f, 1.5f, 2) }
            n == "punch" -> {   // đòn dịch chuyển của ULT
                val c = arrayOf("claw_slash_h", "claw_thrust", "claw_slash_dn", "claw_rake_x", "claw_slash_up")[atkN++ % 5] + (if (flip) "_L" else "_R")
                combat(); fit(c, d * 1.6f + .05f, 1f, 2.6f, 2)
            }
            n == "raise" || n == "cast" || n == "pray" || n == "spread" -> { combat(); fit("nen_release_burst", .9f, .8f, 1.5f, 1) }
        }
    }

    /** Phát thẳng một clip theo tên (do Chars2/Game gọi cho các khoảnh khắc đặc biệt). */
    fun cue(name: String, rate: Float = 1f, prio: Int = 2) { if (!dead) start(name, rate, prio) }

    fun dash(dx: Float, dz: Float, face: Float) {
        if (dead) return
        val c = cos(face); val s = sin(face); val lx = dx * c - dz * s; val lz = dx * s + dz * c
        val n = if (abs(lx) > abs(lz)) (if (lx < 0f) "dash_L" else "dash_R") else if (lz >= 0f) "dash_fwd" else "dash_back"
        start(n, 1.1f, 2)
    }

    fun dodge(dx: Float, dz: Float, face: Float) {
        if (dead) return
        val c = cos(face); val s = sin(face); val lx = dx * c - dz * s
        start(if (lx < 0f) "dodge_side_L" else "dodge_side_R", 1.7f, 2)
    }

    /** Trúng đòn: from = vị trí nguồn đòn (null: không rõ), heavy: đòn nặng. */
    fun hurt(fx: Float, fz: Float, hasFrom: Boolean, px: Float, pz: Float, face: Float, dmgFrac: Float) {
        if (dead) return
        var name: String
        if (!hasFrom) name = "hit_front_light"
        else {
            val dx = fx - px; val dz = fz - pz; val c = cos(face); val s = sin(face)
            val lx = dx * c - dz * s; val lz = dx * s + dz * c
            val a = atan2(lx, lz); lastHitA = a
            name = if (abs(a) < 1.0f) {
                if (dmgFrac > .22f) (if (rnd01() < .5f) "hit_front_heavy" else "hit_gut")
                else arrayOf("hit_front_light", "hit_head_L", "hit_head_R", "hit_gut")[rndi(4)]
            } else if (abs(a) > 2.2f) "hit_back"
            else if (lx > 0f) "hit_side_L" else "hit_side_R"
        }
        start(name, if (dmgFrac > .22f) 1.0f else 1.25f, 3, .03f, .2f)
    }

    fun die() {
        if (dead) return
        val front = abs(lastHitA) < 1.4f
        val c = if (front) arrayOf("death_back", "death_collapse", "death_spin", "death_kneel_fall", "death_shock", "death_flung")[rndi(6)] else "death_front"
        start(c, 1f, 9, .05f, .2f, hold = true, force = true); dead = true
    }

    fun emote(name: String) { if (!dead && !actOn) start(name, 1f, 0, .25f, .3f) }

    // ---- showcase ----
    fun showSet(on: Boolean) { showOn = on; if (on) { showT = 0f; playShow() } else { baseName = "" } }
    fun showMove(d: Int) { showOn = true; showIdx = ((showIdx + d) % lib.clips.size + lib.clips.size) % lib.clips.size; playShow() }
    fun showCat(d: Int) {
        showOn = true
        val cs = lib.cats; val cur = cs.indexOf(lib.clips[showIdx].cat); val nx = ((cur + d) % cs.size + cs.size) % cs.size
        showIdx = lib.clips.indexOfFirst { it.cat == cs[nx] }; playShow()
    }
    fun showToggleAuto() { showAuto = !showAuto; if (showOn) showT = 0f }
    private fun playShow() { val c = lib.clips[showIdx]; base.play(c, 1f, 0f, .25f); baseName = c.name; showT = 0f; showWait = 0f }

    // =========================== nội bộ ===========================
    private fun combat() { combatT = 3.5f; idleT = 0f }

    private fun fit(name: String, target: Float, lo: Float, hi: Float, prio: Int) {
        val c = lib[name] ?: return
        start(name, (c.dur / max(.12f, target)).coerceIn(lo, hi), prio)
    }

    private fun legBased(n: String) = n.startsWith("kick") || n.startsWith("knee") || n.startsWith("stomp") || n.startsWith("sweep") ||
        n.contains("flip") || n.contains("dive") || n.contains("meteor") || n.contains("drop_kick") || n.contains("spin") ||
        n.startsWith("combo_kick") || n.startsWith("combo_front_knee")

    private fun start(name: String, rate: Float, prio: Int, fin: Float = .06f, fout: Float = .14f, hold: Boolean = false, force: Boolean = false): Boolean {
        val c = lib[name] ?: return false
        val live = actOn && actW > 0f
        if (!force && live && !actFading && prio < actPrio && act.t < (act.clip?.dur ?: 0f) * .55f) return false
        if (live) act.play(c, rate, 0f, max(fin, .04f)) else { actW = 0f; act.play(c, rate, 0f, 0f) }
        actOn = true; actFading = false; actPrio = prio; actIn = fin; actOut = fout; actHold = hold; actName = name
        actFull = when (c.cat) { "acro", "dash", "dodge", "hurt", "fall", "death", "emote", "nen", "defense", "idle", "fidget" -> true; else -> legBased(name) }
        return true
    }

    private fun kinematics(dt: Float) {
        val p = h.root.pos; val ry = h.root.rot.y
        if (dt > 1e-4f) {
            if (havePrev) {
                var vx = (p.x - lpx) / dt; var vz = (p.z - lpz) / dt
                if (hypot(vx, vz) > 22f) { vx = 0f; vz = 0f }       // dịch chuyển tức thời / lướt: bỏ qua
                val k = 1f - exp(-dt * 12f)
                svx += (vx - svx) * k; svz += (vz - svz) * k
                var dy = ry - lry; while (dy > PIF) dy -= TAU; while (dy < -PIF) dy += TAU
                yawRate += (dy / dt - yawRate) * (1f - exp(-dt * 10f))
            }
            lpx = p.x; lpz = p.z; lry = ry; havePrev = true
            spd = hypot(svx, svz)
            val c = cos(ry); val s = sin(ry)
            plvx = lvx; plvz = lvz
            lvx = svx * c - svz * s; lvz = svx * s + svz * c
        }
    }

    private val tierTh = floatArrayOf(1.4f, 3.2f, 5.0f)
    private val defStride = floatArrayOf(.64f, 1.7f, 2.25f, 2.87f)

    private fun pickBase(dt: Float) {
        if (showOn) return
        val sp = spd
        if (moving && sp < .35f) moving = false else if (!moving && sp > .7f) moving = true
        val name: String; var rate = 1f; var nf = 0
        if (!moving) {
            if (h.gsOn) name = "idle_charged"
            else if (h.stealthOn) name = "idle_stalk_L"
            else if (combatT > 0f) name = "idle_ready_" + (if (atkN % 2 == 0) "L" else "R")
            else name = idleVar
        } else {
            val ang = atan2(lvx, lvz); val aa = abs(ang)
            nf = when (fam) {
                1 -> if (aa > 1.15f) (if (aa > 2.3f) 3 else 2) else 1
                2 -> if (aa < .9f) 1 else if (aa > 2.3f) 3 else 2
                3 -> if (aa < 2.1f) (if (aa < .9f) 1 else 2) else 3
                else -> if (aa < 1.0f) 1 else if (aa > 2.2f) 3 else 2
            }
            if (tier < 3 && sp > tierTh[tier] * 1.08f) tier++
            else if (tier > 0 && sp < tierTh[tier - 1] * .92f) tier--
            val side = if (lvx < 0f) "L" else "R"
            name = when (nf) {
                1 -> when {
                    h.stealthOn -> if (tier == 0) "walk_sneak" else "run_sneak"
                    h.gsOn && tier >= 1 -> "run_godspeed"
                    tier == 0 -> if (combatT > 0f) "walk_combat" else "walk"
                    tier == 1 -> "jog"
                    tier == 2 -> "run"
                    else -> "sprint"
                }
                2 -> if (tier == 0) "strafe_walk_$side" else if (tier < 3) "strafe_run_$side" else "strafe_sprint_$side"
                else -> if (tier == 0) (if (combatT > 0f) "back_walk_guard" else "back_walk") else "back_run"
            }
            val c = lib[name]
            if (c != null) {
                val st = if (c.stride > .05f) c.stride else defStride[tier.coerceIn(0, 3)]
                rate = (sp / (st * h.s * scale)).coerceIn(.55f, if (tier == 3) 2.0f else 2.3f)
            }
        }
        val c = lib[name] ?: return
        if (name != baseName) {
            val carry = moving && fam != 0 && nf != 0 && c.loop
            val st = if (carry) base.phase * c.dur else 0f
            base.play(c, rate, st, if (moving) .2f else .3f)
            baseName = name
        } else base.rate = rate
        fam = if (moving) nf else 0
    }

    private fun fidgets(dt: Float) {
        if (showOn || dead) return
        if (!moving && !actOn && combatT <= 0f && !h.gsOn && !h.stealthOn) {
            idleT += dt; idleVarT += dt
            if (idleVarT > 12f) {
                idleVarT = 0f
                idleVar = arrayOf("idle_relaxed", "idle_relaxed_shift_L", "idle_relaxed_shift_R", "idle_hum", "idle_think", "idle_pockets", "idle_arms_crossed", "idle_bored", "idle_relaxed")[rndi(9)]
            }
            if (idleT > fidgetAt) {
                idleT = 0f; fidgetAt = rnd(5f, 10f)
                val f = arrayOf("fidget_neck_crack", "fidget_shrug", "fidget_stretch_arms", "fidget_yawn", "fidget_look_around", "fidget_scratch_head", "fidget_knuckles",
                    "fidget_bounce", "fidget_shake_arms", "fidget_sigh", "fidget_stretch_legs", "fidget_snap_fingers", "fidget_nod", "fidget_tie_shoe")[rndi(14)]
                start(f, 1f, 0, .3f, .35f)
            }
        } else if (moving || combatT > 0f) idleT = 0f
    }

    private fun showStep(dt: Float) {
        val c = lib.clips[showIdx]
        showT += dt
        if (base.clip == null || baseName != c.name) playShow()
        if (!c.loop && base.done) {
            showWait += dt
            if (showWait > .9f) { if (showAuto) { showIdx = (showIdx + 1) % lib.clips.size; playShow() } else playShow() }
        } else if (c.loop && showAuto && showT > max(3.2f, c.dur * 2f)) { showIdx = (showIdx + 1) % lib.clips.size; playShow() }
    }

    fun update(dt0: Float, time: Float, mv: Float) {
        val dt = min(dt0, .05f)
        kinematics(dt)
        if (combatT > 0f) combatT -= dt
        atkIdle += dt
        if (showOn) showStep(dt) else { pickBase(dt); fidgets(dt) }
        base.step(dt)

        // ----- lớp hành động -----
        if (actOn && actPrio == 0 && moving && !actFading) actFading = true   // fidget/ăn mừng nhường chỗ khi người chơi di chuyển
        if (actOn && !showOn) {
            act.step(dt)
            if (!actFading) {
                if (actW < 1f) actW = min(1f, actW + dt / max(.02f, actIn))
                if (act.done && !actHold) actFading = true
            }
            if (actFading) { actW -= dt / max(.04f, actOut); if (actW <= 0f) { actW = 0f; actOn = false; actFading = false } }
        } else if (actOn) { actOn = false; actW = 0f }

        // ----- hợp lớp -----
        val src = base.out
        if (actOn && actW > 0f) {
            val moveK = if (actFull) 0f else ((spd - .8f) / 1.7f).coerceIn(0f, 1f)
            val lw = 1f - moveK; val hw = 1f - .45f * moveK
            for (j in 0 until NB) mask[j] = if (j == 0) hw else if (j >= 13) lw else 1f
            mask[NB] = lw
            Blend.mix(src, act.out, actW, mask, pose)
        } else System.arraycopy(src, 0, pose, 0, FL)

        // ----- ghi xương -----
        m.resetQ()
        for (j in 0 until NB) { val p = j * 4; m.setQ(iB[j], pose[p], pose[p + 1], pose[p + 2], pose[p + 3]) }
        hair(dt, time)
        m.update()
        m.root.pos.set(pose[NB * 4] * scale, pose[NB * 4 + 1] * scale, pose[NB * 4 + 2] * scale)
    }

    // =========================== tóc: lò xo theo vận tốc + quán tính ===========================
    private fun hair(dt: Float, time: Float) {
        if (dt > 1e-4f) {
            val ax = ((lvx - plvx) / dt).coerceIn(-150f, 150f); val az = ((lvz - plvz) / dt).coerceIn(-150f, 150f)
            val steps = max(1, ceil(dt / .012f).toInt()); val h2 = dt / steps
            val w = if (h.gsOn) 13f else 15f; val k = w * w; val c = 2f * .32f * w
            for (s in 0 until steps) for (i in 0 until 8) {
                val g = hGain[i]
                val tx = (g * lvz * .04f).coerceIn(-.7f, .7f) + sin(time * 1.9f + i * 1.3f) * .03f * g
                val tz = (-g * lvx * .04f - g * yawRate * .02f).coerceIn(-.7f, .7f) + sin(time * 1.5f + i * .9f) * .03f * g
                // tóc ì ạch phía sau đầu: tăng tốc tới trước -> tóc hất ra sau; tăng tốc sang bên -> hất ngược lại
                hvx[i] += (-(hx[i] - tx) * k - c * hvx[i] + az * .5f * g) * h2
                hvz[i] += (-(hz[i] - tz) * k - c * hvz[i] - ax * .5f * g) * h2
                hx[i] += hvx[i] * h2; hz[i] += hvz[i] * h2
                hx[i] = hx[i].coerceIn(-1f, 1f); hz[i] = hz[i].coerceIn(-1f, 1f)
            }
        }
        for (i in 0 until 8) {
            val b = iH[i]; if (b < 0) continue
            val a = hx[i]; val z = hz[i]
            val sx = sin(a * .5f); val cx = cos(a * .5f); val sz = sin(z * .5f); val cz = cos(z * .5f)
            m.setQ(b, sx * cz, -sx * sz, cx * sz, cx * cz)
        }
    }

    companion object {
        /** Gắn bộ animation vào model skin của human [h]; trả null (giữ nguyên bộ khớp cũ) nếu thiếu asset. */
        fun attach(h: Human, m: SkinModel, scale: Float): KilluaAnimator? {
            return try {
                val lib = KAnim.get() ?: return null
                val a = KilluaAnimator(h, m, lib, scale)
                h.anim = a
                h.sync = { dt, time, mv -> a.update(dt, time, mv) }
                a.update(0f, 0f, 0f)
                a
            } catch (e: Throwable) { h.anim = null; null }
        }
    }
}
