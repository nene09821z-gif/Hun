package com.nenarena.game.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.atan2

/** Giữ Context ứng dụng để đọc model/texture trong thư mục assets. Gán ở MainActivity.onCreate. */
object Assets { @JvmField var ctx: Context? = null }

/** Texture màu. Bitmap được giữ lại để nạp lại lên GPU khi mất context GL. id = 0 nghĩa là chưa nạp. */
class Tex(@JvmField val bmp: Bitmap) { @JvmField var id = 0; @JvmField var gen = 0 }

class MeshData(val geo: Geometry, val tex: Tex, val cut: Float, val ds: Boolean, val ol: Boolean)

/**
 * Dữ liệu một model skin (chia sẻ giữa các bản sao): xương (cha, vị trí cục bộ, vị trí nghỉ) + các mesh.
 * Định dạng do script export tạo ra: <name>.json (metadata) + <name>.bin (mảng nhị phân little-endian) + PNG.
 * Mọi xương ở tư thế nghỉ có quay = đơn vị, nên chỉ cần lưu vị trí. Xương cha luôn đứng trước xương con.
 * Chiều cao model đã chuẩn hoá = 1, chân chạm y = 0, nhìn về +Z.
 */
class ModelData(val name: String) {
    val boneName: Array<String>
    val parent: IntArray
    val lt: FloatArray      // vị trí cục bộ của từng xương (3 float/xương)
    val rest: FloatArray    // vị trí nghỉ trong không gian model (3 float/xương)
    val index = HashMap<String, Int>()
    val meshes = ArrayList<MeshData>()

    init {
        val ctx = Assets.ctx ?: throw IllegalStateException("Assets.ctx chưa được khởi tạo")
        val js = JSONObject(String(ctx.assets.open("$name.json").use { it.readBytes() }, Charsets.UTF_8))
        val bb = ByteBuffer.wrap(ctx.assets.open("$name.bin").use { it.readBytes() }).order(ByteOrder.LITTLE_ENDIAN)

        val bj = js.getJSONArray("bones"); val nb = bj.length()
        boneName = Array(nb) { "" }; parent = IntArray(nb); lt = FloatArray(nb * 3); rest = FloatArray(nb * 3)
        for (i in 0 until nb) {
            val b = bj.getJSONObject(i)
            boneName[i] = b.getString("n"); parent[i] = b.getInt("p"); index[boneName[i]] = i
            val t = b.getJSONArray("t")
            for (k in 0 until 3) lt[i * 3 + k] = t.getDouble(k).toFloat()
            val p = parent[i]
            for (k in 0 until 3) rest[i * 3 + k] = lt[i * 3 + k] + (if (p >= 0) rest[p * 3 + k] else 0f)
        }

        fun floats(off: Int, n: Int): FloatArray { val a = FloatArray(n); bb.position(off); bb.asFloatBuffer().get(a); return a }

        val mj = js.getJSONArray("meshes")
        for (mi in 0 until mj.length()) {
            val e = mj.getJSONObject(mi)
            val v = e.getInt("v"); val ic = e.getInt("i")
            val pos = floats(e.getInt("pos"), v * 3); val nor = floats(e.getInt("nor"), v * 3)
            val uv = floats(e.getInt("uv"), v * 2); val jw = floats(e.getInt("jw"), v * 4)
            val ji = ByteArray(v * 4); bb.position(e.getInt("ji")); bb.get(ji)
            val idx = ShortArray(ic); bb.position(e.getInt("idx")); bb.asShortBuffer().get(idx)

            val verts = FloatArray(v * 6)
            val ext = FloatArray(v * 10)
            for (i in 0 until v) {
                verts[i * 6] = pos[i * 3]; verts[i * 6 + 1] = pos[i * 3 + 1]; verts[i * 6 + 2] = pos[i * 3 + 2]
                verts[i * 6 + 3] = nor[i * 3]; verts[i * 6 + 4] = nor[i * 3 + 1]; verts[i * 6 + 5] = nor[i * 3 + 2]
                ext[i * 10] = uv[i * 2]; ext[i * 10 + 1] = uv[i * 2 + 1]
                for (k in 0 until 4) {
                    ext[i * 10 + 2 + k] = (ji[i * 4 + k].toInt() and 255).toFloat()
                    ext[i * 10 + 6 + k] = jw[i * 4 + k]
                }
            }
            val g = Geometry(verts, idx); g.ext = ext
            meshes.add(MeshData(g, ModelCache.tex(e.getString("tex")), e.getDouble("cut").toFloat(), e.getBoolean("ds"), e.getBoolean("ol")))
        }
    }
}

object ModelCache {
    private val models = HashMap<String, ModelData>()
    private val texs = HashMap<String, Tex>()

    @Synchronized fun get(name: String): ModelData {
        var m = models[name]
        if (m == null) { m = ModelData(name); models[name] = m }
        return m
    }

    @Synchronized fun tex(file: String): Tex {
        var t = texs[file]
        if (t == null) {
            val ctx = Assets.ctx ?: throw IllegalStateException("Assets.ctx chưa được khởi tạo")
            val bmp = ctx.assets.open(file).use { BitmapFactory.decodeStream(it) } ?: throw IllegalStateException("Không đọc được texture $file")
            t = Tex(bmp); texs[file] = t
        }
        return t
    }

    /** Context GL mới: mọi buffer/texture cũ vô hiệu (kể cả model chưa nằm trong cảnh). */
    @Synchronized fun invalidateGpu() {
        for (t in texs.values) t.id = 0
        for (m in models.values) for (md in m.meshes) { md.geo.vao = 0; md.geo.vbo = 0; md.geo.ibo = 0; md.geo.vbo2 = 0 }
    }
}

/** Một bản sao model: có nút gốc, vật liệu riêng (độ mờ/phát sáng độc lập) và bộ quay xương riêng. */
class SkinModel(val d: ModelData) {
    val root = Node()
    val n = d.parent.size
    val mats = ArrayList<Material>()
    val outNodes = ArrayList<Node>()
    private val q = FloatArray(4 * n)
    private val skinM = FloatArray(32 * 16)
    private val rw = FloatArray(9 * n)
    private val pw = FloatArray(3 * n)

    init {
        if (n > 32) throw IllegalStateException("Model có $n xương, shader chỉ hỗ trợ tối đa 32")
        for (md in d.meshes) {
            val m = Material(MatType.TOON, 0xffffff)
            m.map = md.tex; m.cut = md.cut; m.doubleSided = md.ds
            mats.add(m)
            val nd = Node(); nd.geo = md.geo; nd.mat = m; nd.outline = md.ol; nd.skin = skinM; nd.skinN = n
            root.add(nd)
            if (md.ol) outNodes.add(nd)
        }
        resetQ(); update()
    }

    fun bi(name: String): Int = d.index[name] ?: -1

    fun resetQ() { for (i in 0 until n) { q[i * 4] = 0f; q[i * 4 + 1] = 0f; q[i * 4 + 2] = 0f; q[i * 4 + 3] = 1f } }

    fun setQ(i: Int, x: Float, y: Float, z: Float, w: Float) {
        if (i < 0) return
        q[i * 4] = x; q[i * 4 + 1] = y; q[i * 4 + 2] = z; q[i * 4 + 3] = w
    }

    /** Tính ma trận skin = (thế giới xương) * (nghịch đảo thế nghỉ) cho mọi xương. Cha luôn tính trước con. */
    fun update() {
        for (i in 0 until n) {
            val x = q[i * 4]; val y = q[i * 4 + 1]; val z = q[i * 4 + 2]; val w = q[i * 4 + 3]
            val r00 = 1f - 2f * (y * y + z * z); val r01 = 2f * (x * y - z * w); val r02 = 2f * (x * z + y * w)
            val r10 = 2f * (x * y + z * w); val r11 = 1f - 2f * (x * x + z * z); val r12 = 2f * (y * z - x * w)
            val r20 = 2f * (x * z - y * w); val r21 = 2f * (y * z + x * w); val r22 = 1f - 2f * (x * x + y * y)
            val tx = d.lt[i * 3]; val ty = d.lt[i * 3 + 1]; val tz = d.lt[i * 3 + 2]
            val o = i * 9; val p = d.parent[i]
            if (p < 0) {
                rw[o] = r00; rw[o + 1] = r01; rw[o + 2] = r02; rw[o + 3] = r10; rw[o + 4] = r11; rw[o + 5] = r12; rw[o + 6] = r20; rw[o + 7] = r21; rw[o + 8] = r22
                pw[i * 3] = tx; pw[i * 3 + 1] = ty; pw[i * 3 + 2] = tz
            } else {
                val a = p * 9
                val a0 = rw[a]; val a1 = rw[a + 1]; val a2 = rw[a + 2]; val a3 = rw[a + 3]; val a4 = rw[a + 4]; val a5 = rw[a + 5]; val a6 = rw[a + 6]; val a7 = rw[a + 7]; val a8 = rw[a + 8]
                rw[o] = a0 * r00 + a1 * r10 + a2 * r20; rw[o + 1] = a0 * r01 + a1 * r11 + a2 * r21; rw[o + 2] = a0 * r02 + a1 * r12 + a2 * r22
                rw[o + 3] = a3 * r00 + a4 * r10 + a5 * r20; rw[o + 4] = a3 * r01 + a4 * r11 + a5 * r21; rw[o + 5] = a3 * r02 + a4 * r12 + a5 * r22
                rw[o + 6] = a6 * r00 + a7 * r10 + a8 * r20; rw[o + 7] = a6 * r01 + a7 * r11 + a8 * r21; rw[o + 8] = a6 * r02 + a7 * r12 + a8 * r22
                pw[i * 3] = pw[p * 3] + a0 * tx + a1 * ty + a2 * tz
                pw[i * 3 + 1] = pw[p * 3 + 1] + a3 * tx + a4 * ty + a5 * tz
                pw[i * 3 + 2] = pw[p * 3 + 2] + a6 * tx + a7 * ty + a8 * tz
            }
            val rx = d.rest[i * 3]; val ry = d.rest[i * 3 + 1]; val rz = d.rest[i * 3 + 2]
            val ex = pw[i * 3] - (rw[o] * rx + rw[o + 1] * ry + rw[o + 2] * rz)
            val ey = pw[i * 3 + 1] - (rw[o + 3] * rx + rw[o + 4] * ry + rw[o + 5] * rz)
            val ez = pw[i * 3 + 2] - (rw[o + 6] * rx + rw[o + 7] * ry + rw[o + 8] * rz)
            val s = i * 16  // cột-chính
            skinM[s] = rw[o]; skinM[s + 1] = rw[o + 3]; skinM[s + 2] = rw[o + 6]; skinM[s + 3] = 0f
            skinM[s + 4] = rw[o + 1]; skinM[s + 5] = rw[o + 4]; skinM[s + 6] = rw[o + 7]; skinM[s + 7] = 0f
            skinM[s + 8] = rw[o + 2]; skinM[s + 9] = rw[o + 5]; skinM[s + 10] = rw[o + 8]; skinM[s + 11] = 0f
            skinM[s + 12] = ex; skinM[s + 13] = ey; skinM[s + 14] = ez; skinM[s + 15] = 1f
        }
    }

    /**
     * Chép thế giới (trong không gian model đã chuẩn hoá) của xương [i] sang [node]: vị trí khớp + góc Euler XYZ.
     * Gọi SAU update(). Dùng để gắn vật phụ (gai tóc Godspeed...) bám đúng xương, kể cả khi thân nghiêng/đầu cúi.
     */
    fun boneWorld(i: Int, node: Node) {
        if (i < 0 || i >= n) return
        val o = i * 9
        node.pos.set(pw[i * 3], pw[i * 3 + 1], pw[i * 3 + 2])
        val m13 = clamp(rw[o + 2], -1f, 1f)
        node.rot.y = asin(m13)
        if (abs(m13) < .9999f) { node.rot.x = atan2(-rw[o + 5], rw[o + 8]); node.rot.z = atan2(-rw[o + 1], rw[o]) }
        else { node.rot.x = atan2(rw[o + 7], rw[o + 4]); node.rot.z = 0f }
    }
}
