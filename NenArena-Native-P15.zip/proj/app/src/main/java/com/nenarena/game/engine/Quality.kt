package com.nenarena.game.engine

import android.app.ActivityManager
import android.content.Context
import android.os.Build

/**
 * Mức đồ họa.
 * scale   : tỉ lệ độ phân giải render so với màn hình (pixel ít hơn = nhẹ GPU hơn nhiều)
 * maxLong : cạnh dài tối đa của khung render (px)
 * fps     : FPS mục tiêu (30 giúp máy yếu mượt đều, ít nóng)
 * outline : vẽ viền đen cho nhân vật (tốn gấp đôi lệnh vẽ)
 * detail  : hệ số số lượng vật thể / độ mịn lưới (0..1)
 * drawDist: khoảng cách xa nhất còn vẽ vật trang trí
 * barrier : vẽ kết giới trong suốt (tốn fill-rate)
 */
enum class Tier(
    val label: String, val scale: Float, val maxLong: Int, val fps: Int,
    val outline: Boolean, val detail: Float, val drawDist: Float, val barrier: Boolean
) {
    LOW("THẤP", 0.55f, 960, 30, false, 0.5f, 110f, false),
    MID("TRUNG", 0.8f, 1440, 60, true, 0.75f, 170f, true),
    HIGH("CAO", 1.0f, 2400, 60, true, 1f, 1e9f, true)
}

object Quality {
    @Volatile var tier: Tier = Tier.MID
    @Volatile var auto: Boolean = true

    /** Đọc lựa chọn đã lưu; chưa có thì tự nhận diện theo RAM / số nhân / đời Android. */
    fun load(ctx: Context) {
        val s = ctx.getSharedPreferences("nen", Context.MODE_PRIVATE).getInt("tier", -1)
        auto = s !in 0..2
        tier = if (auto) detect(ctx) else Tier.values()[s]
    }

    /** TỰ ĐỘNG -> THẤP -> TRUNG -> CAO -> TỰ ĐỘNG ... */
    fun cycle(ctx: Context) {
        val p = ctx.getSharedPreferences("nen", Context.MODE_PRIVATE)
        val s = p.getInt("tier", -1)
        p.edit().putInt("tier", if (s >= 2) -1 else s + 1).apply()
    }

    fun label(): String = (if (auto) "TỰ ĐỘNG · " else "") + tier.label

    private fun detect(ctx: Context): Tier {
        return try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            val gb = mi.totalMem / 1073741824.0
            val cores = Runtime.getRuntime().availableProcessors()
            when {
                am.isLowRamDevice || gb < 3.5 || Build.VERSION.SDK_INT < 28 -> Tier.LOW
                gb < 7.0 || cores < 8 -> Tier.MID
                else -> Tier.HIGH
            }
        } catch (e: Throwable) {
            Tier.MID
        }
    }
}
