package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)

// ======================= HISOKA =======================
fun buildHisoka(): Human {
    val h = buildHuman(HumanOpts(s = .9f, skin = 0xf4e4d8, top = 0x2c1b45, bottom = 0xf0e8f4, shoe = 0x15101c))
    val hair = h.mt(0xe94b74, 0x300010)
    val hair2 = h.mt(0x8a2a8c, 0x200030)
    // tóc: khối nền vuốt ra sau, trán cao phẳng
    h.mkk(Geometry.sphere(.215f, 14, 10, 0f, TAU, 0f, PIF * .52f), hair, h.head, 0f, .15f, -.03f, rx = -.35f)
    // lọn tóc dài vuốt ngược lên & ra sau (hàng: x,y,z,rx,rz,độ dài)
    val spikes = arrayOf(
        floatArrayOf(0f, .34f, -.02f, -.35f, 0f, .42f), floatArrayOf(.07f, .33f, -.02f, -.3f, -.28f, .4f), floatArrayOf(-.07f, .33f, -.02f, -.3f, .28f, .4f),
        floatArrayOf(.14f, .3f, -.03f, -.2f, -.6f, .36f), floatArrayOf(-.14f, .3f, -.03f, -.2f, .6f, .36f),
        floatArrayOf(.19f, .22f, -.04f, -.1f, -.95f, .3f), floatArrayOf(-.19f, .22f, -.04f, -.1f, .95f, .3f),
        floatArrayOf(0f, .3f, -.1f, -.95f, 0f, .38f), floatArrayOf(.09f, .28f, -.1f, -.9f, -.3f, .36f), floatArrayOf(-.09f, .28f, -.1f, -.9f, .3f, .36f),
        floatArrayOf(.16f, .2f, -.12f, -.8f, -.7f, .3f), floatArrayOf(-.16f, .2f, -.12f, -.8f, .7f, .3f))
    for ((i, sp) in spikes.withIndex())
        h.mkk(cone(.062f, sp[5], 6), if (i % 3 == 2) hair2 else hair, h.head, sp[0], sp[1], sp[2], rx = sp[3], rz = sp[4])
    // mắt hẹp xếch, tròng vàng, mi trên dày che nửa tròng
    val gold = basic(0xe0a834); val ink = basic(0x1b1020); val skinM = basic(0xf4e4d8)
    for (s in listOf(-1f, 1f)) {
        mk(sph(.03f, 8, 6), gold, h.head, s * .082f, .165f, .184f, sx = 1.2f, sy = .75f, sz = .3f, outline = false)
        mk(sph(.012f, 6, 5), ink, h.head, s * .082f, .163f, .19f, sy = 1.1f, sz = .3f, outline = false)
        mk(box(.1f, .02f, .02f), ink, h.head, s * .084f, .186f, .19f, rz = s * .22f, outline = false)      // mi trên dày
        mk(box(.085f, .006f, .012f), ink, h.head, s * .084f, .145f, .19f, rz = s * .22f, outline = false)  // mi dưới mảnh
        mk(box(.12f, .008f, .014f), ink, h.head, s * .088f, .224f, .186f, rz = s * .28f, outline = false)  // chân mày sắc
    }
    mk(box(.012f, .06f, .02f), basic(0xc8aebb), h.head, 0f, .13f, .2f, outline = false)       // sống mũi
    mk(box(.04f, .008f, .018f), basic(0xb89aaa), h.head, 0f, .098f, .2f, outline = false)     // chóp mũi
    // sao xanh trên má phải nhân vật (bên trái ảnh), giọt lệ vàng-lục dưới mắt trái
    val star = Geometry.octahedron(.034f)
    mk(star, basic(0x2fa0e8), h.head, -.115f, .1f, .186f, rz = .3f, sy = 1.1f, sz = .3f, outline = false)
    mk(star, basic(0x2fa0e8), h.head, -.115f, .1f, .186f, rz = .3f + PIF / 4, sx = .8f, sy = .8f, sz = .3f, outline = false)
    mk(sph(.017f, 8, 6), basic(0xd6da3e), h.head, .108f, .105f, .187f, sy = 1.5f, sz = .4f, outline = false)
    mk(cone(.011f, .03f, 6), basic(0xd6da3e), h.head, .108f, .135f, .187f, rx = PIF / 2 * 0f, sz = .4f, outline = false)
    // nụ cười nhếch: một bên cao hơn
    mk(box(.07f, .01f, .012f), basic(0x7a1030), h.head, .005f, .052f, .192f, rz = .12f, outline = false)
    mk(box(.02f, .008f, .012f), basic(0x7a1030), h.head, -.045f, .062f, .19f, rz = .7f, outline = false)
    h.mkk(Geometry.torus(.14f, .035f, 6, 14), h.mt(0xff7fb8), h.torso, 0f, .66f, 0f, rx = PIF / 2)
    // biểu tượng trái tim trên ngực + lá bài trên tay
    mk(Geometry.heart(.16f), basic(0xff3fa0), h.torso, 0f, .22f, .262f, outline = false)
    mk(Geometry.heart(.1f), basic(0x1b1020), h.torso, .11f, .46f, .262f, outline = false)
    mk(box(.16f, .24f, .01f), basic(0xfffaf0), h.elR, 0f, -.47f, .06f, rx = 1f, outline = false)
    mk(Geometry.heart(.07f), basic(0xd01040), h.elR, 0f, -.47f, .07f, rx = 1f, outline = false)
    addAura(h, 0xff3fa0, 0xffb0dd)
    return h
}

/** Lá bài Nen: tấm trắng + biểu tượng ♥ ♦ ♠ ♣ (thay texture thẻ bài bản HTML). */
fun Game.makeCard(kind: Int): Node {
    val root = Node(); val w = Material(MatType.BASIC, 0xfffaf0, 0, 1f, doubleSided = true)
    val back = Node(); back.geo = Geometry.plane(.55f, .8f).rotatedX(-PIF / 2); back.mat = w; root.add(back)
    val edge = Node(); edge.geo = Geometry.plane(.62f, .87f).rotatedX(-PIF / 2); edge.mat = Material(MatType.BASIC, 0xff3fa0, 0, 1f, doubleSided = true); edge.pos.y = -.004f; root.add(edge)
    val red = kind == 0 || kind == 1
    val sym = Material(MatType.BASIC, if (red) 0xd01040 else 0x181018, 0, 1f, doubleSided = true)
    val g = when (kind) { 0 -> Geometry.heart(.36f); 1 -> Geometry.octahedron(.18f); 2 -> Geometry.heart(.36f); else -> Geometry.circle(.1f, 10) }
    for (side in intArrayOf(-1, 1)) {
        val n = Node(); n.geo = g; n.mat = sym; n.rot.x = -PIF / 2 * side; n.pos.y = .006f * side
        if (kind == 1) { n.scl.set(.7f, 1.2f, .7f); n.rot.x = if (side > 0) 0f else PIF; n.rot.x = -PIF / 2 * side }
        if (kind == 2) n.rot.z = PIF
        root.add(n)
    }
    return root
}

/** Phiên bản sao chép "Hisoka giả" dán lên không trung (thay texJoker): tấm bài hồng + mặt hề. */
fun Game.makeJoker(): Node {
    val root = Node(); fun dm(c: Int) = Material(MatType.BASIC, c, 0, 1f, doubleSided = true)
    fun layer(g: Geometry, c: Int, x: Float, y: Float, z: Float, sx: Float = 1f, sy: Float = 1f, rz: Float = 0f) {
        val n = Node(); n.geo = g; n.mat = dm(c); n.pos.set(x, y, z); n.scl.set(sx, sy, 1f); n.rot.z = rz; root.add(n)
    }
    layer(Geometry.plane(2.6f, 3.8f), 0xd6246e, 0f, 0f, 0f)
    layer(Geometry.plane(2.4f, 3.6f), 0xfff7ee, 0f, 0f, .01f)
    layer(Geometry.circle(.75f, 24), 0xf6e6dc, 0f, .2f, .02f, 1f, 1.2f)
    for (i in 0..4) layer(Geometry.circle(.2f, 3), 0xe94b74, (i - 2) * .32f, 1.25f - abs(i - 2) * .1f, .015f, 1f, 2f, (i - 2) * -.22f)
    layer(Geometry.circle(.13f, 10), 0x1b1020, -.28f, .45f, .03f, 1f, .8f); layer(Geometry.circle(.13f, 10), 0x1b1020, .28f, .45f, .03f, 1f, .8f)
    layer(Geometry.heart(.28f), 0xd6246e, .0f, -.2f, .03f)
    layer(Geometry.circle(.07f, 8), 0x7a2cff, -.45f, .2f, .03f); layer(Geometry.heart(.18f), 0xd6246e, .5f, .2f, .03f)
    layer(Geometry.plane(.6f, .08f), 0x7a1030, 0f, -.38f, .03f)
    layer(Geometry.heart(.5f), 0xd6246e, 0f, -1.2f, .02f); layer(Geometry.octahedron(.3f), 0x2c1b45, 0f, -1.2f, .03f)
    return root
}

private fun Game.hisokaS1(): Boolean {
    val t = nearest(P.pos, 19f) ?: return false
    P.cast = .5f; act("cast", .5f); SFX.skill(); val d = aim(); val far = dxz(P.pos, t.pos) > 8f
    val tgt = { Vec3(t.pos.x, 1.2f + t.hover, t.pos.z) }
    val m = addMat(0xff3fa0); val o = Node(); o.geo = fx.gBeam; o.mat = m
    fx.add(o, .7f, m) { k, n, _ ->
        val A = hand(1.4f); val B = tgt(); val ext = min(1f, k / .15f); val E = A.clone().lerpTo(B, ext); val len = A.distanceTo(E)
        n.pos.copy(A); n.lookDir(E.x - A.x, E.y - A.y, E.z - A.z)
        val w = .28f * min(1.4f, 5f / max(2f, len)) * (1 + sin(k * 70) * .2f) * (1 - max(0f, k - .6f) * 2)
        n.scl.set(w, w, max(.01f, len)); m.opacity = if (k > .6f) (1 - k) / .4f else 1f
        if (rnd01() < .7f) emit(A.x + (E.x - A.x) * rnd01(), A.y + (E.y - A.y) * rnd01(), A.z + (E.z - A.z) * rnd01(), 0f, .5f, 0f, .4f, .35f, .05f, 0xffb0dd)
    }
    later(.15f) {
        if (!t.dead) {
            fx.ring(t.pos.x, t.pos.z, 0xff3fa0, .5f, 2.5f, .35f)
            if (far) {
                val dir = Vec3(t.pos.x - P.pos.x, 0f, t.pos.z - P.pos.z); val L = max(1f, dir.length() - 1.8f); dir.normalize()
                P.lunge = Lunge(dir, L / .25f, .25f, end = {
                    if (!t.dead) { hurtE(t, 62f, Hit(knock = 2f, stun = 1f, big = true, hs = .05f, from = P.pos)); heartBurst(P.pos.x, 1.5f, P.pos.z + .5f, 0xff3fa0, 28, .35f)
                    radiusHit(t.pos, 4.5f) { e -> if (e !== t) hurtE(e, 28f, Hit(knock = 1.5f, stun = .5f, from = P.pos)) } }
                }); SFX.dash()
            } else {
                val to = Vec3(P.pos.x + d.x * 2.2f, 0f, P.pos.z + d.z * 2.2f); setPull(t, to, .3f)
                later(.32f) {
                    if (!t.dead) {
                        hurtE(t, 58f, Hit(knock = 2.2f, stun = 1.3f, big = true, hs = .05f, from = P.pos)); radiusHit(t.pos, 4.5f) { e -> if (e !== t) hurtE(e, 28f, Hit(knock = 1.5f, stun = .5f, from = P.pos)) }
                        heartBurst(t.pos.x, 1.6f, t.pos.z + .5f, 0xff3fa0, 28, .35f); fx.ring(t.pos.x, t.pos.z, 0xffb0dd, .5f, 4f, .4f)
                    }
                }
            }
        }
    }
    return true
}

private fun Game.hisokaS2(): Boolean {
    P.cast = .35f; act("throw", .4f); SFX.skill(); val d = fwd()
    val pos = Vec3(P.pos.x + d.x * 5, 0f, P.pos.z + d.z * 5); val c = hypot(pos.x, pos.z); if (c > ARENA - 2) pos.scale((ARENA - 2) / c)
    val o = makeJoker(); o.pos.set(pos.x, 2f, pos.z); scene.root.add(o)
    val dec = Decoy(pos, o, 4f); P.decoy?.let { scene.root.remove(it.node) }; P.decoy = dec; P.stealth = 3f; P.h.fade(.3f); P.speedBuf = 3f
    fx.ring(pos.x, pos.z, 0xff3fa0, .5f, 3f, .5f); burst(pos.x, 2f, pos.z, 0xffb0dd, 24, 6f, .6f, .7f); burst(P.pos.x, 1.2f, P.pos.z, 0xff3fa0, 18, 5f, .5f, .6f)
    later(4f) {
        if (P.decoy === dec) {
            scene.root.remove(o); P.decoy = null; SFX.boom()
            fx.ring(pos.x, pos.z, 0xff3fa0, .5f, 7f, .5f); fx.dome(pos.x, 1.5f, pos.z, 0xff3fa0, .5f, 7f, .4f); heartBurst(pos.x, 2f, pos.z, 0xff3fa0, 36, .4f); shake = .4f
            radiusHit(pos, 8.5f) { e -> hurtE(e, 90f, Hit(knock = 2.5f, stun = 1f, big = true, from = pos)) }
        }
    }
    return true
}

private fun Game.hisokaUlt(): Boolean {
    val list = liveEn(20f, 10); if (list.isEmpty()) return false
    P.cast = 1.5f; P.inv = 1.6f; act("cast", 1.5f); SFX.ult(); slowmo(.45f, .6f); flash(0xff3fa0, .35f, 400)
    val d = fwd(); val ctr = Vec3(P.pos.x + d.x * 4.5f, 0f, P.pos.z + d.z * 4.5f); val cc = hypot(ctr.x, ctr.z); if (cc > ARENA - 3) ctr.scale((ARENA - 3) / cc)
    for (e in list) {
        fx.beam({ hand(1.4f) }, { Vec3(e.pos.x, 1.2f + e.hover, e.pos.z) }, 0xff3fa0, 1f, .3f); e.stun = 3.5f
        later(.2f) { if (!e.dead) setPull(e, Vec3(ctr.x + rnd(-1.4f, 1.4f), 0f, ctr.z + rnd(-1.4f, 1.4f)), .6f) }
    }
    later(.95f) {
        SFX.bigBoom(); shake = 1f; flash(0xffffff, .7f, 500)
        fx.ring(ctr.x, ctr.z, 0xff3fa0, 1f, 16f, .8f); fx.ring(ctr.x, ctr.z, 0xffb0dd, 1f, 10f, .6f); fx.pillar(ctr.x, ctr.z, 0xff3fa0, 3f, 30f, .8f); fx.dome(ctr.x, 1f, ctr.z, 0xff3fa0, 1f, 13f, .6f)
        heartBurst(ctr.x, 3f, ctr.z, 0xff3fa0, 70, .6f); heartBurst(ctr.x, 3f, ctr.z, 0xffb0dd, 50, .38f)
        radiusHit(ctr, 11f) { e -> hurtE(e, 150f, Hit(knock = 3f, big = true, from = ctr, hs = .1f, gain = 0f)) }
        P.dmgBuff = 1.25f; P.dmgBuffT = 8f; P.speedBuf = 3f   // Cuồng Si: hưng phấn sau khi giật cả bầy
    }
    return true
}

private fun Game.hisoka() = CharCfg(
    "hisoka", "HISOKA MOROW", "♠", "Biến Hoá (Transmutation) · Hạng A", 0xff3fa0, 0xffb0dd, 140f, 8.3f, 1.2f, 1.4f, .93f, .1f,
    "Ảo thuật gia điên cuồng, mê chiến đấu với kẻ mạnh. Nen của hắn mang tính chất cao su và keo dính.",
    "Nội tại: Cuồng chiến, nạp Nen nhanh hơn 40%, giáp dày hơn, 10% chí mạng.", intArrayOf(4, 5, 3, 5),
    listOf(
        Skill("Thẻ Bài (Shu)", "🃏", "BÀI", 0f, "Phóng thẻ bài bọc Nen, nhanh và đau hơn. Mỗi đòn thứ 3 phóng quạt 5 lá."),
        Skill("Elastic Love: Bungee Gum", "💗", "GUM", 4f, "Gắn keo vào địch: địch xa thì bay tới húc, địch gần thì bị kéo lại rồi bật mạnh, choáng lâu hơn. Sát thương lan sang kẻ địch xung quanh."),
        Skill("Flimsy Lies: Texture Surprise", "🎴", "ẢO ẢNH", 8f, "Dán tấm ảnh Hisoka giả lên không trung dụ địch, tàng hình và tăng tốc lâu hơn rồi nổ bất ngờ, vùng nổ rộng hơn."),
        Skill("Bungee Gum: Cuồng Si", "♥", "ULT", 0f, "Dán keo lên mọi kẻ địch, giật cả bầy vào một điểm rồi nổ trái tim khổng lồ, choáng lâu. Sau đó +25% sát thương và tăng tốc 8 giây.")
    ),
    sigWrap("hisoka", 0xff3fa0, ::buildHisoka),
    atk = {
        val d = aim(); act("throw", .26f); P.atkCd = .26f; SFX.swing(); val n = if (P.combo % 3 == 2) 5 else 1
        for (i in 0 until n) shoot(makeCard(rndi(4)), hand(1.5f, .8f), rotY(d, (i - (n - 1) / 2f) * .22f), 34f, 12f, .75f, .7f, 'p', 0, 0xff3fa0, 3f, null, 25f, .6f)
        P.combo++
    },
    s1 = { hisokaS1() }, s2 = { hisokaS2() }, ult = { hisokaUlt() }
)

// ======================= ILLUMI =======================
fun buildIllumi(): Human {
    val h = buildHuman(HumanOpts(s = .9f, skin = 0xeee0da, top = 0x15131f, bottom = 0x15131f, shoe = 0x0a0810))
    val hair = h.mt(0x0b0910)
    h.mkk(Geometry.sphere(.22f, 14, 10, 0f, TAU, 0f, PIF * .62f), hair, h.head, 0f, .15f, -.015f, rx = -.15f)
    h.mkk(cyl(.2f, .1f, 1.75f, 10), hair, h.head, 0f, -.72f, -.13f)
    for (s in listOf(-1f, 1f)) { h.mkk(box(.07f, .8f, .08f), hair, h.head, s * .18f, -.15f, .1f, rz = s * .05f); h.mkk(box(.17f, .12f, .1f), hair, h.head, s * .09f, .3f, .15f, rz = s * -.25f) }
    for (s in listOf(-1f, 1f)) { mk(sph(.052f, 8, 8), basic(0x050308), h.head, s * .08f, .15f, .176f, sy = 1.3f, sz = .5f, outline = false); mk(sph(.012f, 6, 6), basic(0xffffff), h.head, s * .08f + .015f, .17f, .2f, outline = false) }
    h.mkk(cyl(.18f, .2f, .3f, 10), h.mt(0x0d0b14), h.torso, 0f, .7f, 0f)
    h.mkk(cyl(.3f, .46f, .95f, 14), h.mt(0x15131f), h.hips, 0f, -.4f, 0f)
    h.mkk(cyl(.285f, .285f, .09f, 12), h.mt(0x5b3ec8, 0x251060), h.torso, 0f, .02f, 0f)
    for (i in 0 until 3) mk(cyl(.008f, .008f, .38f, 4), basic(0xb89cff), h.elR, (i - 1) * .03f, -.55f, .05f, rx = .2f, outline = false)
    addAura(h, 0x6b4bff, 0xb89cff, 0x0c0618)
    return h
}

internal val needleGeo by lazy { Geometry.cylinder(.03f, .03f, 1.2f, 5).rotatedX(PIF / 2) }
internal val needleMat by lazy { basic(0xc8b0ff) }
internal fun mkNeedle(): Node { val n = Node(); n.geo = needleGeo; n.mat = needleMat; return n }

private fun Game.illumiS1(): Boolean {
    val t = nearest(P.pos, 22f) ?: return false
    P.cast = .4f; act("throw", .35f); SFX.skill(); val d = aim()
    val m = Node(); m.geo = needleGeo; m.mat = pm(0xffffff); m.scl.set(2.4f, 2.4f, 2f)
    shoot(m, hand(1.45f, .8f), d, 46f, 0f, .9f, .8f, 'p', 0, 0x8a6aff, 9f, { e ->
        puppetize(e, 9f, 130f); burst(e.pos.x, 1.5f, e.pos.z, 0x8a6aff, 18, 6f, .5f, .7f); fx.ring(e.pos.x, e.pos.z, 0x8a6aff, .4f, 3f, .4f)
    })
    return true
}

private fun Game.illumiS2(): Boolean {
    val t = nearest(P.pos, 22f) ?: return false
    P.cast = .5f; P.inv = .6f; SFX.dash(); val from = P.pos.clone(); burst(from.x, 1f, from.z, 0x6b4bff, 24, 5f, .5f, .7f)
    P.h.root.visible = false; P.stealth = 1.2f
    later(.22f) {
        if (t.dead) { P.h.root.visible = true } else {
            val dir = Vec3(t.pos.x - from.x, 0f, t.pos.z - from.z).normalize()
            P.pos.set(t.pos.x + dir.x * 1.9f, 0f, t.pos.z + dir.z * 1.9f); P.face = atan2(-dir.x, -dir.z); P.h.root.visible = true
            val a = Vec3(from.x, 1.2f, from.z); val b = Vec3(P.pos.x, 1.2f, P.pos.z)
            fx.beam({ a }, { b }, 0x6b4bff, .4f, .12f); burst(P.pos.x, 1f, P.pos.z, 0xb89cff, 20, 6f, .5f, .6f); act("slash", .3f)
            for (i in 0 until 4) later(i * .09f) {
                if (!t.dead) { hurtE(t, 34f, Hit(col = 0xffffff, knock = .6f, noCrit = true, big = true, from = P.pos)); fx.slash(t.pos.x, 1.4f, t.pos.z, P.face + i * 1.1f, 0xb89cff, 3.4f, .25f) }
            }
            P.critN = 4; toast("Zetsu: 4 đòn kế tiếp chí mạng", 1.5f)
        }
    }
    return true
}

private fun Game.illumiUlt(): Boolean {
    val list = EN.filter { !it.dead && it.team == 'e' && it.spawnT <= 0f && dxz(it.pos, P.pos) < 22f }; if (list.isEmpty()) return false
    P.cast = 2.2f; P.inv = 2.4f; act("raise", 2.2f); SFX.ult(); slowmo(.5f, .6f); flash(0x1a0840, .55f, 900)
    for (i in 0 until 70) {
        val a = rnd(0f, TAU); val r = rnd(0f, 17f); val x = P.pos.x + cos(a) * r; val z = P.pos.z + sin(a) * r
        later(rnd(.3f, 1.6f)) {
            val m = mkNeedle(); m.scl.set(1.6f, 1.6f, 2f); m.pos.set(x, 22f, z); m.lookDir(0f, -1f, 0f)
            fx.add(m, .3f, null) { k, o, _ -> o.pos.y = lerp(22f, 0f, k) }
            later(.3f) { burst(x, .2f, z, 0x8a6aff, 5, 4f, .4f, .5f) }
        }
    }
    for (e in list) later(rnd(.8f, 1.5f)) {
        if (!e.dead && e.team == 'e') {
            puppetize(e, 8f, 220f); fx.ring(e.pos.x, e.pos.z, 0x8a6aff, .4f, 3f, .4f); burst(e.pos.x, 1.5f, e.pos.z, 0xb89cff, 14, 5f, .5f, .6f)
            hurtE(e, 60f, Hit(col = 0xb89cff, noCrit = true, gain = 0f))
        }
    }
    return true
}

private fun Game.illumi() = CharCfg(
    "illumi", "ILLUMI ZOLDYCK", "✦", "Thao Túng (Manipulation) · Hạng A", 0x6b4bff, 0xb89cff, 135f, 8.1f, 1.18f, 1.15f, .93f, .22f,
    "Sát thủ hàng đầu nhà Zoldyck. Lạnh lùng, vô cảm, dùng kim Nen để điều khiển người khác như con rối.",
    "Nội tại: 22% cơ hội chí mạng (×1.6 sát thương), giáp dày hơn.", intArrayOf(4, 4, 3, 4),
    listOf(
        Skill("Kim Nen", "🗡️", "KIM", 0f, "Phóng liên tục ba cây kim Nen xuyên hai mục tiêu, nhanh và đau hơn."),
        Skill("Needle People (Hari Ningen)", "🧵", "RỐI", 6f, "Cắm kim vào địch: biến thành con rối chiến đấu cho bạn 9 giây rồi phát nổ mạnh. Boss bị choáng + sát thương rất lớn."),
        Skill("Zetsu: Sát Thủ Thầm Lặng", "👁️", "ZETSU", 6f, "Tắt aura, biến mất rồi hiện sau lưng địch đâm 4 nhát nặng. 4 đòn kế tiếp chí mạng."),
        Skill("Hari Ningen: Mưa Kim", "🌑", "ULT", 0f, "Mưa kim Nen dày đặc phủ cả đấu trường, mọi kẻ địch bị cắm kim thành con rối 8 giây rồi nổ liên hoàn.")
    ),
    sigWrap("illumi", 0x6b4bff, ::buildIllumi),
    atk = {
        val d = aim(); act("throw", .24f); P.atkCd = .17f; SFX.swing()
        for (i in 0 until 3) shoot(mkNeedle(), hand(1.45f, .8f), rotY(d, (i - 1f) * .13f + rnd(-.03f, .03f)), 44f, 10f, .6f, .55f, 'p', 2, 0xb89cff, 2.5f, null, 0f, .3f)
        P.combo++
    },
    s1 = { illumiS1() }, s2 = { illumiS2() }, ult = { illumiUlt() }
)

/** Danh sách nhân vật đã port; thứ tự theo bản HTML. */
fun Game.allChars(): List<CharCfg> = listOf(hisoka(), illumi()) + moreChars()
