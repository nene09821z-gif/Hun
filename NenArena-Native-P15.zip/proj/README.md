# NEN ARENA – Native (Kotlin + Jetpack Compose + OpenGL ES 3.0)

Bản viết lại **hoàn toàn native**: không WebView, không HTML, không three.js.
Engine 3D tự viết bằng Kotlin (OpenGL ES 3.0), giao diện/điều khiển bằng Jetpack Compose.

## Cấu trúc
- `engine/MathX.kt` – vector, ma trận 4x4, Euler XYZ (giống three.js)
- `engine/Geometry.kt` – box, sphere, cylinder, cone, torus, ring, capsule, octahedron...
- `engine/Scene.kt` – Node (scene graph), Material (toon / basic / lambert / sky), đèn, sương mù
- `engine/Renderer.kt` – shader toon 4 bậc + viền đen + sương mù exp2 + trời gradient + additive blending
- `game/Human.kt` – mô hình người, tư thế đi, các động tác (port từ buildHuman/poseHuman)
- `game/World.kt` – đấu trường, trụ tổ kiến, trứng, tinh thể
- `game/Game.kt` – vòng lặp, di chuyển, camera
- `game/Audio.kt` – nhạc nền (MediaPlayer) + hiệu ứng âm thanh (SoundPool); file nằm ở `assets/music`, `assets/sfx`
- `game/KilluaAnim.kt` – bộ phát animation xương của Killua: 312 clip (`assets/killua_anim.*`), cross-fade, tóc lò xo, thư viện xem clip ở màn chọn
- `MainActivity.kt` – Compose: cần analog trái, vuốt phải xoay camera

## Tiến độ port (xem PORT_STATUS.md)

## Công cụ
- `tools/killua_anim/` – bộ sinh 312 clip của Killua (Python + numpy): `python3 export.py` ghi lại `assets/killua_anim.json/.bin`. Danh sách clip: `docs/DANH_SACH_CHUYEN_DONG.md`.

## Ghi công
- Model Sukuna: "Sukuna" của Aliza tiktok (https://sketchfab.com/Aliza.tiktok), CC-BY-4.0. Đã được chuẩn hoá, tự gắn xương và thêm đôi tay phụ bằng `tools/export_sukuna.py`.
