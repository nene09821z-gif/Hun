#!/usr/bin/env python3
"""Chuyển 'Gon Freecss.glb' (trong gon-freecss.zip, không có xương) sang assets/gon.json + gon.bin + PNG.

Hình dáng và texture giữ nguyên; script chỉ tự gắn xương theo từng mảnh lưới và chỉnh góc cầm cần câu.
Model gốc đã cao 1 đơn vị, chân ở y = 0, nhìn về +Z, tư thế chữ T.
Dùng:  python3 tools/export_gon.py "<đường dẫn Gon Freecss.glb>" app/src/main/assets
Chỉ cần numpy.
"""
import hashlib
import json
import os
import struct
import sys

import numpy as np

CT = {5121: np.uint8, 5123: np.uint16, 5125: np.uint32, 5126: np.float32}
NC = {"SCALAR": 1, "VEC2": 2, "VEC3": 3}


def read_glb(path):
    b = open(path, "rb").read()
    if b[:4] != b"glTF":
        raise SystemExit("Không phải file .glb")
    n = struct.unpack("<I", b[12:16])[0]
    return json.loads(b[20:20 + n]), b[28 + n:]


def accessor(j, data, i):
    a = j["accessors"][i]
    v = j["bufferViews"][a["bufferView"]]
    dt, c = CT[a["componentType"]], NC[a["type"]]
    off = v.get("byteOffset", 0) + a.get("byteOffset", 0)
    step = v.get("byteStride", 0) or c * np.dtype(dt).itemsize
    return np.array([np.frombuffer(data, dt, c, off + k * step) for k in range(a["count"])])


# ---------- xương (quy ước của ModelRig: "L" ở phía -X) ----------
JOINTS = {
    "hips": (None, (0, .48, -.005)), "spine0": ("hips", (0, .58, -.005)), "spine1": ("spine0", (0, .64, -.008)),
    "neck": ("spine1", (0, .74, -.005)), "head": ("neck", (0, .77, 0)),
}
for side, s in (("L", -1), ("R", 1)):
    JOINTS["arm" + side] = ("spine1", (s * .095, .706, -.025))
    JOINTS["el" + side] = ("arm" + side, (s * .23, .708, -.028))
    JOINTS["wr" + side] = ("el" + side, (s * .362, .708, -.030))
    JOINTS["thigh" + side] = ("hips", (s * .052, .47, -.008))
    JOINTS["knee" + side] = ("thigh" + side, (s * .053, .31, -.006))
NAMES = list(JOINTS)


def ramp(v, a, b):
    """0 tại a, 1 tại b (a có thể lớn hơn b)."""
    t = min(1.0, max(0.0, (v - a) / (b - a)))
    return t * t * (3 - 2 * t)


def components(pos, idx):
    """Nhãn mảnh liên thông của từng đỉnh (đỉnh trùng vị trí coi là một)."""
    par = list(range(len(pos)))

    def find(a):
        while par[a] != a:
            par[a] = par[par[a]]
            a = par[a]
        return a

    seen = {}
    for i, p in enumerate(np.round(pos, 4)):
        k = tuple(p)
        if k in seen:
            par[find(i)] = find(seen[k])
        else:
            seen[k] = i
    for t in idx.reshape(-1, 3):
        par[find(int(t[0]))] = find(int(t[1]))
        par[find(int(t[1]))] = find(int(t[2]))
    return np.array([find(i) for i in range(len(pos))])


def mix(a, wa, b, wb_frac):
    """Pha hai bộ trọng số: (1-f)*a + f*b."""
    out = {a: wa * (1 - wb_frac)}
    out[b] = out.get(b, 0) + wa * wb_frac
    return out


def torso_weights(y):
    if y < .60:
        return mix("hips", 1.0, "spine0", ramp(y, .555, .60))
    return mix("spine0", 1.0, "spine1", ramp(y, .60, .66))


def body_weights(p, kind):
    x, y, z = p
    side = "L" if x < 0 else "R"
    ax = abs(x)
    if kind == "hair":
        return {"head": 1}
    if kind == "boot":
        return {"knee" + side: 1}
    if kind == "leg":
        return mix("knee" + side, 1.0, "thigh" + side, ramp(y, .285, .345))
    if kind == "belt":
        return {"hips": 1}
    if kind == "shorts":
        t = ramp(y, .51, .43) * ramp(ax, 0.0, .03)
        return mix("hips", 1.0, "thigh" + side, t)
    # thân áo + tay áo + ba lô
    backpack = z < -.065 and ax < .105
    a = 0.0 if backpack else ramp(ax, .082, .128) * ramp(y, .615, .66)
    base = torso_weights(y)
    if a <= 0:
        return base
    e = ramp(ax, .205, .258)
    out = {k: v * (1 - a) for k, v in base.items()}
    for k, v in mix("arm" + side, a, "el" + side, e).items():
        out[k] = out.get(k, 0) + v
    return out


def classify(pos):
    lo, hi = pos.min(0), pos.max(0)
    if lo[1] > .76:
        return "hair"
    if hi[1] < .26:
        return "boot"
    if hi[1] < .42:
        return "leg"
    if lo[1] < .45:
        return "shorts"
    if hi[1] < .61:
        return "belt"
    return "torso"


# Cần câu: xoay quanh chỗ nắm để khi hạ tay nó chếch ra ngoài và thấp xuống, không chắn ngang mặt lúc chạy.
GRIP = np.array([-.415, .707, -.030])
ROD_DIR = np.array([-.55, .40, 1.0])


def rod_matrix():
    """Ma trận quay đưa hướng +Z của cần trong tư thế chữ T về ROD_DIR."""
    a, b = np.array([0.0, 0.0, 1.0]), ROD_DIR / np.linalg.norm(ROD_DIR)
    v, c = np.cross(a, b), float(a @ b)
    k = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    return np.eye(3) + k + k @ k / (1 + c)


def main(src, out):
    j, data = read_glb(src)
    bones = []
    for n in NAMES:
        parent, w = JOINTS[n]
        base = JOINTS[parent][1] if parent else (0, 0, 0)
        bones.append({"n": n, "p": NAMES.index(parent) if parent else -1, "t": [round(w[k] - base[k], 5) for k in range(3)]})

    blob = bytearray()

    def push(arr):
        off = len(blob)
        blob.extend(arr.tobytes())
        blob.extend(b"\0" * ((4 - len(blob) % 4) % 4))
        return off

    meshes = []
    for m in j["meshes"]:
        name, pr = m["name"], m["primitives"][0]
        pos = accessor(j, data, pr["attributes"]["POSITION"]).astype("<f4")
        nor = accessor(j, data, pr["attributes"]["NORMAL"]).astype("<f4")
        uv = accessor(j, data, pr["attributes"]["TEXCOORD_0"]).astype("<f4")
        idx = accessor(j, data, pr["indices"]).ravel().astype("<u2")
        if name in ("mesh_id12", "mesh_id13"):
            r = rod_matrix()
            pos = ((pos - GRIP) @ r.T + GRIP).astype("<f4")
            nor = (nor @ r.T).astype("<f4")
        mat = j["materials"][pr["material"]]
        pbr = mat.get("pbrMetallicRoughness", {})
        tref = pbr.get("baseColorTexture") or mat["extensions"]["KHR_materials_pbrSpecularGlossiness"]["diffuseTexture"]
        img = j["images"][j["textures"][tref["index"]]["source"]]
        bv = j["bufferViews"][img["bufferView"]]
        raw = data[bv.get("byteOffset", 0):bv.get("byteOffset", 0) + bv["byteLength"]]
        tex = "gon_" + hashlib.md5(raw).hexdigest()[:6] + ".png"
        with open(os.path.join(out, tex), "wb") as f:
            f.write(raw)

        mid = int(name.replace("mesh_id", ""))
        center_x = float(pos[:, 0].mean())
        weights = []
        if mid in (4,):                       # mắt
            weights = [{"head": 1}] * len(pos)
        elif mid == 5:                        # mặt + cổ
            weights = [mix("neck", 1.0, "head", ramp(float(p[1]), .748, .775)) for p in pos]
        elif mid == 6:                        # huy hiệu
            weights = [{"spine1": 1}] * len(pos)
        elif mid in (7, 8, 10, 11):           # bàn tay
            weights = [{"wr" + ("L" if center_x < 0 else "R"): 1}] * len(pos)
        elif mid in (12, 13):                 # cần câu cầm tay
            weights = [{"wrL": 1}] * len(pos)
        elif mid == 9:                        # thân: chia theo mảnh liên thông
            lab = components(pos, idx)
            kinds = {c: classify(pos[lab == c]) for c in set(lab.tolist())}
            weights = [body_weights(tuple(float(v) for v in p), kinds[int(lab[i])]) for i, p in enumerate(pos)]
        else:
            raise SystemExit("Mesh lạ: " + name + " (script chỉ dành cho đúng file Gon)")

        ji = np.zeros((len(pos), 4), np.uint8)
        jw = np.zeros((len(pos), 4), "<f4")
        for i, w in enumerate(weights):
            top = sorted(((k, v) for k, v in w.items() if v > 1e-4), key=lambda kv: -kv[1])[:4]
            tot = sum(v for _, v in top)
            for k, (bone, v) in enumerate(top):
                ji[i, k] = NAMES.index(bone)
                jw[i, k] = v / tot

        e = {"v": len(pos), "i": len(idx)}
        e["pos"], e["nor"], e["uv"] = push(pos), push(nor), push(uv)
        e["ji"], e["jw"], e["idx"] = push(ji), push(jw), push(idx)
        e["tex"] = tex
        e["cut"] = mat.get("alphaCutoff", .5) if mat.get("alphaMode") == "MASK" else 0
        e["ds"] = True
        e["ol"] = mid in (5, 7, 8, 9, 10, 11)
        meshes.append(e)

    with open(os.path.join(out, "gon.bin"), "wb") as f:
        f.write(blob)
    with open(os.path.join(out, "gon.json"), "w") as f:
        json.dump({"bones": bones, "meshes": meshes}, f, separators=(",", ":"))
    print("gon: bones", len(bones), "meshes", len(meshes), "bin", len(blob))


if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit(__doc__)
    main(sys.argv[1], sys.argv[2])
