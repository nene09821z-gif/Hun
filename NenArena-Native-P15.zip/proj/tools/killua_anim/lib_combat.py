"""Đòn đánh: đấm/vuốt/chưởng/chỏ/gối/đá, mỗi đòn có cả hai bên (L/R = xương L/R là bên ra đòn)."""
from lib_core import *

def ready(lead='L', yaw=22, crouch=.05, extra=None, **kw):
    sd = SD[lead]
    d = dict(crouch=crouch, gw=.045, stag=-.09 * sd, hip=(2, -sd * yaw * .5, 0), s0=(6, -sd * yaw * .6, 0), s1=(6, -sd * yaw * .5, 0), nk=(-2, 0, 0), hd=(3, sd * yaw * .9, 0),
             hL=(.15, -.06, .07), hR=(.13, -.03, .04))
    if lead == 'R': d.update(hL=(.13, -.03, .04), hR=(.15, -.06, .07))
    d.update(kw); return d

def strike_keys(side, wind, hit, follow=None, lead=None, t=(0.0, .13, .19, .26, .5), stance_kw=None, hit_hold=.04):
    """Khoá: sẵn sàng -> lấy đà -> trúng -> giữ -> về. wind/hit/follow là dict ghi đè lên tư thế sẵn sàng."""
    lead = lead or opp(side)
    base = ready(lead, **(stance_kw or {}))
    k0 = dict(base); kw = dict(base, **wind); kh = dict(base, **hit)
    ks = [(t[0], k0), (t[1], kw), (t[2], kh)]
    if follow is not None: ks.append((t[3], dict(base, **follow)))
    else: ks.append((t[3], dict(kh)))
    ks.append((t[4], dict(base)))
    return ks

S_ = lambda s: SD[s]
CAT = 'atk'

# ---------------- ĐẤM / VUỐT / CHƯỞNG ----------------
def punch_def(name, fnw, fnh, dur=.52, hitt=.15, cat=CAT, leadmode='opp', **kw):
    def fn(side):
        sd = SD[side]; wind = fnw(side, sd); hit = fnh(side, sd)
        ks = strike_keys(side, wind, hit, lead=(side if leadmode == 'same' else opp(side)), t=(0, hitt * .62, hitt, hitt + .07, dur))
        return ks, dur, dict(hit=hitt)
    add_pair(name, fn, cat=cat, **kw)

def hk(side, v): return {'hL' if side == 'L' else 'hR': v}
def hr(side, v): return {'hR' if side == 'L' else 'hL': v}

# jab: tay trước
punch_def('jab', lambda s, d: dict(hk(s, (.10, -.02, .06)), s1=(8, -d * -8, 0)),
          lambda s, d: dict(hk(s, (.30, .03, .02)), s0=(8, d * 14, 0), s1=(8, d * 10, 0), hip=(2, d * 8, 0), root=(0, 0, .035), stag=.02 * -d, hd=(3, 4, 0)), dur=.4, hitt=.12, leadmode='same')
punch_def('cross', lambda s, d: dict(hk(s, (.08, -.04, .08)), hip=(2, -d * -26, 0), s0=(8, -d * -26, 0), s1=(8, -d * -22, 0)),
          lambda s, d: dict(hk(s, (.31, .02, -.04)), hip=(3, d * 30, 0), s0=(10, d * 32, 0), s1=(10, d * 26, 0), root=(0, 0, .06), fL=(.06 if s == 'R' else -.1, -.375, .05, 0) if False else None) if False else dict(hk(s, (.31, .02, -.04)), hip=(3, d * 30, 0), s0=(10, d * 32, 0), s1=(10, d * 26, 0), root=(0, 0, .06)), dur=.5, hitt=.15, leadmode='opp')
punch_def('hook', lambda s, d: dict(hk(s, (.02, .0, .30, (.5 * 1, .3, 0))), hip=(2, -d * -22, 0), s0=(6, -d * -26, d * 8), s1=(6, -d * -20, d * 8)),
          lambda s, d: dict(hk(s, (.20, .0, -.12, (.6, .5, 0))), hip=(2, d * 34, 0), s0=(8, d * 36, -d * 8), s1=(8, d * 30, -d * 8), root=(0, 0, .04)), dur=.52, hitt=.17, leadmode='same')
punch_def('uppercut', lambda s, d: dict(hk(s, (.10, -.30, .05)), s0=(14, 0, 0), s1=(12, 0, 0), crouch=.10),
          lambda s, d: dict(hk(s, (.20, .20, .02)), s0=(-4, d * 18, 0), s1=(-6, d * 12, 0), crouch=.02, root=(0, .02, .05), hd=(-4, 0, 0)), dur=.5, hitt=.15, leadmode='opp')
punch_def('overhand', lambda s, d: dict(hk(s, (-.02, .22, .16)), s0=(-6, -d * -34, 0), s1=(-4, -d * -26, 0), hip=(0, -d * -28, 0)),
          lambda s, d: dict(hk(s, (.26, -.10, -.02)), s0=(22, d * 30, 0), s1=(18, d * 22, 0), hip=(4, d * 24, 0), root=(0, -.02, .08)), dur=.58, hitt=.2, leadmode='opp')
punch_def('hammerfist', lambda s, d: dict(hk(s, (.04, .26, .08)), s0=(-8, 0, 0), s1=(-6, 0, 0)),
          lambda s, d: dict(hk(s, (.26, -.16, .02)), s0=(24, d * 10, 0), s1=(20, d * 6, 0), root=(0, -.03, .05), hd=(8, 0, 0)), dur=.5, hitt=.16, leadmode='opp')
punch_def('backfist', lambda s, d: dict(hk(s, (.10, .03, .0)), s0=(6, -d * -50, 0), s1=(6, -d * -40, 0), hip=(2, -d * -40, 0), hd=(3, d * 40, 0)),
          lambda s, d: dict(hk(s, (.04, .06, .31)), s0=(6, d * 38, 0), s1=(6, d * 30, 0), hip=(2, d * 28, 0), root=(0, 0, .03)), dur=.46, hitt=.14, leadmode='same')
punch_def('palm', lambda s, d: dict(hk(s, (.06, .0, .06)), s0=(8, -d * -14, 0), wL=(-30, 0, 0), wR=(-30, 0, 0)),
          lambda s, d: dict(hk(s, (.31, .05, .02)), s0=(10, d * 22, 0), s1=(8, d * 16, 0), root=(0, 0, .05), wL=(-70, 0, 0) if s == 'L' else (-5, 0, 0), wR=(-70, 0, 0) if s == 'R' else (-5, 0, 0)), dur=.48, hitt=.15, leadmode='opp')
punch_def('palm_double', lambda s, d: dict(hL=(.05, -.02, .06), hR=(.05, -.02, .06), s0=(10, 0, 0), crouch=.09),
           lambda s, d: dict(hL=(.30, .03, .0), hR=(.30, .03, .0), s0=(14, 0, 0), s1=(10, 0, 0), crouch=.03, root=(0, 0, .09), wL=(-80, 0, 0), wR=(-80, 0, 0)), dur=.55, hitt=.17, leadmode='opp')
punch_def('elbow_fwd', lambda s, d: dict(hk(s, (.02, .04, .10)), s0=(6, -d * -22, 0)),
          lambda s, d: dict(hk(s, (.10, .04, -.02, (.1, .2, 1))), s0=(8, d * 30, 0), s1=(8, d * 22, 0), hip=(2, d * 20, 0), root=(0, 0, .07)), dur=.48, hitt=.14, leadmode='opp')
punch_def('elbow_up', lambda s, d: dict(hk(s, (.08, -.14, .05)), s0=(12, 0, 0), crouch=.09),
          lambda s, d: dict(hk(s, (.06, .20, .0, (0, -1, -.4))), s0=(-6, d * 14, 0), crouch=.02, root=(0, .02, .04), hd=(-6, 0, 0)), dur=.48, hitt=.15, leadmode='opp')

# --- vuốt điện (claw) ---
CL = dict(wL=(-45, 0, 0), wR=(-45, 0, 0))
punch_def('claw_slash_h', lambda s, d: dict(hk(s, (.08, .04, .30, (.5, .2, 0))), s0=(6, -d * -30, d * 6), s1=(6, -d * -22, 0), hip=(2, -d * -22, 0)),
          lambda s, d: dict(hk(s, (.26, .0, -.16)), s0=(8, d * 34, -d * 6), s1=(8, d * 26, 0), hip=(2, d * 26, 0), root=(0, 0, .05)), dur=.46, hitt=.14, leadmode='same')
punch_def('claw_slash_dn', lambda s, d: dict(hk(s, (.04, .26, .22, (.6, .3, 0))), s0=(-4, -d * -26, d * 10), s1=(-2, -d * -20, 0)),
          lambda s, d: dict(hk(s, (.24, -.16, -.10)), s0=(18, d * 28, -d * 10), s1=(14, d * 22, 0), hip=(3, d * 20, 0), root=(0, -.02, .06)), dur=.48, hitt=.15, leadmode='opp')
punch_def('claw_slash_up', lambda s, d: dict(hk(s, (.08, -.26, .20)), s0=(14, -d * -22, d * 8), crouch=.10),
          lambda s, d: dict(hk(s, (.22, .24, -.08)), s0=(-8, d * 26, -d * 6), s1=(-6, d * 18, 0), crouch=.01, root=(0, .03, .05), hd=(-6, 0, 0)), dur=.5, hitt=.16, leadmode='opp')
punch_def('claw_thrust', lambda s, d: dict(hk(s, (.05, .02, .08)), s0=(10, -d * -14, 0), crouch=.08),
          lambda s, d: dict(hk(s, (.31, .02, .0)), s0=(16, d * 14, 0), s1=(14, d * 10, 0), crouch=.04, root=(0, -.01, .1), wL=(-20, 0, 0), wR=(-20, 0, 0)), dur=.44, hitt=.13, leadmode='opp')
punch_def('claw_rake_x', lambda s, d: dict(hL=(.06, .22, .15), hR=(.06, .22, .15), s0=(-6, 0, 0), crouch=.04),
           lambda s, d: dict(hL=(.24, -.14, -.08), hR=(.24, -.14, -.08), s0=(18, 0, 0), s1=(14, 0, 0), crouch=.07, root=(0, -.02, .06)), dur=.5, hitt=.16, leadmode='opp')
punch_def('claw_rake_wide', lambda s, d: dict(hL=(.06, .0, .02), hR=(.06, .0, .02), s0=(8, 0, 0)),
           lambda s, d: dict(hL=(.14, .02, .30), hR=(.14, .02, .30), s0=(10, 0, 0), crouch=.08, root=(0, 0, .04)), dur=.46, hitt=.14, leadmode='opp')
punch_def('shoulder_charge', lambda s, d: dict(s0=(12, -d * -30, 0), s1=(10, -d * -24, 0), hip=(2, -d * -20, 0), crouch=.10),
          lambda s, d: dict(s0=(22, d * 40, 0), s1=(18, d * 30, 0), hip=(4, d * 26, 0), crouch=.06, root=(0, 0, .16), hd=(6, 0, 0)), dur=.5, hitt=.17, leadmode='opp')

# ---------------- ĐÁ / GỐI ----------------
def kick_def(name, wind, hit, dur=.7, hitt=.22, rec=None, lean=0, spin=0, cat=CAT, **kw):
    """wind/hit là hàm (side, sd) -> dict. Chân đá = side; bên kia là chân trụ."""
    def fn(side):
        sd = SD[side]; base = ready(opp(side), crouch=.05)
        w = dict(base, **wind(side, sd)); h = dict(base, **hit(side, sd))
        ks = [(0, dict(base)), (hitt * .6, w), (hitt, h), (hitt + .12, dict(h)), (dur, dict(base))]
        return ks, dur, dict(hit=hitt)
    add_pair(name, fn, cat=cat, **kw)

def fk(side, v): return {'fL' if side == 'L' else 'fR': v}
def fs(side, v): return {'fR' if side == 'L' else 'fL': v}

kick_def('kick_front', lambda s, d: dict(fk(s, (.14, -.10, .0, 20)), s0=(2, 0, 0), s1=(2, 0, 0), hL=(.12, -.04, .08), hR=(.12, -.04, .08)),
         lambda s, d: dict(fk(s, (.38, -.0, .0, 20)), s0=(-8, 0, 0), s1=(-8, 0, 0), hip=(-4, 0, 0), hd=(0, 0, 0), root=(0, 0, .02)), dur=.62, hitt=.2)
kick_def('kick_snap', lambda s, d: dict(fk(s, (.10, -.12, .0, 30)), s0=(6, 0, 0)),
         lambda s, d: dict(fk(s, (.36, -.02, .0, 5)), s0=(-4, 0, 0), s1=(-2, 0, 0)), dur=.45, hitt=.14)
kick_def('kick_round_low', lambda s, d: dict(fk(s, (-.02, -.26, d * -.16, 0)), hip=(0, -d * -20, 0), s0=(4, -d * -20, 0)),
         lambda s, d: dict(fk(s, (.30, -.28, -d * -.06, 0)), hip=(0, d * 30, 0), s0=(6, d * 24, 0), s1=(6, d * 18, 0), root=(0, 0, .02), hL=(.10, -.06, .12), hR=(.10, -.06, .12)), dur=.6, hitt=.2)
kick_def('kick_round_mid', lambda s, d: dict(fk(s, (.0, -.10, d * -.22, 20)), hip=(0, -d * -24, d * -4), s0=(4, -d * -20, 0)),
         lambda s, d: dict(fk(s, (.32, -.02, -d * -.04 * 0 + d * .02, 20)), hip=(0, d * 44, d * -8), s0=(-2, d * 28, d * 14), s1=(-2, d * 20, d * 10), root=(0, 0, .02), hL=(.10, .0, .16), hR=(.10, .0, .16)), dur=.66, hitt=.22)
kick_def('kick_round_high', lambda s, d: dict(fk(s, (.0, .02, d * -.24, 20)), hip=(0, -d * -24, d * -6), s0=(2, -d * -20, 0)),
         lambda s, d: dict(fk(s, (.28, .16, d * .02, 20)), hip=(0, d * 54, d * -14), s0=(-4, d * 30, d * 24), s1=(-4, d * 22, d * 16), root=(0, 0, .0), hL=(.06, .08, .22), hR=(.06, .08, .22), hd=(-3, 0, 0)), dur=.72, hitt=.25)
kick_def('kick_side', lambda s, d: dict(fk(s, (.04, -.08, d * -.12, 10)), hip=(0, -d * -70, 0), s0=(2, -d * -60, 0), s1=(2, -d * -50, 0), hd=(3, d * 70, 0)),
         lambda s, d: dict(fk(s, (.0, .0, d * -.38, 0)), hip=(0, -d * -78, 0), s0=(0, -d * -60, d * 18), s1=(0, -d * -50, d * 14), hd=(3, d * 74, 0), hL=(.12, .02, .14), hR=(.12, .02, .14)), dur=.7, hitt=.24)
kick_def('kick_back', lambda s, d: dict(fk(s, (-.10, -.10, .0, 20)), s0=(14, d * -20, 0), s1=(14, 0, 0), hip=(4, 0, 0), hd=(4, d * 70, 0)),
         lambda s, d: dict(fk(s, (-.38, .02, .0, 20)), hip=(6, d * 24, 0), s0=(40, d * 30, 0), s1=(30, d * 20, 0), hd=(-10, d * 60, 0), hL=(.2, .08, .1), hR=(.2, .08, .1)), dur=.7, hitt=.24)
kick_def('kick_hook', lambda s, d: dict(fk(s, (.10, -.04, d * -.30, 20)), hip=(0, -d * -20, 0)),
         lambda s, d: dict(fk(s, (.12, .08, d * .14, 20)), hip=(0, d * 40, 0), s0=(-2, d * 30, d * 10), s1=(0, d * 24, d * 8)), dur=.68, hitt=.24)
kick_def('kick_axe', lambda s, d: dict(fk(s, (.12, .34, .02, 30)), s0=(-14, 0, 0), s1=(-10, 0, 0), hip=(-4, 0, 0), hL=(.10, .10, .16), hR=(.10, .10, .16)),
         lambda s, d: dict(fk(s, (.26, -.14, .0, -10)), s0=(14, 0, 0), s1=(10, 0, 0), hip=(6, 0, 0), root=(0, -.02, .03)), dur=.8, hitt=.3)
kick_def('kick_crescent', lambda s, d: dict(fk(s, (.26, .10, d * .16, 20)), s0=(-6, 0, 0)),
         lambda s, d: dict(fk(s, (.26, .10, -d * .14, 20)), s0=(-8, d * 14, 0), hip=(0, d * 10, 0)), dur=.62, hitt=.2)
kick_def('knee_strike', lambda s, d: dict(fk(s, (-.04, -.14, .0, 40)), s0=(4, 0, 0)),
         lambda s, d: dict(fk(s, (.12, -.14, .0, 30)), s0=(22, 0, 0), s1=(16, 0, 0), hip=(6, 0, 0), hL=(.12, -.14, .0), hR=(.12, -.14, .0), root=(0, 0, .06)), dur=.5, hitt=.16)
kick_def('knee_round', lambda s, d: dict(fk(s, (.0, -.12, d * -.16, 40)), hip=(0, -d * -20, 0), s0=(6, -d * -20, 0)),
         lambda s, d: dict(fk(s, (.12, -.08, d * .04, 30)), hip=(0, d * 40, 0), s0=(10, d * 26, d * 8), s1=(8, d * 18, 0)), dur=.54, hitt=.18)
kick_def('stomp', lambda s, d: dict(fk(s, (.12, -.02, .0, 10)), s0=(-4, 0, 0)),
         lambda s, d: dict(fk(s, (.24, -.36, .0, 5)), s0=(14, 0, 0), s1=(10, 0, 0), root=(0, -.02, .02)), dur=.5, hitt=.18)
kick_def('sweep_low', lambda s, d: dict(fk(s, (.0, -.28, d * -.12, 0)), crouch=.18, hip=(10, -d * -20, 0), s0=(12, -d * -20, 0), hL=(.06, -.22, .16), hR=(.06, -.22, .16)),
         lambda s, d: dict(fk(s, (.34, -.30, d * .08, 0)), crouch=.18, hip=(10, d * 40, 0), s0=(14, d * 26, 0), hL=(.04, -.24, .2), hR=(.04, -.24, .2)), dur=.64, hitt=.22)
