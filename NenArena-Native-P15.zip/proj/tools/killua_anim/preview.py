"""Xem trước: skin bằng numpy, vẽ tam giác có màu texture (matplotlib)."""
import numpy as np, os, pickle
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import PolyCollection
from PIL import Image
import rig

_cache = {}
def load():
    if 'm' in _cache: return _cache['m']
    meshes = pickle.load(open('/tmp/killua_skin.pkl', 'rb')) if os.path.exists('/tmp/killua_skin.pkl') else rig.build_skin()[1]
    for m in meshes:
        im = Image.open(os.path.join(rig.ASSETS, m['meta']['tex'])).convert('RGBA'); m['img'] = np.asarray(im)
        tri = m['idx'].reshape(-1, 3); m['tri'] = tri
        uv = m['uv'][tri].mean(1); h, w = m['img'].shape[:2]
        px = np.clip((uv[:, 0] % 1) * w, 0, w - 1).astype(int); py = np.clip((uv[:, 1] % 1) * h, 0, h - 1).astype(int)
        c = m['img'][py, px].astype(float) / 255; m['col'] = c
        # three.js uv.y lật: thử cả 2 và chọn cái ít trong suốt hơn
        c2 = m['img'][np.clip(((1 - uv[:, 1]) % 1) * h, 0, h - 1).astype(int), px].astype(float) / 255
        if c2[:, 3].mean() > c[:, 3].mean(): m['col'] = c2
    _cache['m'] = meshes; return meshes

def skin_verts(meshes, eul, root):
    Rw, Pw = rig.fk(eul, root); R, T = rig.skin_mats(Rw, Pw)
    out = []
    for m in meshes:
        p = m['pos']; ji = m['ji']; jw = m['jw']; res = np.zeros_like(p)
        for k in range(4):
            b = ji[:, k]; res += jw[:, k:k + 1] * (np.einsum('vij,vj->vi', R[b], p) + T[b])
        out.append(res)
    return out, Pw

def draw(ax, meshes, eul, root, yaw=0., ground=True, xlim=(-.9, .9), ylim=(-.05, 1.2), skel=False, shade=True):
    vs, Pw = skin_verts(meshes, eul, root)
    cy, sy = np.cos(yaw), np.sin(yaw)
    polys = []; cols = []; depth = []
    L = np.array([.35, .6, .7]); L /= np.linalg.norm(L)
    for m, v in zip(meshes, vs):
        # xoay quanh trục y rồi chiếu: x' = x cos + z sin ; z' = -x sin + z cos ; nhìn từ +z về gốc, x trái-phải
        X = v[:, 0] * cy + v[:, 2] * sy; Z = -v[:, 0] * sy + v[:, 2] * cy; Y = v[:, 1]
        tri = m['tri']
        P = np.stack([X, Y], 1)[tri]
        z = Z[tri].mean(1)
        a = v[tri[:, 1]] - v[tri[:, 0]]; b = v[tri[:, 2]] - v[tri[:, 0]]; n = np.cross(a, b); n /= (np.linalg.norm(n, axis=1, keepdims=True) + 1e-9)
        nz = -n[:, 0] * sy + n[:, 2] * cy
        nx = n[:, 0] * cy + n[:, 2] * sy
        lam = np.abs(nx * L[0] + n[:, 1] * L[1] + nz * L[2]) * .5 + .5 if shade else np.ones(len(z))
        c = m['col'].copy(); keep = c[:, 3] > .4
        c[:, :3] *= lam[:, None] * .85 + .15
        polys += list(P[keep]); cols += list(c[keep]); depth += list(z[keep])
    o = np.argsort(depth)   # xa trước (z nhỏ = xa khi nhìn từ +z)
    pc = PolyCollection([polys[i] for i in o], facecolors=[cols[i] for i in o], edgecolors=[(0, 0, 0, .25)] * len(o), linewidths=.15)
    ax.add_collection(pc)
    if ground: ax.axhline(0, color='#555', lw=.8)
    if skel:
        for i in range(rig.NB):
            if rig.PARENT[i] >= 0:
                a_, b_ = Pw[rig.PARENT[i]] + np.array(root), Pw[i] + np.array(root)
                ax.plot([a_[0] * cy + a_[2] * sy, b_[0] * cy + b_[2] * sy], [a_[1], b_[1]], 'r-', lw=.5)
    ax.set_xlim(*xlim); ax.set_ylim(*ylim); ax.set_aspect('equal'); ax.axis('off')

def neutral(): return np.zeros((rig.NA, 3))

if __name__ == '__main__':
    meshes = load()
    fig, axs = plt.subplots(1, 4, figsize=(16, 5))
    e = neutral()
    draw(axs[0], meshes, e, (0, 0, 0), yaw=0)
    draw(axs[1], meshes, e, (0, 0, 0), yaw=np.pi / 2)
    # tay giơ ngang (hanging frame: arm L rz=-1.45 => T-pose) + chân co + cúi
    e2 = neutral(); I = rig.ANIM.index
    e2[I('armL')] = (-1.2, 0, -.3); e2[I('armR')] = (-1.2, 0, .3); e2[I('elL')] = (-1.0, 0, 0); e2[I('elR')] = (-1.0, 0, 0)
    e2[I('thighL')] = (-1.0, 0, 0); e2[I('kneeL')] = (1.4, 0, 0); e2[I('spine0')] = (.2, .3, 0); e2[I('spine1')] = (.15, .3, 0); e2[I('head')] = (-.2, -.3, 0)
    draw(axs[2], meshes, e2, (0, 0, 0), yaw=0.4)
    draw(axs[3], meshes, e2, (0, 0, 0), yaw=np.pi / 2)
    plt.tight_layout(); plt.savefig('/tmp/out/rig_test.png', dpi=70)
