"""
Bộ xương mới cho Killua (29 xương) + FK/skinning bằng numpy (dùng để bake và xem trước).
Quy ước: model chuẩn hoá cao ~1, nhìn về +Z, xương "L" nằm ở -X (giống assets cũ / khung Human).
Rest pose = chữ T. Tay được "hạ" bằng B = Rz(±ARM_DOWN) giống ModelRig.attachSkinModel (armDown = 1.45).
"""
import json, numpy as np, os
HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'assets')
ARM_DOWN = 1.45

# (tên, cha, vị trí thế giới ở tư thế nghỉ)
Z0 = -0.04
BONES = [
 ('hips',   None,     (0, .50, Z0)),
 ('spine0', 'hips',   (0, .58, -.045)),
 ('spine1', 'spine0', (0, .66, -.05)),
 ('neck',   'spine1', (0, .755, -.045)),
 ('head',   'neck',   (0, .795, -.04)),
 ('clavL',  'spine1', (-.035, .725, -.06)), ('armL', 'clavL', (-.11, .72, -.06)), ('elL', 'armL', (-.25, .72, -.06)), ('wrL', 'elL', (-.37, .72, -.06)),
 ('clavR',  'spine1', (.035, .725, -.06)),  ('armR', 'clavR', (.11, .72, -.06)),  ('elR', 'armR', (.25, .72, -.06)),  ('wrR', 'elR', (.37, .72, -.06)),
 ('thighL', 'hips',   (-.055, .50, Z0)), ('kneeL', 'thighL', (-.055, .27, Z0)), ('ankleL', 'kneeL', (-.055, .10, -.035)), ('toeL', 'ankleL', (-.055, .03, .035)),
 ('thighR', 'hips',   (.055, .50, Z0)),  ('kneeR', 'thighR', (.055, .27, Z0)),  ('ankleR', 'kneeR', (.055, .10, -.035)),  ('toeR', 'ankleR', (.055, .03, .035)),
 # tóc (chạy bằng lò xo lúc chạy game, không có trong clip)
 ('hairTop', 'head', (0, .93, -.04)),
 ('hairFr',  'head', (0, .90, .045)),
 ('hairBk0', 'head', (0, .91, -.10)), ('hairBk1', 'hairBk0', (0, .85, -.135)),
 ('hairL0',  'head', (-.085, .90, -.04)), ('hairL1', 'hairL0', (-.105, .83, -.05)),
 ('hairR0',  'head', (.085, .90, -.04)),  ('hairR1', 'hairR0', (.105, .83, -.05)),
]
NAMES = [b[0] for b in BONES]
IDX = {n: i for i, n in enumerate(NAMES)}
NB = len(BONES)
PARENT = np.array([-1 if b[1] is None else IDX[b[1]] for b in BONES])
REST = np.array([b[2] for b in BONES], dtype=np.float64)
LT = np.array([REST[i] - (REST[PARENT[i]] if PARENT[i] >= 0 else 0) for i in range(NB)])
# các xương được clip điều khiển (21 xương đầu, tóc là vật lý)
ANIM = NAMES[:21]
NA = len(ANIM)

def rx(a):
    c, s = np.cos(a), np.sin(a); return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
def ry(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
def rz(a):
    c, s = np.cos(a), np.sin(a); return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])
def euler(x, y, z): return rx(x) @ ry(y) @ rz(z)   # Euler XYZ như three.js / Node.rot

def mat_to_quat(R):
    t = R[0, 0] + R[1, 1] + R[2, 2]
    if t > 0:
        s = np.sqrt(t + 1) * 2; return np.array([(R[2, 1] - R[1, 2]) / s, (R[0, 2] - R[2, 0]) / s, (R[1, 0] - R[0, 1]) / s, .25 * s])
    if R[0, 0] > R[1, 1] and R[0, 0] > R[2, 2]:
        s = np.sqrt(1 + R[0, 0] - R[1, 1] - R[2, 2]) * 2; return np.array([.25 * s, (R[0, 1] + R[1, 0]) / s, (R[0, 2] + R[2, 0]) / s, (R[2, 1] - R[1, 2]) / s])
    if R[1, 1] > R[2, 2]:
        s = np.sqrt(1 + R[1, 1] - R[0, 0] - R[2, 2]) * 2; return np.array([(R[0, 1] + R[1, 0]) / s, .25 * s, (R[1, 2] + R[2, 1]) / s, (R[0, 2] - R[2, 0]) / s])
    s = np.sqrt(1 + R[2, 2] - R[0, 0] - R[1, 1]) * 2; return np.array([(R[0, 2] + R[2, 0]) / s, (R[1, 2] + R[2, 1]) / s, .25 * s, (R[1, 0] - R[0, 1]) / s])

def quat_to_mat(q):
    x, y, z, w = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
                     [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
                     [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])

def local_rotations(eul):
    """eul: (21,3) rad, kiểu "khung treo tay" -> danh sách ma trận quay cục bộ của 29 xương (tóc = I)."""
    R = [np.eye(3) for _ in range(NB)]
    for i, n in enumerate(ANIM):
        e = euler(*eul[i])
        if n.startswith('clav'):
            # tác giả: (0, reach, shrug) đối xứng -> khung T: L: ry=+reach, rz=-shrug ; R: ry=-reach, rz=+shrug
            reach, shrug = eul[i][1], eul[i][2]
            sgn = -1 if n.endswith('L') else 1
            e = ry(-sgn * reach) @ rz(sgn * shrug)
        if n in ('armL', 'armR'):
            b = rz(ARM_DOWN if n == 'armL' else -ARM_DOWN); e = e @ b
        if n in ('elL', 'wrL', 'elR', 'wrR'):
            b = rz(ARM_DOWN if n.endswith('L') else -ARM_DOWN); e = b.T @ e @ b
        R[IDX[n]] = e
    return R

def fk(eul, root=(0, 0, 0)):
    """Trả về (R_world[NB,3,3], P_world[NB,3]) ở không gian model (đã cộng root)."""
    R = local_rotations(eul)
    Rw = [None] * NB; Pw = np.zeros((NB, 3))
    for i in range(NB):
        p = PARENT[i]
        if p < 0: Rw[i] = R[i]; Pw[i] = LT[i]
        else: Rw[i] = Rw[p] @ R[i]; Pw[i] = Pw[p] + Rw[p] @ LT[i]
    return np.array(Rw), Pw + np.array(root)

def skin_mats(Rw, Pw):
    """Ma trận skin: v' = Rw (v - rest) + Pw."""
    return Rw, Pw - np.einsum('bij,bj->bi', Rw, REST)

# ============ re-skin từ asset cũ ============
def sig(x): return 1 / (1 + np.exp(-np.clip(x, -30, 30)))
def seg_dist(p, a, b):
    ab = b - a; l2 = float(ab @ ab); t = np.clip(((p - a) @ ab) / l2, 0, 1)
    q = a + t[:, None] * ab; return np.linalg.norm(p - q, axis=1), t

def load_old(path_json, path_bin):
    js = json.load(open(path_json)); bb = open(path_bin, 'rb').read(); out = []
    for m in js['meshes']:
        v = m['v']
        out.append(dict(meta=m, pos=np.frombuffer(bb, '<f4', v * 3, m['pos']).reshape(-1, 3).astype(np.float64),
                        nor=np.frombuffer(bb, '<f4', v * 3, m['nor']).reshape(-1, 3).copy(),
                        uv=np.frombuffer(bb, '<f4', v * 2, m['uv']).reshape(-1, 2).copy(),
                        idx=np.frombuffer(bb, '<u2', m['i'], m['idx']).copy()))
    return js, out

def W(name): return REST[IDX[name]]

def body_weights(p):
    """Trọng số cho đỉnh thân/tay/chân: (n, NB)."""
    n = len(p); w = np.zeros((n, NB))
    # ---- chuỗi spine theo y
    def part(s, js):  # js: list (bone, y_start); phân hoạch mượt theo s
        ws = []
        for k, (bn, s0) in enumerate(js):
            s1 = js[k + 1][1] if k + 1 < len(js) else 99
            wd = .014
            a = sig((s - s0) / wd) if k > 0 else np.ones_like(s)
            b = 1 - sig((s - s1) / wd) if k + 1 < len(js) else np.ones_like(s)
            ws.append((bn, a * b))
        return ws
    chains = []
    # spine: hips .50..., biên giữa các xương ở trung điểm khớp
    sp = [('hips', -9), ('spine0', .54), ('spine1', .625), ('neck', .715), ('head', .785)]
    chains.append(('spine', [(IDX[b], f) for b, f in part(p[:, 1], sp)], [(W('hips'), W('spine0')), (W('spine0'), W('spine1')), (W('spine1'), W('neck')), (W('neck'), W('head') + np.array([0, .12, 0]))], .12))
    for sd, X in (('L', -1), ('R', 1)):
        # chân: thigh/knee/ankle theo y; toe theo z
        y = p[:, 1]
        th = [('thigh' + sd, -9), ('knee' + sd, .385), ('ankle' + sd, .155)]
        ws = part(y, th)
        toe = sig((p[:, 2] - .03) / .012) * sig((.075 - y) / .02)
        lw = [(IDX[b], f) for b, f in ws]
        lw = [(i, f * ((1 - toe) if NAMES[i] == 'ankle' + sd else 1)) for i, f in lw] + [(IDX['toe' + sd], toe)]
        sidef = sig((-p[:, 0] if sd == 'L' else p[:, 0]) / .012)      # chỉ vertex cùng phía mới thuộc chân này
        chains.append(('leg' + sd, lw, [(W('thigh' + sd), W('knee' + sd)), (W('knee' + sd), W('ankle' + sd)), (W('ankle' + sd), W('toe' + sd))], .075, sidef))
        # tay theo |x|
        ax = np.abs(p[:, 0])
        ar = part(ax, [('clav' + sd, -9), ('arm' + sd, .085), ('el' + sd, .205), ('wr' + sd, .335)])
        # biên vai rộng hơn
        chains.append(('arm' + sd, [(IDX[b], f) for b, f in ar], [(W('clav' + sd), W('arm' + sd)), (W('arm' + sd), W('el' + sd)), (W('el' + sd), W('wr' + sd)), (W('wr' + sd), W('wr' + sd) + np.array([X * .12, 0, 0]))], .05))
    # khoảng cách chuẩn hoá tới mỗi chuỗi
    nds = []
    for ch in chains:
        name, ws, segs, r = ch[:4]
        d = np.min(np.stack([seg_dist(p, a, b)[0] for a, b in segs]), axis=0) / r
        if len(ch) > 4: d = d + (1 - ch[4]) * 1.2
        nds.append(d)
    nds = np.stack(nds); mn = nds.min(0)
    cw = np.exp(-(nds - mn) / .30); cw /= cw.sum(0)
    for ci, ch in enumerate(chains):
        for bi, f in ch[1]: w[:, bi] += cw[ci] * f
    # vùng thân trên của chuỗi tay: |x| nhỏ -> thuộc spine nên không rò; chuẩn hoá
    w /= w.sum(1, keepdims=True)
    return w

def hair_weights(p):
    """Tóc: đầu + các cụm tóc, độ "lỏng" tăng theo khoảng cách khỏi hộp sọ và độ thấp."""
    n = len(p); w = np.zeros((n, NB)); hc = np.array([0, .885, -.035])
    d = p - hc; r = np.linalg.norm(d * np.array([1, .95, 1]), axis=1)
    loose = np.clip((r - .085) / .06, 0, 1)
    cl = np.zeros((n, 5))   # Top, Fr, Bk, L, R
    cl[:, 0] = np.clip(d[:, 1] / .09, 0, 1) * 1.2
    cl[:, 1] = np.clip((d[:, 2] - .02) / .06, 0, 1) * 1.1 * (d[:, 1] > -.01)
    cl[:, 2] = np.clip((-d[:, 2] - .02) / .05, 0, 1) * 1.2
    cl[:, 3] = np.clip((-d[:, 0] - .03) / .05, 0, 1) * 1.2
    cl[:, 4] = np.clip((d[:, 0] - .03) / .05, 0, 1) * 1.2
    cl = cl ** 2 + 1e-4; cl /= cl.sum(1, keepdims=True)
    low = np.clip((.885 - p[:, 1]) / .09, 0, 1)
    for i in range(n):
        lo = float(max(loose[i] * .85, low[i]))
        # chuỗi 2 đốt cho tóc sau / hai bên: đốt 1 nhận phần lỏng nhất
        h0 = lo * (1 - lo) * 2.4; h1 = lo ** 1.6
        wsum = 0
        bw = {}
        def add(b, v): bw[IDX[b]] = bw.get(IDX[b], 0) + v
        add('hairTop', cl[i, 0] * (loose[i] * .9))
        add('hairFr', cl[i, 1] * (loose[i] * .9))
        add('hairBk0', cl[i, 2] * min(1, h0 * 1.1 + h1 * .15)); add('hairBk1', cl[i, 2] * h1)
        add('hairL0', cl[i, 3] * min(1, h0 * 1.1 + h1 * .15)); add('hairL1', cl[i, 3] * h1)
        add('hairR0', cl[i, 4] * min(1, h0 * 1.1 + h1 * .15)); add('hairR1', cl[i, 4] * h1)
        tot = sum(bw.values()); tot = min(tot, .97)
        sc = tot / max(1e-6, sum(bw.values()))
        for k, v in bw.items(): w[i, k] = v * sc
        w[i, IDX['head']] = 1 - tot
    return w

def build_skin():
    js, meshes = load_old(os.path.join('/tmp/orig', 'killua.json'), os.path.join('/tmp/orig', 'killua.bin'))
    out = []
    for i, m in enumerate(meshes):
        p = m['pos']
        if i in (1, 3, 6):          # mắt, mặt, phần cổ áo đầu -> đầu cứng
            w = np.zeros((len(p), NB)); w[:, IDX['head']] = 1
        elif i == 2:                # tóc
            w = hair_weights(p)
        elif i in (4, 5, 8, 9):     # bàn tay -> cổ tay cứng
            w = np.zeros((len(p), NB)); w[:, IDX['wrL' if p[:, 0].mean() < 0 else 'wrR']] = 1
        elif i == 0:                # chi tiết nhỏ trước ngực -> ngực
            w = np.zeros((len(p), NB)); w[:, IDX['spine1']] = 1
        else:
            w = body_weights(p)
        # top-4
        ji = np.zeros((len(p), 4), np.uint8); jw = np.zeros((len(p), 4), np.float32)
        for v in range(len(p)):
            o = np.argsort(-w[v])[:4]; s = w[v][o].sum()
            ji[v] = o; jw[v] = w[v][o] / s
        out.append(dict(m, ji=ji, jw=jw, w=w))
    return js, out

def write_asset(js_old, meshes, name='killua'):
    chunks = []; off = 0; meta = {'bones': [], 'meshes': []}
    for i in range(NB):
        meta['bones'].append({'n': NAMES[i], 'p': int(PARENT[i]), 't': [round(float(v), 5) for v in LT[i]]})
    def push(arr):
        nonlocal off
        b = arr.tobytes(); o = off; chunks.append(b); off += len(b); pad = (4 - off % 4) % 4
        if pad: chunks.append(b'\0' * pad); off += pad
        return o
    for m in meshes:
        e = dict(m['meta']); e['v'] = len(m['pos']); e['i'] = len(m['idx'])
        e['pos'] = push(m['pos'].astype('<f4')); e['nor'] = push(m['nor'].astype('<f4')); e['uv'] = push(m['uv'].astype('<f4'))
        e['ji'] = push(m['ji']); e['jw'] = push(m['jw'].astype('<f4')); e['idx'] = push(m['idx'].astype('<u2'))
        meta['meshes'].append(e)
    open(os.path.join(ASSETS, name + '.bin'), 'wb').write(b''.join(chunks))
    json.dump(meta, open(os.path.join(ASSETS, name + '.json'), 'w'), separators=(',', ':'))
    print('wrote', name, 'bones', NB, 'bin', off)

if __name__ == '__main__':
    js, meshes = build_skin()
    import pickle; pickle.dump(meshes, open('/tmp/killua_skin.pkl', 'wb'))
    write_asset(js, meshes)
