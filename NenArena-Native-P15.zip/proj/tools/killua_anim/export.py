"""Bake toàn bộ clip -> assets/killua_anim.json + killua_anim.bin ; ghi docs/DANH_SACH_CHUYEN_DONG.md"""
import sys, json, os, numpy as np, time
import rig
from lib_core import CLIPS
import lib_combat, lib_loco, lib_acro, lib_react, lib_emote, lib_special
from motion import D, J

def clamp_limits(R):
    for s in 'LR':
        k = R[:, J['knee' + s], 0]; R[:, J['knee' + s], 0] = np.clip(k, -2, 155)
        e = R[:, J['el' + s], 0]; R[:, J['el' + s], 0] = np.clip(e, -155, 3)
    return R

def bake_all(verbose=True):
    t0 = time.time(); out = []
    for i, (n, c) in enumerate(CLIPS.items()):
        c.bake(); c.frames = clamp_limits(c.frames); out.append(c)
    if verbose: print('bake', len(out), 'clips', round(time.time() - t0, 1), 's')
    return out

def to_quats(c):
    N = len(c.frames); q = np.zeros((N, rig.NA, 4), np.float32)
    for i in range(N):
        R = rig.local_rotations(c.frames[i] * D)
        for j in range(rig.NA):
            v = rig.mat_to_quat(R[j]); q[i, j] = v / np.linalg.norm(v)
    # liên tục dấu
    for i in range(1, N):
        d = (q[i] * q[i - 1]).sum(-1); q[i][d < 0] *= -1
    return q

def write(clips):
    meta = {'fps': 30, 'bones': rig.ANIM, 'clips': []}; chunks = []; off = 0; nframes = 0
    for c in clips:
        q = to_quats(c); qi = np.clip(np.round(q * 32767), -32767, 32767).astype('<i2')
        rt = np.clip(np.round(c.rootf * 2000), -32767, 32767).astype('<i2')
        data = np.concatenate([qi.reshape(len(q), -1), rt], axis=1)   # (N, NA*4+3)
        b = data.tobytes(); chunks.append(b)
        e = {'n': c.name, 'c': c.cat, 'o': off, 'f': int(len(q)), 'd': round(c.dur, 4), 'l': 1 if c.loop else 0}
        if c.stride: e['s'] = round(float(c.stride), 4)
        hits = getattr(c, 'hits', None) or ([c.hit] if c.hit else [])
        if hits: e['h'] = [round(float(h), 3) for h in hits]
        meta['clips'].append(e); off += len(b); nframes += len(q)
    A = rig.ASSETS
    open(os.path.join(A, 'killua_anim.bin'), 'wb').write(b''.join(chunks))
    json.dump(meta, open(os.path.join(A, 'killua_anim.json'), 'w'), separators=(',', ':'), ensure_ascii=False)
    print('wrote killua_anim: clips', len(clips), 'frames', nframes, 'bytes', off)

def check(clips):
    bad = 0
    for c in clips:
        if not np.isfinite(c.frames).all() or not np.isfinite(c.rootf).all(): print('NaN', c.name); bad += 1
        mx = np.abs(c.rootf).max()
        if mx > 4: print('root xa', c.name, mx); bad += 1
    return bad

if __name__ == '__main__':
    cl = bake_all(); print('lỗi:', check(cl)); write(cl)
