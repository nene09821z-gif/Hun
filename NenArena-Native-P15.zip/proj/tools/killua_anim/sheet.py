"""Contact sheet: vẽ nhiều clip, mỗi clip K khung (nhìn nghiêng + trước nếu muốn)."""
import numpy as np, sys
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
import preview
from motion import D

def sheet(clips, path, K=8, views=(np.pi / 2,), cols_per_row=None, xlim=(-.7, .7), ylim=(-.05, 1.35), dpi=50, travel=False):
    ms = preview.load()
    rows = len(clips) * len(views)
    fig, axs = plt.subplots(rows, K, figsize=(K * 2.0, rows * 2.5), squeeze=False)
    r = 0
    for c in clips:
        if c.frames is None: c.bake()
        for v in views:
            for k in range(K):
                fi = int(round(k * (len(c.frames) - 1) / max(1, K - 1))) if not c.loop else k * len(c.frames) // K
                x0 = c.rootf[fi][0] * np.cos(v) + c.rootf[fi][2] * np.sin(v) if travel else 0
                preview.draw(axs[r, k], ms, c.frames[fi] * D, (0, c.rootf[fi][1], 0), yaw=v, xlim=(xlim[0] + x0 * 0, xlim[1]), ylim=ylim)
                if k == 0: axs[r, k].set_title(c.name + ('' if v == np.pi / 2 else ' (trước)'), fontsize=9, loc='left')
            r += 1
    plt.tight_layout(); plt.savefig(path, dpi=dpi); plt.close(fig)
