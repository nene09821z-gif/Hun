"""Tiện ích dựng tư thế/clip: build() với IK theo toạ độ thân, registry các clip."""
import numpy as np
from collections import OrderedDict
from motion import *
import rig

CLIPS = OrderedDict()
def reg(c):
    assert c.name not in CLIPS, c.name
    CLIPS[c.name] = c; return c

REL = P(a=(3, 0, 8), e=(-14, 0, 0), w=(-5, 0, 0), s1=(1, 0, 0), t=(0, 0, 0), k=(0, 0, 0), f=(0, 0, 0))

def yaw_of(p, upto='s1'):
    y = p.r[J['hips']][1]
    if upto in ('s0', 's1'): y += p.r[J['spine0']][1]
    if upto == 's1': y += p.r[J['spine1']][1]
    return y * D

def _rel(p, anchor, yaw, f, u, o, sd):
    v = np.array([sd * o, u, f], float)
    return anchor + ry(yaw) @ v

def build(base=None, **kw):
    """Khoá tư thế. Tham số:
    hip,s0,s1,nk,hd,root,cl(clL/clR) ... như Pose.set; a,e,w,t,k,f,o dạng thô (đối xứng);
    hL/hR=(f,u,o[,pole]) : cổ tay tới vị trí tương đối vai (f tiến, u lên, o ra ngoài) theo hướng thân;
    fL/fR=(f,u,o,pitch)  : cổ chân tới vị trí tương đối khớp hông (u âm = dưới hông);
    crouch=d : hạ thấp (chân co) khi chưa chỉ định chân; gw=độ rộng chân; stag=chân L tiến thêm."""
    p = (base or REL).copy()
    cr = kw.pop('crouch', 0.); gw = kw.pop('gw', 0.); stag = kw.pop('stag', 0.)
    hL = kw.pop('hL', None); hR = kw.pop('hR', None); fL = kw.pop('fL', None); fR = kw.pop('fR', None)
    pitch = kw.pop('pitch', None)
    late = {k: kw.pop(k) for k in list(kw) if k in ('wL', 'wR', 'oL', 'oR', 'w_', 'o_')}
    p.set(**kw)
    if fL is None: fL = (stag, -(.388 - cr), gw, 0)
    if fR is None: fR = (-stag, -(.388 - cr), gw, 0)
    yh = yaw_of(p, 'hips')
    for side, fx in (('L', fL), ('R', fR)):
        if fx is False: continue
        sd = -1 if side == 'L' else 1
        f = list(fx) + [0] * (4 - len(fx))
        hp = hip_pos(p, side); tgt = _rel(p, hp, yh, f[0], f[1], f[2], sd)
        leg_ik(p, side, tgt, pitch=f[3])
    ys = yaw_of(p, 's1')
    for side, hx in (('L', hL), ('R', hR)):
        if hx is None: continue
        sd = -1 if side == 'L' else 1
        pole = None
        if len(hx) > 3: pole = np.array([sd * hx[3][0], hx[3][1], hx[3][2]], float)
        sp = shoulder_pos(p, side); tgt = _rel(p, sp, ys, hx[0], hx[1], hx[2], sd)
        arm_ik(p, side, tgt, pole=(ry(ys) @ pole if pole is not None else None))
    for k, v in late.items():
        k = k.rstrip('_'); p.set(**{k: v})
    return p

def mk(name, keys, dur=None, loop=False, cat='', **kw):
    ks = []
    for t, pz in keys:
        if isinstance(pz, dict): pz = build(**pz)
        ks.append((t, pz))
    if dur is None: dur = ks[-1][0]
    return Clip(name, dur, ks, loop=loop, cat=cat, **kw)

def add(name, keys, dur=None, loop=False, cat='', **kw):
    return reg(mk(name, keys, dur, loop, cat, **kw))

def add_pair(name, fn, cat='', **kw):
    """fn(side) -> keys list hoặc (keys, dur, extra). Đăng ký name_L và name_R."""
    for s in 'LR':
        r = fn(s)
        keys, dur, ex = (r + (None, {}))[:3] if isinstance(r, tuple) else (r, None, {})
        k2 = dict(kw); k2.update(ex or {})
        add(f'{name}_{s}', keys, dur, cat=cat, **k2)

SD = {'L': -1, 'R': 1}
def opp(s): return 'R' if s == 'L' else 'L'
