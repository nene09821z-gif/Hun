"""
Bộ máy chuyển động cho Killua: Pose (21 khớp, độ) + IK tay/chân 2 đoạn + Clip (keyframe PCHIP) + bake.
Quy ước góc xem rig.py. Mọi toạ độ IK ở không gian model (cao ~1, mặt +Z), chưa cộng root.
"""
import numpy as np
import rig
from rig import ANIM, NA, IDX, euler, rx, ry, rz
D = np.pi / 180
J = {n: i for i, n in enumerate(ANIM)}
SIDE_JOINTS = ['clav', 'arm', 'el', 'wr', 'thigh', 'knee', 'ankle', 'toe']
SYM = {'a': 'arm', 'e': 'el', 'w': 'wr', 't': 'thigh', 'k': 'knee', 'f': 'ankle', 'o': 'toe', 'cl': 'clav'}
SINGLE = {'hip': 'hips', 's0': 'spine0', 's1': 'spine1', 'nk': 'neck', 'hd': 'head'}

def _v(x):
    if x is None: return None
    if np.isscalar(x): return np.array([x, 0, 0], float)
    x = list(x) + [0] * (3 - len(x)); return np.array(x[:3], float)

class Pose:
    """r: (21,3) độ; root: (x,y,z) đơn vị model (y = nâng khỏi mặt đất)."""
    def __init__(self, r=None, root=None):
        self.r = np.zeros((NA, 3)) if r is None else r.copy()
        self.root = np.zeros(3) if root is None else np.array(root, float)
    def copy(self): return Pose(self.r, self.root)
    def set(self, **kw):
        """Khoá đơn: hip,s0,s1,nk,hd,root. Cặp đối xứng (L giữ nguyên, R tự đối gương): a,e,w,t,k,f,o,cl.
        Cặp riêng: aL/aR, eL/eR... Tiền tố '_' = cộng thêm thay vì gán."""
        for k, val in kw.items():
            add = k.startswith('_'); k = k.lstrip('_')
            if k == 'root':
                self.root = self.root + _v(val) if add else _v(val); continue
            if k in SINGLE:
                j = J[SINGLE[k]]; self.r[j] = (self.r[j] + _v(val)) if add else _v(val); continue
            if k in SYM or (k[:-1] in SYM and k[-1] in 'LR'):
                if k in SYM: sides = 'LR'; base = SYM[k]; v = _v(val)
                else: sides = k[-1]; base = SYM[k[:-1]]; v = _v(val)
                for s in sides:
                    vv = v.copy()
                    if k in SYM and s == 'R' and not base == 'clav': vv[1] = -vv[1]; vv[2] = -vv[2]
                    j = J[base + s]; self.r[j] = (self.r[j] + vv) if add else vv
                continue
            raise KeyError(k)
        return self
    def jr(self, name): return self.r[J[name]] * D
    def mirrored(self):
        p = Pose(root=self.root * np.array([-1, 1, 1]))
        for n, i in J.items():
            if n.endswith('L') or n.endswith('R'):
                o = J[n[:-1] + ('R' if n.endswith('L') else 'L')]; v = self.r[i].copy()
                if not n.startswith('clav'): v[1] = -v[1]; v[2] = -v[2]
                p.r[o] = v
            else:
                v = self.r[i].copy(); v[1] = -v[1]; v[2] = -v[2]; p.r[i] = v
        return p
    def fk(self): return rig.fk(self.r * D, (0, 0, 0))
    def __repr__(self): return 'Pose'

def P(**kw): return Pose().set(**kw)
def blend(a, b, t): return Pose(a.r * (1 - t) + b.r * t, a.root * (1 - t) + b.root * t)

# ---------- IK 2 đoạn ----------
def _frame(a, b):
    a = a / np.linalg.norm(a); b = b - (b @ a) * a; n = np.linalg.norm(b)
    if n < 1e-6:
        t = np.array([1, 0, 0]) if abs(a[0]) < .9 else np.array([0, 0, 1]); b = t - (t @ a) * a; n = np.linalg.norm(b)
    b = b / n; return np.stack([a, b, np.cross(a, b)], 1)

def euler_from_mat(R):
    sy = np.clip(R[0, 2], -1, 1); y = np.arcsin(sy)
    if abs(sy) < .99999: x = np.arctan2(-R[1, 2], R[2, 2]); z = np.arctan2(-R[0, 1], R[0, 0])
    else: x = np.arctan2(R[2, 1], R[1, 1]); z = 0
    return np.array([x, y, z])

_ARMB = {'L': rz(rig.ARM_DOWN), 'R': rz(-rig.ARM_DOWN)}
def _ik(S, Rp, T, L1, L2, d0, sign, pole, twist=0.):
    """Trả (E_local 3x3 của khớp gốc, theta khuỷu/gối). S: vị trí khớp gốc (thế giới), Rp: quay thế giới của cha."""
    v = T - S; d = np.linalg.norm(v); dmax = (L1 + L2) * .9995; dmin = abs(L1 - L2) * 1.02 + 1e-3
    d = np.clip(d, dmin, dmax); ah = v / np.linalg.norm(v)
    T2 = S + ah * d
    cpsi = np.clip((L1 * L1 + L2 * L2 - d * d) / (2 * L1 * L2), -1, 1)          # góc trong tại khuỷu
    psi = np.arccos(cpsi)
    # tìm theta: d0·(Rx(theta) d0) = cos(psi_between) với psi_between = pi - psi
    cb = np.cos(np.pi - psi)   # góc giữa cánh tay trên và cẳng tay (hướng) = pi - góc trong
    # d0·Rx(th)d0 = d0x^2 + (d0y^2 + d0z^2) cos th  (d0z = 0)
    ct = np.clip((cb - d0[0] ** 2) / (d0[1] ** 2 + d0[2] ** 2), -1, 1)
    th = sign * np.arccos(ct)
    f_local = rx(th) @ d0
    alpha = np.arccos(np.clip((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1))
    pv = pole - (pole @ ah) * ah
    if np.linalg.norm(pv) < 1e-5: pv = np.cross(ah, np.array([0, 0, 1.]))
    pv /= np.linalg.norm(pv)
    if twist: # xoay khuỷu quanh trục S->T
        c, s = np.cos(twist), np.sin(twist); pv = pv * c + np.cross(ah, pv) * s
    el = S + L1 * (np.cos(alpha) * ah + np.sin(alpha) * pv)
    u = (el - S) / L1; f = (T2 - el) / L2
    A = _frame(d0, f_local); Bm = _frame(u, f)
    Ew = Bm @ A.T            # quay thế giới: d0 -> u
    El = Rp.T @ Ew
    return El, th

ARM_L1, ARM_L2 = .14, .12
LEG_L1, LEG_L2 = .23, .17
def arm_ik(p, side, target, pole=None, twist=0., wrist=None):
    """Đặt tay `side` ('L'/'R') sao cho cổ tay chạm `target` (không gian model)."""
    Rw, Pw = p.fk(); sd = -1 if side == 'L' else 1
    S = Pw[IDX['arm' + side]]; Rp = Rw[IDX['clav' + side]]
    if pole is None: pole = np.array([sd * .5, -1, -.35])
    d0 = _ARMB[side] @ np.array([sd, 0, 0.])   # hướng xương cánh tay ở tư thế treo
    El, th = _ik(S, Rp, np.array(target, float), ARM_L1, ARM_L2, d0, -1, np.array(pole, float), twist)
    p.r[J['arm' + side]] = euler_from_mat(El) / D
    e = p.r[J['el' + side]]; e[0] = th / D; e[1] = 0; e[2] = 0
    if wrist is not None: p.r[J['wr' + side]] = _v(wrist)
    return p

def leg_ik(p, side, target, pitch=0., pole=None, yaw=0., toe=0.):
    """Đặt cổ chân `side` tại `target`; pitch = góc bàn chân so với mặt đất (độ, + = mũi chân chúc xuống)."""
    Rw, Pw = p.fk(); sd = -1 if side == 'L' else 1
    S = Pw[IDX['thigh' + side]]; Rp = Rw[IDX['hips']]
    if pole is None: pole = np.array([sd * .12, 0, 1.])
    El, th = _ik(S, Rp, np.array(target, float), LEG_L1, LEG_L2, np.array([0, -1, 0.]), +1, np.array(pole, float))
    p.r[J['thigh' + side]] = euler_from_mat(El) / D
    k = p.r[J['knee' + side]]; k[0] = th / D; k[1] = 0; k[2] = 0
    # bàn chân: quay thế giới mong muốn Rx(pitch) Ry(yaw)
    Rw2, _ = p.fk(); Rs = Rw2[IDX['knee' + side]]
    want = rx(pitch * D) @ ry(yaw * D)
    p.r[J['ankle' + side]] = euler_from_mat(Rs.T @ want) / D
    p.r[J['toe' + side]] = np.array([toe, 0, 0])
    return p

def hip_pos(p, side):
    return p.fk()[1][IDX['thigh' + side]]
def shoulder_pos(p, side):
    return p.fk()[1][IDX['arm' + side]]

# ---------- Clip ----------
def _pchip_slopes(t, y):
    n = len(t); h = np.diff(t); dl = np.diff(y, axis=0) / h[:, None]
    m = np.zeros_like(y)
    if n == 2: m[:] = dl[0]; return m
    for k in range(1, n - 1):
        a = dl[k - 1]; b = dl[k]
        w1 = 2 * h[k] + h[k - 1]; w2 = h[k] + 2 * h[k - 1]
        den = w1 / np.where(a == 0, 1, a) + w2 / np.where(b == 0, 1, b)
        hm = (w1 + w2) / np.where(den == 0, 1, den)
        m[k] = np.where(a * b > 0, hm, 0)
    def end(h0, h1, d0, d1):
        s = ((2 * h0 + h1) * d0 - h0 * d1) / (h0 + h1)
        s = np.where(np.sign(s) != np.sign(d0), 0, s)
        s = np.where((np.sign(d0) != np.sign(d1)) & (np.abs(s) > 3 * np.abs(d0)), 3 * d0, s); return s
    m[0] = end(h[0], h[1], dl[0], dl[1]); m[-1] = end(h[-1], h[-2], dl[-1], dl[-2])
    return m

def _eval(t, y, m, x):
    x = np.clip(x, t[0], t[-1]); k = np.clip(np.searchsorted(t, x, side='right') - 1, 0, len(t) - 2)
    h = t[k + 1] - t[k]; s = (x - t[k]) / h
    h00 = 2 * s ** 3 - 3 * s ** 2 + 1; h10 = s ** 3 - 2 * s ** 2 + s; h01 = -2 * s ** 3 + 3 * s ** 2; h11 = s ** 3 - s ** 2
    return h00[:, None] * y[k] + h10[:, None] * h[:, None] * m[k] + h01[:, None] * y[k + 1] + h11[:, None] * h[:, None] * m[k + 1]

LAG = {'neck': .03, 'head': .06, 'spine1': .02, 'wrL': .035, 'wrR': .035, 'toeL': .03, 'toeR': .03, 'ankleL': .015, 'ankleR': .015, 'elL': .012, 'elR': .012}

class Clip:
    def __init__(self, name, dur, keys, loop=False, ground='auto', cat='', fps=30, lag=True, breath=0., stab=0., hit=None, tags=(), mask='full', stride=0., travel=None):
        """keys: [(t_giây, Pose)]. loop: khoá cuối tự nối về khoá đầu (không cần lặp lại khoá đầu).
        ground: 'auto' = bàn chân thấp nhất chạm đất; 'free' = dùng root.y của khoá (chỉ chống lún sàn)."""
        self.name = name; self.dur = dur; self.keys = keys; self.loop = loop; self.ground = ground; self.cat = cat; self.fps = fps
        self.lag = lag; self.breath = breath; self.stab = stab; self.hit = hit; self.tags = tags; self.mask = mask; self.stride = stride; self.travel = travel
        self.frames = None; self.rootf = None

    def _channels(self):
        ks = sorted(self.keys, key=lambda k: k[0]); fixed = []
        if self.loop: ks = [k for k in ks if k[0] < self.dur - 1e-3]
        for t, p in ks:
            if fixed and t - fixed[-1][0] < 1e-3: t = fixed[-1][0] + 1e-3
            fixed.append((t, p))
        self.keys = fixed
        ts = np.array([k[0] for k in self.keys], float)
        Y = np.stack([np.concatenate([k[1].r.ravel(), k[1].root]) for k in self.keys])
        if self.loop:
            ts = np.concatenate([ts - self.dur, ts, ts + self.dur, [ts[0] + 2 * self.dur]]);  # lặp 3 lần
            Y = np.concatenate([Y, Y, Y, Y[:1]])
        return ts, Y

    def sample(self, t):
        ts, Y = self._channels(); m = _pchip_slopes(ts, Y)
        out = np.zeros((len(t), Y.shape[1]))
        if self.lag and self.dur > .25:
            lagj = np.zeros(NA)
            for n, v in LAG.items(): lagj[J[n]] = v
            for j in range(NA):
                tt = np.asarray(t, float) - lagj[j]
                if not self.loop: tt = np.clip(tt, 0, self.dur)
                out[:, j * 3:j * 3 + 3] = _eval(ts, Y[:, j * 3:j * 3 + 3], m[:, j * 3:j * 3 + 3], tt)
            out[:, NA * 3:] = _eval(ts, Y[:, NA * 3:], m[:, NA * 3:], np.asarray(t, float))
        else:
            out = _eval(ts, Y, m, np.asarray(t, float))
        return out

    def bake(self):
        n = int(round(self.dur * self.fps)); n = max(n, 2)
        N = n if self.loop else n + 1
        t = np.arange(N) * (self.dur / n)
        S = self.sample(t); R = S[:, :NA * 3].reshape(N, NA, 3).copy(); root = S[:, NA * 3:].copy()
        # ổn định đầu, thở
        if self.stab:
            yaw = R[:, J['hips'], 1] + R[:, J['spine0'], 1] + R[:, J['spine1'], 1]; roll = R[:, J['hips'], 2] + R[:, J['spine0'], 2] + R[:, J['spine1'], 2]
            R[:, J['neck'], 1] -= .30 * self.stab * yaw; R[:, J['head'], 1] -= .40 * self.stab * yaw
            R[:, J['neck'], 2] -= .30 * self.stab * roll; R[:, J['head'], 2] -= .40 * self.stab * roll
        if self.breath:
            cyc = max(1, round(self.dur / 3.2)); ph = np.arange(N) / n * 2 * np.pi * cyc
            R[:, J['spine1'], 0] -= self.breath * 1.4 * np.sin(ph); R[:, J['spine0'], 0] += self.breath * .5 * np.sin(ph)
            R[:, J['clavL'], 2] += self.breath * .9 * np.sin(ph); R[:, J['clavR'], 2] += self.breath * .9 * np.sin(ph)
            R[:, J['head'], 0] += self.breath * .6 * np.sin(ph + .6)
        # tiếp đất / chống lún
        ys = np.zeros(N)
        for i in range(N):
            Rw, Pw = rig.fk(R[i] * D, (0, 0, 0))
            foot = min(Pw[IDX['toeL']][1] - .03, Pw[IDX['toeR']][1] - .03, Pw[IDX['ankleL']][1] - .07, Pw[IDX['ankleR']][1] - .07)
            pts = body_points(Rw, Pw); allmin = pts[:, 1].min()
            lift = root[i, 1]
            if self.ground == 'auto': y = -foot + lift
            else: y = lift
            y = max(y, -allmin + .005) if self.ground != 'none' else y
            ys[i] = y
        root[:, 1] = ys
        self.frames = R; self.rootf = root
        if self.stride == -1 or self.stride == -2: self.stride = self._measure(R, root, 'z' if self.stride == -1 else 'x')
        return self

    def _measure(self, R, root, axis):
        N = len(R); ax = 2 if axis == 'z' else 0; pts = []
        for i in range(N):
            Rw, Pw = rig.fk(R[i] * D, (0, 0, 0)); Pw = Pw + root[i]
            row = []
            for s in 'LR':
                cands = [Pw[IDX['toe' + s]] + Rw[IDX['toe' + s]] @ np.array([0, -.03, .06]), Pw[IDX['ankle' + s]] + Rw[IDX['ankle' + s]] @ np.array([0, -.05, -.05])]
                c = min(cands, key=lambda q: q[1]); row.append(c)
            pts.append(row)
        pts = np.array(pts); vel = []
        for i in range(N):
            j = (i + 1) % N
            for s in (0, 1):
                if pts[i, s, 1] < .02 and pts[j, s, 1] < .02:
                    vel.append(-(pts[j, s, ax] - pts[i, s, ax]) * N)
        if not vel: return 0.
        return float(abs(np.mean(vel)))

def body_points(Rw, Pw):
    pts = [Pw[IDX[n]] for n in ('hips', 'spine1', 'head', 'elL', 'elR', 'kneeL', 'kneeR', 'ankleL', 'ankleR', 'toeL', 'toeR', 'wrL', 'wrR')]
    pts.append(Pw[IDX['head']] + Rw[IDX['head']] @ np.array([0, .2, 0]))
    pts.append(Pw[IDX['wrL']] + Rw[IDX['wrL']] @ np.array([-.12, 0, 0])); pts.append(Pw[IDX['wrR']] + Rw[IDX['wrR']] @ np.array([.12, 0, 0]))
    pts.append(Pw[IDX['toeL']] + Rw[IDX['toeL']] @ np.array([0, -.03, .06])); pts.append(Pw[IDX['toeR']] + Rw[IDX['toeR']] @ np.array([0, -.03, .06]))
    pts.append(Pw[IDX['ankleL']] + Rw[IDX['ankleL']] @ np.array([0, -.05, -.05])); pts.append(Pw[IDX['ankleR']] + Rw[IDX['ankleR']] @ np.array([0, -.05, -.05]))
    pts.append(Pw[IDX['spine1']] + Rw[IDX['spine1']] @ np.array([0, .04, -.1])); pts.append(Pw[IDX['hips']] + Rw[IDX['hips']] @ np.array([0, -.05, -.12]))
    return np.array(pts)

def mirror_clip(c, name):
    keys = [(t, p.mirrored()) for t, p in c.keys]
    n = Clip(name, c.dur, keys, c.loop, c.ground, c.cat, c.fps, c.lag, c.breath, c.stab, c.hit, c.tags, c.mask, c.stride, c.travel)
    return n
