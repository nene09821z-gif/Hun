"""Di chuyển (chu kỳ theo tốc độ), đứng yên, quay người, thở/nghịch ngợm khi rảnh."""
from lib_core import *
import gait
from gait import WALK, JOG, RUN, SPRINT, make_cycle, gait_poses, measure_stride, cyc
import numpy as np

def gait_clip(name, Pm, post=None, rev=False, cat='loco', dur=1.0, **kw):
    poses = gait_poses(Pm, **{k: v for k, v in kw.items() if k in ('back',)})
    if post: poses = [(p, post(p, ps)) for p, ps in poses]
    if rev: poses = [(1 - p, ps) for p, ps in poses][::-1]; poses = [((i / len(poses)), ps) for i, (_, ps) in enumerate(poses)]
    keys = [(p * dur, ps) for p, ps in poses]
    return reg(Clip(name, dur, keys, loop=True, ground='auto', cat=cat, stride=-1, stab=.6, lag=False))

def hands_guard(L=(.13, -.05, .06), R=(.13, -.05, .06)):
    def f(p, ps):
        q = ps.copy()
        q = build(base=q, hL=L, hR=R)
        return q
    return f

def lean(a_hips, a_sp, a_nk=0, crouch=0.):
    def f(p, ps):
        q = ps.copy(); q.set(_hip=(a_hips, 0, 0), _s0=(a_sp, 0, 0), _s1=(a_sp * .6, 0, 0), _nk=(a_nk, 0, 0))
        return q
    return f

def chain(*fs):
    def f(p, ps):
        for g in fs: ps = g(p, ps)
        return ps
    return f

# ---- đi / chạy (chuỗi theo tốc độ)
gait_clip('walk', WALK)
gait_clip('jog', JOG)
gait_clip('run', RUN)
gait_clip('sprint', SPRINT)
gait_clip('walk_relaxed', dict(WALK, hipA=20, armA=26, elb=14, yaw=8, roll=4.5, sway=.016, lean=-1))
gait_clip('walk_strut', dict(WALK, hipA=22, yaw=10, roll=6, sway=.02, armA=14, elb=22, lean=-3), post=lambda p, ps: (ps.set(_hd=(-3, 0, 0), _s1=(-3, 0, 0)), ps)[1])
gait_clip('walk_combat', dict(WALK, hipA=18, kLoad=14, yaw=3, armA=0, elbA=0), post=hands_guard((.15, -.06, .07), (.13, -.03, .04)))
gait_clip('walk_sneak', dict(WALK, hipA=22, kLoad=18, kSw=70, yaw=4, roll=2, armA=8, elb=36, lean=14), post=lambda p, ps: (ps.set(_hip=(6, 0, 0), _s0=(10, 0, 0), _nk=(-6, 0, 0), _hd=(-4, 0, 0)), ps)[1])
gait_clip('walk_tired', dict(WALK, hipA=16, kSw=48, ankPush=8, armA=10, elb=10, lean=12, yaw=3, sway=.02), post=lambda p, ps: (ps.set(_s0=(8, 0, 0), _s1=(10, 0, 0), _hd=(10, 0, 0)), ps)[1])
def limp(p, ps):
    q = ps.copy(); w = .5 * (1 + np.cos(2 * np.pi * p))
    q.set(_s0=(4, 0, 3), _hd=(4, 0, 0)); q.root = q.root + np.array([.0, -.01, 0]); return q
gait_clip('walk_limp', dict(WALK, hipA=18, kLoad=14, kSw=48, yaw=3, roll=7, sway=.03, armA=8, lean=6), post=limp)
gait_clip('walk_hands_head', dict(WALK, hipA=22, yaw=7, roll=4, armA=0), post=lambda p, ps: (ps.set(a=(-170, 0, 40), e=(-120, 0, 0)) if False else build(base=ps, hL=(-.04, .22, .08), hR=(-.04, .22, .08), hd=(-4, 0, 0)), ps)[1] if False else build(base=ps, hL=(-.05, .20, .06), hR=(-.05, .20, .06)))
gait_clip('run_godspeed', dict(SPRINT, lean=36, armA=40, elb=100, lift=.11, hipA=52, yaw=8), post=lambda p, ps: (ps.set(_hip=(8, 0, 0), _s0=(8, 0, 0), _nk=(-14, 0, 0), _hd=(-10, 0, 0), a=(40, 0, 18)), ps)[1])
gait_clip('run_anime', dict(RUN, lean=34, armA=0, elb=0, elbA=0, yaw=6, lift=.06), post=lambda p, ps: (ps.set(a=(48, 0, 4), e=(-6, 0, 0), _nk=(-12, 0, 0), _hd=(-10, 0, 0), w=(10, 0, 0)), ps)[1])
gait_clip('run_guard', dict(RUN, lean=8, armA=0, armAb=0), post=hands_guard((.15, -.05, .07), (.13, -.03, .04)))
gait_clip('run_tired', dict(JOG, hipA=28, kSw=70, ankPush=14, lean=16, armA=24, elb=60, lift=.01, yaw=6), post=lambda p, ps: (ps.set(_s1=(8, 0, 0), _hd=(8, 0, 0)), ps)[1])
gait_clip('run_sneak', dict(JOG, lean=24, kLoad=34, kSw=100, lift=.0, armA=14, elb=80), post=lambda p, ps: (ps.set(_hip=(10, 0, 0), _s0=(12, 0, 0), _nk=(-12, 0, 0), _hd=(-8, 0, 0)), ps)[1])
gait_clip('run_scared', dict(RUN, hipA=40, armA=62, elb=40, lean=10, yaw=16, lift=.045), post=lambda p, ps: (ps.set(_hd=(-6, 0, 0), a=(10, 0, 30)), ps)[1])
gait_clip('run_cheer', dict(JOG, armA=0, elb=0, lift=.03), post=lambda p, ps: (ps.set(a=(-170, 0, -30 * (1 if False else 1))), ps)[1])
gait_clip('back_walk', WALK, back=True, rev=True, post=lean(-2, -3))
gait_clip('back_run', JOG, back=True, rev=True, post=lean(-4, -6, 2))
gait_clip('back_walk_guard', dict(WALK, armA=0), rev=True, post=hands_guard((.14, -.05, .07), (.12, -.03, .04)))

# ---- strafe (IK chân): dirx=+1 bước sang phía +X (bên R), -1 sang phía L
def strafe(name, dirx, A=.12, Lh=.05, bob=.012, speedy=False, guard=True):
    N = 16; keys = []; lead = 'R' if dirx > 0 else 'L'
    for i in range(N):
        p = i / N; kw = {}
        for side, ph in (('L', p), ('R', p + .5)):
            sd = SD[side]; X = dirx * A * np.cos(2 * np.pi * ph); lift = Lh * max(0, -np.sin(2 * np.pi * ph))
            kw['f' + side] = (0, -(.386 - (.03 if speedy else .01)) + lift, X * sd, 0)
        kw.update(crouch=0, hip=(2, -dirx * 10, -dirx * 2 * np.sin(2 * np.pi * p)), s0=(6, dirx * 10, dirx * 3), s1=(6, dirx * 6, 0), hd=(0, -dirx * 10, 0), root=(-dirx * .01 * np.sin(2 * np.pi * p), bob * np.cos(4 * np.pi * p), 0))
        if guard: kw.update(hL=(.14, -.06, .07), hR=(.14, -.06, .07))
        keys.append((p, build(**kw)))
    c = Clip(name, 1.0, [(t, k) for t, k in keys], loop=True, ground='auto', cat='loco', stab=0, lag=False)
    # sải ngang: biên độ chân (2A mỗi nửa chu kỳ) -> quãng ngang mỗi chu kỳ = 4A
    c.stride = -2; reg(c)
strafe('strafe_walk_L', -1, A=.09, Lh=.03); strafe('strafe_walk_R', 1, A=.09, Lh=.03)
strafe('strafe_run_L', -1, A=.16, Lh=.07, bob=.02); strafe('strafe_run_R', 1, A=.16, Lh=.07, bob=.02)
strafe('strafe_sprint_L', -1, A=.2, Lh=.09, bob=.03); strafe('strafe_sprint_R', 1, A=.2, Lh=.09, bob=.03)

# ---- đứng yên (vòng lặp, có thở)
def idle(name, keys, dur, **kw):
    add(name, [(t * dur, k) for t, k in keys], dur, loop=True, cat='idle', breath=kw.pop('breath', 1.0), stab=.5, **kw)

idle('idle_relaxed', [(0, dict(hip=(0, 0, 1.5), s0=(1, 1.5, -1))), (.5, dict(hip=(0, 0, -1.5), s0=(2, -1.5, 1), hd=(1, 3, 0), a=(3, 0, 9))), ], 4.8)
idle('idle_relaxed_shift_L', [(0, dict(hip=(0, 0, 4), s0=(0, 0, -3), crouch=0, fR=(0, -.37, 0, 0), fL=(.02, -.39, .02, 0), a=(3, 0, 9))), (.5, dict(hip=(0, 0, 3), s0=(1, 2, -2), fR=(0, -.37, 0, 0), hd=(0, 8, 0)))], 5.2)
idle('idle_relaxed_shift_R', [(0, dict(hip=(0, 0, -4), s0=(0, 0, 3), fL=(0, -.37, 0, 0), fR=(.02, -.39, .02, 0))), (.5, dict(hip=(0, 0, -3), s0=(1, -2, 2), fL=(0, -.37, 0, 0), hd=(0, -8, 0)))], 5.2)
for lead in 'LR':
    sd = SD[lead]
    idle(f'idle_ready_{lead}', [(0, dict(crouch=.05, gw=.045, stag=-.09 * sd, hip=(2, -sd * 11, 0), s0=(6, -sd * 13, 0), s1=(6, -sd * 11, 0), hd=(3, sd * 20, 0), hL=(.15, -.06, .07), hR=(.13, -.03, .04) if lead == 'L' else (.15, -.06, .07))),
                                (.25, dict(crouch=.075, gw=.045, stag=-.09 * sd, hip=(2, -sd * 11, 0), s0=(7, -sd * 13, 0), s1=(7, -sd * 11, 0), hd=(3, sd * 20, 0), hL=(.14, -.07, .07), hR=(.13, -.04, .04) if lead == 'L' else (.14, -.07, .07))),
                                (.5, dict(crouch=.05, gw=.045, stag=-.09 * sd, hip=(2, -sd * 11, 0), s0=(6, -sd * 13, 0), s1=(6, -sd * 11, 0), hd=(3, sd * 20, 0), hL=(.15, -.06, .07), hR=(.13, -.03, .04) if lead == 'L' else (.15, -.06, .07))),
                                (.75, dict(crouch=.075, gw=.045, stag=-.09 * sd, hip=(2, -sd * 11, 0), s0=(7, -sd * 13, 0), s1=(7, -sd * 11, 0), hd=(3, sd * 20, 0), hL=(.14, -.07, .07), hR=(.13, -.04, .04) if lead == 'L' else (.14, -.07, .07)))], 1.6 if False else 1.2, breath=.6)
idle('idle_alert', [(0, dict(crouch=.02, gw=.03, hd=(0, 0, 0), hL=(.10, -.12, .09), hR=(.10, -.12, .09))), (.3, dict(crouch=.02, gw=.03, hd=(0, 28, 0), s1=(0, 8, 0), hL=(.10, -.12, .09), hR=(.10, -.12, .09))),
                     (.55, dict(crouch=.02, gw=.03, hd=(0, -28, 0), s1=(0, -8, 0), hL=(.10, -.12, .09), hR=(.10, -.12, .09))), (.8, dict(crouch=.025, gw=.03, hd=(-3, 0, 0), hL=(.10, -.12, .09), hR=(.10, -.12, .09)))], 5.0)
idle('idle_hands_head', [(0, dict(hL=(-.06, .20, .07), hR=(-.06, .20, .07), hip=(0, 0, 2), hd=(-3, 0, 0), s1=(-3, 0, 0))), (.5, dict(hL=(-.06, .20, .07), hR=(-.06, .20, .07), hip=(0, 0, -2), hd=(-5, 4, 0), s1=(-4, 0, 0)))], 5.0)
idle('idle_arms_crossed', [(0, dict(hL=(.10, -.07, -.14), hR=(.10, -.04, -.14), hip=(0, 0, 3), hd=(2, 6, 0), fR=(.0, -.37, 0), fL=(.02, -.39, .03))), (.5, dict(hL=(.10, -.07, -.14), hR=(.10, -.04, -.14), hip=(0, 0, 2.5), hd=(3, -6, 0)))], 5.5)
idle('idle_bored', [(0, dict(hip=(0, 0, 3), s0=(6, 0, 0), s1=(6, 0, 0), hd=(10, 8, 0), a=(8, 0, 10))), (.35, dict(hip=(0, 0, 3.5), s0=(7, 0, 0), s1=(6, 0, 0), hd=(8, -10, 0), a=(10, 0, 10), fL=(.05, -.385, .0, 0))), (.7, dict(hip=(0, 0, 3), s0=(6, 0, 0), s1=(6, 0, 0), hd=(12, 6, 0), a=(8, 0, 10)))], 6.0)
idle('idle_tired', [(0, dict(crouch=.05, s0=(14, 0, 0), s1=(14, 0, 0), nk=(8, 0, 0), hd=(10, 0, 0), a=(8, 0, 6), hL=(.0, -.2, .08), hR=(.0, -.2, .08))), (.5, dict(crouch=.07, s0=(19, 0, 0), s1=(18, 0, 0), nk=(10, 0, 0), hd=(12, 0, 0), a=(10, 0, 6), hL=(.02, -.22, .08), hR=(.02, -.22, .08)))], 1.6, breath=3.0)
for lead in 'LR':
    sd = SD[lead]
    idle(f'idle_stalk_{lead}', [(0, dict(crouch=.14, gw=.05, stag=-.1 * sd, hip=(8, -sd * 10, 0), s0=(14, -sd * 10, 0), s1=(10, -sd * 8, 0), nk=(-10, 0, 0), hd=(-6, sd * 14, 0), hL=(.12, -.14, .08), hR=(.12, -.14, .08))),
                                (.5, dict(crouch=.16, gw=.05, stag=-.1 * sd, hip=(9, -sd * 10, 0), s0=(15, -sd * 10, 0), s1=(11, -sd * 8, 0), nk=(-10, 0, 0), hd=(-6, sd * 14, 0), hL=(.12, -.14, .08), hR=(.12, -.14, .08)))], 3.6)
idle('idle_crouch', [(0, dict(crouch=.20, gw=.07, hip=(10, 0, 0), s0=(18, 0, 0), s1=(14, 0, 0), nk=(-12, 0, 0), hL=(.08, -.18, .1), hR=(.08, -.18, .1))), (.5, dict(crouch=.215, gw=.07, hip=(11, 0, 0), s0=(19, 0, 0), s1=(14, 0, 0), nk=(-12, 0, 0), hd=(-3, 10, 0), hL=(.08, -.18, .1), hR=(.08, -.18, .1)))], 4.0)
idle('idle_charged', [(0, dict(crouch=.06, gw=.06, hip=(2, 0, 0), s0=(8, 0, 0), s1=(8, 0, 0), a=(-4, 0, 22), e=(-30, 0, 0), hd=(6, 0, 0))), (.5, dict(crouch=.07, gw=.06, hip=(2, 0, 0), s0=(9, 0, 0), s1=(9, 0, 0), a=(-6, 0, 26), e=(-34, 0, 0), hd=(7, 0, 0)))], .9, breath=1.5)
idle('idle_hum', [(0, dict(hip=(0, 0, 1), hd=(0, 0, 4), a=(3, 0, 8))), (.25, dict(hip=(0, 0, -1), hd=(2, 0, -4), a=(3, 0, 8))), (.5, dict(hip=(0, 0, 1), hd=(0, 0, 4), a=(3, 0, 8))), (.75, dict(hip=(0, 0, -1), hd=(2, 0, -4), a=(3, 0, 8)))], 2.4)
idle('idle_think', [(0, dict(hR=(.08, .08, -.02), hL=(.04, -.12, -.12), hd=(10, 0, 6), s1=(4, 0, 0), hip=(0, 0, 3), fL=(.0, -.37, 0), fR=(.03, -.39, .03))), (.5, dict(hR=(.08, .08, -.02), hL=(.04, -.12, -.12), hd=(12, -6, 8), s1=(5, 0, 0), hip=(0, 0, 2)))], 5.0)
idle('idle_pockets', [(0, dict(hL=(.0, -.22, -.04), hR=(.0, -.22, -.04), hip=(0, 0, 2), s1=(3, 0, 0), hd=(0, 0, 0))), (.5, dict(hL=(.0, -.22, -.04), hR=(.0, -.22, -.04), hip=(0, 0, -2), s1=(3, 0, 0), hd=(2, 8, 0)))], 5.0)

# ---- quay người tại chỗ
def turn(name, ang, dur=.45):
    k = lambda f: dict(hip=(0, ang * f * .5, 0), s0=(2, ang * f * .35, 0), s1=(2, ang * f * .15, 0), hd=(0, ang * f * .1, 0), crouch=.03, gw=.03)
    add(name, [(0, dict(crouch=.02)), (dur * .35, k(.4)), (dur * .7, dict(k(1), hip=(0, ang * .5, 0))), (dur, dict(crouch=.02))], dur, cat='loco', ground='auto')
    # (quay thật do game xoay root; clip chỉ là bước chân/nghiêng người)
for a in (90, 180): turn(f'turn_L{a}', -a, .35 + a / 600.); turn(f'turn_R{a}', a, .35 + a / 600.)

# ---- nghịch ngợm khi rảnh (không lặp)
def fid(name, keys, dur, cat='fidget', **kw):
    add(name, [(t * dur, k) for t, k in keys], dur, cat=cat, breath=0, stab=.3, **kw)
fid('fidget_neck_crack', [(0, {}), (.25, dict(hd=(0, 0, 16), nk=(0, 0, 8))), (.4, dict(hd=(0, 0, 24), nk=(0, 0, 10))), (.55, dict(hd=(0, 0, -16), nk=(0, 0, -8))), (.7, dict(hd=(0, 0, -22), nk=(0, 0, -10))), (.88, {}), (1, {})], 2.2)
fid('fidget_shrug', [(0, {}), (.3, dict(clL=(0, 18), clR=(0, 18), hd=(0, 0, 6), a=(0, 0, 14), e=(-30, 0, 0))), (.6, dict(clL=(0, 18), clR=(0, 18), hd=(0, 0, 6), a=(0, 0, 14), e=(-30, 0, 0))), (1, {})], 1.4)
fid('fidget_stretch_arms', [(0, {}), (.3, dict(hL=(.0, .42, .04), hR=(.0, .42, .04), s0=(-10, 0, 0), s1=(-10, 0, 0), hd=(-10, 0, 0))), (.65, dict(hL=(.0, .42, .04), hR=(.0, .42, .04), s0=(-14, 0, 0), s1=(-12, 0, 0), hd=(-14, 0, 0))), (1, {})], 3.0)
fid('fidget_yawn', [(0, {}), (.3, dict(hR=(.1, .12, -.03), hd=(-18, 0, 0), s0=(-4, 0, 0), s1=(-6, 0, 0))), (.7, dict(hR=(.1, .12, -.03), hd=(-20, 0, 0), s0=(-5, 0, 0), s1=(-6, 0, 0))), (1, {})], 3.2)
fid('fidget_look_around', [(0, {}), (.25, dict(hd=(0, 55, 0), s1=(0, 14, 0), hip=(0, 6, 0))), (.5, dict(hd=(0, 55, 0), s1=(0, 14, 0), hip=(0, 6, 0))), (.75, dict(hd=(0, -55, 0), s1=(0, -14, 0), hip=(0, -6, 0))), (1, {})], 3.4)
fid('fidget_scratch_head', [(0, {}), (.25, dict(hR=(.0, .24, .06), hd=(0, 0, -6))), (.4, dict(hR=(-.02, .26, .1), hd=(0, 0, -6))), (.55, dict(hR=(.02, .24, .04), hd=(0, 0, -6))), (.7, dict(hR=(-.02, .26, .1), hd=(0, 0, -6))), (1, {})], 2.4)
fid('fidget_knuckles', [(0, {}), (.25, dict(hL=(.14, -.06, -.04), hR=(.14, -.06, -.04), s0=(6, 0, 0), hd=(8, 0, 0))), (.5, dict(hL=(.12, -.04, -.0), hR=(.14, -.08, -.04), s0=(6, 0, 0), hd=(10, 0, 0))), (.75, dict(hL=(.14, -.06, -.04), hR=(.12, -.04, -.0), s0=(6, 0, 0), hd=(8, 0, 0))), (1, {})], 2.4)
fid('fidget_bounce', [(0, {}), (.15, dict(crouch=.08)), (.3, dict(root=(0, .04, 0))), (.45, dict(crouch=.08)), (.6, dict(root=(0, .04, 0))), (.75, dict(crouch=.06)), (1, {})], 1.4)
fid('fidget_shake_arms', [(0, {}), (.2, dict(a=(0, 0, 18), e=(-30, 0, 0), w=(0, 0, 25))), (.35, dict(a=(0, 0, 6), e=(-10, 0, 0), w=(0, 0, -25))), (.5, dict(a=(0, 0, 18), e=(-30, 0, 0), w=(0, 0, 25))), (.65, dict(a=(0, 0, 6), e=(-10, 0, 0), w=(0, 0, -25))), (1, {})], 2.0)
fid('fidget_sigh', [(0, {}), (.35, dict(s0=(-3, 0, 0), s1=(-6, 0, 0), clL=(0, 10), clR=(0, 10), hd=(-8, 0, 0))), (.65, dict(s0=(10, 0, 0), s1=(12, 0, 0), clL=(0, -6), clR=(0, -6), hd=(14, 0, 0))), (1, {})], 3.0)
fid('fidget_stretch_legs', [(0, {}), (.35, dict(fL=(.0, -.375, .02, 0), fR=(-.16, -.375, .0, 0), s0=(14, 0, 0), s1=(14, 0, 0), hL=(.1, -.3, .0), hR=(.1, -.3, .0), hd=(6, 0, 0))), (.7, dict(fL=(.0, -.375, .02, 0), fR=(-.16, -.375, .0, 0), s0=(16, 0, 0), s1=(16, 0, 0), hL=(.1, -.32, .0), hR=(.1, -.32, .0))), (1, {})], 3.6)
fid('fidget_snap_fingers', [(0, {}), (.3, dict(hR=(.14, .04, .02), hd=(0, 8, 0))), (.4, dict(hR=(.14, .06, .02), hd=(0, 8, 0), wR=(-20, 0, 0))), (.5, dict(hR=(.14, .04, .02), hd=(0, 8, 0), wR=(20, 0, 0))), (1, {})], 1.8)
fid('fidget_nod', [(0, {}), (.2, dict(hd=(14, 0, 0))), (.4, dict(hd=(-4, 0, 0))), (.6, dict(hd=(14, 0, 0))), (1, {})], 1.2)
fid('fidget_tie_shoe', [(0, {}), (.3, dict(crouch=.2, s0=(40, 0, 0), s1=(30, 0, 0), hL=(.1, -.3, .1), hR=(.1, -.3, .1), nk=(10, 0, 0))), (.75, dict(crouch=.2, s0=(40, 0, 0), s1=(30, 0, 0), hL=(.1, -.32, .08), hR=(.1, -.3, .1), nk=(10, 0, 0))), (1, {})], 3.0)
fid('fidget_yoyo_flick', [(0, {}), (.3, dict(hR=(.16, .04, .06), s0=(0, 6, 0))), (.45, dict(hR=(.2, -.12, .04), s0=(2, 6, 0))), (.6, dict(hR=(.16, .04, .06))), (1, {})], 1.6)
