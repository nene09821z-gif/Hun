"""Chu kỳ đi/chạy tham số hoá (hài hoà + bảng khoá chu kỳ), tiếp đất tự động; đo độ dài sải chân (stride)."""
import numpy as np
from motion import *
import rig

def cyc(keys):
    """keys [(p, v)] p in [0,1): hàm tuần hoàn PCHIP."""
    ps = np.array([k[0] for k in keys], float); vs = np.array([k[1] for k in keys], float)[:, None]
    ps3 = np.concatenate([ps - 1, ps, ps + 1]); vs3 = np.concatenate([vs, vs, vs])
    from motion import _pchip_slopes, _eval
    m = _pchip_slopes(ps3, vs3)
    return lambda p: float(_eval(ps3, vs3, m, np.array([p % 1.0]))[0, 0])

WALK = dict(hipA=24, hipC=4, kLoad=10, kSw=62, kSwP=.70, kSwW=.11, ankPush=18, ankHs=-9, ankSw=-6, yaw=6, roll=3.5, sway=.012, lean=2, armA=22, armC=0, elb=18, elbA=14, armAb=3,
            spYaw=.9, spRoll=.8, lift=0, wid=.045, bob=0, headDip=0, toeP=14)
JOG = dict(WALK, hipA=34, hipC=8, kLoad=22, kSw=95, kSwW=.13, ankPush=26, ankHs=-6, ankSw=-10, yaw=9, roll=4, sway=.014, lean=9, armA=36, elb=70, elbA=22, lift=.020, toeP=20)
RUN = dict(JOG, hipA=42, hipC=12, kLoad=30, kSw=115, kSwW=.15, ankPush=32, yaw=12, roll=4.5, lean=14, armA=48, elb=88, elbA=22, lift=.050, armAb=5, toeP=28)
SPRINT = dict(RUN, hipA=50, hipC=16, kLoad=36, kSw=128, kSwW=.16, ankPush=38, yaw=14, roll=5, lean=22, armA=62, elb=96, elbA=18, lift=.085, armAb=7, toeP=34)

def knee_f(P):
    # trọng số gauss tuần hoàn
    def g(p, c, w):
        d = ((p - c + .5) % 1) - .5; return np.exp(-.5 * (d / w) ** 2)
    return lambda p: P['kLoad'] * g(p, .10, .07) + P['kSw'] * g(p, P['kSwP'], P['kSwW']) + 4

def gait_poses(P, N=16, strafe=0., back=False, scale=1.):
    """Danh sách (p, Pose) cho một chu kỳ. strafe: -1..1 (âm = sang L). back: chạy lùi."""
    kf = knee_f(P)
    ank = cyc([(0, P['ankHs']), (.10, 0), (.30, 3), (.45, P['ankPush'] * .45), (.55, P['ankPush']), (.62, P['ankPush'] * .55), (.75, P['ankSw']), (.9, P['ankSw'] + 2)])
    toe = cyc([(0, 0), (.1, 0), (.4, 2), (.55, P['toeP']), (.65, P['toeP'] * .4), (.8, -4), (.95, -2)])
    out = []
    dirf = -1 if back else 1
    for i in range(N):
        p = i / N; pose = Pose()
        for side, ph in (('L', p), ('R', p + .5)):
            sd = -1 if side == 'L' else 1
            fl = (P['hipC'] + P['hipA'] * np.cos(2 * np.pi * ph)) * dirf if not back else (P['hipC'] * .3 + P['hipA'] * np.cos(2 * np.pi * ph + 0)) * -1 * -1
            if strafe:
                # bước ngang: đùi dang/khép theo pha, ít gập
                ab = P['hipA'] * .7 * np.cos(2 * np.pi * ph) * strafe
                pose.r[J['thigh' + side]] = np.array([-(fl * .25 + 4), 0, (ab + 4 * sd * strafe) * (1 if side == 'L' else 1) * 1])
                # đối xứng cho R: giữ cùng dấu theo hướng bước (sang -X khi strafe<0)
            else:
                pose.r[J['thigh' + side]] = np.array([-fl, 0, -sd * (P['wid'] * 80 / 8) * 0 + sd * -1 * 0])
            kv = kf(ph)
            pose.r[J['knee' + side]] = np.array([kv * (1 if not strafe else .6), 0, 0])
            pose.r[J['ankle' + side]] = np.array([ank(ph), 0, 0]); pose.r[J['toe' + side]] = np.array([toe(ph), 0, 0])
            # tay đối bên với chân cùng phía
            af = np.cos(2 * np.pi * ph)
            arm_rx = (P['armA'] * af) * (0 if strafe else 1) + 4
            ab = P['armAb'] * 1.0 + 2
            pose.r[J['arm' + side]] = np.array([arm_rx, 0, sd * -ab * -1 * (-1) * 0 + (ab if side == 'L' else -ab) * -1 * -1])
            ef = P['elb'] + P['elbA'] * (.5 - .5 * af)
            pose.r[J['el' + side]] = np.array([-ef, 0, 0])
            pose.r[J['wr' + side]] = np.array([-8, 0, 0])
        # đảo dấu tay: arm rx dương = ra sau khi chân cùng bên ra trước (af=1 ở ph=0 => chân L trước, tay L sau)
        yaw = P['yaw'] * np.cos(2 * np.pi * p); roll = -P['roll'] * np.sin(2 * np.pi * p)
        if strafe: yaw *= .3
        pose.r[J['hips']] = np.array([P['lean'] * .35, yaw * dirf, roll])
        pose.r[J['spine0']] = np.array([P['lean'] * .35, -yaw * P['spYaw'] * .55, -roll * P['spRoll'] * .7])
        pose.r[J['spine1']] = np.array([P['lean'] * .3, -yaw * P['spYaw'] * .85, -roll * P['spRoll'] * .4])
        pose.r[J['neck']] = np.array([-P['lean'] * .35, 0, 0]); pose.r[J['head']] = np.array([-P['lean'] * .2, 0, 0])
        pose.r[J['clavL']] = np.array([0, np.cos(2 * np.pi * p) * 3 * -1, 0]); pose.r[J['clavR']] = np.array([0, np.cos(2 * np.pi * p) * 3, 0])
        # lift (bay) + lắc ngang hông
        lift = P['lift'] * (1 + np.cos(4 * np.pi * p)) / 2
        pose.root = np.array([-P['sway'] * np.sin(2 * np.pi * p), lift, 0])
        out.append((p, pose))
    return out

def measure_stride(poses):
    """Sải chân (đơn vị model / chu kỳ) = quãng chân trụ trượt về sau so với hông khi không vi phạm trượt."""
    N = len(poses); zs = []; ys = []
    for p, pose in poses:
        Rw, Pw = rig.fk(pose.r * D, (0, 0, 0)); zs.append((Pw[IDX['ankleL']][2], Pw[IDX['ankleR']][2])); ys.append((Pw[IDX['ankleL']][1], Pw[IDX['ankleR']][1]))
    zs = np.array(zs); ys = np.array(ys); tot = []; 
    for i in range(N):
        j = (i + 1) % N
        for s in (0, 1):
            # chân trụ = chân thấp hơn
            if ys[i, s] <= ys[i, 1 - s] and ys[j, s] <= ys[j, 1 - s]:
                tot.append(-(zs[j, s] - zs[i, s]) * N)
    return float(np.mean(tot)) if tot else 0.

def make_cycle(name, Pm, cat='loco', **kw):
    poses = gait_poses(Pm, **{k: v for k, v in kw.items() if k in ('strafe', 'back')})
    stride = measure_stride(poses)
    dur = kw.get('dur', 1.0)
    keys = [(p * dur, pose) for p, pose in poses]
    return Clip(name, dur, keys, loop=True, ground='auto', cat=cat, stride=stride, stab=.6, lag=False, breath=0.)

if __name__ == '__main__':
    import preview, matplotlib.pyplot as plt, sys
    ms = preview.load()
    cl = [('walk', WALK), ('jog', JOG), ('run', RUN), ('sprint', SPRINT)]
    fig, axs = plt.subplots(len(cl), 8, figsize=(20, 2.8 * len(cl)))
    for r, (n, Pm) in enumerate(cl):
        c = make_cycle(n, Pm).bake(); print(n, 'stride', round(c.stride, 3), 'ymin/max root', c.rootf[:, 1].min().round(3), c.rootf[:, 1].max().round(3))
        for k in range(8):
            fi = k * len(c.frames) // 8
            preview.draw(axs[r, k], ms, c.frames[fi] * D, c.rootf[fi], yaw=np.pi / 2, xlim=(-.5, .5), ylim=(-.05, 1.15))
    plt.tight_layout(); plt.savefig('/tmp/out/gait_test.png', dpi=55)
