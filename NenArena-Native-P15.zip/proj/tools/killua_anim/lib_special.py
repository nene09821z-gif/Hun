"""Chiêu đặc trưng của Killua (Yo-yo, Narukami, Godspeed, ám sát, Oka...) + combo ghép từ các đòn."""
from lib_core import *
from lib_combat import ready, strike_keys, hk, hr, fk, fs
RW = lambda **kw: build(**{'fL': False, 'fR': False, **kw})
def sp(name, keys, dur=None, cat='skill', **kw): return add(name, [(t, k) for t, k in keys], dur, cat=cat, breath=0, stab=0, **kw)

# ---- Yo-yo ----
for s in 'LR':
    sd = SD[s]; h = 'hL' if s == 'L' else 'hR'; o = 'hR' if s == 'L' else 'hL'
    base = ready(opp(s))
    sp(f'yoyo_throw_{s}', [(0, base), (.1, dict(base, **{h: (.0, .22, .2, (.6, .2, 0))}, s0=(-4, -sd * -30, 0), s1=(-2, -sd * -22, 0), hip=(0, -sd * -20, 0))),
                           (.2, dict(base, **{h: (.3, .02, .0)}, s0=(14, sd * 30, 0), s1=(10, sd * 22, 0), hip=(4, sd * 22, 0), root=(0, 0, .06))), (.34, dict(base, **{h: (.3, .0, .0)}, s0=(12, sd * 26, 0))), (.6, base)], .6, hit=.2)
    sp(f'yoyo_sidearm_{s}', [(0, base), (.1, dict(base, **{h: (.0, .0, .32, (1, .2, 0))}, s0=(4, -sd * -40, 0), hip=(0, -sd * -30, 0))), (.2, dict(base, **{h: (.3, .0, -.14)}, s0=(8, sd * 40, 0), s1=(6, sd * 30, 0), hip=(2, sd * 30, 0))), (.6, base)], .6, hit=.2)
    sp(f'yoyo_overhead_{s}', [(0, base), (.12, dict(base, **{h: (-.04, .3, .1)}, s0=(-12, 0, 0))), (.24, dict(base, **{h: (.26, -.12, .0)}, s0=(24, 0, 0), s1=(18, 0, 0), root=(0, -.03, .08))), (.62, base)], .62, hit=.24)
    sp(f'yoyo_recall_{s}', [(0, base), (.12, dict(base, **{h: (.3, .02, .02)})), (.26, dict(base, **{h: (.06, .0, .08)}, s0=(6, 0, 0))), (.5, base)], .5)
sp('yoyo_whirl', [(0, ready('L')), (.15, dict(ready('L'), hR=(.0, .3, .12, (1, .2, 0)), s0=(-4, 0, 0))), (.3, dict(ready('L'), hR=(.1, .24, -.08, (1, .2, 0)), s0=(-4, 10, 0))), (.45, dict(ready('L'), hR=(.0, .3, .12, (1, .2, 0)), s0=(-4, 0, 0))), (.6, dict(ready('L'), hR=(.1, .24, -.08, (1, .2, 0)), s0=(-4, 10, 0)))], .6, loop=True)
# ---- Narukami / lôi chưởng ----
for s in 'LR':
    sd = SD[s]; h = 'hL' if s == 'L' else 'hR'; base = ready(opp(s), crouch=.07)
    sp(f'narukami_palm_{s}', [(0, base), (.18, dict(base, **{h: (.06, .0, .08)}, s0=(12, -sd * -20, 0), crouch=.12, wL=(-30, 0, 0), wR=(-30, 0, 0))),
                              (.3, dict(base, **{h: (.31, .06, .0)}, s0=(10, sd * 24, 0), s1=(8, sd * 18, 0), root=(0, 0, .12), crouch=.06, wL=(-75, 0, 0) if s == 'L' else (-5, 0, 0), wR=(-75, 0, 0) if s == 'R' else (-5, 0, 0))), (.55, dict(base, **{h: (.31, .06, .0)}, s0=(10, sd * 24, 0), root=(0, 0, .12))), (.85, base)], .85, hit=.3)
sp('narukami_cast', [(0, {}), (.15, dict(crouch=.1, s0=(10, 0, 0), hR=(.1, -.1, .1))), (.35, dict(hR=(.04, .42, .04), s0=(-14, 0, 0), s1=(-10, 0, 0), hd=(-28, 0, 0), hL=(.08, -.12, .12))), (.6, dict(hR=(.04, .42, .04), s0=(-14, 0, 0), hd=(-28, 0, 0), hL=(.08, -.12, .12))),
                     (.72, dict(hR=(.3, -.04, .0), s0=(18, 0, 0), s1=(12, 0, 0), crouch=.08, hd=(6, 0, 0), hL=(.1, -.1, .1), root=(0, 0, .06))), (1.0, dict(hR=(.3, -.04, .0), s0=(16, 0, 0), crouch=.08)), (1.3, {})], 1.3, hit=.72)
sp('narukami_double_palm_ground', [(0, {}), (.2, dict(crouch=.18, s0=(24, 0, 0), s1=(18, 0, 0), hL=(.04, .1, .12), hR=(.04, .1, .12))), (.38, dict(crouch=.3, s0=(36, 0, 0), s1=(26, 0, 0), hL=(.2, -.34, .06), hR=(.2, -.34, .06), hd=(-10, 0, 0))), (.7, dict(crouch=.3, s0=(36, 0, 0), s1=(26, 0, 0), hL=(.2, -.34, .06), hR=(.2, -.34, .06), hd=(-10, 0, 0))), (1.0, {})], 1.0, hit=.38)
sp('lightning_palm_beam', [(0, ready('L')), (.2, dict(ready('L'), crouch=.12, hR=(.08, -.02, .1), hL=(.12, -.04, .06))), (.32, dict(ready('L'), crouch=.08, hR=(.31, .04, .0), hL=(.31, .04, .0), s0=(8, 0, 0), s1=(6, 0, 0), wL=(-75, 0, 0), wR=(-75, 0, 0), root=(0, 0, .08))), (.9, dict(ready('L'), crouch=.08, hR=(.31, .04, .0), hL=(.31, .04, .0), s0=(8, 0, 0), wL=(-75, 0, 0), wR=(-75, 0, 0), root=(0, 0, .08))), (1.2, ready('L'))], 1.2, hit=.32)
# ---- Godspeed ----
for s in 'LR':
    sd = SD[s]; h = 'hL' if s == 'L' else 'hR'
    aa = 'aL' if s == 'L' else 'aR'; ee = 'eL' if s == 'L' else 'eR'
    sp(f'godspeed_slash_{s}', [(0, RW(root=(0, 0, .0), hip=(40, 0, 0), s0=(16, 0, 0), a=(60, 0, 16), e=(-20, 0, 0), t=(-46, 0, 0), k=(80, 0, 0), f=(30, 0, 0), hd=(-22, 0, 0))),
                               (.1, RW(root=(0, 0, .5), hip=(30, sd * 30, 0), s0=(10, sd * -20, 0), t=(-40, 0, 0), k=(70, 0, 0), a=(60, 0, 16), e=(-20, 0, 0), hd=(-22, 0, 0), **{aa: (-80, 0, (-70 if s == 'L' else 70)), ee: (-10, 0, 0)})),
                               (.2, dict(crouch=.14, root=(0, 0, 1.1), hip=(8, sd * 40, 0), s0=(10, sd * 20, 0), **{('hL' if s == 'L' else 'hR'): (.2, .0, -.12)})), (.45, dict(crouch=.1, root=(0, 0, 1.1)))], .45, ground='auto', hit=.15)
sp('godspeed_spin_slash', [(0, dict(crouch=.1)), (.12, RW(root=(0, 0, .3), hip=(20, -90, 0), s0=(10, 0, 0), a=(-30, 0, -50), t=(-30, 0, 0), k=(50, 0, 0))), (.28, RW(root=(0, 0, .8), hip=(10, -270, 0), s0=(6, 0, 0), a=(-20, 0, 60), e=(-10, 0, 0), t=(-20, 0, 0), k=(30, 0, 0))), (.42, dict(crouch=.14, root=(0, 0, 1.3), hip=(0, -360, 0))), (.65, dict(root=(0, 0, 1.3), hip=(0, -360, 0)))], .65, ground='auto', hit=.2)
sp('whirlwind_claw', [(0, ready('L')), (.1, dict(ready('L'), hL=(.1, .0, .3), hR=(.1, .0, .3), crouch=.1)), (.3, RW(hip=(8, 360, 0), s0=(10, 0, 0), a=(-4, 0, -62), e=(-6, 0, 0), t=(-10, 0, 0), k=(40, 0, 0), root=(0, .02, 0), w=(-40, 0, 0))), (.5, RW(hip=(8, 720, 0), a=(-4, 0, -62), e=(-6, 0, 0), t=(-10, 0, 0), k=(40, 0, 0), w=(-40, 0, 0))), (.7, dict(ready('L'), hip=(0, 720, 0)))], .7, hit=.3, ground='auto')
for s in 'LR':
    sd = SD[s]; h = 'hL' if s == 'L' else 'hR'
    sp(f'assassin_stab_{s}', [(0, dict(crouch=.16, gw=.05, hip=(8, 0, 0), s0=(16, 0, 0), s1=(12, 0, 0), nk=(-10, 0, 0), hd=(-6, 0, 0), hL=(.1, -.12, .08), hR=(.1, -.12, .08))),
                              (.12, dict(crouch=.24, gw=.05, hip=(14, 0, 0), s0=(24, sd * -14, 0), s1=(18, 0, 0), **{h: (.04, -.04, .1)}, nk=(-10, 0, 0))), (.22, dict(crouch=.12, stag=-.14 * sd, hip=(16, sd * 20, 0), s0=(28, sd * 24, 0), s1=(20, 0, 0), **{h: (.31, .06, .02)}, root=(0, -.02, .26), nk=(-12, 0, 0), hd=(-8, 0, 0), wL=(-40, 0, 0), wR=(-40, 0, 0))),
                              (.42, dict(crouch=.12, stag=-.14 * sd, hip=(16, sd * 20, 0), s0=(28, sd * 24, 0), **{h: (.31, .06, .02)}, root=(0, -.02, .26))), (.7, dict(crouch=.1, root=(0, 0, .26)))], .7, ground='auto', hit=.22)
    sp(f'assassin_strike_down_{s}', [(0, dict(crouch=.2, hip=(10, 0, 0), s0=(20, 0, 0), hL=(.1, -.12, .08), hR=(.1, -.12, .08))), (.14, RW(root=(0, .3, .0), hip=(-10, 0, 0), s0=(-10, 0, 0), t=(-30, 0, 0), k=(50, 0, 0), a=(-140, 0, 30), e=(-40, 0, 0))), (.28, RW(root=(0, .0, .3), hip=(20, 0, 0), s0=(28, 0, 0), t=(-30, 0, 0), k=(40, 0, 0), a=(-60, 0, 8), e=(-10, 0, 0), w=(-40, 0, 0))), (.6, dict(crouch=.16, root=(0, 0, .3), s0=(20, 0, 0)))], .6, ground='auto', hit=.28)
# ---- Oka / nhịp bước ----
sp('snake_dance', [(0, dict(crouch=.1, hip=(2, 0, 8), s0=(6, 0, -10), s1=(4, 0, -8), hd=(0, 0, 14), hL=(.1, -.1, .14), hR=(.08, -.1, -.08), root=(-.06, 0, 0))), (.25, dict(crouch=.12, hip=(2, 0, 0), s0=(8, 0, 0), hd=(2, 0, 0), hL=(.1, -.1, .1), hR=(.1, -.1, .1), root=(0, 0, 0))), (.5, dict(crouch=.1, hip=(2, 0, -8), s0=(6, 0, 10), s1=(4, 0, 8), hd=(0, 0, -14), hL=(.08, -.1, -.08), hR=(.1, -.1, .14), root=(.06, 0, 0))), (.75, dict(crouch=.12, hip=(2, 0, 0), s0=(8, 0, 0), hd=(2, 0, 0), hL=(.1, -.1, .1), hR=(.1, -.1, .1)))], 1.0, loop=True, cat='skill')
sp('rhythm_echo_L', [(0, dict(crouch=.1, root=(0, 0, 0))), (.1, dict(crouch=.1, root=(-.3, 0, 0), hip=(2, 0, 6))), (.2, dict(crouch=.1, root=(-.6, 0, 0))), (.3, dict(crouch=.1, root=(-.2, 0, 0))), (.4, dict(crouch=.1, root=(.2, 0, 0))), (.5, dict(crouch=.1, root=(0, 0, 0)))], .5, loop=True, cat='skill')
sp('thunder_clap', [(0, {}), (.2, dict(hL=(.1, .06, .2), hR=(.1, .06, .2), s0=(-4, 0, 0))), (.32, dict(hL=(.16, .04, .02), hR=(.16, .04, .02), s0=(6, 0, 0), crouch=.06)), (.6, {})], .6, hit=.32)
sp('lightning_dive_claw', [(0, {}), (.14, dict(crouch=.16, s0=(18, 0, 0))), (.3, RW(root=(0, .9, 0), hip=(-10, 0, 0), a=(-170, 0, 20), t=(-20, 0, 0), k=(40, 0, 0), s0=(-10, 0, 0))), (.46, RW(root=(0, .6, .6), hip=(60, 0, 0), s0=(12, 0, 0), a=(-110, 0, 20), e=(-10, 0, 0), t=(-30, 0, 0), k=(60, 0, 0), w=(-40, 0, 0))), (.58, RW(root=(0, .0, 1.0), hip=(70, 0, 0), s0=(20, 0, 0), a=(-100, 0, 10), e=(-6, 0, 0), t=(-20, 0, 0), k=(40, 0, 0), w=(-40, 0, 0))), (.8, dict(crouch=.22, root=(0, 0, 1.0), s0=(24, 0, 0))), (1.0, dict(root=(0, 0, 1.0)))], 1.0, ground='free', hit=.58)
sp('meteor_kick', [(0, {}), (.14, dict(crouch=.16, s0=(18, 0, 0))), (.3, RW(root=(0, .9, 0), hip=(-10, 0, 0), a=(-160, 0, 20), t=(-20, 0, 0), k=(40, 0, 0))), (.46, RW(root=(0, .9, .3), hip=(-60, 0, 0), s0=(-10, 0, 0), a=(-100, 0, 30), tL=(-150, 0, 0), kL=(10, 0, 0), tR=(10, 0, 0), kR=(30, 0, 0))), (.6, RW(root=(0, .3, .9), hip=(30, 0, 0), s0=(10, 0, 0), a=(-40, 0, 40), tL=(-30, 0, 0), kL=(10, 0, 0), tR=(-10, 0, 0), kR=(40, 0, 0), f=(-20, 0, 0))), (.85, dict(crouch=.24, root=(0, 0, 1.0), s0=(26, 0, 0))), (1.1, dict(root=(0, 0, 1.0)))], 1.1, ground='free', hit=.6)
sp('rising_claw_flip', [(0, ready('L')), (.14, dict(ready('L'), crouch=.18, hR=(.08, -.28, .1), s0=(14, 0, 0))), (.3, RW(root=(0, .4, .1), hip=(-60, 0, 0), s0=(-10, 0, 0), a=(-130, 0, 20), t=(-20, 0, 0), k=(40, 0, 0), w=(-40, 0, 0))), (.5, RW(root=(0, .8, -.2), hip=(-220, 0, 0), t=(-90, 0, 0), k=(100, 0, 0), a=(-40, 0, 20))), (.72, RW(root=(0, .3, -.4), hip=(-330, 0, 0), t=(-40, 0, 0), k=(60, 0, 0), a=(-30, 0, 20))), (.9, dict(crouch=.2, hip=(-360, 0, 0), root=(0, 0, -.5))), (1.1, dict(hip=(-360, 0, 0), root=(0, 0, -.5)))], 1.1, ground='free', hit=.3)
sp('lightning_drop_kick', [(0, ready('L')), (.14, dict(ready('L'), crouch=.16)), (.3, RW(root=(0, .3, .3), hip=(-50, 0, 0), s0=(-14, 0, 0), a=(-30, 0, 40), t=(-20, 0, 0), k=(50, 0, 0))), (.44, RW(root=(0, .25, .8), hip=(-84, 0, 0), s0=(-6, 0, 0), a=(-60, 0, 44), tL=(-100, 0, 0), kL=(6, 0, 0), tR=(-100, 0, 0), kR=(6, 0, 0), f=(-10, 0, 0), hd=(20, 0, 0))), (.7, RW(root=(0, -.45, 1.3), hip=(-90, 0, 0), a=(-10, 0, 36), t=(2, 0, 3), k=(8, 0, 0))), (1.1, dict(crouch=.2, root=(0, 0, 1.3)))], 1.1, ground='free', hit=.44)
sp('finisher_pose', [(0, {}), (.3, dict(hR=(.26, .1, .04), hL=(.02, -.2, .06), s0=(6, -16, 0), hd=(-6, 16, 0), crouch=.04)), (1.0, dict(hR=(.26, .1, .04), hL=(.02, -.2, .06), s0=(6, -16, 0), hd=(-6, 16, 0), crouch=.04))], 1.5)

# ---- COMBO: ghép từ các đòn có sẵn ----
def combo(name, parts, speed=1.25, cat='combo'):
    keys = []; t0 = 0.; hits = []
    for i, nm in enumerate(parts):
        c = CLIPS[nm]; ks = c.keys[1:] if i else c.keys
        for t, p in ks: keys.append((t0 + t / speed, p))
        if c.hit: hits.append(round(t0 + c.hit / speed, 3))
        t0 += c.dur / speed
    k = Clip(name, t0, keys, cat=cat, ground='auto', hit=hits[0] if hits else None, breath=0, stab=0); k.hits = hits
    return reg(k)
combo('combo_jab_cross_hook', ['jab_L', 'cross_R', 'hook_L'])
combo('combo_1_2_round', ['jab_L', 'jab_L', 'cross_R', 'kick_round_mid_L'])
combo('combo_claw_triple', ['claw_slash_h_L', 'claw_slash_h_R', 'claw_slash_dn_L'], 1.3)
combo('combo_boxer_high', ['cross_R', 'hook_L', 'uppercut_R', 'kick_round_high_L'])
combo('combo_front_knee', ['kick_front_L', 'cross_R', 'knee_strike_R'])
combo('combo_thrust_rake', ['claw_thrust_L', 'claw_thrust_R', 'claw_rake_x_L'], 1.3)
combo('combo_spin_chain', ['backfist_L', 'kick_back_R', 'kick_round_mid_L'], 1.2)
combo('combo_hook_elbow', ['jab_R', 'hook_L', 'kick_round_low_R', 'elbow_fwd_L'])
combo('combo_palm_storm', ['palm_R', 'palm_L', 'palm_double_L'], 1.2)
combo('combo_claw_side_hook', ['claw_rake_wide_L', 'kick_side_R', 'kick_hook_L'], 1.2)
combo('combo_hammer_sweep_axe', ['hammerfist_L', 'sweep_low_R', 'kick_axe_L'], 1.15)
combo('combo_finisher_claw', ['claw_slash_up_L', 'claw_slash_dn_R', 'claw_rake_x_L', 'kick_round_high_R'], 1.3)
combo('combo_blitz_6', ['jab_L', 'cross_R', 'jab_L', 'cross_R', 'hook_L', 'kick_round_high_R'], 1.6)
combo('combo_claw_blitz', ['claw_slash_h_L', 'claw_slash_h_R', 'claw_slash_dn_L', 'claw_slash_dn_R', 'claw_slash_up_L', 'claw_rake_x_R'], 1.6)
combo('combo_kick_storm', ['kick_front_L', 'kick_round_mid_R', 'kick_hook_L', 'kick_round_high_R'], 1.25)
combo('combo_assassin', ['assassin_stab_L', 'claw_slash_h_R', 'kick_back_L'], 1.2)
combo('combo_yoyo_claw', ['yoyo_throw_R', 'claw_slash_h_L', 'claw_slash_h_R', 'yoyo_sidearm_L'], 1.2)
combo('combo_elbow_knee', ['elbow_fwd_R', 'knee_strike_L', 'elbow_up_L', 'knee_round_R'], 1.2)
