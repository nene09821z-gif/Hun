package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

typealias SigFn = (h: Human, t: Float, mv: Float, A: String?, k: Float, w: Float, r: Float, sa: Float) -> Unit

/** Trộn góc xoay của nút o về (x,y,z) với trọng số w. */
fun B(o: Node, x: Float, y: Float, z: Float, w: Float) { o.rot.set(lerp(o.rot.x, x, w), lerp(o.rot.y, y, w), lerp(o.rot.z, z, w)) }
fun pls(t: Float, p: Float, d: Float): Float { val c = t % p; return if (c < d) sin(c / d * PIF) else 0f }
fun setMatHex(m: Material, hex: Int) { m.c[0] = ((hex shr 16) and 255) / 255f; m.c[1] = ((hex shr 8) and 255) / 255f; m.c[2] = (hex and 255) / 255f }

/**
 * Tư thế chiêu: [tayP x,y,z, chỏP, tayT x,y,z, chỏT, thân x,y, đầu x, hạ trọng tâm, tấn bộ] — pose lúc đánh trúng;
 * pose lấy đà tự suy ra (bản MV của HTML).
 */
val MV: Map<String, FloatArray> = mapOf(
    "hisoka:0" to floatArrayOf(-1.3f, 0f, .4f, -.4f, .1f, 0f, -.6f, -.5f, .2f, -.5f, .15f, .05f, .2f),
    "hisoka:1" to floatArrayOf(-1.5f, 0f, .3f, -.2f, -1.5f, 0f, -.3f, -.2f, .35f, 0f, -.1f, .12f, .5f),
    "hisoka:2" to floatArrayOf(-2.2f, 0f, .5f, -1.4f, .3f, 0f, -.8f, -.4f, -.1f, .4f, -.3f, .05f, 0f),
    "hisoka:3" to floatArrayOf(-.2f, 0f, 1.5f, -.1f, -.2f, 0f, -1.5f, -.1f, -.45f, 0f, -.5f, .1f, .15f),
    "illumi:0" to floatArrayOf(-1.2f, 0f, .2f, -.3f, 0f, 0f, -.2f, -.4f, .15f, -.4f, .1f, .02f, .1f),
    "illumi:1" to floatArrayOf(-1.4f, .3f, .5f, -.6f, -1.4f, -.3f, -.5f, -.6f, .1f, 0f, .1f, .05f, 0f),
    "illumi:2" to floatArrayOf(0f, 0f, .1f, -.2f, 0f, 0f, -.1f, -.2f, .1f, 0f, .25f, 0f, 0f),
    "illumi:3" to floatArrayOf(-2.9f, 0f, .2f, -.1f, -.2f, 0f, -.3f, -.4f, -.25f, 0f, -.3f, 0f, 0f),
    "netero:0" to floatArrayOf(-1.55f, 0f, 0f, -.1f, -.9f, 0f, -.5f, -1.5f, .25f, -.5f, 0f, .1f, .7f),
    "netero:2" to floatArrayOf(-1.6f, 0f, 0f, 0f, -.4f, 0f, -.4f, -1.2f, .2f, -.3f, 0f, .08f, .4f),
    "meruem:0" to floatArrayOf(-1.7f, 0f, .6f, -.1f, .2f, 0f, -.5f, -.8f, .1f, -.8f, 0f, .05f, .3f),
    "meruem:1" to floatArrayOf(-1.2f, 0f, .5f, -.2f, -1.2f, 0f, -.5f, -.2f, .2f, 0f, .2f, .05f, 0f),
    "meruem:2" to floatArrayOf(.3f, 0f, 1.2f, -.1f, .3f, 0f, -1.2f, -.1f, -.5f, 0f, -.2f, 0f, 0f),
    "meruem:3" to floatArrayOf(-2.7f, 0f, .3f, -.1f, -1.5f, 0f, -.2f, -.1f, -.2f, 0f, -.35f, .05f, 0f),
    "zeno:0" to floatArrayOf(-1.4f, 0f, .2f, -.3f, .6f, 0f, -.1f, -.9f, .3f, -.4f, -.15f, .05f, .3f),
    "zeno:1" to floatArrayOf(-1.6f, 0f, .1f, -.2f, -1.5f, 0f, -.2f, -.2f, .3f, 0f, -.15f, .1f, .5f),
    "zeno:2" to floatArrayOf(-1.5f, 0f, 0f, 0f, .5f, 0f, -.3f, -.8f, .25f, -.3f, -.1f, .08f, .35f),
    "zeno:3" to floatArrayOf(-2.9f, 0f, .4f, -.1f, -2.9f, 0f, -.4f, -.1f, -.5f, 0f, -.4f, 0f, 0f),
    "chrollo:0" to floatArrayOf(-1.4f, 0f, .3f, -.3f, -.9f, 0f, -.3f, -1.2f, .1f, -.6f, 0f, .05f, .3f),
    "chrollo:1" to floatArrayOf(-.9f, 0f, .3f, -1f, -1.5f, 0f, -.2f, -.3f, 0f, .2f, .2f, 0f, 0f),
    "chrollo:2" to floatArrayOf(-1.5f, 0f, .2f, 0f, -.9f, 0f, -.4f, -1f, .1f, 0f, .05f, .04f, .2f),
    "chrollo:3" to floatArrayOf(-2.4f, 0f, .3f, -.8f, -2.6f, 0f, -.3f, -.1f, -.3f, 0f, -.3f, 0f, 0f),
    "gon:0" to floatArrayOf(-1.55f, 0f, .1f, -.15f, -.9f, 0f, -.5f, -1.5f, .3f, -.5f, .05f, .08f, .4f),
    "gon:1" to floatArrayOf(-1.2f, 0f, .5f, -.1f, .2f, 0f, -.4f, -1.1f, .2f, .7f, 0f, .12f, .4f),
    "gon:2" to floatArrayOf(-1.8f, 0f, .2f, -.1f, -1f, 0f, -.6f, -1.5f, .35f, -.7f, .1f, .25f, .8f),
    "gon:3" to floatArrayOf(-1.6f, 0f, .3f, 0f, -1.6f, 0f, -.3f, 0f, .3f, 0f, -.1f, .2f, .5f),
    "killua:0" to floatArrayOf(-1.4f, 0f, .5f, -.2f, .2f, 0f, -.4f, -.6f, .25f, -.6f, .1f, .1f, .4f),
    "killua:1" to floatArrayOf(-2.5f, 0f, .1f, 0f, .3f, 0f, -.4f, -.5f, -.15f, 0f, -.2f, .05f, .2f),
    "killua:2" to floatArrayOf(.6f, 0f, .2f, -.4f, .6f, 0f, -.2f, -.4f, .7f, 0f, -.2f, .3f, .9f),
    "killua:3" to floatArrayOf(.3f, 0f, .9f, -.3f, .3f, 0f, -.9f, -.3f, .3f, 0f, -.5f, .2f, 0f),
    "kurapika:0" to floatArrayOf(-1.6f, 0f, .1f, -.1f, .4f, 0f, -.3f, -.9f, .1f, -.4f, 0f, .05f, .2f),
    "kurapika:1" to floatArrayOf(-1.5f, 0f, .2f, -.4f, -.4f, 0f, -.2f, -1.2f, .1f, .3f, 0f, .05f, .1f),
    "kurapika:2" to floatArrayOf(-1f, 0f, .5f, -.7f, -1f, 0f, -.5f, -.7f, .15f, 0f, .1f, .12f, 0f),
    "kurapika:3" to floatArrayOf(-.4f, 0f, 1.3f, -.1f, -.4f, 0f, -1.3f, -.1f, -.3f, 0f, -.4f, 0f, 0f),
    "silva:0" to floatArrayOf(-1.5f, 0f, .1f, -.15f, -.8f, 0f, -.4f, -1.4f, .3f, -.5f, 0f, .12f, .5f),
    "silva:1" to floatArrayOf(-2.3f, 0f, .2f, -.2f, -.6f, 0f, -.3f, -.8f, .45f, .3f, -.1f, .15f, .3f),
    "silva:2" to floatArrayOf(-1.7f, 0f, .3f, -.2f, .3f, 0f, -.3f, -.6f, .5f, -.9f, 0f, .3f, .9f),
    "silva:3" to floatArrayOf(-2.9f, 0f, .2f, -.1f, -2.9f, 0f, -.2f, -.1f, -.45f, 0f, -.3f, .05f, 0f),
    "leorio:0" to floatArrayOf(-1.2f, .8f, .2f, -.3f, -.4f, 0f, -.3f, -.9f, .15f, -.7f, 0f, .06f, .3f),
    "leorio:1" to floatArrayOf(-1.7f, 0f, .3f, 0f, -.5f, 0f, -.5f, -1.4f, .2f, -.4f, 0f, .1f, .5f),
    "leorio:2" to floatArrayOf(-1.1f, 0f, .4f, -.6f, -1.1f, 0f, -.4f, -.6f, .1f, 0f, .1f, 0f, 0f),
    "leorio:3" to floatArrayOf(-2.2f, 0f, .2f, -.5f, -.8f, 0f, -.5f, -1.4f, -.35f, -.4f, -.2f, .25f, .6f),
    "morel:0" to floatArrayOf(-1.3f, 0f, .3f, -1.5f, .2f, 0f, -.2f, -.5f, .1f, 0f, -.3f, 0f, 0f),
    "morel:1" to floatArrayOf(-1.2f, 0f, .5f, -.5f, -1.2f, 0f, -.5f, -.5f, .25f, 0f, .15f, .12f, 0f),
    "morel:2" to floatArrayOf(-1f, 0f, .9f, -.3f, -1f, 0f, -.9f, -.3f, 0f, 0f, -.1f, .05f, 0f),
    "morel:3" to floatArrayOf(-2.6f, 0f, .3f, -.2f, -2.6f, 0f, -.3f, -.2f, -.4f, 0f, -.4f, 0f, 0f),
    "ging:0" to floatArrayOf(-1.55f, 0f, .1f, -.1f, -.9f, 0f, -.5f, -1.5f, .2f, -.5f, 0f, .08f, .4f),
    "ging:1" to floatArrayOf(-1.5f, 0f, .1f, -.1f, .2f, 0f, -.3f, -.6f, .1f, -.3f, 0f, .04f, .3f),
    "ging:2" to floatArrayOf(-.9f, 0f, 1f, -.3f, -.9f, 0f, -1f, -.3f, -.2f, 0f, -.3f, .03f, 0f),
    "ging:3" to floatArrayOf(-1.8f, 0f, .2f, -.1f, -1f, 0f, -.6f, -1.5f, .35f, -.7f, .1f, .25f, .8f)
)

fun kfPose(h: Human, S: FloatArray, k: Float, sa: Float, mir: Boolean, col: Int) {
    var v = FloatArray(13) { i ->
        val x = S[i]; val w = if (i == 9) -x * .8f else x * .25f
        if (k < .3f) w * ease(k / .3f) else lerp(w, x, ease(clamp((k - .3f) / .15f, 0f, 1f)))
    }
    if (mir) v = floatArrayOf(v[4], -v[5], -v[6], v[7], v[0], -v[1], -v[2], v[3], v[8], -v[9], v[10], v[11], v[12])
    B(h.armR, v[0], v[1], v[2], sa); h.elR.rot.x = lerp(h.elR.rot.x, v[3], sa)
    B(h.armL, v[4], v[5], v[6], sa); h.elL.rot.x = lerp(h.elL.rot.x, v[7], sa)
    B(h.torso, v[8], v[9], 0f, sa); B(h.head, v[10], 0f, 0f, sa); h.hips.pos.y -= v[11] * sa
    B(h.legL, -v[12], 0f, 0f, sa); B(h.legR, v[12] * .6f, 0f, 0f, sa)
    h.knL.rot.x = lerp(h.knL.rot.x, v[12] * .8f, sa); h.knR.rot.x = lerp(h.knR.rot.x, v[12] * .6f, sa)
    if (k > .3f && k < .5f && rnd01() < .5f) {
        val p = h.root.pos; emit(p.x + rnd(-.5f, .5f), rnd(.6f, 1.6f), p.z + rnd(-.5f, .5f), 0f, 0f, 0f, .2f, .35f, .02f, col, 0f, 2f)
    }
}

private const val DP = 0x8a2cff

/** Chuyển động đặc trưng: đứng (w), chạy (r), ra đòn (sa). */
val SIG: Map<String, SigFn> = mapOf(
    "hisoka" to { h, t, _, A, k, w, r, sa ->
        B(h.armL, .1f, 0f, -.6f, w); B(h.elL, -.5f, 0f, 1.1f, w)
        val f = pls(t, 3.6f, .5f); B(h.armR, -.9f, 0f, -.25f, w * f); B(h.elR, -1.1f + sin(t * 40f) * .25f, 0f, 0f, w * f)
        h.hips.rot.z = sin(t * 1.3f) * .07f * w + sin(h.phase) * .08f * r; h.hips.rot.y = sin(h.phase) * .18f * r
        h.head.rot.z += sin(t * .9f) * .2f * w + .12f * r; h.head.rot.x += .1f * w
        h.torso.rot.y += sin(t * .6f) * .18f * w; h.torso.rot.x += .12f * r
        if (A == "cast") { h.head.rot.x -= .6f * sa * sin(k * PIF); h.torso.rot.x -= .25f * sa }
        if (A == "throw") { B(h.elR, -.9f, 0f, 0f, .7f * sa); h.head.rot.z += .25f * sa }
    },
    "illumi" to { h, t, _, A, _, w, r, sa ->
        B(h.armL, 0f, 0f, .1f, w); B(h.armR, 0f, 0f, -.1f, w); B(h.elL, -.2f, 0f, 0f, w); B(h.elR, -.45f + sin(t * 22f) * .05f, 0f, 0f, w)
        val c = t % 5.5f; val tl = if (c > 4f) ease(clamp((c - 4f) / .12f, 0f, 1f)) * (1 - ease(clamp((c - 5.1f) / .25f, 0f, 1f))) else 0f
        h.head.rot.z += tl * .42f * w; h.head.rot.y += tl * .35f * w
        h.hips.pos.y -= abs(cos(h.phase)) * .05f * r; h.armL.rot.x *= 1 - .75f * r; h.armR.rot.x *= 1 - .75f * r; h.torso.rot.x -= .1f * r
        if (A == "raise") h.head.rot.x -= .35f * sa
        if (A == "slash" || A == "throw") h.head.rot.z += .3f * sa
    },
    "gon" to { h, t, _, A, _, w, r, sa ->
        h.hips.pos.y += -.05f * w + abs(sin(t * 5f)) * .05f * w
        B(h.armL, -.7f, 0f, -.2f, w); B(h.elL, -1.5f, 0f, 0f, w); B(h.armR, -.5f, 0f, .15f, w); B(h.elR, -1.7f, 0f, 0f, w)
        h.head.rot.z += sin(t * 2.4f) * .07f * w; h.torso.rot.x += .08f * w + .18f * r; B(h.elL, -1.4f, 0f, 0f, r); B(h.elR, -1.4f, 0f, 0f, r)
        if (A == "punch") { h.hips.pos.y -= .1f * sa; B(h.legL, -.5f, 0f, 0f, sa); B(h.legR, .35f, 0f, 0f, sa) }
        if (A == "raise") { h.head.rot.x -= .3f * sa; h.torso.rot.x -= .3f * sa }
        // Hắc hoá: tím sẫm, to ra, mắt đỏ, aura tím
        h.dkK = lerp(h.dkK, if (h.dkOn) 1f else 0f, .08f); val g = h.dkK
        for (m in h.mats) m.setEmissiveF(.3f * g, 0f, .42f * g)
        h.root.setScale(1f + .22f * g); for (e in h.dkEyes) e.visible = g > .3f
        h.auraMat?.let { setMatHex(it, if (g > .5f) DP else 0xffc82e) }; h.aCol = if (g > .5f) intArrayOf(DP, 0xff2a5a) else intArrayOf(0xffc82e, 0xfff3a6)
        if (g > .25f && rnd01() < .6f) { val p = h.root.pos; emit(p.x + rnd(-.5f, .5f), rnd(.2f, 2f), p.z + rnd(-.5f, .5f), rnd(-.5f, .5f), rnd(1f, 3f), rnd(-.5f, .5f), .5f, .45f, .03f, if (rnd01() < .5f) DP else 0x1a0030, 0f, .6f) }
    },
    "killua" to { h, t, _, A, _, w, r, sa ->
        B(h.armL, .35f, 0f, -.12f, w); B(h.elL, -.7f, 0f, 0f, w); B(h.armR, .35f, 0f, .12f, w); B(h.elR, -.7f, 0f, 0f, w)
        h.hips.rot.z = sin(t * 1.7f) * .09f * w; h.torso.rot.z = -sin(t * 1.7f) * .05f * w; h.head.rot.z += sin(t * .9f) * .12f * w
        h.torso.rot.x += .32f * r; h.hips.pos.y -= .05f * r; h.legL.rot.x *= 1.25f; h.legR.rot.x *= 1.25f
        if (rnd01() < .04f + .3f * sa + .1f * r) { val p = h.root.pos; emit(p.x + rnd(-.4f, .4f), rnd(.3f, 1.6f), p.z + rnd(-.4f, .4f), 0f, 0f, 0f, .18f, .3f, .02f, 0x8ae8ff, 0f, 2f) }
        if (A == "punch" || A == "throw") h.torso.rot.x += .2f * sa
        if (A == "raise") { h.torso.rot.x += .25f * sa; h.head.rot.x += .2f * sa }
        // Godspeed: người phát sáng xanh, tia điện quanh thân
        h.gsK = lerp(h.gsK, if (h.gsOn) 1f else 0f, .1f); val g = h.gsK
        for (m in h.mats) m.setEmissiveF(0f, .12f * g, .22f * g)
        h.godHair?.tick(g, t)   // tóc dựng gai trắng-xanh (ghi đè phát sáng của tóc, chạy sau vòng lặp trên)
        if (g > .2f) {
            val p = h.root.pos
            if (rnd01() < .7f) emit(p.x + rnd(-.5f, .5f), rnd(.2f, 1.8f), p.z + rnd(-.5f, .5f), 0f, 0f, 0f, .22f, .35f, .02f, if (rnd01() < .5f) 0xffffff else 0x7ae6ff, 0f, 2f)
            h.hips.rot.x = 0f; h.head.rot.x -= .1f * g
        }
    },
    "kurapika" to { h, t, _, A, _, w, r, sa ->
        B(h.armR, -.5f, 0f, -.2f, w); B(h.elR, -1f + sin(t * 3f) * .08f, 0f, 0f, w); B(h.armL, .35f, 0f, .1f, w + r * .6f); B(h.elL, -.8f, 0f, 0f, w + r * .6f)
        h.torso.rot.x += -.04f * w + .1f * r; h.head.rot.x += .06f * w; h.head.rot.y += sin(t * .5f) * .18f * w; h.hips.rot.z = sin(t * 1.2f) * .025f * w; h.armR.rot.x *= 1 - .5f * r
        if (A == "raise") {
            h.head.rot.x -= .25f * sa; h.torso.rot.x -= .15f * sa
            if (rnd01() < .3f) { val p = h.root.pos; emit(p.x + rnd(-.3f, .3f), rnd(1f, 1.6f), p.z + rnd(-.3f, .3f), 0f, 1f, 0f, .4f, .3f, .02f, 0xff3d4f, 0f, 1f) }
        }
        // Mắt đỏ rực (Scarlet Eyes) trong 10 giây sau Emperor Time
        val on = t < h.scarUntil && t > h.scarUntil - 11f
        h.scar = lerp(h.scar, if (on) 1f else 0f, .06f); val c = h.scar * (.85f + .15f * sin(t * 8f))
        h.skin?.let { sk -> sk.c[0] = lerp(h.skinBase[0], 1f, .6f * c); sk.c[1] = lerp(h.skinBase[1], .353f, .6f * c); sk.c[2] = lerp(h.skinBase[2], .29f, .6f * c); sk.setEmissiveF(.32f * c, 0f, 0f) }
        h.em?.let { it.c[0] = lerp(.16f, 1f, c); it.c[1] = lerp(.1f, .04f, c); it.c[2] = lerp(.08f, .08f, c) }
        for (e in h.eyeM) e.scl.set(1f + .7f * c, .8f * (1f + .7f * c), .5f)
        if (c > .3f && rnd01() < .35f) { val p = h.root.pos; emit(p.x + rnd(-.15f, .15f), 1.55f, p.z + rnd(-.15f, .15f), 0f, 1.2f, 0f, .35f, .25f, .02f, 0xff2a3a, 0f, 1f) }
    },
    // Kurotsuki: thế kiếm trung đoạn, các đòn vung kiếm / lao trảm / huyết trảm / tuyệt không trảm (xem Chars3.kt)
    "kurotsuki" to { h, t, _, A, k, w, r, sa -> kuroSig(h, t, A, k, w, r, sa) }
)

/** Gắn bộ chuyển động đặc trưng lên mô hình người (installSig). */
fun installSig(h: Human, id: String, col: Int): Human {
    val f = SIG[id] ?: return h; val old = h.extra; var sa = 0f
    h.extra = { dt, t, mv ->
        old?.invoke(dt, t, mv)
        val a = h.act; sa = lerp(sa, if (a != null) 1f else 0f, min(1f, dt * 14f))
        val m = clamp(mv, 0f, 1f); val w = (1 - clamp(m * 5f, 0f, 1f)) * (1 - sa); val r = m * (1 - sa)
        val k = if (a != null) min(1f, a.t / a.d) else 0f
        h.hips.rot.set(0f, 0f, 0f)
        f(h, t, m, a?.n, k, w, r, sa)
        val kf = if (a != null) MV[a.n] else null
        if (kf != null) kfPose(h, kf, k, sa, a!!.m, col)
        h.hips.pos.y -= .06f * (if (a != null) sin(min(1f, k * 3f) * PIF) else 0f)
    }
    return h
}

fun sigWrap(id: String, col: Int, b: () -> Human): () -> Human = { installSig(b(), id, col) }
