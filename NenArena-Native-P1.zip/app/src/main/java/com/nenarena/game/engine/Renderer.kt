package com.nenarena.game.engine

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Vòng lặp game chạy trên luồng GL. */
interface GameLoop {
    val scene: Scene
    fun onSurface(w: Int, h: Int)
    fun update(dt: Float)
}

private const val VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNor;
uniform mat4 uVP; uniform mat4 uView; uniform mat4 uModel; uniform mat3 uNM; uniform float uOutline;
out vec3 vN; out vec3 vP; out float vD;
void main(){
  vec3 p = aPos;
  if(uOutline > 0.) p += normalize(aNor) * uOutline;
  vec4 wp = uModel * vec4(p, 1.);
  vP = aPos;
  vN = normalize(uNM * aNor);
  vD = -(uView * wp).z;
  gl_Position = uVP * wp;
}"""

private const val FS = """#version 300 es
precision mediump float;
in vec3 vN; in vec3 vP; in float vD;
uniform int uMode;
uniform vec3 uCol; uniform vec3 uEmi; uniform float uOpa; uniform float uOutline;
uniform vec3 uSky; uniform vec3 uGnd; uniform vec3 uSunC; uniform vec3 uSunD;
uniform float uHemiI; uniform float uSunI;
uniform vec3 uFogC; uniform float uFogD; uniform float uUseFog;
out vec4 o;
void main(){
  if(uOutline > 0.){ o = vec4(.04, .02, .08, 1.); return; }
  vec3 col;
  if(uMode == 3){
    float h = normalize(vP).y;
    vec3 hor = vec3(.231,.071,.188), mid = vec3(.169,.051,.259), top = vec3(.02,.012,.09);
    col = mix(hor, mid, smoothstep(0., .22, h));
    col = mix(col, top, smoothstep(.15, .7, h));
    if(h < 0.) col = hor;
    o = vec4(col, 1.); return;
  }
  if(uMode == 1){ col = uCol; }
  else {
    vec3 n = normalize(vN);
    if(!gl_FrontFacing) n = -n;
    float nd = dot(n, uSunD);
    float dif;
    if(uMode == 0){
      float g = clamp(nd * .5 + .5, 0., .999);
      float gi = floor(g * 4.);
      dif = gi < 1. ? .353 : (gi < 2. ? .6 : (gi < 3. ? .816 : 1.));
    } else dif = max(nd, 0.);
    vec3 hemi = mix(uGnd, uSky, n.y * .5 + .5) * uHemiI;
    col = uCol * (hemi + uSunC * uSunI * dif) + uEmi;
  }
  if(uUseFog > .5){
    float f = 1. - exp(-uFogD * uFogD * vD * vD);
    col = mix(col, uFogC, clamp(f, 0., 1.));
  }
  o = vec4(col, uOpa);
}"""

class GLRenderer(private val game: GameLoop) : GLSurfaceView.Renderer {
    private var prog = 0
    private val loc = HashMap<String, Int>()
    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val nm = FloatArray(9)
    private var aspect = 1f
    private var last = 0L
    private val opaque = ArrayList<Node>()
    private val blend = ArrayList<Node>()
    private val addv = ArrayList<Node>()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VS, FS)
        loc.clear()
        for (n in listOf("uVP", "uView", "uModel", "uNM", "uOutline", "uMode", "uCol", "uEmi", "uOpa", "uSky", "uGnd",
            "uSunC", "uSunD", "uHemiI", "uSunI", "uFogC", "uFogD", "uUseFog"))
            loc[n] = GLES30.glGetUniformLocation(prog, n)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glFrontFace(GLES30.GL_CCW)
        // GPU context mới: mọi buffer cũ vô hiệu
        invalidateAll(game.scene.root)
        last = 0L
    }

    private fun invalidateAll(n: Node) {
        n.geo?.let { it.vao = 0; it.vbo = 0; it.ibo = 0 }
        for (c in n.children) invalidateAll(c)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h)
        aspect = w.toFloat() / h
        game.onSurface(w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        var dt = if (last == 0L) 0.016f else (now - last) / 1e9f
        last = now
        if (dt > 0.05f) dt = 0.05f
        game.update(dt)
        draw(game.scene)
    }

    private fun hex3(h: Int, out: FloatArray) { out[0] = ((h shr 16) and 255) / 255f; out[1] = ((h shr 8) and 255) / 255f; out[2] = (h and 255) / 255f }
    private val tmp = FloatArray(3)

    private fun draw(sc: Scene) {
        hex3(sc.fogHex, tmp)
        GLES30.glClearColor(tmp[0], tmp[1], tmp[2], 1f)
        GLES30.glDepthMask(true)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        sc.root.updateWorld(null)
        M4.perspective(proj, sc.fov, aspect, 0.1f, 600f)
        M4.lookAt(view, sc.camPos.x, sc.camPos.y, sc.camPos.z, sc.camTarget.x, sc.camTarget.y, sc.camTarget.z)
        M4.mul(vp, proj, view)

        GLES30.glUseProgram(prog)
        GLES30.glUniformMatrix4fv(loc["uVP"]!!, 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(loc["uView"]!!, 1, false, view, 0)
        val L = sc.light
        hex3(L.sky[0], tmp); GLES30.glUniform3f(loc["uSky"]!!, tmp[0], tmp[1], tmp[2])
        hex3(L.sky[1], tmp); GLES30.glUniform3f(loc["uGnd"]!!, tmp[0], tmp[1], tmp[2])
        hex3(L.sun, tmp); GLES30.glUniform3f(loc["uSunC"]!!, tmp[0], tmp[1], tmp[2])
        val d = L.sunDir; val dl = Math.sqrt((d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).toDouble()).toFloat()
        GLES30.glUniform3f(loc["uSunD"]!!, d[0] / dl, d[1] / dl, d[2] / dl)
        GLES30.glUniform1f(loc["uHemiI"]!!, L.hemiI)
        GLES30.glUniform1f(loc["uSunI"]!!, L.sunI)
        hex3(sc.fogHex, tmp); GLES30.glUniform3f(loc["uFogC"]!!, tmp[0], tmp[1], tmp[2])
        GLES30.glUniform1f(loc["uFogD"]!!, sc.fogDensity)

        opaque.clear(); blend.clear(); addv.clear()
        collect(sc.root)
        val ex = sc.camPos
        for (n in blend) n.sortKey = (n.world[12] - ex.x).let { it * it } + (n.world[13] - ex.y).let { it * it } + (n.world[14] - ex.z).let { it * it }
        blend.sortByDescending { it.sortKey }

        // 1) trời (vẽ đầu tiên, không ghi depth)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST); GLES30.glDepthMask(false); GLES30.glDisable(GLES30.GL_CULL_FACE)
        for (n in opaque) if (n.mat!!.type == MatType.SKY) drawNode(n, false)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST); GLES30.glDepthMask(true)
        // 2) viền đen (inverted hull) rồi vật đục
        for (n in opaque) {
            val m = n.mat!!
            if (m.type != MatType.SKY && n.outline) { cull(front = true); drawNode(n, outlinePass = true) }
        }
        for (n in opaque) {
            val m = n.mat!!
            if (m.type == MatType.SKY) continue
            cull(front = false, off = m.doubleSided); drawNode(n, false)
        }
        // 3) trong suốt thường
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        for (n in blend) { val m = n.mat!!; cull(false, m.doubleSided); GLES30.glDepthMask(m.depthWrite); drawNode(n, false) }
        // 4) cộng sáng (additive)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE)
        GLES30.glDepthMask(false)
        for (n in addv) { cull(false, true); drawNode(n, false) }
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun cull(front: Boolean, off: Boolean = false) {
        if (off) { GLES30.glDisable(GLES30.GL_CULL_FACE); return }
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(if (front) GLES30.GL_FRONT else GLES30.GL_BACK)
    }

    private fun collect(n: Node) {
        if (!n.visible) return
        val g = n.geo; val m = n.mat
        if (g != null && m != null) {
            if (m.additive) addv.add(n) else if (m.transparent) blend.add(n) else opaque.add(n)
        }
        for (c in n.children) collect(c)
    }

    private fun drawNode(n: Node, outlinePass: Boolean) {
        val g = n.geo!!; val m = n.mat!!
        upload(g)
        GLES30.glUniformMatrix4fv(loc["uModel"]!!, 1, false, n.world, 0)
        M4.normalMat(nm, n.world)
        GLES30.glUniformMatrix3fv(loc["uNM"]!!, 1, false, nm, 0)
        GLES30.glUniform1f(loc["uOutline"]!!, if (outlinePass) 0.028f else 0f)
        val mode = when (m.type) { MatType.TOON -> 0; MatType.BASIC -> 1; MatType.LAMBERT -> 2; MatType.SKY -> 3 }
        GLES30.glUniform1i(loc["uMode"]!!, mode)
        GLES30.glUniform3f(loc["uCol"]!!, m.c[0], m.c[1], m.c[2])
        GLES30.glUniform3f(loc["uEmi"]!!, m.e[0], m.e[1], m.e[2])
        GLES30.glUniform1f(loc["uOpa"]!!, m.opacity)
        GLES30.glUniform1f(loc["uUseFog"]!!, if (m.fog && !m.additive) 1f else 0f)
        GLES30.glBindVertexArray(g.vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, g.indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
        GLES30.glBindVertexArray(0)
    }

    private fun upload(g: Geometry) {
        if (g.vao != 0) return
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); g.vao = ids[0]
        GLES30.glBindVertexArray(g.vao)
        GLES30.glGenBuffers(1, ids, 0); g.vbo = ids[0]
        val vb = ByteBuffer.allocateDirect(g.verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(g.verts)
        vb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, g.vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, g.verts.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glGenBuffers(1, ids, 0); g.ibo = ids[0]
        val ib = ByteBuffer.allocateDirect(g.indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(g.indices)
        ib.position(0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, g.ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, g.indices.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
    }

    private fun link(vs: String, fs: String): Int {
        fun sh(t: Int, src: String): Int {
            val s = GLES30.glCreateShader(t)
            GLES30.glShaderSource(s, src); GLES30.glCompileShader(s)
            val ok = IntArray(1); GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader lỗi: " + GLES30.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(p)
        val ok = IntArray(1); GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("Link lỗi: " + GLES30.glGetProgramInfoLog(p))
        return p
    }
}
