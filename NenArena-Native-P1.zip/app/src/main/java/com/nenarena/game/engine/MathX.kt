package com.nenarena.game.engine

import kotlin.math.*

const val TAU = (PI * 2).toFloat()
const val PIF = PI.toFloat()

fun clamp(v: Float, a: Float, b: Float) = if (v < a) a else if (v > b) b else v
fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
fun ease(t: Float): Float { val k = clamp(t, 0f, 1f); return k * k * (3 - 2 * k) }

class Vec3(@JvmField var x: Float = 0f, @JvmField var y: Float = 0f, @JvmField var z: Float = 0f) {
    fun set(a: Float, b: Float, c: Float): Vec3 { x = a; y = b; z = c; return this }
    fun copy(o: Vec3): Vec3 { x = o.x; y = o.y; z = o.z; return this }
    fun clone() = Vec3(x, y, z)
    fun length() = sqrt(x * x + y * y + z * z)
    fun scale(s: Float): Vec3 { x *= s; y *= s; z *= s; return this }
    fun addScaled(o: Vec3, s: Float): Vec3 { x += o.x * s; y += o.y * s; z += o.z * s; return this }
}

/** Ma trận 4x4 cột-chính (column-major) giống OpenGL. */
object M4 {
    fun identity(m: FloatArray) {
        for (i in 0 until 16) m[i] = 0f
        m[0] = 1f; m[5] = 1f; m[10] = 1f; m[15] = 1f
    }

    fun mul(out: FloatArray, a: FloatArray, b: FloatArray) {
        val r = FloatArray(16)
        for (c in 0 until 4) for (rr in 0 until 4) {
            var s = 0f
            for (k in 0 until 4) s += a[k * 4 + rr] * b[c * 4 + k]
            r[c * 4 + rr] = s
        }
        System.arraycopy(r, 0, out, 0, 16)
    }

    /** Dựng ma trận từ vị trí + Euler XYZ (như three.js) + scale. */
    fun compose(out: FloatArray, px: Float, py: Float, pz: Float, rx: Float, ry: Float, rz: Float, sx: Float, sy: Float, sz: Float) {
        val a = cos(rx); val b = sin(rx)
        val c = cos(ry); val d = sin(ry)
        val e = cos(rz); val f = sin(rz)
        val ae = a * e; val af = a * f; val be = b * e; val bf = b * f
        // three.js Matrix4.makeRotationFromEuler, order XYZ
        val m00 = c * e;            val m01 = -c * f;           val m02 = d
        val m10 = af + be * d;      val m11 = ae - bf * d;      val m12 = -b * c
        val m20 = bf - ae * d;      val m21 = be + af * d;      val m22 = a * c
        out[0] = m00 * sx; out[1] = m10 * sx; out[2] = m20 * sx; out[3] = 0f
        out[4] = m01 * sy; out[5] = m11 * sy; out[6] = m21 * sy; out[7] = 0f
        out[8] = m02 * sz; out[9] = m12 * sz; out[10] = m22 * sz; out[11] = 0f
        out[12] = px; out[13] = py; out[14] = pz; out[15] = 1f
    }

    fun perspective(out: FloatArray, fovDeg: Float, aspect: Float, near: Float, far: Float) {
        val f = 1f / tan(Math.toRadians(fovDeg.toDouble()) / 2.0).toFloat()
        for (i in 0 until 16) out[i] = 0f
        out[0] = f / aspect; out[5] = f
        out[10] = (far + near) / (near - far); out[11] = -1f
        out[14] = 2f * far * near / (near - far)
    }

    fun lookAt(out: FloatArray, ex: Float, ey: Float, ez: Float, tx: Float, ty: Float, tz: Float) {
        var fx = tx - ex; var fy = ty - ey; var fz = tz - ez
        val fl = sqrt(fx * fx + fy * fy + fz * fz); fx /= fl; fy /= fl; fz /= fl
        // up = (0,1,0)
        var sx = fy * 0f - fz * 1f; var sy = fz * 0f - fx * 0f; var sz = fx * 1f - fy * 0f
        val sl = sqrt(sx * sx + sy * sy + sz * sz); sx /= sl; sy /= sl; sz /= sl
        val ux = sy * fz - sz * fy; val uy = sz * fx - sx * fz; val uz = sx * fy - sy * fx
        out[0] = sx; out[1] = ux; out[2] = -fx; out[3] = 0f
        out[4] = sy; out[5] = uy; out[6] = -fy; out[7] = 0f
        out[8] = sz; out[9] = uz; out[10] = -fz; out[11] = 0f
        out[12] = -(sx * ex + sy * ey + sz * ez)
        out[13] = -(ux * ex + uy * ey + uz * ez)
        out[14] = (fx * ex + fy * ey + fz * ez)
        out[15] = 1f
    }

    /** Ma trận pháp tuyến = (phần 3x3 của m)^-T, ghi vào out[9] (cột-chính). */
    fun normalMat(out: FloatArray, m: FloatArray) {
        val a00 = m[0]; val a01 = m[4]; val a02 = m[8]
        val a10 = m[1]; val a11 = m[5]; val a12 = m[9]
        val a20 = m[2]; val a21 = m[6]; val a22 = m[10]
        val b01 = a22 * a11 - a12 * a21
        val b11 = -a22 * a10 + a12 * a20
        val b21 = a21 * a10 - a11 * a20
        var det = a00 * b01 + a01 * b11 + a02 * b21
        if (abs(det) < 1e-12f) { for (i in 0 until 9) out[i] = 0f; out[0] = 1f; out[4] = 1f; out[8] = 1f; return }
        det = 1f / det
        // inverse
        val i00 = b01 * det; val i01 = (-a22 * a01 + a02 * a21) * det; val i02 = (a12 * a01 - a02 * a11) * det
        val i10 = b11 * det; val i11 = (a22 * a00 - a02 * a20) * det; val i12 = (-a12 * a00 + a02 * a10) * det
        val i20 = b21 * det; val i21 = (-a21 * a00 + a01 * a20) * det; val i22 = (a11 * a00 - a01 * a10) * det
        // transpose of inverse, column-major
        out[0] = i00; out[1] = i01; out[2] = i02
        out[3] = i10; out[4] = i11; out[5] = i12
        out[6] = i20; out[7] = i21; out[8] = i22
    }
}
