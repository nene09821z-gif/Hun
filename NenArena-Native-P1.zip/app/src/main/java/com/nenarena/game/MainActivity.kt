package com.nenarena.game

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nenarena.game.engine.GLRenderer
import com.nenarena.game.game.Game
import com.nenarena.game.game.Input
import kotlin.math.hypot
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private var gl: GLSurfaceView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        val game = Game()
        setContent {
            Box(Modifier.fillMaxSize().then(Modifier)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        GLSurfaceView(ctx).apply {
                            setEGLContextClientVersion(3)
                            setEGLConfigChooser(8, 8, 8, 8, 24, 0)
                            setRenderer(GLRenderer(game))
                            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                            gl = this
                        }
                    }
                )
                CameraZone(Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(.5f))
                Joystick(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(.5f))
            }
        }
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { gl?.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); gl?.onResume() }
}

/** Cần analog trái: nơi chạm đầu tiên là tâm. */
@Composable
private fun Joystick(modifier: Modifier) {
    var origin by remember { mutableStateOf<Offset?>(null) }
    var knob by remember { mutableStateOf(Offset.Zero) }
    val radius = 150f
    Box(modifier.pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { p -> origin = p; knob = p },
            onDragEnd = { origin = null; Input.mx = 0f; Input.my = 0f },
            onDragCancel = { origin = null; Input.mx = 0f; Input.my = 0f },
            onDrag = { change, _ ->
                val o = origin ?: change.position
                val dx = change.position.x - o.x; val dy = change.position.y - o.y
                val d = hypot(dx, dy)
                val k = if (d > 0f) min(d, radius) / d else 0f
                knob = Offset(o.x + dx * k, o.y + dy * k)
                Input.mx = dx * k / radius; Input.my = dy * k / radius
                change.consume()
            }
        )
    }) {
        val o = origin
        if (o != null) Canvas(Modifier.fillMaxSize()) {
            drawCircle(Color(0x55FF3FA0), radius, o)
            drawCircle(Color(0xAAFFB0DD), 46f, knob)
        }
    }
}

/** Vuốt nửa phải màn hình để xoay camera. */
@Composable
private fun CameraZone(modifier: Modifier) {
    Box(modifier.pointerInput(Unit) {
        detectDragGestures { change, drag ->
            Input.camDX += drag.x; Input.camDY += drag.y; change.consume()
        }
    })
}
