package com.nenarena.game.engine

enum class MatType { TOON, BASIC, LAMBERT, SKY }

/** Vật liệu: toon (ánh sáng bậc thang như MeshToonMaterial), basic (không đèn) hoặc lambert. */
class Material(
    @JvmField var type: MatType,
    hex: Int,
    emissiveHex: Int = 0,
    @JvmField var opacity: Float = 1f,
    @JvmField var additive: Boolean = false,
    @JvmField var depthWrite: Boolean = true,
    @JvmField var doubleSided: Boolean = false,
    @JvmField var fog: Boolean = true
) {
    @JvmField val c = FloatArray(3)
    @JvmField val e = FloatArray(3)
    val transparent get() = opacity < 1f || additive

    init { setColor(hex); setEmissive(emissiveHex) }

    fun setColor(hex: Int) { c[0] = ((hex shr 16) and 255) / 255f; c[1] = ((hex shr 8) and 255) / 255f; c[2] = (hex and 255) / 255f }
    fun setEmissive(hex: Int) { e[0] = ((hex shr 16) and 255) / 255f; e[1] = ((hex shr 8) and 255) / 255f; e[2] = (hex and 255) / 255f }
}

fun toon(hex: Int, emissive: Int = 0) = Material(MatType.TOON, hex, emissive)
fun basic(hex: Int, opacity: Float = 1f, additive: Boolean = false) =
    Material(MatType.BASIC, hex, 0, opacity, additive, depthWrite = !additive && opacity >= 1f)
fun lambert(hex: Int, emissive: Int = 0) = Material(MatType.LAMBERT, hex, emissive)

/** Nút cảnh: có vị trí/xoay (Euler XYZ)/tỉ lệ, con cháu, và tuỳ chọn mesh. */
open class Node {
    @JvmField val pos = Vec3()
    @JvmField val rot = Vec3()
    @JvmField val scl = Vec3(1f, 1f, 1f)
    @JvmField val children = ArrayList<Node>()
    @JvmField var parent: Node? = null
    @JvmField var geo: Geometry? = null
    @JvmField var mat: Material? = null
    @JvmField var outline = false
    @JvmField var visible = true
    @JvmField val world = FloatArray(16).also { M4.identity(it) }
    @JvmField var sortKey = 0f

    fun add(n: Node): Node { n.parent?.children?.remove(n); n.parent = this; children.add(n); return n }
    fun remove(n: Node) { if (children.remove(n)) n.parent = null }

    fun setScale(s: Float) { scl.set(s, s, s) }

    fun updateWorld(pm: FloatArray?) {
        M4.compose(world, pos.x, pos.y, pos.z, rot.x, rot.y, rot.z, scl.x, scl.y, scl.z)
        if (pm != null) M4.mul(world, pm, world)
        for (c in children) c.updateWorld(world)
    }
}

/** Tương đương mk() trong bản HTML: tạo mesh có viền đen, gắn vào cha. */
fun mk(geo: Geometry, mat: Material, parent: Node?, x: Float = 0f, y: Float = 0f, z: Float = 0f,
       rx: Float = 0f, ry: Float = 0f, rz: Float = 0f, sx: Float = 1f, sy: Float = 1f, sz: Float = 1f,
       outline: Boolean = true): Node {
    val n = Node()
    n.geo = geo; n.mat = mat
    n.pos.set(x, y, z); n.rot.set(rx, ry, rz); n.scl.set(sx, sy, sz)
    n.outline = outline && mat.type == MatType.TOON
    parent?.add(n)
    return n
}

class Light(val sky: IntArray = intArrayOf(0xb9a0ff, 0x2a1030), val sun: Int = 0xffc8e0) {
    @JvmField var hemiI = 1.05f
    @JvmField var sunI = 0.95f
    @JvmField val sunDir = floatArrayOf(-12f, 24f, 14f)
}

class Scene {
    @JvmField val root = Node()
    @JvmField val camPos = Vec3(0f, 12f, 22f)
    @JvmField val camTarget = Vec3(0f, 1f, 0f)
    @JvmField var fov = 50f
    @JvmField var fogHex = 0x3b1230
    @JvmField var fogDensity = 0.0125f
    @JvmField val light = Light()
}
