package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*
import java.util.Random

const val ARENA = 25f

/** Đấu trường: trời, nền, bục đá, vòng rune, kết giới, trụ tổ kiến, trứng, gai núi, tinh thể (port từ buildWorld). */
class World(val scene: Scene) {
    val root = Node()
    val rune = ArrayList<Material>()
    private val rnd = Random(20260101L)
    private fun rnd(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)

    init {
        scene.root.add(root)

        // Trời: hình cầu bán kính 400, shader gradient
        val sky = Material(MatType.SKY, 0x3b1230, doubleSided = true, depthWrite = false, fog = false)
        mk(Geometry.sphere(400f, 24, 16), sky, root, outline = false)

        // Nền tối ở xa
        val gr = mk(Geometry.circle(220f, 40), lambert(0x1a0f22), root, y = -.7f, rx = -PIF / 2, outline = false)
        gr.mat!!.doubleSided = true

        // Bục đá trung tâm (màu xấp xỉ texStone * 0xb8a8c8)
        mk(Geometry.cylinder(27.5f, 29f, 1.2f, 48), lambert(0x33233f), root, y = -.6f, outline = false)

        // Vòng rune hồng (cộng sáng)
        for (r in floatArrayOf(25.8f, 24.8f, 17.4f, 16.9f, 9.5f)) {
            val m = basic(0xff3fa0, .75f, additive = true); rune.add(m)
            mk(Geometry.ring(r - .12f, r + .12f, 72), m, root, y = .03f, rx = -PIF / 2, outline = false)
        }

        // Kết giới hình trụ rỗng, mờ dần
        val bm = basic(0xff3fa0, .16f, additive = true); bm.doubleSided = true; rune.add(bm)
        mk(Geometry.cylinder(26.8f, 26.8f, 4f, 64, true), bm, root, y = 2f, outline = false)

        // 16 trụ tổ kiến
        val pg = Geometry.cylinder(1f, 1.5f, 1f, 8).translated(0f, .5f, 0f)
        val pm = lambert(0x3b2a44, 0x1a0820)
        for (i in 0 until 16) {
            val a = i / 16f * TAU; val r = 34f + (i % 2) * 4f; val hh = rnd(9f, 17f)
            mk(pg, pm, root, cos(a) * r, -.6f, sin(a) * r, ry = rnd(0f, 3f), sx = rnd(1.4f, 2.2f), sy = hh, sz = rnd(1.4f, 2.2f), outline = false)
        }
        // 40 trứng cam
        val eg = Geometry.sphere(1f, 10, 8); val em = basic(0xffa23a, .85f)
        for (i in 0 until 40) {
            val a = rnd(0f, TAU); val r = rnd(33f, 70f); val s = rnd(.5f, 1.6f)
            mk(eg, em, root, cos(a) * r, rnd(.2f, 1.2f), sin(a) * r, sx = s, sy = s * 1.3f, sz = s, outline = false)
        }
        // 40 gai núi xa
        val sg = Geometry.cone(1f, 1f, 6).translated(0f, .5f, 0f); val sm = lambert(0x25122e)
        for (i in 0 until 40) {
            val a = rnd(0f, TAU); val r = rnd(80f, 160f); val hh = rnd(25f, 70f)
            mk(sg, sm, root, cos(a) * r, -1f, sin(a) * r, sx = rnd(8f, 16f), sy = hh, sz = rnd(8f, 16f), outline = false)
        }
        // 22 tinh thể xanh
        val cg = Geometry.octahedron(1f); val cm = basic(0x58f0e0, .9f)
        for (i in 0 until 22) {
            val a = rnd(0f, TAU); val r = rnd(30f, 40f)
            mk(cg, cm, root, cos(a) * r, rnd(1f, 3f), sin(a) * r, rx = rnd(-.3f, .3f), rz = rnd(-.3f, .3f), sx = .5f, sy = rnd(1.2f, 2.8f), sz = .5f, outline = false)
        }
    }

    fun update(t: Float) {
        // vòng rune nhấp nháy nhẹ
        for ((i, m) in rune.withIndex()) m.opacity = (if (i == rune.size - 1) .16f else .75f) * (.9f + .1f * sin(t * 2f + i))
    }
}
