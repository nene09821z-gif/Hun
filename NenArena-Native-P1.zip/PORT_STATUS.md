# Tiến độ port NEN ARENA HTML -> Kotlin native

## Giai đoạn 1 (bản này) – ENGINE + DI CHUYỂN
- [x] Engine: toán, mesh, scene graph, shader toon, viền, sương mù, trời, additive
- [x] Đấu trường (nền, bục, vòng rune, kết giới, trụ, trứng, gai núi, tinh thể)
- [x] Mô hình người + animation đi + 7 động tác (throw/punch/cast/pray/raise/spread/slash)
- [x] Hisoka (thiếu: lá bài texture, hình trái tim texture, hào quang aura)
- [x] Cần analog + camera bám + vuốt xoay camera

## Còn lại (theo thứ tự)
- [ ] Hệ texture (canvas -> bitmap), sprite, hạt (particles), aura shader, FX (ring/beam/dome/slash)
- [ ] HUD: thanh máu, thanh Nen, nút đánh/chiêu 1/chiêu 2/ULT/lướt, chiến cảnh, banner, combo
- [ ] Chiến đấu: đạn, va chạm, sát thương, knockback, hit-stop, slow-mo, camera điện ảnh
- [ ] Kẻ địch: Kiến Lính, Cận Vệ, Cánh; 3 boss Hộ Vệ; 4 quái Nen (Franklin, Feitan, Uvogin, Nobunaga); AI + đợt sóng
- [ ] 13 nhân vật: Hisoka, Illumi, Netero, Meruem, Zeno, Chrollo, Gon, Killua, Kurapika, Silva, Leorio, Morel, Ging (mô hình + 4 kỹ năng mỗi người)
- [ ] Màn chọn nhân vật, menu, tạm dừng, thất bại, khu vực (areas), âm thanh, đồ hoạ thấp/trung/cao
