# ===== NEN ARENA — R8 full-mode, tối ưu mạnh =====
# Game không dùng reflection: KHÔNG giữ cả package, để R8 inline / gộp / loại code chết.
-optimizationpasses 5
-allowaccessmodification
-repackageclasses ''
-mergeinterfacesaggressively
-overloadaggressively

# Xoá toàn bộ log + kiểm tra null của Kotlin (đỡ tốn CPU ở vòng lặp nóng)
-assumenosideeffects class android.util.Log {
    public static *** v(...);
    public static *** d(...);
    public static *** i(...);
}
-assumenosideeffects class kotlin.jvm.internal.Intrinsics {
    public static void checkNotNull(...);
    public static void checkNotNullParameter(...);
    public static void checkNotNullExpressionValue(...);
    public static void checkParameterIsNotNull(...);
    public static void checkExpressionValueIsNotNull(...);
    public static void checkReturnedValueIsNotNull(...);
    public static void checkFieldIsNotNull(...);
}

# Enum values()/valueOf() (Tier) vẫn được R8 xử lý tự động. Chỉ giữ thứ thật sự cần:
-keepclassmembers enum * { public static **[] values(); public static ** valueOf(java.lang.String); }
-keep class com.nenarena.game.MainActivity { <init>(); }
-dontwarn org.jspecify.**
-dontwarn kotlin.**
