package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

class Act(val n: String, val d: Float, val flip: Boolean = false) { var t = 0f; var m = false }

/** Mô hình người dựng bằng hình khối (port 1-1 từ buildHuman của bản HTML). */
class Human(val s: Float, val w: Float) {
    val root = Node()
    val body = Node()
    val hips = Node()
    val torso = Node()
    val head = Node()
    val armL = Node(); val armR = Node()
    val elL = Node(); val elR = Node()
    val legL = Node(); val legR = Node()
    val knL = Node(); val knR = Node()
    val mats = ArrayList<Material>()
    val outs = ArrayList<Node>()
    var phase = 0f
    var act: Act? = null
    var lean = 0f
    var extra: ((dt: Float, time: Float, mv: Float) -> Unit)? = null
    var hover = 0f
    /** Mô hình 3D thật (skin): đồng bộ xương theo các khớp của khung người vô hình, chạy cuối poseHuman. */
    var sync: ((dt: Float, time: Float, mv: Float) -> Unit)? = null
    var fadeHook: ((Float) -> Unit)? = null
    var skin: Material? = null; val skinBase = FloatArray(3)
    var em: Material? = null; var eyeM: List<Node> = emptyList(); var dkEyes: List<Node> = emptyList()
    var scar = 0f; var scarUntil = 0f; var gsOn = false; var gsK = 0f; var dkOn = false; var dkK = 0f
    var aura: Node? = null; var auraDark: Node? = null
    /** Aura sấm sét bao quanh thân (Killua). */
    var zap: ZapAura? = null
    var auraMat: Material? = null; var auraMat2: Material? = null
    var aCol = intArrayOf(0xffffff, 0xffffff)
    /** Kurotsuki: thanh katana đang cầm (SkinModel), trạng thái nhuốm máu / nguyệt thực, độ vung kiếm 0..1. */
    var blade: SkinModel? = null
    var bloodOn = false; var eclOn = false; var swingK = 0f
    /** Kurotsuki: kiếm đang nằm trong vỏ (tay không), và mã chống thu kiếm trễ sau khi đã rút lại. */
    var sheathed = false; var sheathTok = 0

    fun mt(c: Int, emissive: Int = 0): Material { val m = toon(c, emissive); mats.add(m); return m }

    /** mkk: mesh có viền, ghi nhận lại để mờ dần khi tàng hình. */
    fun mkk(g: Geometry, m: Material, p: Node, x: Float = 0f, y: Float = 0f, z: Float = 0f,
            rx: Float = 0f, ry: Float = 0f, rz: Float = 0f, sx: Float = 1f, sy: Float = 1f, sz: Float = 1f, ol: Boolean = true): Node {
        val n = mk(g, m, p, x, y, z, rx, ry, rz, sx, sy, sz, ol)
        if (n.outline) outs.add(n)
        return n
    }

    fun fade(o: Float) {
        for (m in mats) m.opacity = o
        for (l in outs) l.visible = o >= 1f
        fadeHook?.invoke(o)
    }
}

class HumanOpts(
    val s: Float = 1f, val w: Float = 1f,
    val skin: Int, val top: Int, val bottom: Int, val shoe: Int = 0x111111,
    val legLow: Int? = null, val sleeveLong: Boolean = false
)

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)

fun buildHuman(o: HumanOpts): Human {
    val h = Human(o.s, o.w)
    val skin = h.mt(o.skin); val top = h.mt(o.top); val bot = h.mt(o.bottom); val shoe = h.mt(o.shoe)
    val W = o.w
    h.skin = skin; skin.c.copyInto(h.skinBase)
    h.root.add(h.body); h.body.setScale(o.s)
    h.hips.pos.y = .95f; h.body.add(h.hips)
    h.mkk(sph(.22f, 12, 8), bot, h.hips, 0f, .02f, 0f, sx = 1.15f * W, sy = .8f)
    for ((i, sx) in listOf(-1f, 1f).withIndex()) {
        val lg = if (i == 0) h.legL else h.legR
        val kn = if (i == 0) h.knL else h.knR
        lg.pos.set(sx * .15f * W, 0f, 0f); h.hips.add(lg)
        h.mkk(cyl(.13f * W, .095f, .52f, 10), bot, lg, 0f, -.26f, 0f)
        kn.pos.y = -.52f; lg.add(kn)
        h.mkk(cyl(.095f, .075f, .46f, 10), if (o.legLow != null) h.mt(o.legLow) else bot, kn, 0f, -.23f, 0f)
        h.mkk(box(.15f, .1f, .3f), shoe, kn, 0f, -.5f, .07f)
    }
    h.torso.pos.y = .02f; h.hips.add(h.torso)
    h.mkk(cyl(.27f * W, .2f * W, .62f, 12), top, h.torso, 0f, .33f, 0f)
    for ((i, sx) in listOf(-1f, 1f).withIndex()) {
        val ar = if (i == 0) h.armL else h.armR
        val el = if (i == 0) h.elL else h.elR
        ar.pos.set(sx * .34f * W, .58f, 0f); h.torso.add(ar)
        h.mkk(sph(.12f * W, 10, 8), top, ar, 0f, 0f, 0f)
        h.mkk(cyl(.075f * W, .065f * W, .4f, 8), top, ar, 0f, -.2f, 0f)
        el.pos.y = -.4f; ar.add(el)
        h.mkk(cyl(.065f * W, .055f * W, .38f, 8), if (o.sleeveLong) top else skin, el, 0f, -.19f, 0f)
        h.mkk(sph(.07f * W, 8, 6), skin, el, 0f, -.42f, 0f)
    }
    h.mkk(cyl(.07f, .08f, .14f, 8), skin, h.torso, 0f, .68f, 0f, ol = false)
    h.head.pos.set(0f, .78f, 0f); h.torso.add(h.head)
    h.mkk(sph(.2f, 16, 12), skin, h.head, 0f, .14f, 0f, sy = 1.08f)
    return h
}

fun humanEyes(h: Human, hex: Int, sz: Float, y: Float, spread: Float) {
    val m = basic(hex)
    for (s in listOf(-1f, 1f)) mk(sph(sz, 8, 6), m, h.head, s * spread, y, .178f, sy = .8f, sz = .5f, outline = false)
}

fun poseHuman(h: Human, dt: Float, mv: Float, time: Float) {
    h.phase += dt * (5f + mv * 7f)
    val s = sin(h.phase) * mv
    h.legL.rot.x = s * .85f; h.legR.rot.x = -s * .85f
    h.knL.rot.x = max(0f, s) * .9f; h.knR.rot.x = max(0f, -s) * .9f
    h.armL.rot.set(-s * .7f, 0f, .08f); h.armR.rot.set(s * .7f, 0f, -.08f)
    h.elL.rot.x = -.25f - mv * .3f; h.elR.rot.x = -.25f - mv * .3f
    h.torso.rot.set(.1f * mv + h.lean, s * .12f, 0f); h.head.rot.set(0f, 0f, 0f)
    h.hips.pos.y = .95f + abs(cos(h.phase)) * .05f * mv + sin(time * 2.2f) * .012f
    val a = h.act
    if (a != null) {
        a.t += dt
        val k = min(1f, a.t / a.d)
        val ob = arrayOf(h.armL, h.armR, h.elL, h.elR, h.torso)
        val sv = Array(ob.size) { floatArrayOf(ob[it].rot.x, ob[it].rot.y, ob[it].rot.z) }
        applyAct(h, a, k)
        val w = ease(clamp(min(a.t / .09f, (a.d - a.t) / .12f), 0f, 1f))
        for (i in ob.indices) ob[i].rot.set(lerp(sv[i][0], ob[i].rot.x, w), lerp(sv[i][1], ob[i].rot.y, w), lerp(sv[i][2], ob[i].rot.z, w))
        if (a.t >= a.d) h.act = null
    }
    h.extra?.invoke(dt, time, mv)
    h.sync?.invoke(dt, time, mv)
}

private fun applyAct(h: Human, a: Act, k: Float) {
    val e = ease(k); val f = min(1f, k * 5f)
    when (a.n) {
        "throw" -> {
            val x = if (k < .35f) lerp(-.2f, -2.7f, k / .35f) else lerp(-2.7f, -1.45f, (k - .35f) / .65f)
            h.armR.rot.set(x, 0f, -.15f); h.elR.rot.x = -.2f; h.torso.rot.y = lerp(.5f, -.5f, e)
        }
        "punch" -> {
            val A = if (a.flip) h.armL else h.armR; val B = if (a.flip) h.armR else h.armL
            val Ael = if (a.flip) h.elL else h.elR; val Bel = if (a.flip) h.elR else h.elL
            val q = if (k < .35f) k / .35f else 1f - (k - .35f) / .65f * .6f
            A.rot.set(-1.55f * q - .2f, 0f, 0f); Ael.rot.x = -.1f
            B.rot.set(-.9f, 0f, if (a.flip) -.5f else .5f); Bel.rot.x = -1.4f
            h.torso.rot.y = (if (a.flip) 1f else -1f) * .5f * q; h.torso.rot.x = .25f
        }
        "cast" -> {
            h.armL.rot.set(-1.5f * f, 0f, .25f * f); h.armR.rot.set(-1.5f * f, 0f, -.25f * f)
            h.elL.rot.x = -.2f; h.elR.rot.x = -.2f
        }
        "pray" -> {
            h.armL.rot.set(-.9f * f, 0f, .5f * f); h.armR.rot.set(-.9f * f, 0f, -.5f * f)
            h.elL.rot.x = -1.3f * f; h.elR.rot.x = -1.3f * f; h.torso.rot.x = .15f
        }
        "raise" -> {
            h.armL.rot.set(-2.9f * f, 0f, .2f * f); h.armR.rot.set(-2.9f * f, 0f, -.2f * f)
            h.elL.rot.x = -.1f; h.elR.rot.x = -.1f; h.torso.rot.x = -.15f
        }
        "spread" -> {
            h.armL.rot.set(0f, 0f, -1.45f * f); h.armR.rot.set(0f, 0f, 1.45f * f)
            h.elL.rot.x = 0f; h.elR.rot.x = 0f; h.torso.rot.x = -.1f
        }
        "slash" -> {
            h.armR.rot.set(-1.5f, 0f, 0f); h.elR.rot.x = -.1f; h.torso.rot.y = lerp(.9f, -.9f, e)
        }
    }
}

/** Vỏ aura (shader viền sáng + nhấp nháy) bọc quanh thân; dark = lớp tối pha thêm (addAura trong bản HTML). */
fun addAura(h: Human, hex: Int, hex2: Int, dark: Int? = null) {
    val m = Material(MatType.AURA, hex, additive = true, depthWrite = false)
    val s = Node(); s.geo = Geometry.capsule(.62f, 1.25f, 6, 16); s.mat = m; s.pos.y = 1.12f; h.body.add(s)
    h.aura = s; h.auraMat = m
    if (dark != null) {
        val d = Material(MatType.AURA, dark, opacity = .999f, depthWrite = false); d.aa = .55f
        val s2 = Node(); s2.geo = Geometry.capsule(.7f, 1.35f, 6, 16); s2.mat = d; s2.pos.y = 1.12f; h.body.add(s2)
        h.auraDark = s2; h.auraMat2 = d
    }
    h.aCol = intArrayOf(hex, hex2)
}

fun auraTick(h: Human, x: Float, y: Float, z: Float, I: Float, dt: Float) {
    val m = h.auraMat ?: return
    m.t += dt; m.inten = I
    h.auraMat2?.let { it.t += dt; it.inten = I }
    h.zap?.tick(I, dt, x, y, z, h.s, h.gsK)
    val n = (I * 2f + (if (rnd01() < (I * 2f) % 1f) 1f else 0f)).toInt()
    for (i in 0 until n) {
        val a = rnd(0f, TAU); val r = rnd(.2f, .7f) * h.s * 1.1f
        emit(x + cos(a) * r, y + rnd(0f, .5f), z + sin(a) * r, rnd(-.2f, .2f), rnd(2.2f, 4.2f) * I, rnd(-.2f, .2f), rnd(.5f, .9f), rnd(.35f, .6f), .05f, h.aCol[if (rnd01() < .6f) 0 else 1], 0f, .5f)
    }
}
