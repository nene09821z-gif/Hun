package com.nenarena.game

import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.BasicText
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.nenarena.game.engine.GLRenderer
import com.nenarena.game.engine.Quality
import com.nenarena.game.game.Game
import com.nenarena.game.game.Input
import com.nenarena.game.game.Music
import com.nenarena.game.game.SFX
import com.nenarena.game.ui.GameRoot
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private var gl: GLSurfaceView? = null
    private lateinit var game: Game
    private var viewW = 0
    private var viewH = 0
    private var dyn = 1f   // hệ số do bộ tự điều chỉnh FPS đặt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Quality.load(this)
        com.nenarena.game.engine.Assets.ctx = applicationContext
        SFX.init(applicationContext)     // hiệu ứng âm thanh (assets/sfx)
        Music.init(applicationContext)   // nhạc nền (assets/music)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        hideBars()
        // Chế độ hiệu năng ổn định: tránh CPU/GPU bị hạ xung khi nóng -> FPS không tụt dần
        try {
            val pm = getSystemService(android.content.Context.POWER_SERVICE) as android.os.PowerManager
            if (pm.isSustainedPerformanceModeSupported) window.setSustainedPerformanceMode(true)
        } catch (e: Throwable) {}
        game = Game()
        onBackPressedDispatcher.addCallback(this, object : androidx.activity.OnBackPressedCallback(true) {
            override fun handleOnBackPressed() { Input.post { val g = game; if (g.state == "play") g.pauseGame() else if (g.state == "pause") g.resumeGame() else if (g.state == "select") g.gotoTitle() } }
        })
        setContent {
            Box(Modifier.fillMaxSize()) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        GLSurfaceView(ctx).apply {
                            setEGLContextClientVersion(3)
                            setEGLConfigChooser(8, 8, 8, 0, 24, 0)
                            preserveEGLContextOnPause = true
                            val r = GLRenderer(game)
                            r.onScale = { s -> post { dyn = s; applySize() } }
                            setRenderer(r)
                            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
                            addOnLayoutChangeListener { _, l, t, rr, bb, _, _, _, _ ->
                                viewW = rr - l; viewH = bb - t; applySize()
                            }
                            gl = this
                            // Khoá nhịp khung hình theo mức đồ hoạ (30/60Hz) ở cấp compositor: đều hơn Thread.sleep
                            holder.addCallback(object : android.view.SurfaceHolder.Callback {
                                override fun surfaceCreated(h: android.view.SurfaceHolder) { pace(h.surface) }
                                override fun surfaceChanged(h: android.view.SurfaceHolder, f: Int, w: Int, hh: Int) { pace(h.surface) }
                                override fun surfaceDestroyed(h: android.view.SurfaceHolder) {}
                            })
                        }
                    }
                )
                GameRoot(Quality.label()) { Quality.cycle(this@MainActivity); recreate() }
            }
        }
    }

    private fun pace(s: android.view.Surface) {
        if (android.os.Build.VERSION.SDK_INT >= 30 && s.isValid) {
            try { s.setFrameRate(Quality.tier.fps.toFloat(), android.view.Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE) } catch (e: Throwable) {}
        }
    }

    /** Render ở độ phân giải thấp hơn màn hình rồi GPU tự phóng to: giảm số pixel cần tô = nhẹ nhất cho máy yếu. */
    private fun applySize() {
        val v = gl ?: return
        if (viewW <= 0 || viewH <= 0) return
        val t = Quality.tier
        val dim = max(viewW, viewH).toFloat()
        var s = t.scale * dyn
        if (dim * s > t.maxLong) s = t.maxLong / dim
        s = max(s, 480f / dim)
        if (s > 1f) s = 1f
        v.holder.setFixedSize(max(2, (viewW * s).toInt()), max(2, (viewH * s).toInt()))
    }

    private fun hideBars() {
        val c = WindowInsetsControllerCompat(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        c.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideBars()
    }

    override fun onPause() { Input.post { game.pauseGame() }; Music.onPause(); gl?.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); Music.onResume(); gl?.onResume() }
    override fun onDestroy() { if (isFinishing) Music.release(); super.onDestroy() }
}

