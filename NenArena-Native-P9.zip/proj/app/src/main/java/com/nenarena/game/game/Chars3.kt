package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)

// Bảng màu Kurotsuki: xanh trăng (aura) · xanh băng · trắng lạnh · đỏ huyết (chỉ dùng cho máu / mắt / thắt lưng) · hư vô
internal const val KURO_BLU = 0x2f8bff   // xanh trăng — màu aura chính
internal const val KURO_CYN = 0x8fe9ff   // xanh băng — viền sáng, tia điện
internal const val KURO_WHT = 0xeaf8ff   // trắng lạnh — lõi trăng, lõi kiếm
internal const val KURO_DEP = 0x1238d0   // xanh thẫm
internal const val KURO_RED = 0xd4204e   // huyết
private const val KURO_NAVY = 0x061a5c   // lớp aura tối (khói xanh đêm)
private const val KURO_VOID = 0x07000d
private const val KURO_CLOTH = 0x14111d
private const val KURO_SASH = 0xb01c40

private fun mixHex(a: Int, b: Int, k: Float): Int {
    val t = clamp(k, 0f, 1f)
    val r = lerp(((a shr 16) and 255).toFloat(), ((b shr 16) and 255).toFloat(), t).toInt()
    val g = lerp(((a shr 8) and 255).toFloat(), ((b shr 8) and 255).toFloat(), t).toInt()
    val bl = lerp((a and 255).toFloat(), (b and 255).toFloat(), t).toInt()
    return (r shl 16) or (g shl 8) or bl
}

// ======================= HIỆU ỨNG DÙNG CHUNG =======================

private val riftGeo by lazy { Geometry.circle(1f, 4) }          // hình thoi: khe nứt không gian
private val crescentGeo by lazy { Geometry.crescent(1.15f, 18) }
private val coronaRayGeo by lazy { Geometry.plane(.18f, 1f).translated(0f, .5f, 0f) }   // tia nhật hoa: từ tâm ra +Y
private val coronaRingGeo by lazy { Geometry.ring(.97f, 1f, 72) }
private val ringOuterGeo by lazy { Geometry.ring(.95f, 1f, 64).rotatedX(-PIF / 2) }
private val ringInnerGeo by lazy { Geometry.ring(.93f, 1f, 48).rotatedX(-PIF / 2) }
// thân kiếm: ống sáng (rộng, mờ) + lõi mảnh (trắng). Hệ toạ độ model katana: gốc = giữa cán, mũi +Z, lưỡi dài .14 → .86
private val bladeGlowGeo by lazy { Geometry.cylinder(.03f, .055f, .74f, 8, true).rotatedX(PIF / 2).translated(0f, 0f, .5f) }
private val bladeCoreGeo by lazy { Geometry.cylinder(.011f, .017f, .74f, 6, true).rotatedX(PIF / 2).translated(0f, 0f, .5f) }

/**
 * Vết nứt không gian: một khe hình thoi màu hư vô, viền sáng, mở ra rồi khép lại.
 * (cx,cy,cz) tâm, yaw hướng trục dài (trục X cục bộ), hx/hy nửa chiều dài/cao, roll nghiêng quanh trục dài.
 */
internal fun Game.riftFx(cx: Float, cy: Float, cz: Float, yaw: Float, hx: Float, hy: Float, hex: Int, life: Float, roll: Float = 0f) {
    val root = Node(); root.pos.set(cx, cy, cz); root.rot.y = yaw
    val tilt = Node(); tilt.rot.x = roll; root.add(tilt)
    val core = Node(); core.geo = riftGeo; core.mat = Material(MatType.BASIC, KURO_VOID, 0, 1f, doubleSided = true); core.pos.z = .012f
    val gm = addMat(hex, .85f)
    val glow = Node(); glow.geo = riftGeo; glow.mat = gm; glow.pos.z = -.012f
    tilt.add(glow); tilt.add(core)
    val n = (hx * 3f).toInt().coerceIn(6, 36)
    for (i in 0 until n) {
        val u = rnd(-hx, hx); val v = rnd(-hy, hy) * .6f
        emit(cx + cos(yaw) * u, cy + v, cz - sin(yaw) * u, rnd(-1.5f, 1.5f), rnd(-.5f, 2f), rnd(-1.5f, 1.5f), rnd(.3f, .7f), .4f, .03f,
            if (rnd01() < .5f) hex else KURO_WHT, 2f, 1.5f)
    }
    fx.add(root, life, gm) { k, _, _ ->
        val o = if (k < .1f) ease(k / .1f) else if (k > .7f) 1f - ease((k - .7f) / .3f) else 1f
        val w = max(.001f, hx * (.5f + .5f * o)); val hh = max(.001f, hy * o)
        core.scl.set(w * .97f, hh * .55f, 1f); glow.scl.set(w * 1.06f, hh * .72f, 1f); gm.opacity = .85f * o
    }
}

/** Khe nứt đứng ngay tại điểm (x,z), quay mặt theo hướng nhìn của người chơi để camera sau lưng thấy rõ. */
internal fun Game.riftStand(x: Float, y: Float, z: Float, hex: Int, life: Float, h: Float = 5.2f) =
    riftFx(x, y, z, P.face, .5f, h / 2f, hex, life)

/** Nút trăng khuyết: gốc quay theo hướng bay (lookDir), nút giữa nghiêng (roll), trăng cong về phía trước. */
internal fun Game.crescentNode(hex: Int, op: Float, sc: Float, tilt: Float): Node {
    val root = Node(); val t = Node(); val m = Node()
    t.rot.z = tilt; m.geo = crescentGeo; m.mat = addMat(hex, op); m.rot.y = -PIF / 2f; m.scl.set(sc, 1f, sc)
    t.add(m); root.add(t); return root
}

/** Vệt chém trăng khuyết (không phải đạn): to dần, mờ dần, trôi theo hướng d. */
internal fun Game.arcSlash(x: Float, y: Float, z: Float, d: Vec3, tilt: Float, hex: Int, size: Float, life: Float, travel: Float = 0f) {
    val n = crescentNode(hex, .95f, 1f, tilt); n.pos.set(x, y, z); n.lookDir(d.x, 0f, d.z)
    val m = n.children[0].children[0].mat
    fx.add(n, life, m) { k, nd, _ ->
        nd.setScale(size * (.55f + k * .6f))
        nd.pos.set(x + d.x * travel * k, y, z + d.z * travel * k)
        m?.opacity = 1f - k * k
    }
}

/** Vệt chém hai lớp: lõi trắng sắc + viền màu mờ rộng hơn (dùng cho các nhát chém lớn). */
private fun Game.arcSlash2(x: Float, y: Float, z: Float, d: Vec3, tilt: Float, hex: Int, size: Float, life: Float, travel: Float = 0f) {
    arcSlash(x, y, z, d, tilt, KURO_WHT, size * .86f, life, travel)
    arcSlash(x, y, z, d, tilt, hex, size * 1.12f, life * 1.25f, travel * 1.1f)
}

/** Hạt "cánh trăng" rơi chậm dọc một đoạn thẳng từ (ox,oy,oz) theo hướng d. */
private fun linePetals(ox: Float, oy: Float, oz: Float, d: Vec3, len: Float, n: Int, hex: Int, hex2: Int, spread: Float = 1f) {
    for (i in 0 until n) {
        val u = rnd01() * len; val s = rnd(-1.6f, 1.6f)
        emit(ox + d.x * u + rnd(-.3f, .3f) * spread, oy + rnd(-.5f, .7f) * spread, oz + d.z * u + rnd(-.3f, .3f) * spread,
            -d.z * s, rnd(.3f, 2.6f), d.x * s, rnd(.5f, 1f), rnd(.5f, .9f), .05f, if (rnd01() < .5f) hex else hex2, 1.2f, 1.2f)
    }
}

/** Bùng aura: vòm sáng + vòng sóng + hạt toả quanh người chơi. */
private fun Game.auraFlare(hex: Int, hex2: Int, r: Float) {
    fx.dome(P.pos.x, 1.2f, P.pos.z, hex, .6f, r, .45f)
    fx.ring(P.pos.x, P.pos.z, hex2, .8f, r * 1.3f, .5f)
    fx.ring(P.pos.x, P.pos.z, hex, .4f, r * .8f, .35f)
    burst(P.pos.x, 1.2f, P.pos.z, hex, 20, 6f, .6f, .7f)
    burst(P.pos.x, 1.2f, P.pos.z, hex2, 12, 4f, .8f, .5f)
}

private fun Game.kuroHeal(v: Float, show: Boolean = true) {
    val before = P.hp; P.hp = min(P.maxHp, P.hp + v)
    if (show && P.hp > before + .5f) dmgNum(P.pos, v, 0x7dff9a, false, "+" + v.roundToInt())
}

/** Nội tại: lướt (Dash) chém đứt không gian dọc đường lướt. Gọi từ Game.doDash. */
internal fun Game.kuroDash(o: Vec3, d: Vec3) {
    kuroDraw(); act("kdash", .26f)
    riftFx(o.x + d.x * 3.2f, 1.2f, o.z + d.z * 3.2f, atan2(-d.z, d.x), 3.4f, 1f, KURO_BLU, .55f, 1.15f)
    val a = Vec3(o.x, 1.2f, o.z); val b = Vec3(o.x + d.x * 6.4f, 1.2f, o.z + d.z * 6.4f)
    fx.beam({ a }, { b }, KURO_CYN, .35f, .09f)
    linePetals(o.x, 1.1f, o.z, d, 6.4f, 14, KURO_CYN, KURO_WHT, .6f)
    arcSlash2(o.x + d.x * 2.8f, 1.2f, o.z + d.z * 2.8f, d, .5f, KURO_BLU, 3.2f, .22f, 2f)
    lineHit(o, d, 6.5f, 1.6f) { e -> hurtE(e, 16f, Hit(col = KURO_BLU, knock = 1f, stun = .25f, from = o, gain = 1f)) }
}

// ======================= MÔ HÌNH =======================
fun buildKurotsuki(): Human {
    val h = buildHuman(HumanOpts(s = .92f, skin = 0xf0e0d6, top = KURO_CLOTH, bottom = 0x1a1724, shoe = 0x0a0810, sleeveLong = true))
    val hair = h.mt(0x0a0c1c)
    // tóc: mũ tóc + hai mái bên + đuôi ngựa dài buộc nút đỏ
    h.mkk(Geometry.sphere(.22f, 14, 10, 0f, TAU, 0f, PIF * .62f), hair, h.head, 0f, .15f, -.012f, rx = -.18f)
    for (s in listOf(-1f, 1f)) {
        h.mkk(box(.07f, .46f, .09f), hair, h.head, s * .185f, -.02f, .06f, rz = s * .05f)
        h.mkk(box(.18f, .12f, .1f), hair, h.head, s * .09f, .3f, .15f, rz = s * -.28f)
    }
    h.mkk(cone(.1f, .95f, 6), hair, h.head, 0f, -.3f, -.34f, rx = PIF + .35f)
    mk(sph(.05f, 8, 6), basic(KURO_SASH), h.head, 0f, .14f, -.23f, outline = false)
    // mắt đỏ, chân mày sắc, vết sẹo dọc mắt trái
    humanEyes(h, 0xff2a4a, .036f, .15f, .08f)
    for (s in listOf(-1f, 1f)) mk(box(.1f, .016f, .02f), basic(0x0a0810), h.head, s * .08f, .215f, .18f, rz = s * -.3f, outline = false)
    mk(box(.012f, .15f, .01f), basic(0xb01030), h.head, -.1f, .15f, .19f, rz = .45f, outline = false)
    // haori đen dài, thắt lưng đỏ, khăn quàng cổ
    h.mkk(cyl(.31f, .45f, .8f, 14), h.mt(KURO_CLOTH), h.hips, 0f, -.32f, 0f)
    mk(Geometry.torus(.45f, .014f, 6, 28), basic(KURO_BLU), h.hips, 0f, -.7f, 0f, rx = PIF / 2, outline = false)   // viền gấu áo xanh trăng
    h.mkk(cyl(.285f, .285f, .1f, 12), h.mt(KURO_SASH), h.torso, 0f, .02f, 0f)
    h.mkk(box(.14f, .16f, .08f), h.mt(KURO_SASH), h.torso, 0f, .02f, -.3f)
    h.mkk(Geometry.torus(.17f, .045f, 6, 14), h.mt(KURO_SASH), h.torso, 0f, .66f, 0f, rx = PIF / 2)
    h.mkk(box(.13f, .62f, .03f), h.mt(KURO_SASH), h.torso, .1f, .3f, -.3f, rx = .12f, rz = .06f)
    // băng đỏ ở cổ tay
    for (el in listOf(h.elL, h.elR)) h.mkk(Geometry.torus(.068f, .018f, 6, 12), h.mt(KURO_SASH), el, 0f, -.34f, 0f, rx = PIF / 2)
    // huy hiệu trăng khuyết: nhỏ trước ngực, lớn sau lưng (camera nhìn từ sau)
    fun moon(y: Float, z: Float, ry: Float, r: Float) {
        val s = if (ry != 0f) -1f else 1f
        mk(Geometry.circle(r, 20), basic(KURO_WHT), h.torso, 0f, y, z, ry = ry, outline = false)
        mk(Geometry.circle(r * .86f, 20), basic(KURO_CLOTH), h.torso, s * r * .32f, y + r * .05f, z + s * .003f, ry = ry, outline = false)
    }
    moon(.38f, .262f, 0f, .09f)
    moon(.36f, -.262f, PIF, .16f)
    // vỏ kiếm (saya) bên hông cùng phía tay cầm kiếm; chuôi thứ hai (KuroAura) hiện ra khi tra kiếm
    h.mkk(cyl(.034f, .03f, .98f, 8), h.mt(0x0b0910), h.hips, .4f, -.08f, -.08f, rx = PIF / 2 - .22f)
    h.mkk(cyl(.038f, .038f, .07f, 8), h.mt(0xc8a24a), h.hips, .4f, .017f, .349f, rx = PIF / 2 - .22f)
    // thanh katana (assets/katana.*): cán nằm trong lòng bàn tay phải, mũi kiếm xuôi theo cẳng tay
    val sm = SkinModel(ModelCache.get("katana"))
    sm.root.setScale(1.3f); sm.root.pos.set(0f, -.44f, 0f); sm.root.rot.x = PIF / 2 - .3f
    h.elR.add(sm.root)
    h.mats.addAll(sm.mats)
    for (nd in sm.outNodes) nd.olw = .012f
    h.fadeHook = { o -> for (nd in sm.outNodes) nd.outline = o >= 1f }
    h.blade = sm
    // aura xanh: lớp chính (sáng) + lớp tối (khói xanh đêm), các lớp phụ (lõi trắng, ngọn lửa ngoài, vòng rune, trăng bay) do KuroAura quản
    addAura(h, KURO_BLU, KURO_CYN, KURO_NAVY)
    val ka = KuroAura(h, sm)
    h.extra = { dt, t, _ -> ka.update(dt, t) }
    return h
}

/**
 * Toàn bộ phần "aura xanh" của Kurotsuki:
 *  - lõi trắng-xanh (viền sáng sắc) + ngọn lửa ngoài mờ, bay lệch pha với lớp aura chính
 *  - hai dòng hạt xoắn ốc quanh thân + bụi sao
 *  - vòng rune dưới chân xoay (hai vòng tròn + sáu trăng khuyết)
 *  - bốn vầng trăng khuyết bay quanh người (to hơn, nhanh hơn khi Nguyệt Thực)
 *  - ánh sáng dọc thân kiếm (ống sáng + lõi trắng + mũi kiếm lấp lánh), chuyển đỏ khi Nhuốm Máu
 *  - ánh xanh nhẹ trên áo (phát sáng rìa)
 * Trạng thái: h.bloodOn (đỏ), h.eclOn (trắng lạnh, mạnh hơn), h.swingK (đang vung kiếm).
 */
private class KuroAura(private val h: Human, private val sm: SkinModel) {
    private val core = Material(MatType.AURA, KURO_WHT, additive = true, depthWrite = false)
    private val flame = Material(MatType.AURA, KURO_CYN, additive = true, depthWrite = false)
    private val coreN = Node(); private val flameN = Node()
    private val gm = addMat(KURO_BLU, 0f); private val gm2 = addMat(KURO_CYN, 0f)
    private val ground = Node(); private val gSpin = Node(); private val gCres = Node()
    private val moons = ArrayList<Node>(); private val moonM = ArrayList<Material>()
    private val glowM = addMat(KURO_CYN, .3f); private val coreM = addMat(KURO_WHT, .8f); private val tipM = addMat(KURO_WHT, .9f)
    private var bK = 0f; private var eK = 0f
    private val hip = SkinModel(ModelCache.get("katana"))   // kiếm trong vỏ: chỉ hiện chuôi + tsuba (ẩn 3 mesh lưỡi)

    init {
        for (i in 0..2) hip.root.children[i].visible = false
        hip.root.setScale(1.3f); hip.root.pos.set(.4f, .056f, .525f); hip.root.rot.x = PIF - .22f
        for (nd in hip.outNodes) nd.olw = .012f
        h.hips.add(hip.root); h.mats.addAll(hip.mats); hip.root.visible = false
        core.aa = .9f; flame.aa = .5f
        coreN.geo = Geometry.capsule(.5f, 1.2f, 6, 14); coreN.mat = core; coreN.pos.y = 1.1f; h.body.add(coreN)
        flameN.geo = Geometry.capsule(.8f, 1.3f, 6, 16); flameN.mat = flame; flameN.pos.y = 1.15f; h.body.add(flameN)
        // vòng rune dưới chân
        ground.pos.y = .06f; h.root.add(ground); ground.add(gSpin); ground.add(gCres)
        val r1 = Node(); r1.geo = ringOuterGeo; r1.mat = gm; r1.setScale(1.6f); ground.add(r1)
        val r2 = Node(); r2.geo = ringInnerGeo; r2.mat = gm; r2.setScale(1.12f); gSpin.add(r2)
        for (i in 0 until 6) {
            val a = i / 6f * TAU
            val c = Node(); c.geo = crescentGeo; c.mat = gm2
            c.pos.set(cos(a) * 1.38f, 0f, sin(a) * 1.38f); c.rot.y = -a; c.setScale(.5f); gCres.add(c)
        }
        // vầng trăng khuyết bay quanh thân
        for (i in 0 until 4) {
            val n = crescentNodeStatic(if (i % 2 == 0) KURO_CYN else KURO_WHT, .9f, .34f, if (i % 2 == 0) .45f else -.45f)
            h.root.add(n); moons.add(n); moonM.add(n.children[0].children[0].mat!!)
        }
        // ánh sáng dọc thân kiếm
        val tube = Node(); tube.geo = bladeGlowGeo; tube.mat = glowM; sm.root.add(tube)
        val line = Node(); line.geo = bladeCoreGeo; line.mat = coreM; sm.root.add(line)
        val tip = Node(); tip.geo = Geometry.sphere(.06f, 8, 6); tip.mat = tipM; tip.pos.z = .86f; sm.root.add(tip)
    }

    fun update(dt0: Float, t: Float) {
        val dt = min(dt0, .05f)
        val main = h.auraMat
        val I = max(.2f, main?.inten ?: 1f)
        val on = h.aura?.visible ?: true
        val q = Quality.tier.detail
        bK += ((if (h.bloodOn) 1f else 0f) - bK) * min(1f, dt * 5f)
        eK += ((if (h.eclOn) 1f else 0f) - eK) * min(1f, dt * 3f)
        val pulse = .5f + .5f * sin(t * 2.6f)
        val sw = h.swingK
        sm.root.visible = !h.sheathed; hip.root.visible = h.sheathed

        // ---- màu & cường độ các lớp aura ----
        main?.let { setMatHex(it, mixHex(KURO_BLU, KURO_CYN, eK * .8f)) }
        setMatHex(core, mixHex(mixHex(KURO_WHT, 0xff5a7a, bK * .85f), KURO_WHT, eK))
        setMatHex(flame, mixHex(mixHex(KURO_CYN, 0x6a5cff, bK * .8f), KURO_WHT, eK * .7f))
        val bt = main?.t ?: t
        core.t = bt * 1.2f + 2.1f; core.inten = I * .9f + .35f + eK * .8f
        flame.t = bt * .8f + 5.3f; flame.inten = I * .85f + eK * 1.0f
        coreN.visible = on; flameN.visible = on
        h.aCol[0] = mixHex(KURO_BLU, KURO_CYN, eK); h.aCol[1] = mixHex(KURO_CYN, KURO_RED, bK * .8f)

        // ---- ánh xanh rìa trên áo + ánh kiếm ----
        val er = .02f + bK * .1f + eK * .1f; val eg = .05f + .05f * pulse + eK * .08f; val eb = .15f + .1f * pulse + eK * .12f
        for (m in h.mats) m.setEmissiveF(er, eg, eb)
        val br = mixHex(mixHex(KURO_CYN, 0xff3a5a, bK), KURO_WHT, eK)
        val gl = .5f + .5f * pulse + sw * .6f
        val bm = sm.mats
        for (i in 0 until min(3, bm.size)) bm[i].setEmissiveF(((br shr 16) and 255) / 255f * gl * .85f, ((br shr 8) and 255) / 255f * gl * .85f, (br and 255) / 255f * gl * .85f)
        glowM.setColor(br); glowM.opacity = clamp(.2f + .1f * pulse + sw * .25f + eK * .15f, 0f, 1f)
        coreM.opacity = clamp(.65f + .3f * pulse + sw * .2f, 0f, 1f)
        tipM.setColor(if (bK > .5f) 0xff9aae else KURO_WHT); tipM.opacity = clamp(.6f + .4f * sin(t * 9f), 0f, 1f)

        // ---- vòng rune dưới chân ----
        gSpin.rot.y += dt * (.9f + sw * 1.5f + eK); gCres.rot.y -= dt * (.55f + eK * .6f)
        val gOp = if (on) clamp(.3f + .22f * pulse + I * .12f + eK * .2f, 0f, 1f) else 0f
        gm.opacity = gOp; gm2.opacity = gOp
        gm.setColor(mixHex(mixHex(KURO_BLU, KURO_RED, bK * .7f), KURO_CYN, eK * .6f)); gm2.setColor(mixHex(KURO_CYN, KURO_WHT, eK))
        ground.visible = on

        // ---- vầng trăng bay quanh người ----
        val spd = 1.9f + 1.4f * eK + .9f * sw; val rad = .95f + .35f * eK
        for (i in moons.indices) {
            val a = t * spd + i * TAU / moons.size; val n = moons[i]
            n.pos.set(cos(a) * rad, 1f + sin(t * 1.7f + i * 1.7f) * .28f + (i % 2) * .25f, sin(a) * rad)
            n.rot.y = -a
            n.setScale(.85f + .2f * min(I, 2.5f) + .25f * eK)
            moonM[i].opacity = if (on) clamp(.5f + .2f * I, 0f, 1f) else 0f
            moonM[i].setColor(if (bK > .5f && i % 2 == 1) 0xff8aa0 else if (i % 2 == 0) KURO_CYN else KURO_WHT)
            n.visible = on
        }

        // ---- hạt: hai dòng xoắn ốc + bụi sao ----
        if (!on) return
        val p = h.root.pos
        val cnt = I * .9f * q + eK
        var n = cnt.toInt(); if (rnd01() < cnt % 1f) n++
        for (i in 0 until n) {
            val a = t * 4.2f + (i % 2) * PIF + rnd(-.2f, .2f); val rr = .62f
            emit(p.x + cos(a) * rr, p.y + .15f, p.z + sin(a) * rr, -sin(a) * 1.6f, rnd(2.5f, 3.8f), cos(a) * 1.6f,
                rnd(.8f, 1.1f), .4f, .04f, if (rnd01() < .6f) h.aCol[0] else h.aCol[1], 0f, 1.2f)
        }
        if (rnd01() < .25f * I * q)
            emit(p.x + rnd(-.7f, .7f), p.y + rnd(.2f, 2.2f), p.z + rnd(-.7f, .7f), 0f, rnd(.2f, .8f), 0f, rnd(.6f, 1.1f), .3f, 0f, KURO_WHT, 0f, .3f)
    }
}

/** crescentNode không cần Game (dùng khi dựng mô hình): cùng cấu trúc gốc → nút nghiêng → trăng. */
private fun crescentNodeStatic(hex: Int, op: Float, sc: Float, tilt: Float): Node {
    val root = Node(); val t = Node(); val m = Node()
    t.rot.z = tilt; m.geo = crescentGeo; m.mat = addMat(hex, op); m.rot.y = -PIF / 2f; m.scl.set(sc, 1f, sc)
    t.add(m); root.add(t); return root
}

// ======================= TƯ THẾ & ĐÒN VUNG KIẾM (gọi từ SIG trong Sig.kt) =======================
private val tmpP = FloatArray(3)
/** Điểm trên lưỡi kiếm trong không gian thế giới (u = 0.14 gần tsuba → 0.86 mũi kiếm), theo ma trận khung hình trước. */
private fun bladePt(sm: SkinModel, u: Float) {
    val w = sm.root.world
    tmpP[0] = w[8] * u + w[12]; tmpP[1] = w[9] * u + w[13]; tmpP[2] = w[10] * u + w[14]
}

/**
 * Chuyển động đặc trưng: đứng thế kiếm trung đoạn (tay phải cầm kiếm hướng trước, tay trái đặt hờ vỏ kiếm),
 * chạy (kiếm thấp phía trước, người chúi), và các động tác: ksl0/ksl1 (hai nhát thường), ksl2 (nhát thứ ba xoay người),
 * kdash (lao trảm / lướt), kcrouch/kslashA/kslashB (cư hợp), knoto (thu kiếm), kult (tuyệt không trảm).
 */
internal fun kuroSig(h: Human, t: Float, A: String?, k: Float, w: Float, r: Float, sa: Float) {
    val br = sin(t * 1.8f)
    // --- đứng ---
    B(h.armR, -.32f, 0f, .16f, w); B(h.elR, -.62f + br * .03f, 0f, 0f, w)
    B(h.armL, .06f, 0f, -.16f, w); B(h.elL, -.38f, 0f, 0f, w)
    h.torso.rot.y += (if (h.sheathed) 0f else -.2f) * w; h.torso.rot.x += (.05f + br * .012f) * w
    h.head.rot.y += .12f * w; h.head.rot.z += sin(t * .8f) * .03f * w
    h.hips.rot.y = -.1f * w; h.hips.pos.y -= .03f * w
    if (h.sheathed) { B(h.armR, -.6f, 0f, .02f, w + r); B(h.elR, -.42f, 0f, 0f, w + r) }   // tay phải đặt lên chuôi
    // --- chạy ---
    B(h.armR, -.38f, 0f, .12f, r); B(h.elR, -.5f, 0f, 0f, r)
    h.torso.rot.x += .24f * r; h.hips.pos.y -= .04f * r; h.head.rot.x -= .08f * r

    // --- ra đòn ---
    val q = min(1f, sa * 1.5f)
    var swing = 0f
    fun legs(a: Float, b: Float, kn: Float) {
        B(h.legL, -a, 0f, 0f, q); B(h.legR, b, 0f, 0f, q)
        h.knL.rot.x = lerp(h.knL.rot.x, kn, q); h.knR.rot.x = lerp(h.knR.rot.x, kn * .8f, q)
    }
    when (A) {
        "ksl0" -> {   // chém chéo từ trên xuống
            val e = ease(clamp((k - .1f) / .42f, 0f, 1f))
            B(h.armR, lerp(-2.15f, -1.4f, e), 0f, lerp(.75f, -.2f, e), q); B(h.elR, lerp(-.25f, -.08f, e), 0f, 0f, q)
            B(h.armL, .3f, 0f, -.5f, q); B(h.elL, -.7f, 0f, 0f, q)
            B(h.torso, lerp(.1f, .3f, e), lerp(.95f, -.9f, e), 0f, q); B(h.head, 0f, lerp(.3f, -.35f, e), 0f, q)
            h.hips.pos.y -= .07f * sin(e * PIF) * q; legs(.4f, .3f, .35f)
            swing = sin(clamp((k - .1f) / .5f, 0f, 1f) * PIF)
        }
        "ksl1" -> {   // hất kiếm từ dưới lên
            val e = ease(clamp((k - .1f) / .42f, 0f, 1f))
            B(h.armR, lerp(-1.05f, -2.0f, e), 0f, lerp(.7f, -.35f, e), q); B(h.elR, -.1f, 0f, 0f, q)
            B(h.armL, .3f, 0f, -.5f, q); B(h.elL, -.7f, 0f, 0f, q)
            B(h.torso, lerp(.3f, -.12f, e), lerp(.95f, -.9f, e), 0f, q); B(h.head, 0f, lerp(.3f, -.35f, e), 0f, q)
            h.hips.pos.y -= .08f * sin(e * PIF) * q; legs(.35f, .4f, .4f)
            swing = sin(clamp((k - .1f) / .5f, 0f, 1f) * PIF)
        }
        "ksl2" -> {   // nhát thứ ba: xoay cả người
            val e = ease(clamp((k - .2f) / .35f, 0f, 1f))
            B(h.armR, -1.55f, 0f, lerp(1f, -.6f, e), q); B(h.elR, -.06f, 0f, 0f, q)
            B(h.armL, -.4f, 0f, -1.1f, q); B(h.elL, -.2f, 0f, 0f, q)
            B(h.torso, .15f, lerp(1.6f, -1.6f, e), 0f, q); B(h.head, 0f, lerp(.5f, -.5f, e), 0f, q)
            h.hips.rot.y = lerp(h.hips.rot.y, lerp(.5f, -.5f, e), q)
            h.hips.pos.y -= .12f * sin(e * PIF) * q; legs(.6f, .45f, .5f)
            swing = sin(clamp((k - .15f) / .5f, 0f, 1f) * PIF)
        }
        "kdash" -> {
            if (k < .38f) {   // lao tới: kiếm đâm thẳng, người chúi
                B(h.armR, -1.55f, 0f, 0f, q); B(h.elR, -.04f, 0f, 0f, q)
                B(h.armL, .8f, 0f, -.7f, q); B(h.elL, -.5f, 0f, 0f, q)
                B(h.torso, .75f, -.2f, 0f, q); B(h.head, -.35f, 0f, 0f, q)
                h.hips.pos.y -= .22f * q; legs(.9f, .7f, .8f)
                swing = 1f
            } else {          // bổ chữ X: hai nhát liên tiếp
                val ph = clamp((k - .4f) / .6f, 0f, 1f); val c2 = cos(ph * TAU * 2f)
                B(h.armR, -1.8f - .5f * c2, 0f, .5f * c2, q); B(h.elR, -.1f, 0f, 0f, q)
                B(h.armL, .3f, 0f, -.5f, q); B(h.elL, -.7f, 0f, 0f, q)
                B(h.torso, .25f, .9f * c2, 0f, q); B(h.head, 0f, .3f * c2, 0f, q)
                h.hips.pos.y -= .1f * q; legs(.5f, .4f, .5f)
                swing = .6f + .4f * abs(sin(ph * TAU * 2f))
            }
        }
        "kcrouch" -> {   // cúi thấp, tay đặt lên chuôi, dồn khí
            val g = ease(clamp(k / .5f, 0f, 1f)); val tr = sin(t * 45f) * .012f * g
            B(h.armR, -.6f + tr, 0f, .02f, q); B(h.elR, -.42f, 0f, 0f, q)
            B(h.armL, -.35f, 0f, -.5f, q); B(h.elL, -.5f, 0f, 0f, q)
            B(h.torso, .5f * g, -.3f * g, 0f, q); B(h.head, -.35f * g, .15f * g, 0f, q)
            h.hips.pos.y -= .2f * g * q
            B(h.legL, -.85f * g, 0f, 0f, q); B(h.legR, -.6f * g, 0f, 0f, q)
            h.knL.rot.x = lerp(h.knL.rot.x, 1.4f * g, q); h.knR.rot.x = lerp(h.knR.rot.x, 1.2f * g, q)
            swing = .15f * g
        }
        "kslashA", "kslashB" -> {   // chém loạn khi vẫn cúi thấp, hai nhát đổi hướng liên tục
            val a = A == "kslashA"
            val e = ease(clamp((k - .05f) / .5f, 0f, 1f))
            if (a) { B(h.armR, -1.55f, 0f, lerp(1f, -.9f, e), q); B(h.torso, .45f, lerp(1f, -1f, e), 0f, q); B(h.head, 0f, lerp(.3f, -.3f, e), 0f, q) }
            else { B(h.armR, lerp(-.8f, -2.1f, e), 0f, lerp(.6f, -.6f, e), q); B(h.torso, lerp(.5f, .2f, e), lerp(-.9f, .9f, e), 0f, q); B(h.head, 0f, lerp(-.3f, .3f, e), 0f, q) }
            B(h.elR, -.08f, 0f, 0f, q); B(h.armL, -.3f, 0f, -.7f, q); B(h.elL, -.4f, 0f, 0f, q)
            h.hips.pos.y -= .2f * q
            B(h.legL, if (a) -.85f else -.55f, 0f, 0f, q); B(h.legR, if (a) -.55f else -.85f, 0f, 0f, q)
            h.knL.rot.x = lerp(h.knL.rot.x, 1.3f, q); h.knR.rot.x = lerp(h.knR.rot.x, 1.3f, q)
            swing = sin(clamp((k - .05f) / .6f, 0f, 1f) * PIF)
        }
        "knoto" -> {   // thu kiếm: kiếm quét về hông rồi tra vào vỏ
            val ph = ease(clamp(k / .75f, 0f, 1f))
            B(h.armR, lerp(-1.4f, -.6f, ph), 0f, lerp(-.2f, .02f, ph), q); B(h.elR, lerp(-.1f, -.42f, ph), 0f, 0f, q)
            B(h.armL, .1f, 0f, -.3f, q); B(h.torso, .2f, lerp(-.5f, 0f, ph), 0f, q); B(h.head, 0f, 0f, 0f, q * .5f)
            swing = .5f * (1f - ph)
        }
        "kult" -> {
            val d = h.act?.d ?: 2f; val kc = (d - .3f) / d   // thời điểm nhát chém cuối
            val rise = ease(clamp(k / .28f, 0f, 1f)); val drop = ease(clamp((k - (kc - .06f)) / .1f, 0f, 1f))
            val tr = sin(t * 38f) * .025f * rise * (1f - drop)
            B(h.armR, lerp(lerp(-1f, -2.95f, rise), -.95f, drop) + tr, 0f, lerp(.2f, .12f, rise), q); B(h.elR, -.1f, 0f, 0f, q)
            B(h.armL, lerp(lerp(.2f, -2.5f, rise), .3f, drop), 0f, lerp(-.1f, -.55f, rise), q); B(h.elL, -.25f, 0f, 0f, q)
            B(h.torso, lerp(lerp(0f, -.25f, rise), .55f, drop), 0f, 0f, q); B(h.head, lerp(lerp(0f, -.5f, rise), .1f, drop), 0f, 0f, q)
            h.hips.pos.y -= .16f * drop * q; legs(.25f + .35f * drop, .2f + .3f * drop, .3f + .3f * drop)
            swing = .5f * rise + drop
        }
    }
    h.swingK = lerp(h.swingK, swing, .35f)

    // --- hạt dọc lưỡi kiếm: vệt sáng khi vung, lấp lánh khi đứng yên ---
    val sm = h.blade
    if (sm != null && !h.sheathed) {
        val sw = h.swingK
        var n = (sw * 3f).toInt(); if (rnd01() < (sw * 3f) % 1f) n++
        if (sw < .1f && rnd01() < .06f) n++
        for (i in 0 until n) {
            bladePt(sm, rnd(.2f, .86f))
            val c = if (h.bloodOn) { if (rnd01() < .5f) KURO_RED else 0xff9aae } else { if (rnd01() < .55f) KURO_CYN else KURO_WHT }
            emit(tmpP[0], tmpP[1], tmpP[2], rnd(-.5f, .5f), rnd(-.2f, .9f), rnd(-.5f, .5f), rnd(.25f, .45f), rnd(.45f, .75f), .03f, c, 0f, 2.2f)
        }
        if (sw > .3f) {
            bladePt(sm, .86f)
            emit(tmpP[0], tmpP[1], tmpP[2], 0f, 0f, 0f, .3f, .9f, .05f, if (h.bloodOn) 0xff9aae else KURO_WHT, 0f, 0f)
        }
    }
}

// ======================= ĐÁNH THƯỜNG: NGUYỆT NHẬN =======================
/** Đạn trăng khuyết hai lớp: lõi trắng sắc + viền màu to hơn, mờ hơn. */
private fun Game.kuroSlashNode(col: Int, tilt: Float): Node {
    val root = Node()
    root.add(crescentNode(KURO_WHT, .95f, 2f, tilt))
    root.add(crescentNode(col, .6f, 2.7f, tilt))
    return root
}

private fun Game.kuroAtk() {
    val d = aim(); val blood = P.bl > 0f; val n = P.combo % 3
    kuroDraw()
    val col = if (blood) KURO_CYN else KURO_BLU
    val hi = if (blood) KURO_WHT else KURO_CYN
    if (n == 2) {
        // đòn thứ 3: chém đứt không gian thành vết nứt dài
        act("ksl2", .3f); P.atkCd = .38f; SFX.swing(); val o = P.pos.clone()
        later(.1f) {
            val a = Vec3(o.x + d.x * .8f, 1.3f, o.z + d.z * .8f); val b = Vec3(o.x + d.x * 10.5f, 1.3f, o.z + d.z * 10.5f)
            fx.beam({ a }, { b }, KURO_WHT, .22f, .05f); fx.beam({ a }, { b }, col, .38f, .16f)
            riftFx(o.x + d.x * 5.5f, 1.3f, o.z + d.z * 5.5f, atan2(-d.z, d.x), 4.6f, 1.2f, col, .7f, 1.15f)
            arcSlash2(o.x + d.x * 1.2f, 1.3f, o.z + d.z * 1.2f, d, 0f, col, 5f, .25f, 4f)
            linePetals(o.x, 1.3f, o.z, d, 10f, 26, col, hi)
            shake = max(shake, .25f); SFX.boom()
            lineHit(o, d, 9.5f, 1.5f) { e ->
                hurtE(e, if (blood) 32f else 24f, Hit(col = col, knock = 1.5f, stun = .35f, big = true, from = o, hs = .04f))
                if (blood) kuroHeal(2.5f, false)
            }
        }
    } else {
        act(if (n == 0) "ksl0" else "ksl1", .22f); P.atkCd = .2f; SFX.swing()
        val tilt = if (n == 0) .6f else -.6f
        later(.06f) {
            arcSlash(P.pos.x + d.x * 1.1f, 1.25f, P.pos.z + d.z * 1.1f, d, tilt, KURO_WHT, 3.2f, .2f, 1.8f)
            val m = kuroSlashNode(col, tilt)
            val oh: (Enemy) -> Unit = { e ->
                fx.slash(e.pos.x, 1.3f + e.hover, e.pos.z, rnd(0f, TAU), hi, 2.4f, .2f)
                burst(e.pos.x, 1.3f + e.hover, e.pos.z, hi, 5, 4f, .3f, .5f)
                if (blood) kuroHeal(1.5f, false)
            }
            shoot(m, hand(1.3f, 1f), d, 40f, if (blood) 16f else 12f, 1.1f, .5f, 'p', 2, col, 0f, oh, 0f, .8f)
        }
    }
    P.combo++
}

// ======================= CHIÊU 1: LAO TRẢM =======================
private fun Game.kuroS1(): Boolean {
    val t = nearest(P.pos, 24f) ?: return false
    kuroDraw(); aim(24f); val o = P.pos.clone()
    val dir = Vec3(t.pos.x - o.x, 0f, t.pos.z - o.z); val L = max(1.2f, dir.length() - 1.7f); dir.normalize()
    val tm = clamp(L / 70f, .1f, .26f)
    P.cast = tm + .35f; P.inv = tm + .5f; act("kdash", tm + .3f); SFX.dash(); SFX.skill()
    riftFx(o.x + dir.x * L / 2f, 1.25f, o.z + dir.z * L / 2f, atan2(-dir.z, dir.x), L / 2f + .5f, 1.1f, KURO_BLU, .8f, 1.15f)
    // vệt sáng suốt đường lao + trăng khuyết lướt qua + hạt cánh trăng
    val pa = Vec3(o.x, 1.2f, o.z); val pb = Vec3(o.x + dir.x * L, 1.2f, o.z + dir.z * L)
    fx.beam({ pa }, { pb }, KURO_CYN, tm + .4f, .12f); fx.beam({ pa }, { pb }, KURO_WHT, tm + .25f, .04f)
    linePetals(o.x, 1.2f, o.z, dir, L, 24, KURO_CYN, KURO_WHT)
    for (i in 0..7) {
        val u = i / 7f; val qx = o.x + dir.x * L * u; val qz = o.z + dir.z * L * u
        later(u * tm) {
            burst(qx, 1.1f, qz, if (i % 2 == 0) KURO_BLU else KURO_CYN, 6, 3.5f, .35f, .55f); fx.ring(qx, qz, KURO_BLU, .3f, 1.8f, .3f)
            if (i % 2 == 1) arcSlash(qx, 1.2f, qz, dir, if (i % 4 == 1) .6f else -.6f, KURO_WHT, 2.8f, .22f, 0f)
        }
    }
    val hit = HashSet<Enemy>()
    P.lunge = Lunge(dir.clone(), L / tm, tm,
        path = { e -> if (e !== t && hit.add(e)) hurtE(e, 20f, Hit(col = KURO_BLU, knock = 1.5f, stun = .3f, from = o, gain = 1.5f)) },
        end = {
            val c = P.pos.clone(); shake = max(shake, .45f)
            fx.ring(c.x, c.z, KURO_CYN, .5f, 5f, .4f); fx.ring(c.x, c.z, KURO_BLU, .3f, 3.4f, .3f)
            if (!t.dead) {
                val ag = atan2(dir.x, dir.z)
                fx.slash(t.pos.x, 1.4f, t.pos.z, ag + .65f, KURO_WHT, 4.6f, .32f); fx.slash(t.pos.x, 1.4f, t.pos.z, ag - .65f, KURO_BLU, 4.6f, .32f)
                riftStand(t.pos.x, 1.7f, t.pos.z, KURO_BLU, .7f)
                fx.pillar(t.pos.x, t.pos.z, KURO_CYN, 1.2f, 18f, .55f)
                fx.dome(t.pos.x, 1.4f, t.pos.z, KURO_BLU, .6f, 4.5f, .35f)
                burst(t.pos.x, 1.4f, t.pos.z, KURO_CYN, 18, 6f, .5f, .7f)
                hurtE(t, 46f, Hit(col = KURO_BLU, knock = 3f, stun = .8f, big = true, hs = .06f, from = o))
                popText("Xuyên Không!", KURO_WHT)
            }
            radiusHit(c, 3.4f) { e -> if (e !== t) hurtE(e, 18f, Hit(col = KURO_BLU, knock = 2f, stun = .4f, from = c)) }
            P.critN = max(P.critN, 2)
        })
    return true
}

// ======================= THU KIẾM / RÚT KIẾM =======================
/** Vị trí chuôi kiếm ở hông (không gian thế giới), để đặt hiệu ứng "tách". */
private fun Game.hipPos(): Vec3 {
    val f = P.face; val lx = .37f; val lz = .5f
    return Vec3(P.pos.x + lx * cos(f) + lz * sin(f), P.y + .95f, P.pos.z - lx * sin(f) + lz * cos(f))
}

private fun Game.clickFx(strong: Boolean) {
    val p = hipPos()
    fx.ring(p.x, p.z, KURO_CYN, .2f, if (strong) 2.6f else 1.6f, .3f, p.y)
    burst(p.x, p.y, p.z, KURO_WHT, if (strong) 18 else 12, 4f, .35f, .5f); burst(p.x, p.y, p.z, KURO_CYN, 8, 3f, .4f, .4f)
    if (strong) flash(KURO_WHT, .18f, 120)
}

/** Tra kiếm vào vỏ ngay lập tức (đổi mô hình: bỏ kiếm ở tay, hiện chuôi ở hông). */
private fun Game.kuroSheath() {
    val h = P.h; h.sheathTok++
    if (h.sheathed) return
    h.sheathed = true; clickFx(false); SFX.katana(false)
}

/** Rút kiếm (mọi đòn tấn công đều tự rút nếu kiếm đang trong vỏ). */
private fun Game.kuroDraw() {
    val h = P.h; h.sheathTok++
    if (!h.sheathed) return
    h.sheathed = false; clickFx(true); SFX.katana(true)
}

/** Thu kiếm có động tác: quét kiếm về hông, tra vào vỏ đúng lúc tay chạm chuôi. Bị huỷ nếu giữa chừng rút lại kiếm. */
private fun Game.kuroNoto() {
    val h = P.h; if (h.sheathed) return
    act("knoto", .4f); val tok = ++h.sheathTok
    later(.28f) { if (P.h.sheathTok == tok && !P.h.sheathed) kuroSheath() }
}

// ======================= CHIÊU 2: CƯ HỢP · NGUYỆT QUANG LOẠN TRẢM =======================
private val slashDiscGeo by lazy { Geometry.crescent(1.35f, 28).rotatedX(PIF / 2) }   // trăng khuyết đứng, mặt hướng +Z

/**
 * Vệt chém trăng khuyết cong mượt đứng thẳng (mặt quay về hướng yaw), nghiêng góc ang quanh trục nhìn.
 * Mở rộng nhanh rồi tan dần, trôi dọc theo chiều cong.
 */
private fun Game.slashDisc(x: Float, y: Float, z: Float, yaw: Float, ang: Float, hex: Int, size: Float, life: Float) {
    val root = Node(); root.pos.set(x, y, z); root.rot.y = yaw
    val tilt = Node(); tilt.rot.z = ang; root.add(tilt)
    val m = Node(); m.geo = slashDiscGeo; val mat = addMat(hex, .95f); m.mat = mat; tilt.add(m)
    fx.add(root, life, mat) { k, _, _ ->
        val e = 1f - (1f - k) * (1f - k)
        val sc = size * (.4f + .8f * e)
        m.scl.set(sc, sc * (1f - .45f * k), 1f); m.pos.set(1.1f * e, 0f, 0f)
        mat.opacity = (1f - k * k) * .95f
    }
}

private fun Game.kuroS2(): Boolean {
    val list = liveEn(20f); if (list.isEmpty()) return false
    val tg = list.take(6); val o = P.pos.clone()
    P.cast = 2.5f; P.inv = 2.7f; SFX.skill(); P.auraBoost = 2f
    popText("Cư Hợp!", KURO_CYN)
    // 1) Cúi thấp, tra kiếm, dồn khí
    act("kcrouch", .6f); kuroSheath()
    auraFlare(KURO_BLU, KURO_CYN, 4.5f)
    for (e in tg) if (!e.dead) e.stun = max(e.stun, if (e.cfg.boss) 1f else 2.8f)
    for (i in 0 until 28) later(i * .018f) {   // bụi trăng hút vào chuôi kiếm
        val a = rnd(0f, TAU); val r = rnd(2f, 3.6f); val hp = hipPos()
        emit(P.pos.x + cos(a) * r, rnd(.2f, 2f), P.pos.z + sin(a) * r, (hp.x - P.pos.x - cos(a) * r) * 2.6f, (hp.y - 1f) * 2f, (hp.z - P.pos.z - sin(a) * r) * 2.6f,
            .4f, .5f, .05f, if (i % 3 == 0) KURO_WHT else KURO_CYN, 0f, .4f)
    }
    // 2) Rút kiếm: sáu nhát xuyên qua địch, mỗi nhát dịch chuyển tức thời tới phía bên kia
    val N = 6
    for (i in 0 until N) later(.55f + i * .19f) {
        var e: Enemy? = null
        for (j in 0 until tg.size) { val c = tg[(i + j) % tg.size]; if (!c.dead) { e = c; break } }
        if (i == 0) { kuroDraw(); shake = max(shake, .25f) }
        if (e == null) return@later
        val from = P.pos.clone()
        val u = Vec3(e.pos.x - from.x, 0f, e.pos.z - from.z); if (u.lengthSq() < .01f) u.set(sin(P.face), 0f, cos(P.face)); u.normalize()
        P.pos.set(e.pos.x + u.x * 1.8f, 0f, e.pos.z + u.z * 1.8f); clampArena(P.pos, 1f); P.face = atan2(u.x, u.z)
        act(if (i % 2 == 0) "kslashA" else "kslashB", .19f); SFX.swing()
        // vệt lao + hình bóng để lại
        val a = Vec3(from.x, 1.05f, from.z); val b = Vec3(P.pos.x, 1.05f, P.pos.z)
        fx.beam({ a }, { b }, KURO_CYN, .28f, .07f); fx.beam({ a }, { b }, KURO_WHT, .2f, .025f)
        burst(from.x, 1.1f, from.z, KURO_CYN, 10, 3.5f, .4f, .6f); fx.ring(from.x, from.z, KURO_BLU, .3f, 2.2f, .3f)
        // vệt chém trăng khuyết cắt qua địch
        val ang = (if (i % 2 == 0) 1f else -1f) * rnd(.35f, 1.1f)
        slashDisc(e.pos.x, 1.4f + e.hover, e.pos.z, P.face, ang, KURO_WHT, 3.6f, .3f)
        slashDisc(e.pos.x, 1.4f + e.hover, e.pos.z, P.face, ang, KURO_BLU, 4.6f, .38f)
        fx.ring(e.pos.x, e.pos.z, KURO_CYN, .5f, 3f, .3f)
        burst(e.pos.x, 1.3f + e.hover, e.pos.z, KURO_CYN, 8, 5f, .35f, .55f)
        shake = max(shake, .2f)
        hurtE(e, 18f, Hit(col = KURO_BLU, knock = .2f, stun = .6f, hs = .03f, from = from, gain = 1.2f))
    }
    // 3) Tra kiếm: "tách" — mọi vết chém hiện ra cùng lúc
    later(1.75f) { act("knoto", .4f); P.h.sheathTok++ }
    later(2.03f) {
        kuroSheath(); shake = max(shake, .8f); SFX.boom(); flash(KURO_WHT, .45f, 300)
        auraFlare(KURO_WHT, KURO_BLU, 7f)
        var healed = 0
        for (e in tg) {
            if (e.dead) continue
            for (j in 0 until 3) later(j * .05f) {
                slashDisc(e.pos.x, 1.4f + e.hover, e.pos.z, P.face, floatArrayOf(.7f, -.85f, 1.45f)[j], if (j == 1) KURO_WHT else KURO_BLU, 5.6f, .45f)
            }
            fx.pillar(e.pos.x, e.pos.z, KURO_CYN, .6f, 10f, .4f); fx.ring(e.pos.x, e.pos.z, KURO_BLU, .5f, 5f, .45f)
            hurtE(e, 60f, Hit(col = KURO_BLU, knock = 3f, stun = 1f, big = true, from = P.pos, hs = .07f))
            if (healed < 5) { healed++; kuroHeal(P.maxHp * .03f) }
        }
        P.bl = 5f; P.critN = max(P.critN, 2)
        toast("Nguyệt Quang: 5 giây đòn thường mạnh hơn 35% và hút máu", 2.2f)
    }
    return true
}

// ======================= TUYỆT KỸ: NGUYỆT THỰC · TUYỆT KHÔNG TRẢM =======================
private fun Game.kuroUlt(): Boolean {
    val list = liveEn(26f); if (list.isEmpty()) return false
    kuroDraw(); val tg = list.take(12); val o = P.pos.clone(); val f = fwd()
    val T = max(1.9f, 1.15f + tg.size * .1f)
    P.cast = T + .5f; P.inv = T + .7f; act("kult", T + .3f); SFX.ult(); slowmo(.45f, .7f); flash(KURO_NAVY, .55f, 900); P.auraBoost = 2.8f
    popText("Không Trảm!", KURO_WHT)
    auraFlare(KURO_BLU, KURO_CYN, 6f)

    // 1) Nguyệt thực: vầng trăng đen treo trên chân trời phía trước, nhật hoa xanh rực quanh viền
    val mp = Vec3(o.x + f.x * 26f, 9.5f, o.z + f.z * 26f)
    fun grow(k: Float) = if (k < .25f) ease(k / .25f) else if (k > .9f) 1f - ease((k - .9f) / .1f) else 1f
    val mn = Node(); mn.geo = fx.gDome; mn.mat = Material(MatType.BASIC, KURO_VOID, 0, 1f); mn.pos.copy(mp)
    fx.add(mn, T + .2f, null) { k, n, _ -> n.setScale(max(.001f, 6.5f * grow(k))) }
    // viền sáng: hai lớp AURA (shader viền Fresnel nhấp nháy) bọc quanh mặt trăng đen
    val rimA = Material(MatType.AURA, KURO_CYN, additive = true, depthWrite = false)
    val rimB = Material(MatType.AURA, KURO_BLU, additive = true, depthWrite = false); rimB.aa = .7f
    for ((rm, sc, ii) in listOf(Triple(rimA, 7.1f, 3.4f), Triple(rimB, 8.8f, 2.4f))) {
        val nd = Node(); nd.geo = fx.gDome; nd.mat = rm; nd.pos.copy(mp)
        fx.add(nd, T + .2f, rm) { k, n, dt -> rm.t += dt; rm.inten = ii * grow(k); n.setScale(max(.001f, sc * grow(k))) }
    }
    // tia nhật hoa + vòng sáng mảnh, quay mặt về phía người chơi
    val cr = Node(); cr.pos.copy(mp); cr.rot.y = P.face + PIF
    val spin = Node(); cr.add(spin)
    val rayM = addMat(KURO_CYN, 0f); val ringM = addMat(KURO_WHT, 0f)
    val rays = ArrayList<Node>()
    for (i in 0 until 18) { val rn = Node(); rn.geo = coronaRayGeo; rn.mat = rayM; rn.rot.z = i / 18f * TAU; rn.scl.set(1f, .001f, 1f); spin.add(rn); rays.add(rn) }
    val rg = Node(); rg.geo = coronaRingGeo; rg.mat = ringM; spin.add(rg)
    fx.add(cr, T + .2f, rayM) { k, _, _ ->
        val g = grow(k); spin.rot.z = k * 2.2f
        rayM.opacity = .55f * g; ringM.opacity = .85f * g
        for ((i, rn) in rays.withIndex()) rn.scl.set(1f, max(.001f, (9f + 5f * sin(k * 9f + i * 1.9f)) * g * (if (i % 3 == 0) 1.3f else 1f)), 1f)
        rg.setScale(max(.001f, 7.6f * g))
    }
    fx.ring(mp.x, mp.z, KURO_BLU, 7f, 16f, .9f, 9.5f)

    // 2) Khoá mục tiêu rồi 3) chém đứt không gian ngay tại chỗ từng kẻ địch
    for ((i, e) in tg.withIndex()) {
        later(.5f) {
            if (!e.dead) {
                e.stun = if (e.cfg.boss) 1f else T
                fx.beam({ mp }, { Vec3(e.pos.x, 1.3f + e.hover, e.pos.z) }, KURO_CYN, .6f, .14f)
                fx.beam({ mp }, { Vec3(e.pos.x, 1.3f + e.hover, e.pos.z) }, KURO_WHT, .6f, .05f)
                fx.ring(e.pos.x, e.pos.z, KURO_CYN, 3f, .6f, .6f); fx.ring(e.pos.x, e.pos.z, KURO_BLU, 1.8f, .3f, .6f)
            }
        }
        later(1f + i * .1f) {
            if (!e.dead) {
                val col = if (i % 2 == 0) KURO_BLU else KURO_CYN
                val d = Vec3(sin(P.face), 0f, cos(P.face))
                riftStand(e.pos.x, 1.7f + e.hover, e.pos.z, col, .7f, 5.4f)
                arcSlash(e.pos.x - d.x * 1.2f, 1.4f, e.pos.z - d.z * 1.2f, d, .7f, KURO_WHT, 4f, .3f, 2.4f)
                arcSlash(e.pos.x - d.x * 1.2f, 1.4f, e.pos.z - d.z * 1.2f, d, -.7f, col, 4f, .3f, 2.4f)
                fx.pillar(e.pos.x, e.pos.z, col, .6f, 9f, .35f)
                hurtE(e, 62f, Hit(col = KURO_BLU, knock = 1.5f, stun = 1f, big = true, from = P.pos, hs = .05f, gain = .5f))
            }
        }
    }

    // 4) Cao trào: tám vết nứt xé toạc từ tâm ra khắp đấu trường
    later(T) {
        SFX.bigBoom(); shake = max(shake, 1.5f); flash(KURO_WHT, .8f, 500)
        val c = P.pos.clone()
        for (a in 0 until 8) {
            val ang = a / 8f * TAU + .3f; val dx = cos(ang); val dz = sin(ang)
            riftFx(c.x + dx * 8f, 1.6f, c.z + dz * 8f, atan2(-dz, dx), 8f, 2.6f, if (a % 2 == 0) KURO_BLU else KURO_CYN, 1f, 1.1f)
        }
        fx.pillar(c.x, c.z, KURO_BLU, 2.6f, 34f, .8f); fx.pillar(c.x, c.z, KURO_WHT, 1.1f, 40f, .6f)
        for (k in 0 until 3) fx.ring(c.x, c.z, if (k % 2 == 0) KURO_BLU else KURO_WHT, 1f, 15f + k * 3f, .6f + k * .1f)
        fx.dome(mp.x, mp.y, mp.z, KURO_CYN, 6f, 22f, .7f); fx.dome(c.x, 1.2f, c.z, KURO_BLU, 1f, 15f, .6f)
        for (i in 0 until 60) {   // trăng vỡ: cánh sáng toả khắp đấu trường
            val a = rnd(0f, TAU); val s = rnd(4f, 12f)
            emit(c.x, 1.2f, c.z, cos(a) * s, rnd(1f, 6f), sin(a) * s, rnd(.8f, 1.4f), rnd(.6f, 1f), .05f, if (i % 3 == 0) KURO_WHT else KURO_CYN, 3f, 1.2f)
        }
        radiusHit(c, 14f) { e -> hurtE(e, 78f, Hit(col = KURO_BLU, knock = 5f, stun = 1.2f, big = true, from = c, hs = .1f, gain = 0f)) }
        P.dmgBuff = 1.25f; P.dmgBuffT = 8f; P.speedBuf = 8f; P.auraBoost = 3f
        toast("Nguyệt Thực: +25% sát thương, chạy nhanh 8 giây", 2.6f)
    }
    return true
}

// ======================= CẤU HÌNH NHÂN VẬT =======================
internal fun Game.kurotsuki(): CharCfg {
    val c = CharCfg(
        "kurotsuki", "KUROTSUKI", "☾", "Đặc Biệt (Specialization) · Hạng A+", KURO_BLU, KURO_CYN, 120f, 8.4f, 1.12f, 1.1f, 1f, .12f,
        "Kiếm sĩ mang vầng trăng đen trong mắt, toả aura xanh như ánh trăng lạnh. Thanh katana của hắn chém đứt cả không gian: trong tầm kiếm, không còn điểm nào là an toàn.",
        "Nội tại: Không Gian Vô Thường. 12% chí mạng (×1.6). Lướt (Dash) chém đứt không gian dọc đường lướt, gây 16 sát thương mọi địch trên đường.",
        intArrayOf(5, 4, 3, 5),
        listOf(
            Skill("Nguyệt Nhận (Katana)", "🌙", "CHÉM", 0f, "Chém ra trăng khuyết xanh xuyên 3 kẻ địch, đổi hướng chéo mỗi nhát. Mỗi đòn thứ 3 xoay người chém đứt không gian thành vết nứt dài 9m, sát thương lớn."),
            Skill("Dạ Nguyệt: Lao Trảm", "💨", "LAO", 5f, "Lao như bóng xanh tới kẻ địch gần nhất, chém xuyên mọi kẻ cản đường rồi bổ chữ X vào mục tiêu, choáng. Hai đòn kế tiếp chí mạng."),
            Skill("Cư Hợp: Nguyệt Quang Loạn Trảm", "🌙", "CƯ HỢP", 9f, "Cúi thấp tra kiếm dồn khí, rồi rút kiếm lao xuyên qua tối đa 6 kẻ địch gần nhất, sáu nhát chém trăng khuyết liên hoàn. Tra kiếm \"tách\": mọi vết chém hiện ra cùng lúc, sát thương lớn và hồi máu. 5 giây sau, đòn thường mạnh hơn 35% và hút máu."),
            Skill("Nguyệt Thực: Tuyệt Không Trảm", "🌑", "ULT", 0f, "Vầng trăng đen với nhật hoa xanh che phủ đấu trường, mọi kẻ địch bị khoá chặt rồi bị chém đứt không gian ngay tại chỗ, sau đó tám vết nứt xé toạc từ tâm. +25% sát thương, chạy nhanh 8 giây.")
        ),
        sigWrap("kurotsuki", KURO_BLU, ::buildKurotsuki), { kuroAtk() }, { kuroS1() }, { kuroS2() }, { kuroUlt() })
    c.tick = { dt ->
        val h = P.h
        h.bloodOn = false; h.eclOn = P.dmgBuffT > 0f || P.bl > 0f   // Nguyệt Quang / Nguyệt Thực: aura trắng lạnh mạnh hơn
        if (P.bl > 0f) {
            P.bl -= dt
            if (P.bl <= 0f) { P.bl = 0f; popText("Hết Nguyệt Quang", KURO_CYN); burst(P.pos.x, 1.2f, P.pos.z, KURO_CYN, 18, 6f, .5f, .6f) }
        }
        // ngoài giao tranh 3 giây thì tự thu kiếm
        if (!h.sheathed && h.act == null && P.atkCd < -3f && P.cast < -3f && !Input.atk && P.lunge == null && !P.dead) kuroNoto()
    }
    return c
}
