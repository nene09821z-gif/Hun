package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*
import java.util.Random

const val ARENA = 25f

/** Đấu trường: trời, nền, bục đá, vòng rune, kết giới, trụ tổ kiến, trứng, gai núi, tinh thể (port từ buildWorld).
 *  Số lượng vật thể và độ mịn lưới co giãn theo mức đồ họa (Quality.tier.detail). */
class World(val scene: Scene) {
    val root = Node()
    val rune = ArrayList<Material>()
    private var barrierMat: Material? = null
    private val rnd = Random(20260101L)
    private fun rnd(a: Float, b: Float) = a + rnd.nextFloat() * (b - a)
    private val detail = Quality.tier.detail
    private fun seg(base: Int, min: Int = 8) = max(min, (base * detail).toInt())
    private fun cnt(base: Int) = max(4, (base * detail).toInt())
    private fun Node.keep(): Node { noCull = true; return this }

    init {
        scene.root.add(root)

        // Trời: hình cầu bán kính 400, shader gradient
        val sky = Material(MatType.SKY, 0x3b1230, doubleSided = true, depthWrite = false, fog = false)
        mk(Geometry.sphere(400f, seg(24, 10), seg(16, 6)), sky, root, outline = false).keep()

        // Nền tối ở xa
        val gr = mk(Geometry.circle(220f, seg(40, 16)), lambert(0x1a0f22), root, y = -.7f, rx = -PIF / 2, outline = false).keep()
        gr.mat!!.doubleSided = true

        // Bục đá trung tâm (màu xấp xỉ texStone * 0xb8a8c8)
        mk(Geometry.cylinder(27.5f, 29f, 1.2f, seg(48, 20)), lambert(0x33233f), root, y = -.6f, outline = false).keep()

        // Vòng rune hồng (cộng sáng)
        for (r in floatArrayOf(25.8f, 24.8f, 17.4f, 16.9f, 9.5f)) {
            val m = basic(0xff3fa0, .75f, additive = true); rune.add(m)
            mk(Geometry.ring(r - .12f, r + .12f, seg(72, 32)), m, root, y = .03f, rx = -PIF / 2, outline = false).keep()
        }

        // Kết giới hình trụ rỗng, mờ dần (bỏ ở mức THẤP: lớp trong suốt rộng rất tốn fill-rate)
        if (Quality.tier.barrier) {
            val bm = basic(0xff3fa0, .16f, additive = true); bm.doubleSided = true; barrierMat = bm
            mk(Geometry.cylinder(26.8f, 26.8f, 4f, seg(64, 24), true), bm, root, y = 2f, outline = false).keep()
        }

        // trụ tổ kiến
        val np = cnt(16)
        val pg = Geometry.cylinder(1f, 1.5f, 1f, 8).translated(0f, .5f, 0f)
        val pm = lambert(0x3b2a44, 0x1a0820)
        for (i in 0 until np) {
            val a = i / np.toFloat() * TAU; val r = 34f + (i % 2) * 4f; val hh = rnd(9f, 17f)
            mk(pg, pm, root, cos(a) * r, -.6f, sin(a) * r, ry = rnd(0f, 3f), sx = rnd(1.4f, 2.2f), sy = hh, sz = rnd(1.4f, 2.2f), outline = false)
        }
        // trứng cam
        val eg = Geometry.sphere(1f, seg(10, 6), seg(8, 4)); val em = basic(0xffa23a, .85f)
        for (i in 0 until cnt(40)) {
            val a = rnd(0f, TAU); val r = rnd(33f, 70f); val s = rnd(.5f, 1.6f)
            mk(eg, em, root, cos(a) * r, rnd(.2f, 1.2f), sin(a) * r, sx = s, sy = s * 1.3f, sz = s, outline = false)
        }
        // gai núi xa
        val sg = Geometry.cone(1f, 1f, 6).translated(0f, .5f, 0f); val sm = lambert(0x25122e)
        for (i in 0 until cnt(40)) {
            val a = rnd(0f, TAU); val r = rnd(80f, 160f); val hh = rnd(25f, 70f)
            mk(sg, sm, root, cos(a) * r, -1f, sin(a) * r, sx = rnd(8f, 16f), sy = hh, sz = rnd(8f, 16f), outline = false)
        }
        // tinh thể xanh
        val cg = Geometry.octahedron(1f); val cm = basic(0x58f0e0, .9f)
        for (i in 0 until cnt(22)) {
            val a = rnd(0f, TAU); val r = rnd(30f, 40f)
            mk(cg, cm, root, cos(a) * r, rnd(1f, 3f), sin(a) * r, rx = rnd(-.3f, .3f), rz = rnd(-.3f, .3f), sx = .5f, sy = rnd(1.2f, 2.8f), sz = .5f, outline = false)
        }
    }

    fun update(t: Float) {
        // vòng rune nhấp nháy nhẹ
        for (i in 0 until rune.size) rune[i].opacity = .75f * (.9f + .1f * sin(t * 2f + i))
        barrierMat?.opacity = .16f * (.9f + .1f * sin(t * 2f + rune.size))
    }
}
