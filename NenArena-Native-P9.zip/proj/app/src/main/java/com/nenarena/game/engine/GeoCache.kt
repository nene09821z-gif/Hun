package com.nenarena.game.engine

import kotlin.math.PI

/**
 * Bộ nhớ đệm Geometry dùng chung: tạo 1 lần, tái sử dụng mãi mãi.
 * Trước đây mỗi lần dùng chiêu lại tạo lưới mới + buffer GPU mới (không bao giờ giải phóng) => rò rỉ + giật.
 * warm() được gọi lúc khởi động để tạo & upload sẵn, nên giữa trận không còn khựng vì nạp lưới.
 */
object GeoCache {
    private val map = HashMap<String, Geometry>()
    @JvmField val all = ArrayList<Geometry>()

    private inline fun get(key: String, make: () -> Geometry): Geometry =
        map.getOrPut(key) { make().also { all.add(it) } }

    private const val HP = (PI / 2).toFloat()

    fun yoyo(): Geometry = get("yoyo") { Geometry.cylinder(.24f, .24f, .1f, 14) }
    fun runeRing(r: Float): Geometry = get("rr$r") { Geometry.ring(r - .012f, r + .012f, 56).rotatedX(-HP) }
    fun runeTri(): Geometry = get("rt") { Geometry.ring(.62f - .008f, .62f + .008f, 3).rotatedX(-HP) }
    fun crackPlane(): Geometry = get("crack") { Geometry.plane(.12f, 1f).rotatedX(-HP).translated(0f, 0f, .5f) }
    fun needle(): Geometry = get("needle") { Geometry.cone(.04f, .7f, 5) }

    val RUNE_R = floatArrayOf(.96f, .92f, .64f, .62f, .35f)

    /** Tạo sẵn toàn bộ lưới hay dùng giữa trận. */
    fun warm() {
        yoyo(); runeTri(); crackPlane(); needle()
        for (r in RUNE_R) runeRing(r)
    }
}
