package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

/**
 * Aura sấm sét của Killua: nhiều tia điện ngoằn ngoèo quấn quanh thân theo hình xoắn ốc, chớp tắt liên tục,
 * cộng thêm vài tia toả xuống mặt đất quanh chân và tia lửa bắn ra. Mỗi tia là một chuỗi đoạn trụ nhỏ
 * (vầng sáng xanh + lõi trắng) gắn vào `parent` (thân nhân vật) nên đi theo mọi chuyển động.
 * Cường độ tăng theo aura I; khi Godspeed (g=1) tia dài hơn, dày hơn và nhiều hơn.
 */
class ZapAura(parent: Node, glowHex: Int, coreHex: Int) {
    private class Bolt(val segs: Int, val ground: Boolean, mg: Material, mc: Material, root: Node) {
        val glow = Array(segs) { Node().also { n -> n.geo = SEG; n.mat = mg; root.add(n) } }
        val core = Array(segs) { Node().also { n -> n.geo = SEG; n.mat = mc; root.add(n) } }
        var t = 0f
        var show = false
        fun setVisible(v: Boolean) { for (n in glow) n.visible = v; for (n in core) n.visible = v }
    }

    private val root = Node()
    private val mg = addMat(glowHex, .55f)
    private val mc = addMat(coreHex, .95f)
    private val bolts = ArrayList<Bolt>()
    private val nBody = if (Quality.tier.detail < 1f) 5 else 9
    private val px = FloatArray(8); private val py = FloatArray(8); private val pz = FloatArray(8)

    init {
        for (i in 0 until nBody) bolts.add(Bolt(5, false, mg, mc, root))
        for (i in 0 until 2) bolts.add(Bolt(4, true, mg, mc, root))
        parent.add(root)
        for (b in bolts) b.setVisible(false)
    }

    private fun radiusAt(y: Float) = if (y < .9f) .3f else if (y < 1.6f) .46f else .34f

    private fun place(b: Bolt, n: Int, wGlow: Float, wCore: Float) {
        for (i in 0 until n) {
            val sx = px[i + 1] - px[i]; val sy = py[i + 1] - py[i]; val sz = pz[i + 1] - pz[i]
            val l = max(.02f, sqrt(sx * sx + sy * sy + sz * sz))
            val g = b.glow[i]; g.pos.set(px[i], py[i], pz[i]); g.lookDir(sx, sy, sz); g.scl.set(wGlow, wGlow, l)
            val c = b.core[i]; c.pos.set(px[i], py[i], pz[i]); c.lookDir(sx, sy, sz); c.scl.set(wCore, wCore, l)
        }
    }

    /** Dựng lại hình dạng một tia (toạ độ cục bộ của thân, cao ~2). Trả về điểm cuối để bắn tia lửa. */
    private fun regen(b: Bolt, I: Float, g: Float) {
        val n = b.segs
        val wG = .15f * (1f + .35f * g); val wC = .045f * (1f + .3f * g)
        if (b.ground) {
            val a = rnd(0f, TAU); val ca = cos(a); val sa = sin(a)
            val len = rnd(.9f, 1.7f) * (1f + .4f * g)
            var side = 0f
            for (i in 0..n) {
                val t = i.toFloat() / n
                side += if (i == 0) 0f else rnd(-.22f, .22f)
                val r = .25f + len * t
                px[i] = ca * r - sa * side; pz[i] = sa * r + ca * side; py[i] = .05f + (if (i == 0 || i == n) 0f else rnd(0f, .18f))
            }
            place(b, n, wG, wC)
            return
        }
        var a = rnd(0f, TAU); var y = rnd(.05f, 1.9f)
        val dir = if (rnd01() < .5f) 1f else -1f; val vy = if (rnd01() < .5f) .32f else -.32f
        val reach = .1f + .2f * min(1.6f, I) + .22f * g
        for (i in 0..n) {
            val r = radiusAt(y) + rnd(0f, reach) * (if (i == 0 || i == n) .35f else 1f)
            px[i] = cos(a) * r; pz[i] = sin(a) * r; py[i] = y
            a += dir * rnd(.3f, .75f); y = clamp(y + vy * rnd(.5f, 1.4f) + rnd(-.1f, .1f), .02f, 2f)
        }
        place(b, n, wG, wC)
    }

    fun tick(I: Float, dt: Float, x: Float, y: Float, z: Float, s: Float, g: Float) {
        val vis = I > .01f
        root.visible = vis
        if (!vis) return
        val k = clamp(I / 1.4f, .35f, 1f)
        val active = ceil(nBody * k).toInt() + (if (g > .3f) 2 else 0)
        for ((i, b) in bolts.withIndex()) {
            b.t -= dt
            if (b.t > 0f) continue
            b.t = rnd(.04f, .1f)
            val on = if (b.ground) rnd01() < .5f + .3f * g else i < active && rnd01() < .82f
            b.show = on; b.setVisible(on)
            if (on) {
                regen(b, I, g)
                if (rnd01() < .55f) {
                    val e = b.segs
                    emit(x + px[e] * s, y + py[e] * s, z + pz[e] * s, rnd(-1.2f, 1.2f), rnd(.5f, 2.5f), rnd(-1.2f, 1.2f), rnd(.15f, .3f), .26f, .02f, if (rnd01() < .5f) 0xffffff else 0x7ae6ff, 4f, 1.5f)
                }
            }
        }
    }

    companion object {
        private val SEG: Geometry = Geometry.cylinder(1f, 1f, 1f, 6, true).rotatedX(PIF / 2).translated(0f, 0f, .5f)
    }
}
