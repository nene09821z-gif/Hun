package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

/** Quaternion nhỏ gọn (x,y,z,w) để dựng tư thế xương từ các góc Euler của khung người. */
private class Q(val x: Float, val y: Float, val z: Float, val w: Float) {
    operator fun times(o: Q) = Q(
        w * o.x + x * o.w + y * o.z - z * o.y,
        w * o.y - x * o.z + y * o.w + z * o.x,
        w * o.z + x * o.y - y * o.x + z * o.w,
        w * o.w - x * o.x - y * o.y - z * o.z)
    fun inv() = Q(-x, -y, -z, w)
}

private fun qAxis(ax: Float, ay: Float, az: Float, a: Float): Q { val s = sin(a / 2f); return Q(ax * s, ay * s, az * s, cos(a / 2f)) }
/** Euler XYZ (cùng quy ước Node.rot / three.js): R = Rx * Ry * Rz. */
private fun qEuler(x: Float, y: Float, z: Float, k: Float = 1f) = qAxis(1f, 0f, 0f, x * k) * qAxis(0f, 1f, 0f, y * k) * qAxis(0f, 0f, 1f, z * k)

private fun hideMeshes(n: Node) {
    if (n.geo != null) n.visible = false
    for (c in n.children) hideMeshes(c)
}

/**
 * Thay hình khối của [h] bằng model skin thật [name].
 * Khung người cũ vẫn chạy mọi chuyển động (đi, đòn đánh, SIG, keyframe chiêu) nhưng bị ẩn; mỗi khung hình
 * các góc khớp của nó được chép sang xương của model (cuối poseHuman).
 * armDown: góc (rad) hạ tay từ tư thế chữ T/chữ A của model xuống thế buông tay của khung người.
 * tail: model có 7 xương đuôi (tail0..tail6) thì cho vẫy.
 */
fun attachSkinModel(h: Human, name: String, height: Float, armDown: Float, tail: Boolean): SkinModel {
    hideMeshes(h.body)
    h.mats.clear(); h.outs.clear()
    val m = SkinModel(ModelCache.get(name))
    m.root.setScale(height)
    h.body.add(m.root)
    h.mats.addAll(m.mats)
    for (nd in m.outNodes) nd.olw = .028f / height
    h.fadeHook = { o -> for (nd in m.outNodes) nd.outline = o >= 1f }

    val iHips = m.bi("hips"); val iSp0 = m.bi("spine0"); val iSp1 = m.bi("spine1"); val iNeck = m.bi("neck"); val iHead = m.bi("head")
    val arm = intArrayOf(m.bi("armL"), m.bi("armR")); val el = intArrayOf(m.bi("elL"), m.bi("elR"))
    val th = intArrayOf(m.bi("thighL"), m.bi("thighR")); val kn = intArrayOf(m.bi("kneeL"), m.bi("kneeR"))
    val tails = IntArray(7) { m.bi("tail$it") }

    fun put(i: Int, q: Q) = m.setQ(i, q.x, q.y, q.z, q.w)

    h.sync = { _, time, _ ->
        m.resetQ()
        put(iHips, qEuler(h.hips.rot.x, h.hips.rot.y, h.hips.rot.z))
        val t = h.torso.rot; val hd = h.head.rot
        if (iSp1 >= 0) { put(iSp0, qEuler(t.x, t.y, t.z, .5f)); put(iSp1, qEuler(t.x, t.y, t.z, .5f)) }
        else put(iSp0, qEuler(t.x, t.y, t.z))
        if (iNeck >= 0) { put(iNeck, qEuler(hd.x, hd.y, hd.z, .4f)); put(iHead, qEuler(hd.x, hd.y, hd.z, .6f)) }
        else put(iHead, qEuler(hd.x, hd.y, hd.z))
        for (s in 0..1) {
            val a = if (s == 0) h.armL else h.armR; val e = if (s == 0) h.elL else h.elR
            val lg = if (s == 0) h.legL else h.legR; val k = if (s == 0) h.knL else h.knR
            // B: hạ tay từ tư thế gốc của model xuống dọc thân (L ở -x quay +z, R ở +x quay -z)
            val b = qAxis(0f, 0f, 1f, if (s == 0) armDown else -armDown)
            put(arm[s], qEuler(a.rot.x, a.rot.y, a.rot.z) * b)
            put(el[s], b.inv() * qEuler(e.rot.x, e.rot.y, e.rot.z) * b)
            put(th[s], qEuler(lg.rot.x, lg.rot.y, lg.rot.z))
            put(kn[s], qEuler(k.rot.x, k.rot.y, k.rot.z))
        }
        if (tail) for (i in 0 until 7) put(tails[i], qAxis(0f, 1f, 0f, sin(time * 3f + i * .6f) * .1f))
        m.update()
        m.root.pos.y = h.hips.pos.y - .95f   // nhún theo hông như khung người
    }
    h.sync?.invoke(0f, 0f, 0f)
    return m
}
