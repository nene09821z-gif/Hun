# NEN ARENA – Native (Kotlin + Jetpack Compose + OpenGL ES 3.0)

Bản viết lại **hoàn toàn native**: không WebView, không HTML, không three.js.
Engine 3D tự viết bằng Kotlin (OpenGL ES 3.0), giao diện/điều khiển bằng Jetpack Compose.

## Cấu trúc
- `engine/MathX.kt` – vector, ma trận 4x4, Euler XYZ (giống three.js)
- `engine/Geometry.kt` – box, sphere, cylinder, cone, torus, ring, capsule, octahedron...
- `engine/Scene.kt` – Node (scene graph), Material (toon / basic / lambert / sky), đèn, sương mù
- `engine/Renderer.kt` – shader toon 4 bậc + viền đen + sương mù exp2 + trời gradient + additive blending
- `game/Human.kt` – mô hình người, tư thế đi, các động tác (port từ buildHuman/poseHuman)
- `game/World.kt` – đấu trường, trụ tổ kiến, trứng, tinh thể
- `game/Game.kt` – vòng lặp, di chuyển, camera
- `game/Audio.kt` – nhạc nền (MediaPlayer) + hiệu ứng âm thanh (SoundPool); file nằm ở `assets/music`, `assets/sfx`
- `MainActivity.kt` – Compose: cần analog trái, vuốt phải xoay camera

## Tiến độ port (xem PORT_STATUS.md)
