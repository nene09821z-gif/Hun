import {NodeIO} from '@gltf-transform/core';
import {ALL_EXTENSIONS} from '@gltf-transform/extensions';
import fs from 'fs';import crypto from 'crypto';
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS);
const OUT='assets/';
function writeModel(name,bones,meshes){
  // bones: [{n,p,t:[x,y,z] local}], meshes: [{pos,nor,uv,ji,jw,idx,tex(Uint8Array),cut,ds,ol}]
  const chunks=[];let off=0;const meta={bones:bones.map(b=>({n:b.n,p:b.p,t:b.t.map(x=>+x.toFixed(5))})),meshes:[]};
  const push=(ta)=>{const b=Buffer.from(ta.buffer,ta.byteOffset,ta.byteLength);const o=off;chunks.push(b);off+=b.length;const pad=(4-off%4)%4;if(pad){chunks.push(Buffer.alloc(pad));off+=pad}return o};
  meshes.forEach((m,i)=>{
    const nv=m.pos.length/3;const e={v:nv,i:m.idx.length};
    e.pos=push(m.pos);e.nor=push(m.nor);e.uv=push(m.uv);e.ji=push(m.ji);e.jw=push(m.jw);e.idx=push(m.idx);
    e.tex=name+'_'+crypto.createHash('md5').update(m.tex).digest('hex').slice(0,6)+'.png';fs.writeFileSync(OUT+e.tex,m.tex);e.cut=m.cut;e.ds=m.ds;e.ol=m.ol;
    meta.meshes.push(e)});
  fs.writeFileSync(OUT+name+'.bin',Buffer.concat(chunks));fs.writeFileSync(OUT+name+'.json',JSON.stringify(meta));
  console.log(name,'bones',bones.length,'bin',off);
}
const seg=(p,a,b)=>{const ab=[b[0]-a[0],b[1]-a[1],b[2]-a[2]],ap=[p[0]-a[0],p[1]-a[1],p[2]-a[2]];const l2=ab[0]**2+ab[1]**2+ab[2]**2;let t=l2>0?(ap[0]*ab[0]+ap[1]*ab[1]+ap[2]*ab[2])/l2:0;t=Math.max(0,Math.min(1,t));const q=[a[0]+ab[0]*t,a[1]+ab[1]*t,a[2]+ab[2]*t];return Math.hypot(p[0]-q[0],p[1]-q[1],p[2]-q[2])};

// ================= KILLUA =================
{
 const d=await io.read('../kil/source/Killua Zoldyck.glb');const r=d.getRoot();
 const nodeOf=new Map();for(const n of r.listNodes())if(n.getMesh())nodeOf.set(n.getMesh(),n);
 const keep=['mesh_id4','mesh_id6','mesh_id7','mesh_id8','mesh_id9','mesh_id10','mesh_id11','mesh_id12','mesh_id13','mesh_id14']; // bỏ mesh_id5 = ván trượt
 const olSet=new Set(['mesh_id12','mesh_id7','mesh_id8','mesh_id9','mesh_id10','mesh_id13','mesh_id14']);
 const S=1/0.512,YO=0.256,ZC=0.2535;
 // joints in normalized coords
 const J={hips:[0,.50,0],spine0:[0,.60,0],head:[0,.79,0],
  armL:[-.11,.72,0],elL:[-.25,.72,0],wrL:[-.37,.72,0],armR:[.11,.72,0],elR:[.25,.72,0],wrR:[.37,.72,0],
  thighL:[-.055,.50,0],kneeL:[-.055,.27,0],ankleL:[-.055,.10,0],thighR:[.055,.50,0],kneeR:[.055,.27,0],ankleR:[.055,.10,0]};
 const order=[['hips',-1],['spine0','hips'],['head','spine0'],['armL','spine0'],['elL','armL'],['wrL','elL'],['armR','spine0'],['elR','armR'],['wrR','elR'],['thighL','hips'],['kneeL','thighL'],['ankleL','kneeL'],['thighR','hips'],['kneeR','thighR'],['ankleR','kneeR']];
 const names=order.map(o=>o[0]);
 const bones=order.map(([n,p])=>({n,p:p===-1?-1:names.indexOf(p),t:p===-1?J[n]:J[n].map((v,k)=>v-J[p][k])}));
 // segments: [boneName, a, b, radius]
 const SG=[['hips',J.hips,J.spine0,.11],['spine0',J.spine0,J.head,.11],['head',J.head,[0,1.04,0],.12],
  ['armL',J.armL,J.elL,.045],['elL',J.elL,J.wrL,.04],['wrL',J.wrL,[-.52,.72,0],.04],
  ['armR',J.armR,J.elR,.045],['elR',J.elR,J.wrR,.04],['wrR',J.wrR,[.52,.72,0],.04],
  ['thighL',J.thighL,J.kneeL,.065],['kneeL',J.kneeL,J.ankleL,.05],['ankleL',J.ankleL,[-.055,.03,.07],.055],
  ['thighR',J.thighR,J.kneeR,.065],['kneeR',J.kneeR,J.ankleR,.05],['ankleR',J.ankleR,[.055,.03,.07],.055]];
 const meshes=[];
 for(const m of r.listMeshes()){if(!keep.includes(m.getName()))continue;const pr=m.listPrimitives()[0];const mat=pr.getMaterial();
  const wm=nodeOf.get(m).getWorldMatrix();const pos=pr.getAttribute('POSITION').getArray(),N=pr.getAttribute('NORMAL').getArray();
  const nv=pos.length/3;const P=new Float32Array(nv*3),Nn=new Float32Array(nv*3);const sc=Math.hypot(wm[0],wm[1],wm[2]);
  for(let i=0;i<nv;i++){const x=pos[i*3],y=pos[i*3+1],z=pos[i*3+2];
   P[i*3]=(wm[0]*x+wm[4]*y+wm[8]*z+wm[12])*S;P[i*3+1]=(wm[1]*x+wm[5]*y+wm[9]*z+wm[13]+YO)*S;P[i*3+2]=(wm[2]*x+wm[6]*y+wm[10]*z+wm[14]-ZC)*S;
   const nx=N[i*3],ny=N[i*3+1],nz=N[i*3+2];Nn[i*3]=(wm[0]*nx+wm[4]*ny+wm[8]*nz)/sc;Nn[i*3+1]=(wm[1]*nx+wm[5]*ny+wm[9]*nz)/sc;Nn[i*3+2]=(wm[2]*nx+wm[6]*ny+wm[10]*nz)/sc}
  const ji=new Uint8Array(nv*4),jw=new Float32Array(nv*4);
  const isHead=['mesh_id4','mesh_id6','mesh_id7','mesh_id8','mesh_id11'].includes(m.getName());
  for(let i=0;i<nv;i++){const p=[P[i*3],P[i*3+1],P[i*3+2]];
   let ws=[];
   if(isHead){ws=[[names.indexOf('head'),1]]}
   else{const nd=SG.map(s=>seg(p,s[1],s[2])/s[3]);const mn=Math.min(...nd);
    ws=SG.map((s,k)=>[names.indexOf(s[0]),Math.exp(-(nd[k]-mn)/.35)]).sort((a,b)=>b[1]-a[1]).slice(0,4);}
   const tot=ws.reduce((a,b)=>a+b[1],0);
   ws.forEach((w,k)=>{ji[i*4+k]=w[0];jw[i*4+k]=w[1]/tot})}
  meshes.push({pos:P,nor:Nn,uv:new Float32Array(pr.getAttribute('TEXCOORD_0').getArray()),ji,jw,idx:new Uint16Array(pr.getIndices().getArray()),tex:Buffer.from(mat.getBaseColorTexture().getImage()),cut:mat.getAlphaMode()==='MASK'?mat.getAlphaCutoff():0,ds:true,ol:olSet.has(m.getName())});
 }
 writeModel('killua',bones,meshes);
}
// ================= PITOU =================
{
 const d=await io.read('/mnt/user-data/attachments/c543b3db-8664-5944-b755-1a8bca66f63e/d8154179-neferpitou.glb');const r=d.getRoot();
 const skin=r.listSkins()[0];const joints=skin.listJoints();const idx=new Map(joints.map((j,i)=>[j,i]));
 const N0=joints.map(j=>j.getName());
 const ren={'root hips_065':'hips','pelvis_057':'pelvis','spine lower_066':'spine0','spine upper_067':'spine1','head neck lower_045':'neck','head neck upper_046':'head'};
 for(const[k,v] of [['right','L'],['left','R']]){
  ren['leg '+k+' thigh_'+(k==='right'?'055':'050')]='thigh'+v;ren['leg '+k+' knee_'+(k==='right'?'054':'049')]='knee'+v;ren['leg '+k+' ankle_'+(k==='right'?'052':'047')]='ankle'+v;ren['leg '+k+' toes_'+(k==='right'?'053':'048')]='toe'+v;
  const a=k==='right'?['031','032','017','018']:['015','016','01','02'];
  ren['arm '+k+' shoulder 1_'+a[0]]='clav'+v;ren['arm '+k+' shoulder 2_'+a[1]]='arm'+v;ren['arm '+k+' elbow_'+a[2]]='el'+v;ren['arm '+k+' wrist_'+a[3]]='wr'+v}
 ['a_00','b_058','c_059','d_060','e_061','f_062','g_063'].forEach((s,i)=>ren['tail '+s]='tail'+i);
 // world rest
 const W=joints.map(()=>null);joints.forEach((j,i)=>{const t=j.getTranslation();const p=idx.has(j.getParentNode())?W[idx.get(j.getParentNode())]:[0,0,0];W[i]=[p[0]+t[0],p[1]+t[1],p[2]+t[2]]});
 const keepIdx=[];N0.forEach((n,i)=>{if(ren[n])keepIdx.push(i)});
 const newIndex=new Map(keepIdx.map((o,i)=>[o,i]));
 const mapOld=joints.map((j,i)=>{let c=i;while(c>=0&&!newIndex.has(c)){const p=joints[c].getParentNode();c=idx.has(p)?idx.get(p):-1}return c>=0?newIndex.get(c):newIndex.get(N0.indexOf('root hips_065'))});
 // parent of new bones
 const keepParent=keepIdx.map(o=>{let c=idx.has(joints[o].getParentNode())?idx.get(joints[o].getParentNode()):-1;while(c>=0&&!newIndex.has(c)){const p=joints[c].getParentNode();c=idx.has(p)?idx.get(p):-1}return c>=0?newIndex.get(c):-1});
 const SC=1/19.8;
 const bones=keepIdx.map((o,i)=>{const p=keepParent[i];const w=W[o];const pw=p<0?[0,0,0]:W[keepIdx[p]];return {n:ren[N0[o]],p,t:[(w[0]-pw[0])*SC,(w[1]-pw[1])*SC,(w[2]-pw[2])*SC]}});
 const pr=r.listMeshes()[0].listPrimitives()[0];const mat=pr.getMaterial();
 const pos=pr.getAttribute('POSITION').getArray(),nor=pr.getAttribute('NORMAL').getArray(),J0=pr.getAttribute('JOINTS_0').getArray(),W0=pr.getAttribute('WEIGHTS_0').getArray();
 const nv=pos.length/3;const P=new Float32Array(nv*3),Nn=new Float32Array(nv*3),ji=new Uint8Array(nv*4),jw=new Float32Array(nv*4);
 for(let i=0;i<nv;i++){P[i*3]=pos[i*3]*SC;P[i*3+1]=pos[i*3+1]*SC;P[i*3+2]=pos[i*3+2]*SC;Nn[i*3]=nor[i*3];Nn[i*3+1]=nor[i*3+1];Nn[i*3+2]=nor[i*3+2];
  const acc=new Map();for(let k=0;k<4;k++){const w=W0[i*4+k];if(w<=0)continue;const nj=mapOld[J0[i*4+k]];acc.set(nj,(acc.get(nj)||0)+w)}
  const arr=[...acc.entries()].sort((a,b)=>b[1]-a[1]).slice(0,4);const tot=arr.reduce((a,b)=>a+b[1],0)||1;
  if(!arr.length)arr.push([0,1]);arr.forEach((a,k)=>{ji[i*4+k]=a[0];jw[i*4+k]=a[1]/(arr.length&&tot)})}
 writeModel('pitou',bones,[{pos:P,nor:Nn,uv:new Float32Array(pr.getAttribute('TEXCOORD_0').getArray()),ji,jw,idx:new Uint16Array(pr.getIndices().getArray()),tex:Buffer.from(mat.getBaseColorTexture().getImage()),cut:0,ds:true,ol:true}]);
 console.log(bones.map(b=>b.n).join(','));
}
