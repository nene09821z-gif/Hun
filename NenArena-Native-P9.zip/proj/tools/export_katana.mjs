// Chuyển katana.glb (Sketchfab) sang định dạng assets của engine: katana.json + katana.bin + texture.
// Chạy:  node tools/export_katana.mjs <katana.glb> [thư-mục-assets]
// Cần:   npm i @gltf-transform/core @gltf-transform/extensions sharp   (sharp không bắt buộc, chỉ để thu nhỏ texture 2048 -> 512)
//
// Quy ước model: dài đúng 1 đơn vị; GỐC (0,0,0) = giữa cán (tsuka) để đặt thẳng vào lòng bàn tay;
// mũi kiếm hướng +Z; mặt dẹt của lưỡi quay ±Y; LƯỠI SẮC (ha) quay về -X, sống kiếm (mune) về +X.
// Một xương duy nhất "root" (engine yêu cầu model có xương).
// Thứ tự mesh cố định: 0..2 = thân lưỡi + hai dải mép (ĐỂ PHÁT SÁNG), 3.. = tsuba, habaki, cán quấn, đầu cán.
import {NodeIO} from '@gltf-transform/core';
import {ALL_EXTENSIONS} from '@gltf-transform/extensions';
import fs from 'fs';import crypto from 'crypto';
const SRC=process.argv[2]||'katana.glb', OUT=(process.argv[3]||'app/src/main/assets/').replace(/\/?$/,'/');
let sharp=null;try{sharp=(await import('sharp')).default}catch{console.log('(không có sharp: giữ nguyên texture gốc)')}
const io=new NodeIO().registerExtensions(ALL_EXTENSIONS);
const d=await io.read(SRC);const r=d.getRoot();

// file gốc: mũi ở -X, lưỡi sắc ở +Z, dẹt theo Y  ->  engine: mũi +Z, sắc -X, dẹt Y  (xoay thuần, det = +1)
const MAP=(x,y,z)=>[-z,-y,-x];
const ORDER=[['10___Default','blade',false],['06___Default','blade_edge_a',false],['11___Default','blade_edge_b',false],
             ['04___Default','tsuba',true],['02___Default','habaki',true],['03___Default','tsuka_a',true],
             ['07___Default','tsuka_b',true],['05___Default','tsuka_c',true],['09___Default','kashira',false]];
const nodeOf=r.listNodes().filter(n=>n.getMesh());
const byMat=new Map();for(const n of nodeOf){const pr=n.getMesh().listPrimitives()[0];byMat.set(pr.getMaterial().getName(),n)}

// 1) toạ độ thế giới sau khi xoay; tìm tâm cán + chiều dài
const world=ORDER.map(([mn])=>{const n=byMat.get(mn);const wm=n.getWorldMatrix();const pr=n.getMesh().listPrimitives()[0];
 const pos=pr.getAttribute('POSITION').getArray(),nor=pr.getAttribute('NORMAL').getArray();const nv=pos.length/3;
 const P=new Float32Array(nv*3),N=new Float32Array(nv*3);
 for(let i=0;i<nv;i++){const x=pos[i*3],y=pos[i*3+1],z=pos[i*3+2];
  const p=MAP(wm[0]*x+wm[4]*y+wm[8]*z+wm[12],wm[1]*x+wm[5]*y+wm[9]*z+wm[13],wm[2]*x+wm[6]*y+wm[10]*z+wm[14]);
  const nx=nor[i*3],ny=nor[i*3+1],nz=nor[i*3+2];const q=MAP(wm[0]*nx+wm[4]*ny+wm[8]*nz,wm[1]*nx+wm[5]*ny+wm[9]*nz,wm[2]*nx+wm[6]*ny+wm[10]*nz);
  const l=Math.hypot(...q)||1;P.set(p,i*3);N.set(q.map(v=>v/l),i*3)}
 return {pr,P,N}});
let zmin=1e9,zmax=-1e9;for(const w of world)for(let i=2;i<w.P.length;i+=3){zmin=Math.min(zmin,w.P[i]);zmax=Math.max(zmax,w.P[i])}
const len=zmax-zmin;
// cán = ba mesh quấn (03,07,05): lấy trung điểm theo Z của chúng làm gốc
let tz0=1e9,tz1=-1e9;for(const i of [5,6,7])for(let k=2;k<world[i].P.length;k+=3){tz0=Math.min(tz0,world[i].P[k]);tz1=Math.max(tz1,world[i].P[k])}
const cz=(tz0+tz1)/2,S=1/len;
console.log('chiều dài gốc',len.toFixed(3),'tâm cán z',cz.toFixed(3),'-> mũi',((zmax-cz)*S).toFixed(3),'đuôi',((zmin-cz)*S).toFixed(3));

// 2) ghi bin + json
const chunks=[];let off=0;const meta={bones:[{n:'root',p:-1,t:[0,0,0]}],meshes:[]};
const push=ta=>{const b=Buffer.from(ta.buffer,ta.byteOffset,ta.byteLength);const o=off;chunks.push(b);off+=b.length;const pad=(4-off%4)%4;if(pad){chunks.push(Buffer.alloc(pad));off+=pad}return o};
const texCache=new Map();
for(let m=0;m<ORDER.length;m++){
 const {pr,P,N}=world[m];const nv=P.length/3;
 for(let i=0;i<nv;i++){P[i*3]*=S;P[i*3+1]*=S;P[i*3+2]=(P[i*3+2]-cz)*S} // X,Y chỉ đổi tỉ lệ (kiếm nằm trên trục, cán ở gốc X,Y)
 const uv=new Float32Array(pr.getAttribute('TEXCOORD_0').getArray());
 const ji=new Uint8Array(nv*4),jw=new Float32Array(nv*4);for(let i=0;i<nv;i++)jw[i*4]=1;
 const idx=new Uint16Array(pr.getIndices().getArray());
 let tex=Buffer.from(pr.getMaterial().getBaseColorTexture().getImage()),ext='png';
 const mime=pr.getMaterial().getBaseColorTexture().getMimeType();
 if(sharp){tex=await sharp(tex).resize(512,512,{fit:'fill'}).jpeg({quality:88}).toBuffer();ext='jpg'}else ext=mime==='image/jpeg'?'jpg':'png';
 const h=crypto.createHash('md5').update(tex).digest('hex').slice(0,6),tf='katana_'+h+'.'+ext;
 if(!texCache.has(tf)){fs.writeFileSync(OUT+tf,tex);texCache.set(tf,1)}
 const e={n:ORDER[m][1],v:nv,i:idx.length};
 e.pos=push(P);e.nor=push(N);e.uv=push(uv);e.ji=push(ji);e.jw=push(jw);e.idx=push(idx);
 e.tex=tf;e.cut=0;e.ds=true;e.ol=ORDER[m][2];meta.meshes.push(e)}
fs.writeFileSync(OUT+'katana.bin',Buffer.concat(chunks));fs.writeFileSync(OUT+'katana.json',JSON.stringify(meta));
console.log('katana: meshes',meta.meshes.length,'bin',off,'bytes; texture',[...texCache.keys()].join(' '));
