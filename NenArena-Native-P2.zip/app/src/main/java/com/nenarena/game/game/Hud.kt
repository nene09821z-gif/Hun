package com.nenarena.game.game

/** Ảnh chụp trạng thái HUD: luồng GL ghi, giao diện Compose đọc (không phụ thuộc Compose để dễ kiểm tra). */
class HudSnap(
    val screen: String = "load",
    val hp: Float = 1f, val hpTxt: String = "", val nen: Float = 0f,
    val cd1: Float = 0f, val cd2: Float = 0f, val cdDash: Float = 0f,
    val cdN1: String = "", val cdN2: String = "", val cdND: String = "",
    val ultFrac: Float = 0f, val ultTxt: String = "", val ultReady: Boolean = false,
    val wave: Int = 1, val kills: Int = 0, val score: Int = 0,
    val bossName: String = "", val bossFrac: Float = -1f,
    val combo: Int = 0, val toast: String = "", val toastId: Int = 0,
    val banner: String = "", val bannerSub: String = "", val bannerId: Int = 0,
    val dns: List<Dn> = emptyList(),
    val flashC: Int = 0, val flashA: Float = 0f, val flashMs: Int = 0, val flashId: Int = 0,
    val hurtId: Int = 0, val speedId: Int = 0, val speedMs: Int = 0,
    val skills: List<Skill> = emptyList(), val avatar: String = "♠", val col: Int = 0xff3fa0, val col2: Int = 0xffb0dd,
    val selIdx: Int = 0, val overStats: List<Pair<String, String>> = emptyList(), val portrait: Boolean = true
)

object Hud {
    @Volatile var snap = HudSnap()
    @Volatile var chars: List<CharCfg> = emptyList()
    @Volatile var gameRef: Game? = null
}

/** Trạng thái điều khiển do giao diện Compose ghi, luồng GL đọc. */
object Input {
    @Volatile var mx = 0f
    @Volatile var my = 0f
    @Volatile var camDX = 0f
    @Volatile var camDY = 0f
    @Volatile var atk = false
    @Volatile var pS1 = false
    @Volatile var pS2 = false
    @Volatile var pUlt = false
    @Volatile var pDash = false
    private val q = java.util.concurrent.ConcurrentLinkedQueue<() -> Unit>()
    fun post(fn: () -> Unit) { q.add(fn) }
    fun drain() { while (true) { val f = q.poll() ?: break; f() } }
}

/** Âm thanh: để trống ở giai đoạn này (sẽ thay bằng bộ tổng hợp AudioTrack). */
object SFX {
    var on = true
    fun swing() {}; fun skill() {}; fun ult() {}; fun boom() {}; fun hit() {}; fun die() {}; fun hurt() {}; fun dash() {}; fun ui() {}
}
