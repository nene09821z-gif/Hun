package com.nenarena.game.engine

import android.opengl.GLES30
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/** Vòng lặp game chạy trên luồng GL. */
interface GameLoop {
    val scene: Scene
    fun onSurface(w: Int, h: Int)
    fun update(dt: Float)
}

// Lưu ý: uniform dùng chung 2 stage (uOutline) PHẢI khai báo cùng precision, nếu lệch sẽ lỗi link -> văng app.
// vP khai báo highp vì hình cầu trời bán kính 400: bình phương vượt dải fp16 (mediump) trên GPU yếu -> NaN.
private const val VS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in vec3 aNor;
uniform mat4 uVP; uniform mat4 uView; uniform mat4 uModel; uniform mat3 uNM; uniform highp float uOutline;
uniform highp int uMode; uniform highp float uT; uniform highp float uI; uniform vec3 uCam;
out vec3 vN; out highp vec3 vP; out float vD; out vec3 vV; out float vY;
void main(){
  vec3 p = aPos;
  if(uOutline > 0.) p += normalize(aNor) * uOutline;
  if(uMode == 4){
    float w = sin(p.y*6.+uT*7.)*.045 + sin(p.x*9.+uT*5.)*.03;
    p += normalize(aNor) * (w*uI + .03);
    p.y += sin(uT*9.+p.x*4.)*.03*uI;
  }
  vec4 wp = uModel * vec4(p, 1.);
  vP = aPos;
  vN = normalize(uNM * aNor);
  vD = -(uView * wp).z;
  vV = normalize(uCam - wp.xyz);
  vY = aPos.y/1.3*.5+.5;
  gl_Position = uVP * wp;
}"""

private const val FS = """#version 300 es
precision mediump float;
in vec3 vN; in highp vec3 vP; in float vD; in vec3 vV; in float vY;
uniform highp int uMode; uniform highp float uT; uniform highp float uI; uniform float uAA;
uniform vec3 uCol; uniform vec3 uEmi; uniform float uOpa; uniform highp float uOutline;
uniform vec3 uSky; uniform vec3 uGnd; uniform vec3 uSunC; uniform vec3 uSunD;
uniform float uHemiI; uniform float uSunI;
uniform vec3 uFogC; uniform float uFogD; uniform float uUseFog;
out vec4 o;
void main(){
  if(uOutline > 0.){ o = vec4(.04, .02, .08, 1.); return; }
  vec3 col;
  if(uMode == 4){
    float f = pow(1. - abs(dot(normalize(vN), normalize(vV))), 1.7);
    float fl = .65 + .35*sin(uT*14. + vY*9.);
    float a = f*fl*uI*uAA*(1.15 - vY*.5);
    o = vec4(uCol*(1.+f), clamp(a, 0., 1.)); return;
  }
  if(uMode == 3){
    float h = normalize(vP).y;
    vec3 hor = vec3(.231,.071,.188), mid = vec3(.169,.051,.259), top = vec3(.02,.012,.09);
    col = mix(hor, mid, smoothstep(0., .22, h));
    col = mix(col, top, smoothstep(.15, .7, h));
    if(h < 0.) col = hor;
    o = vec4(col, 1.); return;
  }
  if(uMode == 1){ col = uCol; }
  else {
    vec3 n = normalize(vN);
    if(!gl_FrontFacing) n = -n;
    float nd = dot(n, uSunD);
    float dif;
    if(uMode == 0){
      float g = clamp(nd * .5 + .5, 0., .999);
      float gi = floor(g * 4.);
      dif = gi < 1. ? .353 : (gi < 2. ? .6 : (gi < 3. ? .816 : 1.));
    } else dif = max(nd, 0.);
    vec3 hemi = mix(uGnd, uSky, n.y * .5 + .5) * uHemiI;
    col = uCol * (hemi + uSunC * uSunI * dif) + uEmi;
  }
  if(uUseFog > .5){
    float f = 1. - exp(-uFogD * uFogD * vD * vD);
    col = mix(col, uFogC, clamp(f, 0., 1.));
  }
  o = vec4(col, uOpa);
}"""

private const val PVS = """#version 300 es
layout(location=0) in vec3 aPos;
layout(location=1) in float aSize;
layout(location=2) in vec3 aCol;
layout(location=3) in float aAl;
uniform mat4 uVP; uniform mat4 uView; uniform highp float uScale;
out vec3 vC; out float vA;
void main(){
  vC = aCol; vA = aAl;
  float d = -(uView * vec4(aPos, 1.)).z;
  gl_PointSize = min(160., aSize * uScale / max(.1, d));
  gl_Position = uVP * vec4(aPos, 1.);
}"""

private const val PFS = """#version 300 es
precision mediump float;
in vec3 vC; in float vA;
out vec4 o;
void main(){
  float d = length(gl_PointCoord - .5) * 2.;
  float a = smoothstep(1., 0., d); a *= a;
  o = vec4(vC, a * vA);
}"""

class GLRenderer(private val game: GameLoop) : GLSurfaceView.Renderer {
    /** Gọi (trên luồng GL) khi bộ điều chỉnh tự đổi tỉ lệ độ phân giải; Activity tự áp dụng. */
    var onScale: ((Float) -> Unit)? = null

    private val tier = Quality.tier
    private var prog = 0
    private var uVP = 0; private var uView = 0; private var uModel = 0; private var uNM = 0; private var uOutline = 0
    private var uMode = 0; private var uCol = 0; private var uEmi = 0; private var uOpa = 0
    private var uSky = 0; private var uGnd = 0; private var uSunC = 0; private var uSunD = 0
    private var uCam = 0; private var uT = 0; private var uI = 0; private var uAA = 0
    private var pProg = 0; private var puVP = 0; private var puView = 0; private var puScale = 0
    private var pVao = 0; private var pVbo = 0
    private val pBuf = ByteBuffer.allocateDirect(Particles.NP * 8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
    private var vh = 1
    private var curFov = 50f
    private var uHemiI = 0; private var uSunI = 0; private var uFogC = 0; private var uFogD = 0; private var uUseFog = 0

    private val proj = FloatArray(16)
    private val view = FloatArray(16)
    private val vp = FloatArray(16)
    private val nm = FloatArray(9)
    private var aspect = 1f
    private var last = 0L
    private val opaque = ArrayList<Node>()
    private val blend = ArrayList<Node>()
    private val addv = ArrayList<Node>()
    private val drawD2 = if (tier.drawDist > 1e8f) Float.MAX_VALUE else tier.drawDist * tier.drawDist
    private val frameNs = 1_000_000_000L / tier.fps

    // ---- tự điều chỉnh độ phân giải theo FPS thực tế ----
    private var frames = 0
    private var ema = 0f
    private var cool = 0f
    private var good = 0f
    private var dyn = 1f
    private var ceiling = 1f
    private var lastRaise = false

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        prog = link(VS, FS)
        fun u(n: String) = GLES30.glGetUniformLocation(prog, n)
        uVP = u("uVP"); uView = u("uView"); uModel = u("uModel"); uNM = u("uNM"); uOutline = u("uOutline")
        uMode = u("uMode"); uCol = u("uCol"); uEmi = u("uEmi"); uOpa = u("uOpa")
        uSky = u("uSky"); uGnd = u("uGnd"); uSunC = u("uSunC"); uSunD = u("uSunD")
        uHemiI = u("uHemiI"); uSunI = u("uSunI"); uFogC = u("uFogC"); uFogD = u("uFogD"); uUseFog = u("uUseFog")
        uCam = u("uCam"); uT = u("uT"); uI = u("uI"); uAA = u("uAA")
        initParticles()
        GLES30.glEnable(GLES30.GL_DEPTH_TEST)
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glDisable(GLES30.GL_DITHER)
        GLES30.glFrontFace(GLES30.GL_CCW)
        // GPU context mới: mọi buffer cũ vô hiệu
        invalidateAll(game.scene.root)
        last = 0L
        frames = 0
    }

    private fun invalidateAll(n: Node) {
        n.geo?.let { it.vao = 0; it.vbo = 0; it.ibo = 0 }
        for (c in n.children) invalidateAll(c)
    }

    override fun onSurfaceChanged(gl: GL10?, w: Int, h: Int) {
        GLES30.glViewport(0, 0, w, h)
        vh = h
        aspect = w.toFloat() / h
        game.onSurface(w, h)
    }

    override fun onDrawFrame(gl: GL10?) {
        val now = System.nanoTime()
        val raw = if (last == 0L) 0.016f else (now - last) / 1e9f
        last = now
        adapt(raw)
        game.update(if (raw > 0.05f) 0.05f else raw)
        draw(game.scene)

        // Giới hạn FPS (máy yếu: 30fps đều thay vì dao động 20-45)
        if (tier.fps < 60) {
            val rem = frameNs - (System.nanoTime() - now) - 2_000_000L
            if (rem > 0) try { Thread.sleep(rem / 1_000_000L, (rem % 1_000_000L).toInt()) } catch (e: InterruptedException) {}
        }
    }

    private fun adapt(raw: Float) {
        frames++
        if (frames < 120 || raw > 0.25f) return   // bỏ qua khởi động / tạm dừng
        if (frames == 120) ema = raw
        ema += (raw - ema) * .06f
        cool -= raw
        val budget = 1f / tier.fps
        if (ema > budget * 1.3f && dyn > MIN_DYN) {
            if (cool <= 0f) {
                if (lastRaise) ceiling = maxOf(MIN_DYN, dyn - .1f)
                dyn = maxOf(MIN_DYN, dyn - .15f)
                lastRaise = false; good = 0f; cool = 2.5f
                onScale?.invoke(dyn)
            }
        } else if (ema < budget * 1.1f && dyn < ceiling) {
            good += raw
            if (good > 6f) lastRaise = false
            if (good > 12f && cool <= 0f) {
                dyn = minOf(ceiling, dyn + .1f)
                lastRaise = true; good = 0f; cool = 2.5f
                onScale?.invoke(dyn)
            }
        } else good = 0f
    }

    private fun hex3(h: Int, out: FloatArray) { out[0] = ((h shr 16) and 255) / 255f; out[1] = ((h shr 8) and 255) / 255f; out[2] = (h and 255) / 255f }
    private val tmp = FloatArray(3)

    private fun draw(sc: Scene) {
        hex3(sc.fogHex, tmp)
        GLES30.glClearColor(tmp[0], tmp[1], tmp[2], 1f)
        GLES30.glDepthMask(true)
        GLES30.glClear(GLES30.GL_COLOR_BUFFER_BIT or GLES30.GL_DEPTH_BUFFER_BIT)

        sc.root.updateWorld(null)
        M4.perspective(proj, sc.fov, aspect, 0.2f, 600f)
        M4.lookAt(view, sc.camPos.x, sc.camPos.y, sc.camPos.z, sc.camTarget.x, sc.camTarget.y, sc.camTarget.z)
        M4.mul(vp, proj, view)
        curFov = sc.fov

        GLES30.glUseProgram(prog)
        GLES30.glUniform3f(uCam, sc.camPos.x, sc.camPos.y, sc.camPos.z)
        GLES30.glUniformMatrix4fv(uVP, 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(uView, 1, false, view, 0)
        val L = sc.light
        hex3(L.sky[0], tmp); GLES30.glUniform3f(uSky, tmp[0], tmp[1], tmp[2])
        hex3(L.sky[1], tmp); GLES30.glUniform3f(uGnd, tmp[0], tmp[1], tmp[2])
        hex3(L.sun, tmp); GLES30.glUniform3f(uSunC, tmp[0], tmp[1], tmp[2])
        val d = L.sunDir; val dl = Math.sqrt((d[0] * d[0] + d[1] * d[1] + d[2] * d[2]).toDouble()).toFloat()
        GLES30.glUniform3f(uSunD, d[0] / dl, d[1] / dl, d[2] / dl)
        GLES30.glUniform1f(uHemiI, L.hemiI)
        GLES30.glUniform1f(uSunI, L.sunI)
        hex3(sc.fogHex, tmp); GLES30.glUniform3f(uFogC, tmp[0], tmp[1], tmp[2])
        GLES30.glUniform1f(uFogD, sc.fogDensity)

        opaque.clear(); blend.clear(); addv.clear()
        collect(sc.root, sc.camPos)
        val ex = sc.camPos
        for (n in blend) n.sortKey = (n.world[12] - ex.x).let { it * it } + (n.world[13] - ex.y).let { it * it } + (n.world[14] - ex.z).let { it * it }
        if (blend.size > 1) blend.sortByDescending { it.sortKey }

        // 1) trời (vẽ đầu tiên, không ghi depth)
        GLES30.glDisable(GLES30.GL_BLEND)
        GLES30.glDisable(GLES30.GL_DEPTH_TEST); GLES30.glDepthMask(false); GLES30.glDisable(GLES30.GL_CULL_FACE)
        for (n in opaque) if (n.mat!!.type == MatType.SKY) drawNode(n, false)
        GLES30.glEnable(GLES30.GL_DEPTH_TEST); GLES30.glDepthMask(true)
        // 2) viền đen (inverted hull) — tắt ở mức THẤP — rồi vật đục
        if (tier.outline) {
            for (n in opaque) {
                if (n.outline && n.mat!!.type != MatType.SKY) { cull(front = true); drawNode(n, outlinePass = true) }
            }
        }
        for (n in opaque) {
            val m = n.mat!!
            if (m.type == MatType.SKY) continue
            cull(front = false, off = m.doubleSided); drawNode(n, false)
        }
        // 3) trong suốt thường
        GLES30.glEnable(GLES30.GL_BLEND)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE_MINUS_SRC_ALPHA)
        for (n in blend) { val m = n.mat!!; cull(false, m.doubleSided); GLES30.glDepthMask(m.depthWrite); drawNode(n, false) }
        // 4) cộng sáng (additive)
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE)
        GLES30.glDepthMask(false)
        for (n in addv) { cull(false, true); drawNode(n, false) }
        drawParticles()
        GLES30.glDepthMask(true)
        GLES30.glDisable(GLES30.GL_BLEND)
    }

    private fun initParticles() {
        pProg = link(PVS, PFS)
        puVP = GLES30.glGetUniformLocation(pProg, "uVP"); puView = GLES30.glGetUniformLocation(pProg, "uView"); puScale = GLES30.glGetUniformLocation(pProg, "uScale")
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); pVao = ids[0]
        GLES30.glBindVertexArray(pVao)
        GLES30.glGenBuffers(1, ids, 0); pVbo = ids[0]
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pVbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, Particles.NP * 32, null, GLES30.GL_DYNAMIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 32, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 1, GLES30.GL_FLOAT, false, 32, 12)
        GLES30.glEnableVertexAttribArray(2); GLES30.glVertexAttribPointer(2, 3, GLES30.GL_FLOAT, false, 32, 16)
        GLES30.glEnableVertexAttribArray(3); GLES30.glVertexAttribPointer(3, 1, GLES30.GL_FLOAT, false, 32, 28)
        GLES30.glBindVertexArray(0)
    }

    private fun drawParticles() {
        if (pProg == 0) return
        pBuf.clear(); pBuf.put(Particles.data); pBuf.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, pVbo)
        GLES30.glBufferSubData(GLES30.GL_ARRAY_BUFFER, 0, Particles.NP * 32, pBuf)
        GLES30.glUseProgram(pProg)
        GLES30.glUniformMatrix4fv(puVP, 1, false, vp, 0)
        GLES30.glUniformMatrix4fv(puView, 1, false, view, 0)
        GLES30.glUniform1f(puScale, vh / (2f * Math.tan(Math.toRadians(curFov.toDouble()) / 2.0).toFloat()))
        GLES30.glBlendFunc(GLES30.GL_SRC_ALPHA, GLES30.GL_ONE)
        GLES30.glDisable(GLES30.GL_CULL_FACE)
        GLES30.glBindVertexArray(pVao)
        GLES30.glDrawArrays(GLES30.GL_POINTS, 0, Particles.NP)
        GLES30.glBindVertexArray(0)
        GLES30.glUseProgram(prog)
    }

    private fun cull(front: Boolean, off: Boolean = false) {
        if (off) { GLES30.glDisable(GLES30.GL_CULL_FACE); return }
        GLES30.glEnable(GLES30.GL_CULL_FACE)
        GLES30.glCullFace(if (front) GLES30.GL_FRONT else GLES30.GL_BACK)
    }

    private fun collect(n: Node, cam: Vec3) {
        if (!n.visible) return
        val g = n.geo; val m = n.mat
        if (g != null && m != null) {
            var ok = true
            if (!n.noCull && drawD2 != Float.MAX_VALUE) {
                val dx = n.world[12] - cam.x; val dz = n.world[14] - cam.z
                if (dx * dx + dz * dz > drawD2) ok = false
            }
            if (ok) { if (m.additive) addv.add(n) else if (m.transparent) blend.add(n) else opaque.add(n) }
        }
        for (c in n.children) collect(c, cam)
    }

    private fun drawNode(n: Node, outlinePass: Boolean) {
        val g = n.geo!!; val m = n.mat!!
        upload(g)
        GLES30.glUniformMatrix4fv(uModel, 1, false, n.world, 0)
        M4.normalMat(nm, n.world)
        GLES30.glUniformMatrix3fv(uNM, 1, false, nm, 0)
        GLES30.glUniform1f(uOutline, if (outlinePass) 0.028f else 0f)
        val mode = when (m.type) { MatType.TOON -> 0; MatType.BASIC -> 1; MatType.LAMBERT -> 2; MatType.SKY -> 3; MatType.AURA -> 4 }
        if (mode == 4) { GLES30.glUniform1f(uT, m.t); GLES30.glUniform1f(uI, m.inten); GLES30.glUniform1f(uAA, m.aa) }
        GLES30.glUniform1i(uMode, mode)
        GLES30.glUniform3f(uCol, m.c[0], m.c[1], m.c[2])
        GLES30.glUniform3f(uEmi, m.e[0], m.e[1], m.e[2])
        GLES30.glUniform1f(uOpa, m.opacity)
        GLES30.glUniform1f(uUseFog, if (m.fog && !m.additive) 1f else 0f)
        GLES30.glBindVertexArray(g.vao)
        GLES30.glDrawElements(GLES30.GL_TRIANGLES, g.indexCount, GLES30.GL_UNSIGNED_SHORT, 0)
        GLES30.glBindVertexArray(0)
    }

    private fun upload(g: Geometry) {
        if (g.vao != 0) return
        val ids = IntArray(1)
        GLES30.glGenVertexArrays(1, ids, 0); g.vao = ids[0]
        GLES30.glBindVertexArray(g.vao)
        GLES30.glGenBuffers(1, ids, 0); g.vbo = ids[0]
        val vb = ByteBuffer.allocateDirect(g.verts.size * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().put(g.verts)
        vb.position(0)
        GLES30.glBindBuffer(GLES30.GL_ARRAY_BUFFER, g.vbo)
        GLES30.glBufferData(GLES30.GL_ARRAY_BUFFER, g.verts.size * 4, vb, GLES30.GL_STATIC_DRAW)
        GLES30.glEnableVertexAttribArray(0); GLES30.glVertexAttribPointer(0, 3, GLES30.GL_FLOAT, false, 24, 0)
        GLES30.glEnableVertexAttribArray(1); GLES30.glVertexAttribPointer(1, 3, GLES30.GL_FLOAT, false, 24, 12)
        GLES30.glGenBuffers(1, ids, 0); g.ibo = ids[0]
        val ib = ByteBuffer.allocateDirect(g.indices.size * 2).order(ByteOrder.nativeOrder()).asShortBuffer().put(g.indices)
        ib.position(0)
        GLES30.glBindBuffer(GLES30.GL_ELEMENT_ARRAY_BUFFER, g.ibo)
        GLES30.glBufferData(GLES30.GL_ELEMENT_ARRAY_BUFFER, g.indices.size * 2, ib, GLES30.GL_STATIC_DRAW)
        GLES30.glBindVertexArray(0)
    }

    private fun link(vs: String, fs: String): Int {
        fun sh(t: Int, src: String): Int {
            val s = GLES30.glCreateShader(t)
            GLES30.glShaderSource(s, src); GLES30.glCompileShader(s)
            val ok = IntArray(1); GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) { val l = GLES30.glGetShaderInfoLog(s); android.util.Log.e("NenArena", "Shader loi: $l"); throw RuntimeException("Shader lỗi: $l") }
            return s
        }
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, sh(GLES30.GL_VERTEX_SHADER, vs))
        GLES30.glAttachShader(p, sh(GLES30.GL_FRAGMENT_SHADER, fs))
        GLES30.glLinkProgram(p)
        val ok = IntArray(1); GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) { val l = GLES30.glGetProgramInfoLog(p); android.util.Log.e("NenArena", "Link loi: $l"); throw RuntimeException("Link lỗi: $l") }
        return p
    }

    companion object { private const val MIN_DYN = 0.5f }
}
