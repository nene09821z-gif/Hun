package com.nenarena.game.game

import com.nenarena.game.engine.*
import kotlin.math.*

private fun cyl(a: Float, b: Float, h: Float, s: Int = 10) = Geometry.cylinder(a, b, h, s)
private fun sph(r: Float, w: Int = 14, h: Int = 10) = Geometry.sphere(r, w, h)
private fun box(x: Float, y: Float, z: Float) = Geometry.box(x, y, z)
private fun cone(r: Float, h: Float, s: Int = 8) = Geometry.cone(r, h, s)
private fun caps(r: Float, l: Float) = Geometry.capsule(r, l, 4, 10)

/** Kiến lính / cận vệ (buildAnt). */
fun buildAnt(sc: Float, shellC: Int, accC: Int, armored: Boolean): Built {
    val g = Node(); val mats = ArrayList<Material>()
    fun mt(c: Int): Material { val m = toon(c); mats.add(m); return m }
    val shell = mt(shellC); val acc = mt(accC); val eye = basic(0xff2a2a)
    val body = Node(); g.add(body)
    mk(caps(.28f, .5f), shell, body, 0f, 1.05f, 0f, rx = .4f)
    mk(sph(.34f, 10, 8), acc, body, 0f, .85f, -.55f, sy = 1.1f, sz = 1.5f)
    if (armored) {
        mk(Geometry.sphere(.5f, 10, 8, 0f, TAU, 0f, PIF / 2), acc, body, 0f, 1.25f, -.15f, rx = .4f, sz = 1.2f)
        mk(cone(.12f, .55f, 6), acc, body, 0f, 1.95f, .55f, rx = .6f)
    }
    val head = Node(); head.pos.set(0f, 1.6f, .35f); body.add(head)
    mk(sph(.26f, 10, 8), shell, head, 0f, 0f, 0f, sz = 1.2f)
    for (s in floatArrayOf(-1f, 1f)) {
        mk(sph(.06f, 6, 6), eye, head, s * .13f, .06f, .22f, outline = false)
        mk(cone(.05f, .3f, 5), acc, head, s * .1f, -.14f, .34f, rx = PIF / 2, rz = s * .5f, outline = false)
        mk(cyl(.012f, .012f, .55f, 4), acc, head, s * .1f, .3f, .12f, rx = -.5f, rz = s * -.2f, outline = false)
    }
    val arms = ArrayList<Node>()
    for (s in floatArrayOf(-1f, 1f)) {
        val a = Node(); a.pos.set(s * .32f, 1.3f, .15f); body.add(a)
        mk(cyl(.06f, .05f, .55f, 6), shell, a, 0f, -.28f, 0f)
        mk(cone(.07f, .3f, 5), acc, a, 0f, -.65f, .05f, rx = PIF, outline = false)
        arms.add(a)
    }
    val legs = ArrayList<Node>()
    for (s in floatArrayOf(-1f, 1f)) {
        val l = Node(); l.pos.set(s * .16f, .75f, 0f); body.add(l)
        mk(cyl(.08f, .05f, .8f, 6), shell, l, 0f, -.4f, 0f)
        mk(box(.12f, .06f, .22f), acc, l, 0f, -.8f, .06f, outline = false)
        legs.add(l)
    }
    g.setScale(sc)
    return Built(g, mats, null, Parts(arms[0], arms[1], legs[0], legs[1], body, head, null))
}

/** Kiến Cánh bay, bắn đạn độc (buildFlier). */
fun buildFlier(): Built {
    val g = Node(); val mats = ArrayList<Material>()
    fun mt(c: Int): Material { val m = toon(c); mats.add(m); return m }
    val shell = mt(0x1c3a30); val acc = mt(0xe8b030)
    val body = Node(); g.add(body)
    mk(caps(.3f, .7f), shell, body, 0f, 1.2f, 0f, rx = PIF / 2 - .3f)
    mk(sph(.28f, 10, 8), acc, body, 0f, 1.1f, -.8f, sz = 1.4f)
    mk(cone(.07f, .5f, 5), acc, body, 0f, .95f, -1.3f, rx = -PIF / 2 - .5f, outline = false)
    val head = Node(); head.pos.set(0f, 1.35f, .65f); body.add(head)
    mk(sph(.25f, 10, 8), shell, head, 0f, 0f, 0f)
    for (s in floatArrayOf(-1f, 1f)) {
        mk(sph(.07f, 6, 6), basic(0xff3030), head, s * .13f, .05f, .17f, outline = false)
        mk(cone(.04f, .3f, 5), acc, head, s * .08f, -.14f, .26f, rx = PIF / 2, outline = false)
    }
    val wm = Material(MatType.BASIC, 0xaaffcc, 0, .45f, depthWrite = false, doubleSided = true)
    val wings = ArrayList<Wing>()
    for (s in floatArrayOf(-1f, 1f)) for (j in 0..1) {
        val w = Node(); w.pos.set(s * .2f, 1.5f, -.1f - j * .35f); body.add(w)
        val p = Node(); p.geo = Geometry.plane(1.3f, .4f).translated(s * .65f, 0f, 0f); p.mat = wm; p.rot.x = -PIF / 2; w.add(p)
        wings.add(Wing(w, s))
    }
    g.setScale(1.1f)
    return Built(g, mats, null, Parts(null, null, null, null, body, head, wings))
}


fun buildPitou(): Built {
    val h = buildHuman(HumanOpts(s = 1.3f, skin = 0xf3e6dc, top = 0x2d58c9, bottom = 0x2d58c9, legLow = 0xe58a2a, shoe = 0x2d58c9, sleeveLong = true))
    val wh = h.mt(0xf6f6ff); val ye = h.mt(0xf0c040)
    h.mkk(Geometry.sphere(.22f, 12, 10, 0f, TAU, 0f, PIF * .65f), wh, h.head, 0f, .15f, -.01f)
    for (i in 0 until 8) { val a = i / 8f * TAU; h.mkk(sph(.1f, 6, 6), wh, h.head, cos(a) * .2f, .1f + sin(a * 2) * .05f, sin(a) * .2f - .03f) }
    for (s in floatArrayOf(-1f, 1f)) {
        h.mkk(cone(.1f, .3f, 4), ye, h.head, s * .14f, .38f, 0f, rz = s * -.3f)
        mk(sph(.04f, 6, 6), basic(0xff2040), h.head, s * .08f, .17f, .178f, sy = .8f, sz = .5f, outline = false)
    }
    val tail = Node(); tail.pos.set(0f, 0f, -.2f); h.hips.add(tail)
    var py = 0f; var pz = 0f; val segs = ArrayList<Node>()
    for (i in 0 until 7) { segs.add(h.mkk(sph(.07f, 6, 6), wh, tail, 0f, py, pz)); py += .05f; pz -= .13f }
    h.extra = { _, t, _ -> for ((i, s) in segs.withIndex()) s.pos.x = sin(t * 4 + i * .6f) * .07f * i }
    return Built(h.root, h.mats, h, null, h.hover)
}

fun buildPouf(): Built {
    val h = buildHuman(HumanOpts(s = 1.2f, skin = 0xe8dfe9, top = 0x6a4ab0, bottom = 0xd8d0e8, shoe = 0x3a2a60, sleeveLong = false))
    val hair = h.mt(0xe4d8f8)
    h.mkk(Geometry.sphere(.22f, 12, 10, 0f, TAU, 0f, PIF * .65f), hair, h.head, 0f, .15f, -.01f)
    h.mkk(cyl(.2f, .08f, .9f, 8), hair, h.head, 0f, -.45f, -.12f)
    for (s in floatArrayOf(-1f, 1f)) {
        mk(sph(.04f, 6, 6), basic(0x30e0d0), h.head, s * .08f, .17f, .178f, sy = .8f, sz = .5f, outline = false)
        mk(cyl(.01f, .01f, .6f, 4), basic(0xffffff), h.head, s * .07f, .55f, .05f, rz = s * -.3f, rx = -.2f, outline = false)
    }
    val outer = Material(MatType.BASIC, 0x825aff, 0, .55f, depthWrite = false, doubleSided = true)
    val inner = Material(MatType.BASIC, 0x28dcc8, 0, .5f, depthWrite = false, doubleSided = true)
    class W(val wg: Node, val s: Float)
    val wl = ArrayList<W>()
    for (s in floatArrayOf(-1f, 1f)) for (j in 0..1) {
        val wg = Node(); wg.pos.set(0f, .5f, -.2f)
        val p = Node(); p.geo = Geometry.plane(1.9f, 2.6f).translated(.95f * s, if (j == 1) -.6f else .3f, 0f); p.mat = outer; wg.add(p)
        val q = Node(); q.geo = Geometry.plane(1.1f, 1.5f).translated(.7f * s, if (j == 1) -.6f else .3f, .01f); q.mat = inner; wg.add(q)
        h.torso.add(wg); wl.add(W(wg, s))
    }
    h.extra = { _, t, _ -> val f = sin(t * 6) * .3f; for (w in wl) w.wg.rot.y = w.s * (.5f + f) }
    h.hover = 1.3f
    return Built(h.root, h.mats, h, null, h.hover)
}

fun buildYoupi(): Built {
    val h = buildHuman(HumanOpts(s = 1.35f, w = 1.55f, skin = 0x6d7a82, top = 0x4a565e, bottom = 0x2a3238, shoe = 0x151a1e))
    val hair = h.mt(0x161c22)
    h.mkk(Geometry.sphere(.22f, 12, 10, 0f, TAU, 0f, PIF * .6f), hair, h.head, 0f, .15f, -.02f, rx = -.3f)
    for (i in 0 until 9) { val a = (i - 4) * .28f; h.mkk(cone(.07f, .5f, 5), hair, h.head, sin(a) * .2f, .2f, -.1f - cos(a) * .1f, rx = -1.1f, rz = -a * .6f) }
    for (s in floatArrayOf(-1f, 1f)) {
        mk(sph(.045f, 6, 6), basic(0xffe030), h.head, s * .08f, .17f, .178f, sy = .7f, sz = .5f, outline = false)
        h.mkk(cone(.05f, .25f, 5), h.mt(0x161c22), h.head, s * .14f, 0f, .14f, rx = PIF / 2, rz = s * .5f)
    }
    val wm = Material(MatType.BASIC, 0x9ad0ff, 0, .35f, depthWrite = false, doubleSided = true)
    for (s in floatArrayOf(-1f, 1f)) {
        val p = Node(); p.geo = Geometry.plane(1.4f, 2f).translated(.7f * s, .2f, 0f); p.mat = wm
        p.pos.set(0f, .5f, -.25f); p.rot.y = s * .6f; h.torso.add(p)
    }
    return Built(h.root, h.mats, h, null, h.hover)
}

val ET: Map<String, EtCfg> = mapOf(
    "soldier" to EtCfg("Kiến Lính", hp = 40f, spd = 5.4f, dmg = 8f, range = 1.7f, cd = 1.1f, r = .7f, score = 10, barY = 2.5f, build = { buildAnt(1f, 0x5a2a1c, 0xd0782e, false) }),
    "brute" to EtCfg("Kiến Cận Vệ", hp = 170f, spd = 3.2f, dmg = 20f, range = 2.7f, cd = 1.9f, r = 1.3f, score = 40, barY = 4.2f, kbMul = .35f, build = { buildAnt(1.7f, 0x262c4a, 0x9aa0b8, true) }),
    "flier" to EtCfg("Kiến Cánh", hp = 55f, spd = 4.2f, dmg = 9f, range = 13f, cd = 2.4f, r = .8f, score = 25, barY = 3.5f, fly = true, build = ::buildFlier),
    "pitou" to EtCfg("NEFERPITOU", "Hộ Vệ Hoàng Gia · Terpsichora", hp = 900f, spd = 7.2f, dmg = 22f, cd = 1.3f, r = 1.1f, score = 500, boss = true, human = true,
        moves = listOf("dash", "spin", "dash", "volley"), build = ::buildPitou),
    "pouf" to EtCfg("SHAIAPOUF", "Hộ Vệ Hoàng Gia · Beelzebub", hp = 1100f, spd = 4.6f, dmg = 14f, cd = 1.6f, r = 1.1f, score = 600, boss = true, human = true,
        moves = listOf("volley", "summon", "volley", "spin"), build = ::buildPouf),
    "youpi" to EtCfg("MENTHUTHUYOUPI", "Hộ Vệ Hoàng Gia · Thể Chất Tối Thượng", hp = 1500f, spd = 5.2f, dmg = 30f, cd = 1.5f, r = 1.6f, score = 800, boss = true, human = true,
        moves = listOf("slam", "dash", "slam", "volley"), build = ::buildYoupi)
)
