package com.nenarena.game.game

import com.nenarena.game.engine.*

/** Tuỳ chọn khi gây sát thương (o trong hurtE bản HTML). */
class Hit(
    var col: Int? = null, val knock: Float = 0f, val stun: Float = 0f, var big: Boolean = false, val hs: Float = 0f,
    val from: Vec3? = null, val src: String? = null, val noCrit: Boolean = false, val gain: Float? = null
)

class Skill(val n: String, val g: String, val lb: String, val cd: Float, val d: String)

class CharCfg(
    val id: String, val name: String, val short: String, var nen: String,
    val col: Int, val col2: Int,
    var hp: Float, val spd: Float, var dmg: Float = 1f, val nenGain: Float = 1f, val def: Float = 1f, val crit: Float = 0f,
    val desc: String, var passive: String, var stats: IntArray, val skills: List<Skill>,
    val build: () -> Human,
    val atk: () -> Unit, val s1: () -> Boolean, val s2: () -> Boolean, val ult: () -> Boolean
)

class Lunge(val dir: Vec3, val speed: Float, var t: Float, val dash: Boolean = false, val fly: Boolean = false,
            val path: ((Enemy) -> Unit)? = null, val end: (() -> Unit)? = null)

class Decoy(val pos: Vec3, val node: Node, var life: Float)

class Player(val cfg: CharCfg, val h: Human) {
    val pos = Vec3(0f, 0f, 8f); var face = PIF
    var hp = cfg.hp; var maxHp = cfg.hp; var nen = 0f
    val cd = FloatArray(3); val cdMax = floatArrayOf(0f, cfg.skills[1].cd, cfg.skills[2].cd)
    var atkCd = 0f; var combo = 0; var cast = 0f; var inv = 1.2f; var dashCd = 0f
    val kb = Vec3(); var lunge: Lunge? = null
    var stealth = 0f; var decoy: Decoy? = null
    var critN = 0; var dmgBuff = 0f; var dmgBuffT = 0f; var speedBuf = 0f; var auraBoost = 0f
    var dead = false; var y = 0f; var assassin = 0f
    var zb = false
}

class Pull(val from: Vec3, val to: Vec3, var t: Float, val d: Float)
class BossAct(val m: String, var tele: Float) {
    var t = 0f; var fired = false; var dir: Vec3? = null; var c: Vec3? = null; var dt = 0f; var hit = false
}

class Wing(val w: Node, val s: Float)
class Parts(val armL: Node?, val armR: Node?, val legL: Node?, val legR: Node?, val body: Node?, val head: Node?, val wings: List<Wing>?)
class Built(val g: Node, val mats: List<Material>, val h: Human?, val parts: Parts?, val hover: Float = 0f)

class EtCfg(
    val name: String, val sub: String = "", val hp: Float, val spd: Float, val dmg: Float, val range: Float = 0f, val cd: Float,
    val r: Float, val score: Int, val barY: Float = 0f, val kbMul: Float = 1f, val fly: Boolean = false,
    val boss: Boolean = false, val human: Boolean = false, val moves: List<String> = emptyList(),
    val build: () -> Built
)

class Enemy(val type: String, val cfg: EtCfg, val b: Built, hpv: Float, dmgv: Float) {
    val g = b.g; val h = b.h; val mats = b.mats; val parts = b.parts
    val pos get() = g.pos
    val kb = Vec3()
    var hp = hpv; var maxHp = hpv; val r = cfg.r; val dmg = dmgv
    var team = 'e'; var dead = false; var deadT = 0f; var spawnT = .7f; var flash = 0f; var stun = 0f
    var st = "chase"; var stT = 0f; var cdT = rnd(.3f, 1f); var ct = 1.2f; var mi = 0
    var act: BossAct? = null; var barT = 0f; var phase = rnd(0f, 6f); var slow = 1f; var face = 0f
    var sc = g.scl.x; var pull: Pull? = null; var hover = b.hover; var mv = 0f
    var puppetT = 0f; var needle: Node? = null
    var bg: Node? = null; var fg: Node? = null
}

class Proj(val node: Node, val pos: Vec3, val vel: Vec3, val dmg: Float, val r: Float, var life: Float, val team: Char,
           var pierce: Int, val col: Int, val homing: Float, val onHit: ((Enemy) -> Unit)?, val spin: Float, val knock: Float, val stun: Float,
           val trail: Boolean) {
    val hit = HashSet<Enemy>()
}

class Zone(val x: Float, val z: Float, val r: Float, var t: Float) { var tick = 0f }
class Timer(var t: Float, val fn: () -> Unit)

/** Số sát thương bay (toạ độ chuẩn hoá màn hình 0..1). */
class Dn(val id: Int, val x: Float, val y: Float, val t: String, val c: Int, val big: Boolean, val born: Long)
