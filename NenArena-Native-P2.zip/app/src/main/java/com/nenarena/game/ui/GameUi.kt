package com.nenarena.game.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nenarena.game.game.CharCfg
import com.nenarena.game.game.Game
import com.nenarena.game.game.Hud
import com.nenarena.game.game.HudSnap
import com.nenarena.game.game.Input
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

private fun col(hex: Int) = Color(0xFF000000.toInt() or hex)
private val PINK = Color(0xFFFF3FA0)
private val PINK2 = Color(0xFFFFB0DD)
private val PANEL = Color(0xE60E0818)

@Composable
private fun T(s: String, size: Int, color: Color = Color.White, bold: Boolean = false, modifier: Modifier = Modifier, align: TextAlign = TextAlign.Start, spacing: Float = 0f) {
    BasicText(
        s, modifier,
        style = TextStyle(
            color = color, fontSize = size.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, textAlign = align,
            letterSpacing = spacing.sp, shadow = Shadow(Color(0xCC000000), Offset(2f, 2f), 4f)
        )
    )
}

/** Nút/vùng nhận chạm theo kiểu "nhấn - nhả", tách biệt từng ngón (đa điểm chạm). */
private fun Modifier.press(onDown: () -> Unit, onUp: () -> Unit = {}): Modifier = pointerInput(Unit) {
    awaitEachGesture {
        val d = awaitFirstDown(requireUnconsumed = false)
        d.consume(); onDown()
        waitForUpOrCancellation()
        onUp()
    }
}

private fun post(fn: (Game) -> Unit) { val g = Hud.gameRef ?: return; Input.post { fn(g) } }

@Composable
fun GameRoot(qualityLabel: String, onQuality: () -> Unit) {
    var snap by remember { mutableStateOf(Hud.snap) }
    val now = remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            androidx.compose.runtime.withFrameNanos { now.value = System.currentTimeMillis() }
            val s = Hud.snap; if (s !== snap) snap = s
        }
    }
    Box(Modifier.fillMaxSize()) {
        when (snap.screen) {
            "title" -> TitleScreen(snap, qualityLabel, onQuality)
            "select" -> SelectScreen(snap)
            "play", "pause", "over" -> {
                PlayHud(snap, now, snap.screen == "play")
                if (snap.screen == "pause") PauseOverlay(qualityLabel, onQuality)
                if (snap.screen == "over") OverOverlay(snap)
            }
        }
    }
}

// ============================ MÀN HÌNH CHÍNH ============================
@Composable
private fun TitleScreen(s: HudSnap, qLabel: String, onQuality: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color(0xDD0A0414), Color(0x00000000))))) {
        Column(Modifier.align(Alignment.CenterStart).padding(start = 48.dp)) {
            T("HUNTER × HUNTER · FAN GAME", 11, PINK2, spacing = 3f)
            Spacer(Modifier.height(6.dp))
            T("NEN", 56, Color.White, true, spacing = 6f)
            T("ARENA", 56, PINK, true, spacing = 6f)
            Spacer(Modifier.height(4.dp))
            T("ĐẠI CHIẾN KIẾN CHIMERA", 12, Color(0xFFFFC8E0), spacing = 4f)
            Spacer(Modifier.height(22.dp))
            Box(
                Modifier.clip(RoundedCornerShape(30.dp)).background(Brush.horizontalGradient(listOf(Color(0xFFFF3FA0), Color(0xFFB02A78))))
                    .clickable { post { it.gotoSelect() } }.padding(horizontal = 44.dp, vertical = 13.dp)
            ) { T("BẮT ĐẦU", 17, Color.White, true, spacing = 3f) }
        }
        T("Đồ hoạ: $qLabel (chạm để đổi)", 11, PINK2, modifier = Modifier.align(Alignment.BottomStart).padding(16.dp).clickable { onQuality() })
    }
}

// ============================ CHỌN NHÂN VẬT ============================
@Composable
private fun SelectScreen(s: HudSnap) {
    val chars = Hud.chars; if (chars.isEmpty()) return
    val c: CharCfg = chars[s.selIdx.coerceIn(0, chars.size - 1)]
    val cc = col(c.col)
    Box(Modifier.fillMaxSize()) {
        Column(
            Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(.5f).background(PANEL)
                .padding(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 66.dp)
        ) {
            Column(Modifier.weight(1f, fill = true).verticalScroll(rememberScrollState())) {
                T(c.name, 22, cc, true, spacing = 1f)
                T("Hệ Nen: ${c.nen}", 11, Color(0xFFFFC8E0))
                Spacer(Modifier.height(6.dp))
                T(c.desc, 12, Color(0xFFE8DDF0))
                Spacer(Modifier.height(5.dp))
                T(c.passive, 11, col(c.col2), true)
                Spacer(Modifier.height(8.dp))
                val names = listOf("Sát thương", "Tốc độ", "Độ bền", "Kỹ năng")
                for (i in 0 until 4) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        T(names[i], 11, Color(0xFFBBAACC), modifier = Modifier.width(78.dp))
                        Box(Modifier.weight(1f).height(7.dp).clip(RoundedCornerShape(4.dp)).background(Color(0x33FFFFFF))) {
                            Box(Modifier.fillMaxHeight().fillMaxWidth(c.stats[i] / 5f).background(Brush.horizontalGradient(listOf(cc, col(c.col2)))))
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
                val lab = listOf("Đánh thường", "Chiêu 1", "Chiêu 2", "TUYỆT KỸ")
                for ((i, k) in c.skills.withIndex()) {
                    Row(Modifier.padding(vertical = 4.dp), verticalAlignment = Alignment.Top) {
                        Box(Modifier.size(34.dp).clip(CircleShape).background(cc.copy(alpha = .25f)).border(1.dp, cc, CircleShape), contentAlignment = Alignment.Center) { T(k.g, 16) }
                        Spacer(Modifier.width(8.dp))
                        Column {
                            T("${lab[i]}: ${k.n}", 12, Color.White, true)
                            T(k.d, 10, Color(0xFFCDBFD8))
                        }
                    }
                }
            }
        }
        // thanh chọn nhân vật + nút
        Column(Modifier.align(Alignment.BottomStart).fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0x00000000), Color(0xCC0A0414))))) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0x55FFFFFF)).clickable { post { it.gotoTitle() } }.padding(horizontal = 14.dp, vertical = 8.dp)) { T("‹ VỀ", 12, Color.White, true) }
                for ((i, ch) in chars.withIndex()) {
                    val on = i == s.selIdx; val k = col(ch.col)
                    Row(
                        Modifier.clip(RoundedCornerShape(20.dp)).background(if (on) k.copy(alpha = .35f) else Color(0x66000000))
                            .border(if (on) 2.dp else 1.dp, if (on) k else Color(0x44FFFFFF), RoundedCornerShape(20.dp))
                            .clickable { post { it.pickChar(i) } }.padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) { T(ch.short, 14, k, true); Spacer(Modifier.width(6.dp)); T(ch.name.split(" ")[0], 12, Color.White, on) }
                }
                Box(
                    Modifier.clip(RoundedCornerShape(24.dp)).background(Brush.horizontalGradient(listOf(cc, Color(0xFFB02A78))))
                        .clickable { val id = c.id; post { it.startGame(id) } }.padding(horizontal = 22.dp, vertical = 9.dp)
                ) { T("CHỌN & CHIẾN ĐẤU", 13, Color.White, true, spacing = 1f) }
            }
        }
    }
}

// ============================ HUD TRONG TRẬN ============================
@Composable
private fun Bar(frac: Float, c1: Color, c2: Color, h: Dp, modifier: Modifier = Modifier) {
    val sh = RoundedCornerShape(h)
    Box(modifier.height(h).clip(sh).background(Color(0x99000000)).border(1.dp, Color(0x44FFFFFF), sh)) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(frac.coerceIn(0f, 1f)).background(Brush.horizontalGradient(listOf(c1, c2))))
    }
}

@Composable
private fun SkillBtn(
    size: Dp, glyph: String, label: String, cd: Float, cdTxt: String, accent: Color, now: State<Long>,
    pulse: Boolean, modifier: Modifier, onDown: () -> Unit, onUp: () -> Unit = {}
) {
    val glow = if (pulse) .55f + .45f * sin(now.value / 130.0).toFloat() else 0f
    Box(
        modifier.size(size).clip(CircleShape)
            .background(Brush.radialGradient(listOf(accent.copy(alpha = .55f + glow * .3f), Color(0xDD12081C))))
            .border(if (pulse) 3.dp else 2.dp, if (pulse) Color.White.copy(alpha = .6f + glow * .4f) else accent, CircleShape)
            .press(onDown, onUp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            T(glyph, (size.value * .36f).toInt(), Color.White)
            T(label, 9, Color(0xFFFFE0F0), true)
        }
        if (cd > 0f) Canvas(Modifier.fillMaxSize()) { drawArc(Color(0xB0000000), -90f, 360f * cd, true) }
        if (cdTxt.isNotEmpty()) T(cdTxt, (size.value * .34f).toInt(), Color.White, true)
    }
}

@Composable
private fun PlayHud(s: HudSnap, now: State<Long>, live: Boolean) {
    val accent = col(s.col); val acc2 = col(s.col2)
    Box(Modifier.fillMaxSize()) {
        if (live) {
            CameraZone(Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(.5f))
            Joystick(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(.5f), accent, acc2)
        }
        Effects(s, now)
        DamageNumbers(s, now)
        // trên-trái: chân dung + thanh máu/Nen
        Row(Modifier.align(Alignment.TopStart).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(46.dp).clip(CircleShape).background(Brush.radialGradient(listOf(accent.copy(alpha = .6f), Color(0xDD12081C)))).border(2.dp, accent, CircleShape), contentAlignment = Alignment.Center) { T(s.avatar, 22, Color.White, true) }
            Spacer(Modifier.width(8.dp))
            Column {
                Bar(s.hp, Color(0xFFFF4060), Color(0xFFFF9A6A), 12.dp, Modifier.width(190.dp))
                Spacer(Modifier.height(3.dp))
                Bar(s.nen, Color(0xFF6B4BFF), Color(0xFFB89CFF), 7.dp, Modifier.width(160.dp))
                T(s.hpTxt, 10, Color(0xFFFFD0DC))
            }
        }
        // trên-giữa: đợt + thanh boss
        Column(Modifier.align(Alignment.TopCenter).padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            T("ĐỢT ${s.wave}", 15, Color.White, true, spacing = 3f)
            if (s.bossFrac >= 0f) {
                Spacer(Modifier.height(3.dp)); T(s.bossName, 12, Color(0xFFFFD27A), true, spacing = 2f)
                Bar(s.bossFrac, Color(0xFFFF8A2A), Color(0xFFFFD27A), 10.dp, Modifier.width(280.dp))
            }
            if (s.combo >= 3) { Spacer(Modifier.height(4.dp)); T("${s.combo} COMBO", 14, Color(0xFFFFE070), true, spacing = 2f) }
        }
        // trên-phải: điểm + tạm dừng
        Row(Modifier.align(Alignment.TopEnd).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(horizontalAlignment = Alignment.End) {
                T("${s.score} đ", 15, Color.White, true)
                T("Hạ ${s.kills}", 11, PINK2)
            }
            if (live) {
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0x88000000)).border(1.dp, Color(0x66FFFFFF), CircleShape).clickable { post { it.pauseGame() } }, contentAlignment = Alignment.Center) { T("II", 13, Color.White, true) }
            }
        }
        if (s.toast.isNotEmpty()) T(s.toast, 13, Color(0xFFFFE9F4), true, Modifier.align(Alignment.TopCenter).padding(top = 84.dp).background(Color(0x77000000), RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 6.dp), TextAlign.Center)
        Banner(s, now)
        if (live) {
            // cụm nút bấm góc phải-dưới
            val sk = s.skills
            Box(Modifier.align(Alignment.BottomEnd).fillMaxHeight(.6f).width(330.dp)) {
                SkillBtn(88.dp, "⚔", sk.getOrNull(0)?.lb ?: "ĐÁNH", 0f, "", accent, now, false, Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 22.dp),
                    { Input.atk = true }, { Input.atk = false })
                SkillBtn(64.dp, sk.getOrNull(1)?.g ?: "1", sk.getOrNull(1)?.lb ?: "1", s.cd1, s.cdN1, accent, now, false, Modifier.align(Alignment.BottomEnd).padding(end = 124.dp, bottom = 30.dp), { Input.pS1 = true })
                SkillBtn(64.dp, sk.getOrNull(2)?.g ?: "2", sk.getOrNull(2)?.lb ?: "2", s.cd2, s.cdN2, accent, now, false, Modifier.align(Alignment.BottomEnd).padding(end = 104.dp, bottom = 104.dp), { Input.pS2 = true })
                SkillBtn(72.dp, sk.getOrNull(3)?.g ?: "★", "ULT", if (s.ultReady) 0f else s.ultFrac, s.ultTxt, acc2, now, s.ultReady, Modifier.align(Alignment.BottomEnd).padding(end = 22.dp, bottom = 124.dp), { Input.pUlt = true })
                SkillBtn(50.dp, "»", "LƯỚT", s.cdDash, s.cdND, Color(0xFF8AD8FF), now, false, Modifier.align(Alignment.BottomEnd).padding(end = 196.dp, bottom = 18.dp), { Input.pDash = true })
            }
        }
    }
}

@Composable
private fun Joystick(modifier: Modifier, accent: Color, acc2: Color) {
    var origin by remember { mutableStateOf<Offset?>(null) }
    var knob by remember { mutableStateOf(Offset.Zero) }
    val radius = 150f
    Box(modifier.pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { p -> origin = p; knob = p },
            onDragEnd = { origin = null; Input.mx = 0f; Input.my = 0f },
            onDragCancel = { origin = null; Input.mx = 0f; Input.my = 0f },
            onDrag = { change, _ ->
                val o = origin ?: change.position
                val dx = change.position.x - o.x; val dy = change.position.y - o.y
                val d = hypot(dx, dy); val k = if (d > 0f) min(d, radius) / d else 0f
                knob = Offset(o.x + dx * k, o.y + dy * k)
                Input.mx = dx * k / radius; Input.my = dy * k / radius
                change.consume()
            }
        )
    }) {
        val o = origin
        if (o != null) Canvas(Modifier.fillMaxSize()) {
            drawCircle(accent.copy(alpha = .3f), radius, o)
            drawCircle(acc2.copy(alpha = .7f), 46f, knob)
        }
    }
}

@Composable
private fun CameraZone(modifier: Modifier) {
    Box(modifier.pointerInput(Unit) {
        detectDragGestures { change, drag -> Input.camDX += drag.x; Input.camDY += drag.y; change.consume() }
    })
}

// ============================ HIỆU ỨNG MÀN HÌNH ============================
@Composable
private fun Effects(s: HudSnap, now: State<Long>) {
    var flashBorn by remember { mutableLongStateOf(0L) }
    var hurtBorn by remember { mutableLongStateOf(0L) }
    var speedBorn by remember { mutableLongStateOf(0L) }
    LaunchedEffect(s.flashId) { if (s.flashId > 0) flashBorn = System.currentTimeMillis() }
    LaunchedEffect(s.hurtId) { if (s.hurtId > 0) hurtBorn = System.currentTimeMillis() }
    LaunchedEffect(s.speedId) { if (s.speedId > 0) speedBorn = System.currentTimeMillis() }
    val t = now.value
    val fa = if (flashBorn > 0 && s.flashMs > 0) (1f - (t - flashBorn).toFloat() / s.flashMs).coerceIn(0f, 1f) * s.flashA else 0f
    val ha = if (hurtBorn > 0) (1f - (t - hurtBorn) / 380f).coerceIn(0f, 1f) else 0f
    val sa = if (speedBorn > 0 && s.speedMs > 0) (1f - (t - speedBorn).toFloat() / s.speedMs).coerceIn(0f, 1f) else 0f
    Canvas(Modifier.fillMaxSize()) {
        if (fa > .005f) drawRect(col(s.flashC).copy(alpha = fa))
        if (ha > .005f) drawRect(Brush.radialGradient(listOf(Color.Transparent, Color(0xFFFF2040).copy(alpha = .55f * ha)), center, size.maxDimension * .65f))
        if (sa > .01f) {
            val c = center; val r0 = size.minDimension * .3f; val r1 = size.maxDimension * .75f
            for (i in 0 until 36) {
                val a = (i / 36.0 * 2 * PI + (t % 400) / 400.0 * .6).toFloat(); val rr = r0 + (i * 37 % 100) / 100f * r0
                drawLine(Color.White.copy(alpha = .35f * sa), Offset(c.x + cos(a) * rr, c.y + sin(a) * rr), Offset(c.x + cos(a) * r1, c.y + sin(a) * r1), 2f)
            }
        }
    }
}

@Composable
private fun DamageNumbers(s: HudSnap, now: State<Long>) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val t = now.value
        for (d in s.dns) {
            val k = ((t - d.born) / 820f).coerceIn(0f, 1f)
            val a = if (k < .6f) 1f else (1f - k) / .4f
            val sc = if (k < .15f) .6f + k * 3f else 1f
            val col = col(d.c)
            T(
                d.t, if (d.big) (26 * sc).toInt() else (18 * sc).toInt(), if (d.big) Color.White else col, true,
                Modifier.offset(x = maxWidth * d.x - 20.dp, y = maxHeight * d.y - (k * 54f).dp - 12.dp).alpha(a)
            )
        }
    }
}

@Composable
private fun Banner(s: HudSnap, now: State<Long>) {
    var born by remember { mutableLongStateOf(0L) }
    LaunchedEffect(s.bannerId) { if (s.bannerId > 0) born = System.currentTimeMillis() }
    val k = ((now.value - born) / 2200f)
    if (born == 0L || k >= 1f || s.banner.isEmpty()) return
    val a = if (k < .15f) k / .15f else if (k > .75f) (1f - k) / .25f else 1f
    Box(Modifier.fillMaxSize().alpha(a), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.offset(y = (-40).dp)) {
            T(s.banner, 32, Color(0xFFFFE9F4), true, spacing = 4f)
            if (s.bannerSub.isNotEmpty()) T(s.bannerSub, 12, PINK2, spacing = 3f)
        }
    }
}

// ============================ TẠM DỪNG / KẾT THÚC ============================
@Composable
private fun Overlay(content: @Composable () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color(0xAA05020C)).pointerInput(Unit) { awaitEachGesture { awaitFirstDown(requireUnconsumed = false).consume() } }, contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun MenuBtn(text: String, primary: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.width(220.dp).clip(RoundedCornerShape(26.dp))
            .background(if (primary) Brush.horizontalGradient(listOf(PINK, Color(0xFFB02A78))) else Brush.horizontalGradient(listOf(Color(0x55FFFFFF), Color(0x33FFFFFF))))
            .clickable { onClick() }.padding(vertical = 11.dp), contentAlignment = Alignment.Center
    ) { T(text, 15, Color.White, true, spacing = 2f) }
}

@Composable
private fun PauseOverlay(qLabel: String, onQuality: () -> Unit) = Overlay {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        T("TẠM DỪNG", 26, Color.White, true, spacing = 5f)
        MenuBtn("TIẾP TỤC", true) { post { it.resumeGame() } }
        MenuBtn("CHỌN NHÂN VẬT", false) { post { it.quitToSelect() } }
        MenuBtn("ĐỒ HOẠ: $qLabel", false) { onQuality() }
    }
}

@Composable
private fun OverOverlay(s: HudSnap) = Overlay {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        T("THẤT BẠI", 28, Color(0xFFFF5A7A), true, spacing = 6f)
        for ((k, v) in s.overStats) Row(Modifier.width(230.dp), horizontalArrangement = Arrangement.SpaceBetween) { T(k, 13, Color(0xFFCDBFD8)); T(v, 14, Color.White, true) }
        Spacer(Modifier.height(4.dp))
        MenuBtn("CHƠI LẠI", true) { post { it.retry() } }
        MenuBtn("CHỌN NHÂN VẬT", false) { post { it.quitToSelect() } }
    }
}
